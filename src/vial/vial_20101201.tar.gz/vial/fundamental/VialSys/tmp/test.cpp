#include <iostream>
#include <iomanip>
test

#if 0
#include <sys/time.h>
#include "Vial.hpp"

const NodeID MACHINE_A = 0xa00;
const NodeID MACHINE_B = 0xa01;

#if 1
const NodeID srcID = MACHINE_A;
const NodeID dstID = MACHINE_B;
#else
const NodeID dstID = MACHINE_A;
const NodeID srcID = MACHINE_B;
#endif


using namespace std;


int getSecInDay()
{
	timeval tv;
	gettimeofday(&tv, NULL);
	return tv.tv_sec;
}


bool incReceiveCount()
{
	static int receiveCount = 0;
	static int lastSec = getSecInDay();

	if (++receiveCount < 1000000)
		return false;

	receiveCount = 0;

	/*
	timeval tv;
	gettimeofday(&tv, NULL);
	cout << "current time, sec=" << tv.tv_sec;
	cout << " usec=" << tv.tv_usec;
	cout << " -----------------------------------------------" << endl;
	*/
	int curSec = getSecInDay();
	cout << "delta time = " << curSec - lastSec << endl;
	lastSec = curSec;

	return true;
}


const int VT_A = 1001;
const int VT_B = 1002;
const int VT_C = 1003;
const int VT_REQ = 1010;
const int VT_ACK = 1011;


struct MyVialA : public Vial
{
	char name[8];
	int x, y;
	MyVialA() { vialType = VT_A; vialLen = sizeof(*this); }
};


struct MyVialB : public Vial
{
	int a, b;
	char name[32];
	int c;
 	MyVialB() { vialType = VT_B; vialLen = sizeof(*this); }
};


struct MyVialC : public Vial
{
	int i;
	char name[16];
	int j;
	MyVialC() { vialType = VT_C; vialLen = sizeof(*this); }
};


struct ReqVial : public Vial
{
	int val;
	ReqVial() { vialType = VT_REQ; vialLen = sizeof(*this); }
};


struct AckVial : public Vial
{
	char str[32];
	AckVial() { vialType = VT_ACK; vialLen = sizeof(*this); }
};


class MyBaseClass
{
	protected:
		VialSystem *vs;
	public:
		MyBaseClass(VialSystem *vs) { this->vs = vs; }
};


class MyClassA : public MyBaseClass, public IVialReceiver
{
	public:
		virtual bool OnReceive(Vial *vial);
	public:
		MyClassA(VialSystem *vs) : MyBaseClass(vs) {}
};


class MyClassB : public MyBaseClass, public IVialReceiver
{
	public:
		virtual bool OnReceive(Vial *vial);
	public:
		MyClassB(VialSystem *vs) : MyBaseClass(vs) {}
};


class MyClassC : public MyBaseClass, public IVialReceiver
{
	public:
		virtual bool OnReceive(Vial *vial);
	public:
		MyClassC(VialSystem *vs) : MyBaseClass(vs) {}
};


bool MyClassA::OnReceive(Vial *vial)
{
	if (vial->vialType == VT_REQ)
	{
		ReqVial *reqVial = (ReqVial *)vial;
		AckVial ackVial;
		sprintf(ackVial.str, "You said %d, I got it.", reqVial->val);
		ackVial.dstID = vial->srcID;
		vs->postReturnVial(&ackVial);
		return true;
	}

	if (vial->vialType != VT_A)
		return false;

	MyVialA *myVial = (MyVialA *)vial;
	cout << "name=" << myVial->name;
	cout << " x=" << myVial->x;
	cout << " y=" << myVial->y;
	cout << endl;

	MyVialB vialB;
	strcpy(vialB.name, "Jeff");
	vialB.a = 1;
	vialB.b = 2;
	vialB.c = 3;

	vialB.dstID = dstID;
	vs->postVial(&vialB);

	/*
	MyVialC vialC;
	strcpy(vialC.name, "someone");
	vialC.i = 411111;
	vialC.j = 422222;

	vs->postVial(&vialC, dstID);
	*/
	ReqVial reqVial;
	reqVial.val = 1234;
	reqVial.dstID = dstID;
	Vial *retVial = vs->exchangeVial(&reqVial);
	if (retVial == NULL)
		printf("exchange failed.\n");
	else if (retVial->vialType != VT_ACK)
		printf("Bad!!!!!!!!!!!!!!!!!!!!!!\n");
	else
		cout << ((AckVial *)retVial)->str << endl;

	incReceiveCount();
	return true;
}


bool MyClassB::OnReceive(Vial *vial)
{
	if (vial->vialType != VT_B)
		return false;

	MyVialB *myVial = (MyVialB *)vial;
	cout << "name=" << myVial->name;
	cout << " a=" << myVial->a;
	cout << " b=" << myVial->b;
	cout << " c=" << myVial->c;
	cout << endl;

	MyVialC vialC;
	strcpy(vialC.name, "someone");
	vialC.i = 11;
	vialC.j = 12;

	vialC.dstID = dstID;
	vs->postVial(&vialC);
	incReceiveCount();
	return true;
}


bool MyClassC::OnReceive(Vial *vial)
{
	if (vial->vialType != VT_C)
		return false;

	MyVialC *myVial = (MyVialC *)vial;
	cout << "name=" << myVial->name;
	cout << " i=" << myVial->i;
	cout << " j=" << myVial->j;
	cout << endl;

	MyVialA vialA;
	strcpy(vialA.name, "Lotus");
	vialA.x = 81;
	vialA.y = 92;

	vialA.dstID = dstID;
	vs->postVial(&vialA);
	incReceiveCount();
	return true;
}


int main()
{
	VialSystem vs(srcID);
	MyClassA classA(&vs);
	MyClassB classB(&vs);
	MyClassC classC(&vs);

	vs.addReceiver(&classA);
	vs.addReceiver(&classB);
	vs.addReceiver(&classC);

	MyVialA vialA;
	strcpy(vialA.name, "ksdj");
	vialA.x = 5;
	vialA.y = 7;

	vialA.dstID = dstID;
	vs.postVial(&vialA);

	vs.run();
}
#endif

//#include <stdio.h>
using namespace std;

int main()
{
	//printf("Hello!\n");
	cout << "Hello!" << endl;
	return 0;
}

