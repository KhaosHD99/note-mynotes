#ifndef VIALTYPE_H_
#define VIALTYPE_H_

#include "Vial.hpp"

#ifdef VIAL_EXAMPLE
const int GUI_BASE = 0xF0000000;
#endif


/*---------------------------------------------------------------------------------------
	����VIAL�ĺ궨��
---------------------------------------------------------------------------------------*/
#ifdef VIAL_EXAMPLE

#define VIAL_LIST \
	VIAL_DEF(	ShowWndReqVial,			GUI_BASE	)\
	VIAL_DEF(	ShowWndAckVial,			GUI_BASE+1	)\
	VIAL_DEF(	ResizeWndReqVial,		GUI_BASE+2	)\
	VIAL_DEF(	ResizeWndAckVial,		GUI_BASE+3	)\
	VIAL_DEF(	KeyPressVial,			0x10000001	)\
	VIAL_DEF(	MouseMoveVial,			0x10000002	)\
	VIAL_DEF(	OtherEventVial,			0x10000003	)

#define VIAL_DEF(className, vialTypeVal)	const int VT_##className = vialTypeVal;
VIAL_LIST
#undef VIAL_DEF

#undef VIAL_LIST

#endif //VIAL_EXAMPLE


#define VIAL_CONSTRUCTOR(className) \
	static const int VT = VT_##className; \
	className() { vialType = VT; vialLen = sizeof(*this); }

#define GETVT(className)	className::VT
/*---------------------------------------------------------------------------------------
	�궨�����
---------------------------------------------------------------------------------------*/


#ifdef VIAL_EXAMPLE

struct ShowWndReqVial : public Vial
{
	int x, y;
	VIAL_CONSTRUCTOR(ShowWndReqVial);
};


struct ResizeWndReqVial : public Vial
{
	int a, b;
	int x;
	VIAL_CONSTRUCTOR(ResizeWndReqVial);
};


struct ShowWndAckVial : public Vial
{
	int x, y, z;
	VIAL_CONSTRUCTOR(ShowWndAckVial);
};


struct ResizeWndAckVial : public Vial
{
	int a, b, c;
	VIAL_CONSTRUCTOR(ResizeWndAckVial);
};


struct KeyPressVial : public Vial
{
	int keyValue;
	VIAL_CONSTRUCTOR(KeyPressVial);
};


struct MouseMoveVial : public Vial
{
	int mouseX, mouseY;
	VIAL_CONSTRUCTOR(MouseMoveVial);
};


struct OtherEventVial : public Vial
{
	int something;
	VIAL_CONSTRUCTOR(OtherEventVial);
};


#endif //VIAL_EXAMPLE


#endif //VIALTYPE_H_

