#include <limits.h>
#include <stdlib.h>
#include <signal.h>
#include <iostream>
#include <fcntl.h>
#include <poll.h>
#include "LogMsg.hpp"
#include "Vial.hpp"
#include "VialType.hpp"


const char *Vial::VIALMARK = "VIAL";


/*----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------*/
const int VT_EndRunningVial = -1;
const int CONFIRM_FLAG = 1789349823;

struct EndRunningVial : public Vial
{
	int confirmFlag;
	VIAL_CONSTRUCTOR(EndRunningVial);
};


/*----------------------------------------------------------------------------------------
	VialBuf
----------------------------------------------------------------------------------------*/
class VialBuf
{
	private:
		static const int VIAL_BUF_SIZE = PIPE_BUF;
		char *buf;
	public:
		char *getAsPChar() { return buf; }
		Vial *getAsVial() { return (Vial *)buf; }
		int getSize() { return VIAL_BUF_SIZE; }
	public:
		VialBuf() { buf = new char[VIAL_BUF_SIZE]; }
		~VialBuf() { delete buf; }
};


/*----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------*/
static void signalPipe(int s)
{
	showError("pipe error.\n");
}


#if 1
bool waitForRead(int hFile)
{
	pollfd pfd;

	pfd.fd = hFile;
	pfd.events = POLLIN;
	pfd.revents = 0;

	if (poll(&pfd, 1, -1) == -1)
	{
		showError("poll error.  pid=<%d>\n", getpid());
		return false;
	}

	return pfd.revents & POLLIN;
}
#else
bool waitForRead(int hFile)
{
	fd_set rdset, errset;

	FD_ZERO(&rdset);
	FD_SET(hFile, &rdset);
	errset = rdset;

	int result = select(FD_SETSIZE, &rdset, NULL, &errset, NULL);
	if (result == -1)
	{
		showError("select error.\n");
		return false;
	}
	if (result == 0)
	{
		showError("time out.\n");
		return false;
	}
	if (FD_ISSET(hFile, &errset))
	{
		showError("file error.\n");
		return false;
	}

	if (FD_ISSET(hFile, &rdset))
		return true;

	return false;
}
#endif


/*----------------------------------------------------------------------------------------
	VialSystem
----------------------------------------------------------------------------------------*/
VialSystem::VialSystem(NodeID uniqueID)
{
	showInfo("VialSystem construct\n");

	//signal(SIGPIPE, signalPipe);
	init(uniqueID);
}


VialSystem::~VialSystem()
{
	showInfo("VialSystem destruct\n");

	for (ReceiverLink *p = receiverLinkRoot.next; p != &receiverLinkRoot; )
	{
		ReceiverLink *tmp = p;
		p = p->next;
		delete tmp;
	}

	close(hPrimaryFifo);
	close(hSecondaryFifo);
	close(hDummyWriter1);
	close(hDummyWriter2);

	pthread_mutex_destroy(&mutexExchangeVial);
}


void VialSystem::init(NodeID uniqueID)
{
	char fifoName[64];

	pthread_mutex_init(&mutexExchangeVial, NULL);

	//����nodeID
	nodeID = uniqueID;

	//��ʼ��˫��ѭ��������ע�⣺���ڵ��ǲ�������ݵģ�ֻʣ�¸���ʱ����ǿ�״̬��
	receiverLinkRoot.receiver = NULL;
	receiverLinkRoot.next = &receiverLinkRoot;
	receiverLinkRoot.prev = &receiverLinkRoot;

	//�ļ�����ȸ�ֵΪ-1
	hPrimaryFifo = -1;
	hSecondaryFifo = -1;
	hDummyWriter1 = -1;
	hDummyWriter2 = -1;

	//������ͨ��FIFO
	sprintf(fifoName, "/tmp/%08X.fifo", nodeID);
	mkfifo(fifoName, 0777);

	//����ͨ��FIFO
	hPrimaryFifo = open(fifoName, O_RDONLY | O_NONBLOCK);
	if (hPrimaryFifo == -1)
	{
		showError("fail to open primary fifo.\n");
		exit(1);
	}

	//��һ����д�����ڱ���read����0�ֽڣ�
	hDummyWriter1 = open(fifoName, O_WRONLY | O_NONBLOCK);
	//����ĳ���ر���д���ļ��������ʹselect������������ʹread����0�ֽڡ�

	//������ͨ��FIFO
	sprintf(fifoName, "/tmp/%08X_r.fifo", nodeID);
	mkfifo(fifoName, 0777);

	//�򿪸�ͨ��FIFO
	hSecondaryFifo = open(fifoName, O_RDONLY | O_NONBLOCK);
	if (hSecondaryFifo == -1)
	{
		showError("fail to open secondary fifo.\n");
		exit(1);
	}

	//��һ����д�����ڱ���read����0�ֽڣ�
	hDummyWriter2 = open(fifoName, O_WRONLY | O_NONBLOCK);
	//����ĳ���ر���д���ļ��������ʹselect������������ʹread����0�ֽڡ�
}


void VialSystem::addReceiver(IVialReceiver *receiver)
{
	ReceiverLink *newLinkNode;

	newLinkNode = new ReceiverLink;
	if (newLinkNode == NULL)
	{
		showCritical("can not allocate memory for ReceiverLink.\n");
		exit(2);
	}
	newLinkNode->receiver = receiver;

	//˫��ѭ������������������뵽���һ����λ����
	newLinkNode->prev = receiverLinkRoot.prev;
	newLinkNode->next = &receiverLinkRoot;
	receiverLinkRoot.prev->next = newLinkNode;
	receiverLinkRoot.prev = newLinkNode;
}


bool VialSystem::removeReceiver(IVialReceiver *receiver)
{
	ReceiverLink *p;

	//˫��ѭ��������������������ɸ���next��ʼ���ص����ͽ���
	for (p = receiverLinkRoot.next; p != &receiverLinkRoot; p = p->next)
	{
		if (p->receiver == receiver)
		{
			//˫������ɾ������
			p->next->prev = p->prev;
			p->prev->next = p->next;
			delete p;
			return true;
		}
	}

	return false;
}


bool VialSystem::readVial(int hFifo, Vial *vialBuf)
{
	const int vialHeadSize = sizeof(Vial);
	int len;

	if (!waitForRead(hFifo))
	{
		showDebug("waitForRead returns false.\n");
		return false;
	}

	len = read(hFifo, vialBuf, vialHeadSize);
	if (len != vialHeadSize)
	{
		showError("read error.\n");
		return false;
	}

	if (memcmp(vialBuf->mark, Vial::VIALMARK, sizeof(vialBuf->mark)) != 0)
	{
		showWarning("bad vial.\n");
		return false;
	}

	len = read(hFifo, ((char *)vialBuf) + vialHeadSize, vialBuf->vialLen - vialHeadSize);
	if (len != vialBuf->vialLen - vialHeadSize)
	{
		showError("vial len error.\n");
		return false;
	}

	return true;
}


void VialSystem::processVial(Vial *vial)
{
	ReceiverLink *p;

	for (p = receiverLinkRoot.next; p != &receiverLinkRoot; p = p->next)
	{
		if (p->receiver->OnReceive(vial))
			break;
	}
}


bool doPostVial(Vial *vial, const char *dstFifoName)
{
	int hDstFifo;

	hDstFifo = open(dstFifoName, O_WRONLY | O_NONBLOCK);
	if (hDstFifo == -1)
	{
		showError("can not open FIFO for write[name=\"%s\"].\n", dstFifoName);
		return false;
	}

	if (write(hDstFifo, vial, vial->vialLen) == -1)
	{
		showError("write FIFO failed(name=\"%s\", handle=%d).\n", dstFifoName, hDstFifo);
		close(hDstFifo);
		return false;
	}

	close(hDstFifo);
	return true;
}


bool VialSystem::postVial(Vial *vial)
{
	char dstFifoName[64];

	vial->srcID = nodeID;
	sprintf(dstFifoName, "/tmp/%08X.fifo", vial->dstID);

	return doPostVial(vial, dstFifoName);
}


bool VialSystem::postReturnVial(Vial *vial)
{
	char dstFifoName[64];

	vial->srcID = nodeID;
	sprintf(dstFifoName, "/tmp/%08X_r.fifo", vial->dstID);

	return doPostVial(vial, dstFifoName);
}


Vial *VialSystem::exchangeVial(Vial *outgoVial)
{
	VialBuf vialBuf;

	pthread_mutex_lock(&mutexExchangeVial);

	if (vialBuf.getAsPChar() == NULL)
	{
		showError("can not alloc vialBuf.\n");
		goto fail;
	}

	//��ȷ����ͨ����û������
	while (read(hSecondaryFifo, vialBuf.getAsPChar(), vialBuf.getSize()) > 0) {}

	if (!postVial(outgoVial))
		goto fail;

	if (readVial(hSecondaryFifo, vialBuf.getAsVial()))
	{
		pthread_mutex_unlock(&mutexExchangeVial);
		return vialBuf.getAsVial();
	}

fail:
	pthread_mutex_unlock(&mutexExchangeVial);
	return NULL;
}


void VialSystem::run()
{
	VialBuf vialBuf;

	if (vialBuf.getAsPChar() == NULL)
	{
		showError("can not alloc vialBuf.\n");
		return;
	}

	signal(SIGPIPE, signalPipe);

	for (;;)
	{
		if (readVial(hPrimaryFifo, vialBuf.getAsVial()))
		{
			if (vialBuf.getAsVial()->vialType == GETVT(EndRunningVial))
			{
				if (((EndRunningVial *)vialBuf.getAsVial())->confirmFlag == CONFIRM_FLAG)
					break;
				showCritical("Invailid vialType.\n");
			}

			processVial(vialBuf.getAsVial());
		}
	}
}


void VialSystem::endRunning()
{
	EndRunningVial vial;

	vial.confirmFlag = CONFIRM_FLAG;
	vial.dstID = nodeID;
	postVial(&vial);
}

