#cp src/lib/libfnphonebook.la src/lib/.libs/libfnphonebook.lai

make install DESTDIR=/opt/fn3/mx515_lucid_Compile
#make uninstall DESTDIR=/opt/fn3/mx515_lucid_Compile
