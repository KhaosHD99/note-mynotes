#ifndef PROMPTER_MODULE_DEF
#define PROMPTER_MODULE_DEF

#include <stdio.h>
#include "CodeConvert.hpp"
#include "LogMsg.hpp"
#include "Vial.hpp"
#include "VialType_Common.hpp"
#include "VialType_PhoneIntf.hpp"
#include "AbstractModule.hpp"
/********************************************************************
							��沥��
*********************************************************************/
class AdverModule : public AbstractModule
{
#define __CLASS__ "AdverModule"
#define VIAL_PHONECODE_LEN	32
	struct
	{
		int nPhoneMode;
		int nCallType;
		int nCodelen;
		char cPhoneCode[VIAL_PHONECODE_LEN];
	}PhoneCode;
	
	private:
		VialSystem *vialSys;
		static AdverModule *adverModule_instance;
	public:
		void run();
	 	static AdverModule *get_instance(VialSystem *vialSys);
		virtual bool localInit();
		virtual bool onExit();
		virtual bool OnReceive(Vial *vial);

	protected:
		//bool onVialStateChang(StateChangeVial *vial);

		//bool onVialDialNotify(DialNotifyVial *vial);
		//bool onVialCallerPhoneCode(CallerPhoneCodeVial *vial);

	private:
		AdverModule(VialSystem *vialSys);
		virtual ~AdverModule(){};
		bool onOnHook(Vial *vial);
		bool onDialing(Vial *vial);
		bool onRinging(Vial *vial);
		bool onNoVideoConn(Vial *vial);
		bool onVideoConn(Vial *vial);
		
};
#endif
