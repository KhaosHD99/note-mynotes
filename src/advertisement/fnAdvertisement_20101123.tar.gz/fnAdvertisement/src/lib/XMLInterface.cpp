// XMLParser.cpp: implementation of the CXMLParser class.
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>

//#include "XMLInterface.h"
#include "XMLParser.h"
#include "LogMsg.hpp"

CXMLParser g_XMLParser;

/* Load XML File */
int XMLLoadFile(char *szFileName)
{
	return g_XMLParser.LoadFile(szFileName);
}

/* Get Root Node */
xmlNodePtr XMLReadRootNode()
{
	return g_XMLParser.ReadRootNode();
}

/* Get Child Node */
xmlNodePtr XMLReadChildNode(xmlNodePtr pNode)
{
	return g_XMLParser.ReadChildNode(pNode);
}

/* Get Brother Node */
xmlNodePtr XMLReadBrotherNode(xmlNodePtr pNode)
{
	return g_XMLParser.ReadBrotherNode(pNode);
}

/* Get  Attribute */
xmlChar *XMLReadAttributeValue(xmlNodePtr pNode, xmlChar *cAttrName)
{
	return g_XMLParser.ReadAttributeValue(pNode, cAttrName);
}

