
#if !defined(__XMLINTERFACE_H__)
#define __XMLINTERFACE_H__

#include <libxml/parser.h>

typedef void* XMLHandle; 

/* Load XML File */
int XMLLoadFile(char *szFileName);

/* Get Root Node */
xmlNodePtr XMLReadRootNode();
	
/* Get Child Node */
xmlNodePtr XMLReadChildNode(xmlNodePtr);
	
/* Get Brother Node */
xmlNodePtr XMLReadBrotherNode(xmlNodePtr);

/* Get  Attribute */
xmlChar *XMLReadAttributeValue(xmlNodePtr pNode, xmlChar *cAttrName);

#endif 
