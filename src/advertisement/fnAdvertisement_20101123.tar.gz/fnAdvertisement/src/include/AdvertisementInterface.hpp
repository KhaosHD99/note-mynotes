#include "Advertisement.hpp"

#ifdef __cplusplus
extern "C" 
{
#endif

void *play_adver_thread(void *p_data);

void *simulateChangeState(void *pData);

#ifdef __cplusplus 
}
#endif

