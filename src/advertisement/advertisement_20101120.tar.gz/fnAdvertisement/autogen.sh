#! /bin/sh
set -x

touch README NEWS AUTHORS ChangeLog

aclocal

autoheader

autoconf

automake --foreign --add-missing --copy


