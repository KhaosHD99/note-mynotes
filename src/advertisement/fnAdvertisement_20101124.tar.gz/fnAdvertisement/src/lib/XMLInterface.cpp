// XMLParser.cpp: implementation of the CXMLParser class.
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>

//#include "XMLInterface.h"
#include "XMLParser.h"
#include "LogMsg.hpp"

/* Load XML File */
int XMLLoadFile(char *szFileName)
{
    CXMLParser *parser = CXMLParser::get_instance();
	return parser->LoadFile(szFileName);
}

/* Get Root Node */
xmlNodePtr XMLReadRootNode()
{
	CXMLParser *parser = CXMLParser::get_instance();
	return parser->ReadRootNode();
}

/* Get Child Node */
xmlNodePtr XMLReadChildNode(xmlNodePtr pNode)
{
	CXMLParser *parser = CXMLParser::get_instance();
	return parser->ReadChildNode(pNode);
}

/* Get Brother Node */
xmlNodePtr XMLReadBrotherNode(xmlNodePtr pNode)
{
	CXMLParser *parser = CXMLParser::get_instance();
	return parser->ReadBrotherNode(pNode);
}

/* Get  Attribute */
xmlChar *XMLReadAttributeValue(xmlNodePtr pNode, xmlChar *cAttrName)
{
	CXMLParser *parser = CXMLParser::get_instance();
	return parser->ReadAttributeValue(pNode, cAttrName);
}

void free_resource()
{
    //showDebug("free\n\n\n\n");
	//CXMLParser *parser = CXMLParser::get_instance();
	//delete parser;
}

