#include "Advertisement.hpp"

#ifdef __cplusplus
extern "C" 
{
#endif

void *play_adver_thread(void *p_data)
{	
	AdverManager *adverManager = AdverManager::get_instance();
	adverManager->play_adver_thread(NULL);
}	
	
void *simulateChangeState(void *pData)
{	
    AdverManager *adverManager = AdverManager::get_instance();
	adverManager->simulateChangeState(NULL);
}	

#ifdef __cplusplus 
}
#endif

