/*
* Copyright ���ݷ�����Ѷ���޹�˾
* All rights reserved.
* 
* �ļ����ƣ�XMLParser.cpp
* 
* ժ    Ҫ��XML������
* 
* ��    �ߣ���ҫȪ
*
* �޸���:   �����
* 
* ����޸����ڣ�2010��11��19��
*/

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <string.h>

#include "XMLParser.h"

CXMLParser::CXMLParser()
{
	
}

CXMLParser::~CXMLParser()
{
	
}

int CXMLParser::LoadFile(char *szFileName)
{	
	if(!szFileName)
	{
		return -1;
	}
	
	xmlNodePtr curElement;
	xmlAttrPtr curProp;
    	
	doc = xmlReadFile(szFileName,
		              NULL,
		              XML_PARSE_NOBLANKS);
	
	/* validate */
	if (!doc)
	{ 	
		showError("open doc fail\n");
		return -1; 
	}
	
	rootNode = xmlDocGetRootElement(doc);

	return 0;
}

xmlNodePtr CXMLParser::ReadRootNode()
{	
	return rootNode;
}

xmlNodePtr CXMLParser::ReadChildNode(xmlNodePtr pNode)
{
	return pNode->children;
}

xmlNodePtr CXMLParser::ReadBrotherNode(xmlNodePtr pNode)
{
	return pNode->next;
}

xmlChar *CXMLParser::ReadAttributeValue(xmlNodePtr pNode, xmlChar *cAttrName)
{
	return xmlGetProp(pNode, cAttrName);
}

