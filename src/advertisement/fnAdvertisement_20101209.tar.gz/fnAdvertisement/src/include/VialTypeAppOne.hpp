#ifndef VIALTYPEAPPONE_H_
#define VIALTYPEAPPONE_H_

#include "Vial.hpp"

const int APP_VIALTYPE_BASE = 0x40000000;

/*---------------------------------------------------------------------------------------
	����VIAL�ĺ궨��
---------------------------------------------------------------------------------------*/
#define VIAL_LIST \
	VIAL_DEF(	ShapeVial,			APP_VIALTYPE_BASE + 0	)\
	VIAL_DEF(	PointVial,			APP_VIALTYPE_BASE + 1	)\
	VIAL_DEF(	CircleVial,			APP_VIALTYPE_BASE + 2	)\
	VIAL_DEF(	RectangleVial,		APP_VIALTYPE_BASE + 3	)\
	/*VIAL_DEF(	PingVial,			APP_VIALTYPE_BASE + 10	)*/\
	VIAL_DEF(	MsgVial,			APP_VIALTYPE_BASE + 16	)

#define VIAL_DEF(className, vialTypeVal)	const int VT_##className = vialTypeVal;
VIAL_LIST
#undef VIAL_DEF

#define VIAL_CONSTRUCTOR(className) \
	static const int VT = VT_##className; \
	className() { vialType = VT; vialLen = sizeof(*this); }

#define GETVT(className)	className::VT


/*---------------------------------------------------------------------------------------
	���¿�ʼ����Vial�ľ��嶨��
---------------------------------------------------------------------------------------*/
struct ShapeVial : public Vial
{
	VIAL_CONSTRUCTOR(ShapeVial);
	virtual void draw(char *buf){}
	virtual bool isInheritFrom(int baseVialType)
	{
		return baseVialType == GETVT(ShapeVial) ?
			   true : Vial::isInheritFrom(baseVialType);
	}
};


struct PointVial : public ShapeVial
{
	int x, y;
	
	VIAL_CONSTRUCTOR(PointVial);
	virtual void draw(char *buf)
	{
		sprintf(buf, "This is a Point, x=%d, y=%d\n", x, y);
	}
};


struct CircleVial : public ShapeVial
{
	int x, y;
	int r;
	
	VIAL_CONSTRUCTOR(CircleVial);
	virtual void draw(char *buf)
	{
		sprintf(buf, "This is a Circle, x=%d, y=%d, r=%d\n", x, y, r);
	}
};


struct RectangleVial : public ShapeVial
{
	int x1, y1;
	int width, height;

	VIAL_CONSTRUCTOR(RectangleVial);
	virtual void draw(char *buf)
	{
		sprintf(buf, "This is a Rectangle, x1=%d, y1=%d, width=%d, height=%d\n",
			x1, y1, width, height);
	}
};

struct MsgVial : public Vial
{
	char msg[128];
	
	VIAL_CONSTRUCTOR(MsgVial);
};


/*---------------------------------------------------------------------------------------
	��Vial�ľ��嶨�����������VialFactory
---------------------------------------------------------------------------------------*/
class VialFactory
{
	public:
		static Vial *createVialByType(int vialType)
		{
			switch (vialType)
			{
				#define VIAL_DEF(className, vialTypeVal)	case VT_##className: return new className;
				VIAL_LIST
				#undef VIAL_DEF
				
				default:
					return NULL;
			}
		}
		
		static Vial *createVialByCopy(Vial *anotherVial)
		{	
			Vial *vial;
			
			vial = createVialByType(anotherVial->vialType);
			if (vial != NULL)
			{
				//*vial = *anotherVial;		//������������������дoperator=��
				//�ӵ�һ����Ա��ʼ���ƣ�
				memcpy(vial->mark, anotherVial->mark,	
					   vial->vialLen-( (int)vial->mark - (int)vial ));	
						//����vptr�ٸ���4���ֽڣ�
						//�����ԣ���ͬ���������ܵó���ȷ�����
			}
			return vial;
		}
};

#undef VIAL_LIST

#endif //VIALTYPEAPPONE_H_

