#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "AdverModule.h"
#include "ModuleID.hpp"

/**************************************************************
                     thread_promptermodule
        (�绰״̬)��ʾģ�������߳�
**************************************************************/
static void *thread_adv_play_module(void *data)
{
	//VialSystem vialSys(FN_PHONE_BOOK_MODULE_ID);
	VialSystem vialSys(FN_ADVPLAY_MODULE_ID);
	AdverModule *adver = AdverModule::get_instance(&vialSys);	
	
	if(adver)
	{
		adver->init();
		adver->run();
	}
	else
		return NULL;
}

/**************************************************************
**creat_and_run_prompter_module
**����(�绰״̬)��ʾģ�������߳�
**
**************************************************************/
#ifdef __cplusplus
extern"C"
#endif
int creat_and_run_adv_play_module()
{
//	���̣߳�
	pthread_t adv_play_module_thread;

	if(pthread_create(&adv_play_module_thread, NULL, thread_adv_play_module, NULL) == 0)
	{
		printf("thread create Ok, promptermodule thread start \n");
		return 0;
	}
	else
	{
		printf("thread promptermodule create Err\n");
		return -1;
	}
}

