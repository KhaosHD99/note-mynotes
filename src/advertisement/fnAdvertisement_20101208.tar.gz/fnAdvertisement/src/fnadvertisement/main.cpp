/*
* Copyright ���ݷ�����Ѷ���޹�˾
* All rights reserved.
* 
* �ļ����ƣ�Main.cpp
* 
* ժ    Ҫ�����Ӧ��������
* 
* ��    �ߣ���ҫȪ
*
* �޸���:   �����
* 
* ����޸����ڣ�2010��11��20��
*/

#include "AdvertisementInterface.hpp"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "LogMsg.hpp"
#include "Vial.hpp"
#include "VialTypeAppOne.hpp"

//#include "AdverCcInterface.h"

/*
#define VIAL_LIST \
	VIA_DEF(	ShowWndReqVial,			GUI_BASE	)\
	VIAL_DEF(	ShowWndAckVial,			GUI_BASE+1	)\
	VIAL_DEF(	ResizeWndReqVial,		GUI_BASE+2	)\
	VIAL_DEF(	ResizeWndAckVial,		GUI_BASE+3	)\
	VIAL_DEF(	KeyPressVial,			0x10000001	)\
	VIAL_DEF(	MouseMoveVial,			0x10000002	)\
	VIAL_DEF(	OtherEventVial,			0x10000003	)
*/

pthread_t player_thread_id;
pthread_t play_adver_thread_id;
pthread_t simulate_change_state_thd_id;

typedef struct st_argvs
{
	int argc;
	char **argv;
}st_argvs;


st_argvs argvs;

/* Init Time List */
int initTimelist()
{
	if (!GetActName::get_instance()->read_play_act())
		showWarning("read timeList fail.\n");
	else
		showDebug("read timeList suc.\n\n");
}

/* Vial Test  */
#define APP_ONE_ID 88
#define APP_TWO_ID 89


#ifdef APP_ONE
const NodeID nodeID = APP_ONE_ID;
#elif defined(APP_TWO)
const NodeID nodeID = APP_TWO_ID;
#else
#error no def APP_ONE or APP_TWO
#endif

VialSystem *vialSys = NULL;

class MyClass : public IVialReceiver
{
	public:
		//��Vial�������¼��ᱻ����
		virtual bool OnReceive(Vial *vial);
};


#if USE_RTTI
static bool isShapeVial(Vial *vial)
{
	ShapeVial *sv;

	sv = dynamic_cast<ShapeVial *>(vial);
	return sv != NULL;
}
#else
static bool isShapeVial(Vial *vial)
{
	return vial->isInheritFrom(GETVT(ShapeVial));
}
#endif

bool MyClass::OnReceive(Vial *inputVial)
{	
	Vial *vial;
	
	vial = VialFactory::createVialByCopy(inputVial);
	if (vial == NULL)
	{
		showWarning("Can not distinguish vial��Type��0x%08X\n", inputVial->vialType);
		delete vial;
		return false;
	}
	
	if (isShapeVial(vial))
	{
		ShapeVial *shapeVial = (ShapeVial *)vial;
		char buf[128];

		shapeVial->draw(buf);
		printf(buf);
		MsgVial msgVial;
		memcpy(msgVial.msg, buf, sizeof(msgVial.msg));
		vialSys->postVial(&msgVial, shapeVial->srcID);
		
		delete vial;
		return true;
	}
	
	switch (vial->vialType)
	{
		case GETVT(MsgVial):
			MsgVial *msgVial;
			msgVial = (MsgVial *)vial;
			printf("get vial��%s\n", msgVial->msg);
			break;
		default:
			break;
	}
	
	delete vial;
	return true;
}


#ifdef APP_ONE
static void *workThread(void *par)
{
	char inputString[64];

	for (;;)
	{
		scanf("%s", inputString);
		if (strcasecmp("point", inputString) == 0)
		{
			PointVial vial;
			vial.x = 1;
			vial.y = 2;
			vialSys->postVial(&vial, APP_TWO_ID);
		}
		else if (strcasecmp("circle", inputString) == 0)
		{
			CircleVial vial;
			vial.x = 3;
			vial.y = 4;
			vial.r = 8;
			vialSys->postVial(&vial, APP_TWO_ID);
		}
		else if (strcasecmp("rectangle", inputString) == 0)
		{
			RectangleVial vial;
			vial.x1 = 11;
			vial.y1 = 12;
			vial.width = 640;
			vial.height = 480;
			vialSys->postVial(&vial, APP_TWO_ID);
		}
		else
		{
			printf("Wrong input\n");
		}
	}
}
#elif defined(APP_TWO)
static void *workThread(void *par)
{
	printf("APP_TWO workThread.\n");
	for (;;)
	{
	
	}
}
#else
#error û�ж���APP_ONE��APP_TWO
#endif



int main(int argc, char *argv[])
{
	#if 1
	VialSystem vialSystem(nodeID);
	vialSys = &vialSystem;
	MyClass myReceiver;

	vialSys->addReceiver(&myReceiver);
	pthread_t thrd;
	pthread_create(&thrd, NULL, workThread, NULL);
	vialSys->run();

	return 0;
	#endif
	
    #if 0
	int ret = 0;
	sem_t timeSem;
	char img_path[128];
	struct timeval tv;
	struct timespec sp;

	showDebug("\n\n\n\n\nGet in %s\n\n\n\n", __FUNCTION__);
	
	/* Initial Advertisment Time List */
	initTimelist();
    sem_init(&timeSem, 0, 0);
	
    //ret = creat_and_run_adv_play_module();

	//StatePrompterInfo stateinfo;
	//memset(&stateinfo, 0, sizeof(stateinfo));
	//stateinfo.state = PP_OFF_HOOK;
	//update_prompter_info(&stateinfo);
	
    /* Init Playe Window */
	sprintf(img_path, "%s%s", IMAGE_PATH_PREFIX, INIT_IMAGE);	
	if(init_adver_play(img_path))
	{
		showError("Init adver play window fail\n");
		return 0;
	}
	
	#if 1
	/* Create Play Advertisement Thread */
    ret = pthread_create(&play_adver_thread_id, 
			              NULL,
	                      play_adver_thread,
	                      NULL);
	if(ret != 0)
	{
		showWarning("Create playTimeThread %d fail\n", ret);
		return -1;
	}
    #endif
	
	#if 1
    /* Create Play Change State Thread */
	ret = pthread_create(&simulate_change_state_thd_id,
						  NULL,
						  simulate_change_state,
						  NULL);
    if(ret != 0)
	{
		showWarning("Create SimulateChangeStateThread %d fail\n", ret);
		return -1;
	}
    #endif
	
	/* wait */
	while(1)
	{
	    gettimeofday (&tv , NULL);
		sp.tv_sec = tv.tv_sec + 1;
		sp.tv_nsec = tv.tv_usec;
		sem_timedwait(&timeSem, &sp);
	}
	
	return 0;
	#endif
}

