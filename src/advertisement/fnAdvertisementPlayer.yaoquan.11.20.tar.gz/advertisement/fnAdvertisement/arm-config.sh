

export PRX=/home/$USER/opt/
export THREAD_CONFIG_PATH=/home/huarun/lib/pkgconfig
#export PKG_CONFIG_PATH=/usr/lib/pkgconfig:$PKG_CONFIG_PATH:$PRX/lib/pkgconfig:$THREAD_CONFIG_PATH

export PKG_CONFIG_PATH=$PKG_CONFIG_PATH:$PRX/lib/pkgconfig:/home/huarun/lib/pkgconfig

./configure \
	--prefix=$PRX \
	--host=arm-linux \
	--with-PACKAGE 


