export LD_LIBRARY_PATH=/usr/lib:/home/huarun/lib:/home/yaoquan/opt/lib

