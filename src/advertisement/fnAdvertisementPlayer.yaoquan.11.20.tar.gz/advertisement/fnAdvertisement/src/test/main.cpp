/*
* Copyright ���ݷ�����Ѷ���޹�˾
* All rights reserved.
* 
* �ļ����ƣ�Main.cpp
* 
* ժ    Ҫ�����Ӧ��������
* 
* ��    �ߣ���ҫȪ
*
* �޸���:   �����
* 
* ����޸����ڣ�2010��11��20��
*/

#include "AdvertisementInterface.hpp"

pthread_t player_thread_id;
pthread_t play_adver_thread_id;
pthread_t simulate_change_state_thd_id;

typedef struct st_argvs
{
	int argc;
	char **argv;
}st_argvs;


st_argvs argvs;

/* Init Time List */
int initTimelist()
{
	if (!GetActName::getInstance()->readPlayAct())
		showWarning("read timeList fail.\n");
	else
		showDebug("read timeList suc.\n\n");
}

/* Player Time Thread */
void *player_thread(void *pData)
{
	if(pData == NULL)
		return (void*)NULL;

	char img_path[128];
	
	st_argvs *argvs = (st_argvs *)pData;
	sprintf(img_path, "%s%s", IMAGE_PATH_PREFIX, INIT_IMAGE);
	
	return (void*)init_adver_play(argvs->argc, argvs->argv, img_path);
}

int main(int argc, char *argv[])
{	
    #if 1
	int ret = 0;
	sem_t timeSem;
	struct timeval tv;
	struct timespec sp;
	
	/* Initial Advertisment Time List */
	initTimelist();
    sem_init(&timeSem, 0, 0);
	
	/* Create Player Thread */
	#if 1
	argvs.argc = argc;
	argvs.argv = argv;
	ret = pthread_create(&player_thread_id, 
						  NULL, 
						  player_thread, 
						  (void *)&argvs);
	
	if(ret != 0)
	{
		showWarning("Create playerTimeThread %d fail\n", ret);
		return -1;
	}
	
	#endif
	
	#if 1
	/* Create Play Advertisement Thread */
    ret = pthread_create(&play_adver_thread_id, 
			              NULL,
	                      play_adver_thread,
	                      NULL);
	if(ret != 0)
	{
		showWarning("Create playTimeThread %d fail\n", ret);
		return -1;
	}
    #endif

	#if 1
    /* Create Play Change State Thread */
	ret = pthread_create(&simulate_change_state_thd_id,  
						  NULL,
						  simulateChangeState,
						  NULL);
    if(ret != 0)
	{
		showWarning("Create SimulateChangeStateThread %d fail\n", ret);
		return -1;
	}
    #endif
	
	/* wait */
	while(1)
	{
	    gettimeofday (&tv , NULL);
		sp.tv_sec = tv.tv_sec + 1;
		sp.tv_nsec = tv.tv_usec;
		sem_timedwait(&timeSem, &sp);
	}
 
	return 0;
	#endif
}

