#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include "phonebookapi.h"
//#include "windowstack.h"
#include "MessageStack.h"
#define IMAGE_PATH "img/image.png"
#define ZHENJIE_PATH "img/镇杰.png"

extern GtkWidget *rootWindow;
extern GtkWidget *contactWindow;
extern GtkWidget *calllogWindow;
extern GtkBuilder *builder;

typedef struct _ContactItemDetail ContactItemDetail;
struct _ContactItemDetail
{
  	GtkWidget* family_name;
  	GtkWidget* given_name;
  	GtkWidget* group;
  	GtkWidget* phone;
	GtkWidget* image;
};

void on_button_menu_clicked(GtkWidget *gtklist, gpointer user_data)
{
	gtk_widget_hide(contactWindow);
	//gtk_widget_destroy(contactWindow);
	//contactWindow = NULL;
}

static GtkTreeModel* create_model(void)
{
		GtkListStore *store;
		GSList *ids;
		GSList *tmp_list;
        int i;
		
		store = gtk_list_store_new(3, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT);
		
		for(i = 0; i < get_contact_count(); i++)
		{
	        Contact contact; 
			GtkTreeIter iter;
	        get_contact_by_index(&contact, i);
			
		    gtk_list_store_append (store, &iter);
		    gtk_list_store_set (store, &iter, 
				                0, contact.name.szgiven_name,
				                1, contact.name.szfamily_name,
				                2, i,
				                -1);
		     
		    //free(&contact);
			#if 0
		   
			#endif
		}
		
		return GTK_TREE_MODEL (store);
}

static void selection_changed(GtkTreeSelection *selection)
{
	  #if 1
	  GtkTreeView *treeview;
	  ContactItemDetail* display;
	  GtkTreeModel *model;
	  GtkTreeIter iter;
	  Contact contact;
	  
	  treeview = gtk_tree_selection_get_tree_view(selection);
	  display = g_object_get_data(G_OBJECT(treeview), "ContactDetail");
	
	  if (gtk_tree_selection_get_selected(selection, &model, &iter))
	  {
	      int i = 0;
	      gint index;
		  GdkPixbuf *image;
		  char phoneInfo[128];

	      gtk_tree_model_get(model, &iter,
	                         2, &index,
	                         -1);

		  //get contact
		  get_contact_by_index(&contact, index);
          
		  gtk_label_set_text (GTK_LABEL(display->given_name), contact.name.szgiven_name);
	      gtk_label_set_text (GTK_LABEL(display->family_name), contact.name.szfamily_name);
	      gtk_label_set_text (GTK_LABEL(display->group), NULL);

		  //phone
		  //while(contact.phones[i].szphone[0] != '\0')
		//  {
		//  		strcat(phoneInfo, contact.phones[i].szphone);
		//		i++;
		//  }
		//  gtk_label_set_text (GTK_LABEL(display->phone), phoneInfo);

		  //image
	      image = gdk_pixbuf_new_from_file(ZHENJIE_PATH	, NULL);
	      gtk_image_set_from_pixbuf (GTK_IMAGE(display->image), image);
          
		  //release
	  }
	  else
	  {
		   
	  }
	  #endif
}

static void set_text (GtkTreeViewColumn *tree_column,
								     GtkCellRenderer   *cell,
								     GtkTreeModel      *model,
								     GtkTreeIter       *iter,
								     gpointer           data)
{
	  gchar *given_name;
	  gchar *family_name;
	  gchar strCombine[64];
	  
	  
	  gtk_tree_model_get(model, iter,
	                     0, &given_name,
	                     1, &family_name,
	                     -1);

	  sprintf(strCombine, "%s%s", family_name, given_name);
	  
	  g_object_set(GTK_CELL_RENDERER(cell),
	               "text", strCombine,
	               NULL);

	  //g_free();
}

int show_contact_window()
{
	  if(!contactWindow)
	  {
        GtkWidget *window;
	    GtkWidget *frame;
	    GtkWidget *vbox;
	    GtkWidget *hbox;
	    GtkWidget *sw;
	    GtkWidget *treeview;
	    GtkWidget *align;
	    GtkTreeModel *tree_model;
	    GtkCellRenderer *cell_renderer;
	    ContactItemDetail*itemDetail;
	    GtkTreeSelection *selection;
	    GtkTreeViewColumn *column;
	
	    //window
        window = GTK_WIDGET(gtk_builder_get_object(builder, "window_contact"));
		contactWindow = window;
		gtk_window_move(GTK_WINDOW(contactWindow), 200, 0);
	
	    //hbox
	    hbox = GTK_WIDGET(gtk_builder_get_object(builder, "hbox1"));
		
	    //scroll window
	    sw = GTK_WIDGET(gtk_builder_get_object(builder, "scrolledwindow"));

	    //add  model to tree view
	    tree_model = create_model();
	    treeview = GTK_WIDGET(gtk_builder_get_object(builder, "treeview1"));
	    gtk_tree_view_set_model(treeview, tree_model);
	   
	    g_object_unref (tree_model);

	    
	    //column  
	    column = gtk_tree_view_column_new();
	  	gtk_tree_view_column_set_title(column, "联系人");
	    
	    //text cell renderer
	    cell_renderer = gtk_cell_renderer_text_new ();
	    gtk_tree_view_column_pack_start(column,
				       	                cell_renderer,
				       					TRUE);
		
	    gtk_tree_view_column_set_cell_data_func(column, cell_renderer,
			                              	    set_text, NULL, NULL);
			
	    //bingding column to tree view                              		      
	    gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
						            column);

		
	    //DetailDisplay
	   // align = gtk_alignment_new(0.5, 0.0, 0.0, 0.0);
	    align = GTK_WIDGET(gtk_builder_get_object(builder, "alignment1"));
	    gtk_box_pack_end(GTK_BOX (hbox), align, FALSE, FALSE, 0);
	    
	    frame = gtk_frame_new("Selected Item");
	    gtk_container_add(GTK_CONTAINER (align), frame);
	
	    vbox = gtk_vbox_new(FALSE, 8);
	    gtk_container_set_border_width(GTK_CONTAINER (vbox), 4);
	    gtk_container_add(GTK_CONTAINER(frame), vbox);

		
	    itemDetail = g_new(ContactItemDetail, 1);
	    g_object_set_data_full(G_OBJECT (treeview),
	                           "ContactDetail",
	                           itemDetail,
	                           g_free);
	    
	    itemDetail->family_name= gtk_label_new(NULL);
	    itemDetail->given_name= gtk_label_new(NULL);
	    itemDetail->group = gtk_label_new(NULL);
		itemDetail->phone = gtk_label_new(NULL);
	    itemDetail->image = gtk_image_new_from_pixbuf (NULL);
	
	    gtk_box_pack_start(GTK_BOX(vbox), itemDetail->family_name,
	                       FALSE, FALSE, 0);
	    gtk_box_pack_start(GTK_BOX(vbox), itemDetail->given_name,
	                       FALSE, FALSE, 0);
	    gtk_box_pack_start(GTK_BOX(vbox), itemDetail->group,
	                       FALSE, FALSE, 0);
		gtk_box_pack_start(GTK_BOX(vbox), itemDetail->phone,
	                       FALSE, FALSE, 0);
	    gtk_box_pack_start(GTK_BOX(vbox), itemDetail->image,
	                       FALSE, FALSE, 0);
	    
	    selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview));
	    gtk_tree_selection_set_mode(selection, GTK_SELECTION_SINGLE);
	    
	    g_signal_connect(selection,
			             "changed",
						 G_CALLBACK (selection_changed),
			             NULL);

        gtk_builder_connect_signals(builder, NULL);
		gtk_widget_show_all(contactWindow);
	  }
	  else if (!GTK_WIDGET_VISIBLE (contactWindow))
	  	 gtk_widget_show_all(contactWindow);
	 
      
      return 0;
}

