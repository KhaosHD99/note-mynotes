#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "PrompterModule.h"
#include "ModuleID.hpp"
/**************************************************************
**thread_promptermodule
**(�绰״̬)��ʾģ�������߳�
**
**************************************************************/
static void *thread_promptermodule(void *data)
{
	//��ʹ���Լ���module id
	VialSystem vialSys(FN_PROMPTER_MODULE_ID);
	
	PrompterModule *prompter = PrompterModule::get_instance(&vialSys);	
	
	if(prompter)
	{
		prompter->init();
		prompter->run();
	}
	else
		return NULL;
}

/**************************************************************
**creat_and_run_prompter_module
**����(�绰״̬)��ʾģ�������߳�
**
**************************************************************/
#ifdef __cplusplus
extern"C"
#endif
int creat_and_run_prompter_module()
{
//	���̣߳�
	pthread_t promptermodule_thread;

	if(pthread_create(&promptermodule_thread, NULL, thread_promptermodule, NULL) == 0)
	{
		printf("thread create Ok, promptermodule thread start \n");
		return 0;
	}
	else
	{
		printf("thread promptermodule create Err\n");
		return -1;
	}
}

