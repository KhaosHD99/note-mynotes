#include <stdio.h>
#include <stdlib.h>
#include "PrompterCcInterface.h"

int update_prompter_info(StatePrompterInfo *stateinfo)
{
	printf("on update_prompter_info function\r\n");
	return 0;
}

int main(int argc, char* argv[])
{
	int ret = creat_and_run_prompter_module();
	if(ret != 0)
	{
	  printf("run prompter module error : %d....\r\n", ret);
	}
	else
		printf("run prompter module scuess....\r\n");
	while(1)
	{
		sleep(5);
		printf("wait for exit!\r\n");
	}
	return 0;	
}
