#ifndef DEFAULT_APPCONFIG_INFO_H_
#define DEFAULT_APPCONFIG_INFO_H_


#ifndef APPCONFIG_DIR
	#define APPCONFIG_DIR					"appfile/config/"
#endif

//#define APP_RINGFILE_DIR				"appfile/ring"
//#define APP_USER_RINGFILE_DIR 			"/home/appfile/config/"
#ifndef SYS_CONFIGFILE_NAME
	#define SYS_CONFIGFILE_NAME			"sysconfig.dat"
#endif

#ifndef USER_CONFIGFILE_NAME
	#define USER_CONFIGFILE_NAME			"appconfig.dat"
#endif

#ifndef USER_CONFIGFILE_BK_NAME
	#define USER_CONFIGFILE_BK_NAME		"appconfig.bk.dat"
#endif

#ifndef APP_LOCAL_RINGFILE_DIR 
	#define APP_LOCAL_RINGFILE_DIR		"ringfile"
#endif

#ifndef APP_RINGFILE_DIR
	#define APP_RINGFILE_DIR				"/c/ringfile"
#endif

#ifndef APP_USER_RINGFILE_DIR
	#define APP_USER_RINGFILE_DIR 			"/d/ringfile"
#endif

#ifndef SYS_CONFIGFILE_NAME
#define SYS_CONFIGFILE_NAME				"sysconfig.dat"
#endif


#ifndef DEF_SERVER_IP
	#define DEF_SERVER_IP	"61.145.112.95"
#endif

#ifndef DEF_DNSSERVER_IP 
	#define DEF_DNSSERVER_IP	"61.144.56.101"
#endif

#ifndef EMERGENCY_SERVER_IP
	#define EMERGENCY_SERVER_IP			"61.145.112.95"
#endif

#ifndef DEF_REGSERVER_DOMAIN
	#define DEF_REGSERVER_DOMAIN "log.finephon.net"
#endif

#ifndef DEF_SWAPSERVER_DOMAIN
	#define DEF_SWAPSERVER_DOMAIN "log.finephon.net"
#endif

#ifndef DEF_FILESERVER_DOMAIN
	#define DEF_FILESERVER_DOMAIN "file.finephon.net"
#endif

#ifndef DEF_VIDEOSERVER_DOMAIN
	#define DEF_VIDEOSERVER_DOMAIN "video.finephon.net"
#endif

#ifndef DEF_BROWSER_MAINURL
	#define DEF_BROWSER_MAINURL "http://web00.finephon.net/ekey/index.action"
#endif

#ifndef DEF_VIDEOSERVER_MAINURL 
	#define DEF_VIDEOSERVER_MAINURL "http://web00.finephon.net/funckey/index.action"
#endif

#ifndef DEF_HELPER_MAINURL
	#define DEF_HELPER_MAINURL "http://web00.finephon.net/helper/index.action"
#endif

#ifndef DEF_NOTIFYEMAIL_MAINURL 
	#define DEF_NOTIFYEMAIL_MAINURL "http://ibss.finephon.com/ibss/getMessage.action"
#endif

#ifndef DEFAULT_STUNSERVER_DOMAIN
	#define DEFAULT_STUNSERVER_DOMAIN "stun01.sipphone.com"
#endif

#ifndef DEFAULT_STUNSERVER_ADDR
	#define DEFAULT_STUNSERVER_ADDR "198.65.166.165"
#endif

#ifndef DEF_CTRLER_PORT 
	#define DEF_CTRLER_PORT					22000
#endif

#ifndef DEF_LOG_SERVER_PORT
	#define DEF_LOG_SERVER_PORT				30000
#endif

#ifndef DEF_SW_SERVER_PORT
	#define DEF_SW_SERVER_PORT				30010
#endif

#ifndef DEF_SW_HEARTBEAT_PORT
	#define DEF_SW_HEARTBEAT_PORT			40010//30015
#endif

#ifndef DEF_FILE_SERVER_PORT
	#define DEF_FILE_SERVER_PORT			30020
#endif

#ifndef DEF_REQ_DOMAIN_SERVER_PROT
	#define DEF_REQ_DOMAIN_SERVER_PROT		DEF_LOG_SERVER_PORT
#endif

#endif	//DEFAULT_APPCONFIG_INFO_H_

