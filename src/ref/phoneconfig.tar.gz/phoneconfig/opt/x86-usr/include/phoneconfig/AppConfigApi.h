#ifndef APPCONFIG_API_DEF
#define APPCONFIG_API_DEF
#include "AppConfigDef.h"

#ifdef __cplusplus
extern "C"
{
#endif
	/************************************************************************************************
	*����configs��Ĭ���û���Ϣ
	*************************************************************************************************/
	#ifdef  SHARED
	int (*set_default_appconfig)(LOCALAPPCONFIG *configs);
	#else
	int set_default_appconfig(LOCALAPPCONFIG *configs);
	#endif

	/************************************************************************************************
	*����configs��Ĭ��ϵͳ��Ϣ
	*************************************************************************************************/
	#ifdef  SHARED
	int (*set_default_sysconfig)(LOCALAPPCONFIG *configs);
	#else
	int set_default_sysconfig(LOCALAPPCONFIG *configs);
	#endif

	/************************************************************************************************
	��ȡ������Ϣ
	*************************************************************************************************/
	#ifdef  SHARED
	int (*read_configs)(LOCALAPPCONFIG *UserConfig, unsigned int sizeConfig);
	#else
	int read_configs(LOCALAPPCONFIG *UserConfig, unsigned int sizeConfig);
	#endif

	/************************************************************************************************
	*д����������Ϣitem����������Ч��д������
	*************************************************************************************************/
	#ifdef  SHARED
	int (*write_configs_item)(CONFIGUPDATE *item);
	#else
	int write_configs_item(CONFIGUPDATE *item);
	#endif

	/************************************************************************************************
	*д����������Ϣ, ����userConfig���ڲ�localappconfig�Ƚϣ����淢���仯������
	*************************************************************************************************/
	#ifdef  SHARED
	int (*write_configs)(LOCALAPPCONFIG *userConfig, unsigned int sizeConfig);
	#else
	int write_configs(LOCALAPPCONFIG *userConfig, unsigned int sizeConfig);
	#endif

	/************************************************************************************************
	*ɾ��������
	*************************************************************************************************/
	#ifdef  SHARED
	int     (*delete_configer)();
	#else
	int     delete_configer();
	#endif

#ifdef __cplusplus
}
#endif


#endif
