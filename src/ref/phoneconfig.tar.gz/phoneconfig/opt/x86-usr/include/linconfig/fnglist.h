/* GLIB - Library of useful routines for C programming
 * Copyright (C) 1995-1997  Peter Mattis, Spencer Kimball and Josh MacDonald
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA 02111-1307, USA.
 */

/*
 * Modified by the GLib Team and others 1997-2000.  See the AUTHORS
 * file for a list of people on the GLib Team.  See the ChangeLog
 * files for a list of changes.  These files are distributed with
 * GLib at ftp://ftp.gtk.org/pub/gtk/. 
 */

#ifndef __G_LIST_H__
#define __G_LIST_H__


#undef	MAX
#define MAX(a, b)  (((a) > (b)) ? (a) : (b))

#undef	MIN
#define MIN(a, b)  (((a) < (b)) ? (a) : (b))

typedef struct _FNGList		FNGList;

struct _FNGList
{
  void * data;
  FNGList *next;
  FNGList *prev;
};

typedef const void *gconstpointer;

typedef gint            (*FNGCompareFunc)         (gconstpointer  a,
                                                 gconstpointer  b);
typedef gint            (*FNGCompareDataFunc)     (gconstpointer  a,
                                                 gconstpointer  b,
						 gpointer       user_data);
typedef void            (*FNGFunc)                (gpointer       data,
                                                 gpointer       user_data);

#ifdef __cplusplus
extern "C" {
#endif
                                                 
/* Doubly linked lists
 */
/*
  void     fng_list_push_allocator (GAllocator       *allocator);
  void     fng_list_pop_allocator  (void);
*/
FNGList*   fng_list_alloc          (void);
void     fng_list_free           (FNGList            *list);
void     fng_list_free_1         (FNGList            *list);
FNGList*   fng_list_append         (FNGList            *list,
				void *          data);
FNGList*   fng_list_prepend        (FNGList            *list,
				void *          data);
FNGList*   fng_list_insert         (FNGList            *list,
				void *          data,
				gint              position);
FNGList*   fng_list_insert_sorted  (FNGList            *list,
				void *          data,
				FNGCompareFunc      func);
FNGList*   fng_list_insert_before  (FNGList            *list,
				FNGList            *sibling,
				void *          data);
FNGList*   fng_list_concat         (FNGList            *list1,
				FNGList            *list2);
FNGList*   fng_list_remove         (FNGList            *list,
				gconstpointer     data);
FNGList*   fng_list_remove_all     (FNGList            *list,
				gconstpointer     data);
FNGList*   fng_list_remove_link    (FNGList            *list,
				FNGList            *llink);
FNGList*   fng_list_delete_link    (FNGList            *list,
				FNGList            *link_);
FNGList*   fng_list_reverse        (FNGList            *list);
FNGList*   fng_list_copy           (FNGList            *list);
FNGList*   fng_list_nth            (FNGList            *list,
				guint             n);
FNGList*   fng_list_nth_prev       (FNGList            *list,
				guint             n);
FNGList*   fng_list_find           (FNGList            *list,
				gconstpointer     data);
FNGList*   fng_list_find_custom    (FNGList            *list,
				gconstpointer     data,
				FNGCompareFunc      func);
gint     fng_list_position       (FNGList            *list,
				FNGList            *llink);
gint     fng_list_index          (FNGList            *list,
				gconstpointer     data);
FNGList*   fng_list_last           (FNGList            *list);
FNGList*   fng_list_first          (FNGList            *list);
guint    fng_list_length         (FNGList            *list);
void     fng_list_foreach        (FNGList            *list,
				FNGFunc             func,
				void *          user_data);
FNGList*   fng_list_sort           (FNGList            *list,
				FNGCompareFunc      compare_func);
FNGList*   fng_list_sort_with_data (FNGList            *list,
				FNGCompareDataFunc  compare_func,
				void *          user_data);
void    *fng_list_nth_data       (FNGList            *list,
				guint             n);


#ifdef __cplusplus
}
#endif

#define fng_list_previous(list)	((list) ? (((FNGList *)(list))->prev) : NULL)
#define fng_list_next(list)	((list) ? (((FNGList *)(list))->next) : NULL)


typedef FNGList FNGSList;
#define fng_slist_prepend fng_list_prepend
#define fng_slist_free fng_list_free
#define fng_slist_free_1  fng_list_free_1
#define fng_slist_reverse fng_list_reverse
#define fng_slist_next fng_list_next
#define fng_slist_foreach fng_list_foreach
#define fng_slist_length fng_list_length

/* to be continued...*/

#endif /* __G_LIST_H__ */
