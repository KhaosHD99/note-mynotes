/*
 QueueAPI.cpp
 wooyaoquan
 2008/01/04
 
 to realize a stack storing bytes array which sustain the mutitread and sycronization.
*/
#ifndef MSS_
#define MSS_

#include <stdio.h>
#include <string.h>

#include "MSTypes.h"

#define MAX_MSS_COUNT	20
#define MAX_MSS_SIZE	1024*64
#define MAX_MSS_LENGTH  0XFFFF

#define SYS_NOWAIT		0
#define SYS_FOREVER		-1

typedef struct MessageStack_Obj {
//	QUE_Obj	dataQue;	/* message queue */
//	QUE_Obj	freeQue;	/* free queue */
//	SEM_Obj	dataSem;	/* count = number of messages */
//	SEM_Obj	freeSem;	/* count = number of free slots */
	int		segid;		/* elements are allocated here */
	uint		size;		/* size of mailbox elements */
	uint		length;		/* number of elements in mailbox */
	void *bytesStack;		//bytesStack
} MessageStack_Obj, *MSS_Handle;

typedef struct MSS_Attrs {
	int		segid;		/* segment for element allocation */
	char 	mssName[64];
} MSS_Attrs;

#ifdef __cplusplus
extern"C"
{
#endif
	MSS_Handle MSS_create(uint size, uint length, MSS_Attrs *attrs);

	void MSS_delete(MSS_Handle mss);

	int MSS_put(MSS_Handle mss, void* msg, int timeout);	//��ջ

	int MSS_get(MSS_Handle mss, void* msg, int timeout);	//��ջ
	
	int MSS_getTop(MSS_Handle mss, void* msg);	//��ȡջ��

	int MSS_getCount(MSS_Handle mss);

	const char* MSS_getName(MSS_Handle mss);

	int MSS_getLength(MSS_Handle mss);

	void MSSS_Infomations();
#ifdef __cplusplus
}
#endif

#endif /* MSS_ */

