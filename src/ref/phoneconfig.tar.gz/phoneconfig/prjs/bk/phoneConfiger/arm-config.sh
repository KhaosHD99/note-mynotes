
#export PRX="$HOME/opt/x86-usr"

#export PKG_CONFIG_PATH=/usr/lib/pkgconfig/:/usr/share/pkgconfig:$PRX/lib/pkgconfig

#arm debug
#####################################
export PRX=/home/$USER
export HOST_PATH=/opt/fn3/rootfs

export PKG_CONFIG_PATH=$PKG_CONFIG_PATH:$HOST_PATH/opt/lib/pkgconfig:$HOST_PATH$PRX/lib/pkgconfig
######################################

./configure \
	--prefix=$PRXi \
	--host=arm-linux

