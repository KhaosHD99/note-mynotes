#ifndef WINDOW_STACK_DEF
#define WINDOW_STACK_DEF

typedef struct GtkWindowInfo
{
	GtkWindow* window;
	char window_name[64];
}GtkWindowInfo;

/***********************************************************
����ջ
***********************************************************/
extern int creat_window_stack();
/***********************************************************
����ʽд��
***********************************************************/
extern int put_window_into_stack(GtkWidget *window);
/***********************************************************
����ʽȡ��
***********************************************************/
extern int get_window_out_stack(GtkWindowInfo *pwindow_info);
/***********************************************************
������ʽ������û��ȡ��
***********************************************************/
extern int read_top_window_stack(GtkWindowInfo *pwindow_info);
/***********************************************************
��ʾ���㴰��
***********************************************************/
extern int show_top_window(GtkWindow* window);

#endif

