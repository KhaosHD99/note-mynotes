#include <stdlib.h>
#include <gtk/gtk.h>
#include "AppConfigApi.h"

#define GET_WIDGET(builder, widgetname) GTK_WIDGET(gtk_builder_get_object(builder, widgetname))
/*********************************************
�ʺ�����ҳ��
*********************************************/

/*********************************************
init account page
*********************************************/
int set_entry_context(GtkWidget* entry, const char*context);
void on_checkbutton_PPPOE_Open_changed(GtkWidget *widget, gpointer checkbutton);

void add_phoneType_combobox(GtkWidget *fixed, int index);

int init_account_page(GtkBuilder *builder)
{
	GtkWidget  *fixed;
	GtkWidget  *gw_phone_num;
	GtkWidget  *gw_phone_type;
	GtkWidget  *gw_phone_exnum;
	GtkWidget  *gw_phone_exkey;
	GtkWidget  *gw_pppoeChecker;
	GtkWidget  *gw_pppoe_account;
	GtkWidget  *gw_pppoe_password;
	
	gw_phone_num = GET_WIDGET(builder, "entry_phone_num");
//	gw_phone_type = GET_WIDGET(builder, "entry_phone_num");
	gw_phone_exnum = GET_WIDGET(builder, "entry_outside_phone_num");
	gw_phone_exkey = GET_WIDGET(builder, "entry_outside_phone_key");
	gw_pppoeChecker = GET_WIDGET(builder, "checkbutton_PPPOE_Open");
	gw_pppoe_account = GET_WIDGET(builder, "entry_PPPOE_account");
	gw_pppoe_password = GET_WIDGET(builder, "entry_PPPOE_password");

	fixed = GTK_WIDGET(gtk_builder_get_object(builder, "fixed_phoneInfo")); 

	LOCALAPPCONFIG config;
	read_configs(&config, sizeof(config));
	printf("read from configs %s\r\n", config.szPhoneNum);

	add_phoneType_combobox(fixed, config.wPhoneNumType);

	set_entry_context(gw_phone_num, config.szPhoneNum);
	set_entry_context(gw_phone_exnum, config.szExtenNum);
	set_entry_context(gw_phone_exkey, config.szExtenKey);
	set_entry_context(gw_pppoe_account, config.szPPPoeAccount);
	set_entry_context(gw_pppoe_password, config.szPPPoePassword);
	
	if(!config.nUsePPPoe)
	{
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(gw_pppoeChecker),FALSE);   
	}
	else
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(gw_pppoeChecker), TRUE);

	g_signal_connect( G_OBJECT(gw_pppoeChecker), "clicked", G_CALLBACK(on_checkbutton_PPPOE_Open_changed), (gpointer)gw_pppoeChecker);
	
}
static GtkWidget *combobox_phonetype;
gboolean combo_changed(GtkComboBox *comboBox, gpointer *gdata);
void add_phoneType_combobox(GtkWidget *fixed, int index)
{
	/*create combobox , append items */
	combobox_phonetype = gtk_combo_box_new_text();
	gtk_combo_box_append_text( GTK_COMBO_BOX(combobox_phonetype ), "普通电话" );
    gtk_combo_box_append_text( GTK_COMBO_BOX(combobox_phonetype ), "汇线通电话" );
    
	gtk_combo_box_set_active( GTK_COMBO_BOX(combobox_phonetype ), index);


	g_signal_connect(GTK_OBJECT(combobox_phonetype), "changed",
		G_CALLBACK(combo_changed), NULL);

	gtk_fixed_put( GTK_FIXED( fixed ), combobox_phonetype, 115, 55 );
	/*show combobox*/
	gtk_widget_show(combobox_phonetype);
	
}

gboolean combo_changed(GtkComboBox *comboBox, gpointer *gdata)
{
	gchar *active = gtk_combo_box_get_active_text(comboBox);

	int reindex = gtk_combo_box_get_active(GTK_COMBO_BOX(combobox_phonetype));
	//gtk_label_set_text(label, active);
	printf("get commbo box active text : %d : %s\r\n", reindex, active);

	CONFIGUPDATE item;
	item.configType = PhoneNum_Type;
	item.wPhoneNumType = reindex;

	write_configs(&item);
}

int set_entry_context(GtkWidget* entry, const char*context)
{
    gint tmp_pos = GTK_ENTRY (entry)->text_length;
    gtk_editable_insert_text (GTK_EDITABLE (entry), context, -1, &tmp_pos);
	return tmp_pos;
}

void on_checkbutton_PPPOE_Open_changed(GtkWidget *widget, gpointer checkbutton)
{

	CONFIGUPDATE item;
	item.configType = USE_PPPOE;
	if(GTK_TOGGLE_BUTTON(widget)->active)
	{
		item.nUsePPPoe = 1;
		printf("set pppoe check : TRUE\n");
	}
	else
	{
		item.nUsePPPoe = 0;
		printf("set pppoe check : FALSE\n");
	}
	write_configs(&item);
}



