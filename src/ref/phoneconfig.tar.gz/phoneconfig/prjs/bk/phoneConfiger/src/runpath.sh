#export DISPLAY=10.10.200.197:0.0
#echo $PATH
#PATH=$PATH:/home/yaoquan/opt/x86-usr/bin
export LD_LIBRARY_PATH=/usr/lib:/home/yaoquan/opt/x86-usr/lib
