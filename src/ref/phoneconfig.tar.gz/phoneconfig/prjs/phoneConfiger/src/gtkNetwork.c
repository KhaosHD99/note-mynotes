#include <stdlib.h>
#include <gtk/gtk.h>
#include "AppConfigApi.h"

#define GET_WIDGET(builder, widgetname) GTK_WIDGET(gtk_builder_get_object(builder, widgetname))
/*********************************************
��������ҳ��
*********************************************/

/*********************************************
init network page
*********************************************/
int set_entry_context_of_network(GtkWidget* entry, const char*context);
void on_radiobutton_auto_group_changed(GtkWidget *widget, gpointer checkbutton);
void on_button_ok_network_clicked(GtkWidget *widget, gpointer button_ok);
void on_button_cancel_network_clicked(GtkWidget *widget, gpointer button_cancel);
void not_editable();
void editable();

LOCALAPPCONFIG config;

GtkWidget  *entry_IP_0;
GtkWidget  *entry_IP_1;
GtkWidget  *entry_IP_2;
GtkWidget  *entry_IP_3;

GtkWidget  *entry_mask_0;
GtkWidget  *entry_mask_1;
GtkWidget  *entry_mask_2;
GtkWidget  *entry_mask_3;

GtkWidget  *entry_gateway_0;
GtkWidget  *entry_gateway_1;
GtkWidget  *entry_gateway_2;
GtkWidget  *entry_gateway_3;

GtkWidget  *entry_dns_0;
GtkWidget  *entry_dns_1;
GtkWidget  *entry_dns_2;
GtkWidget  *entry_dns_3;

GtkWidget  *gw_pppoeChecker;

int init_network_page(GtkBuilder *builder)
{
	GtkWidget  *radiobutton_auto;
	GtkWidget  *radiobutton_static;
	GtkWidget  *button_ok_network;
	GtkWidget  *button_cancel_network;

	radiobutton_auto = GET_WIDGET(builder, "radiobutton_auto");
	radiobutton_static = GET_WIDGET(builder, "radiobutton_static");
	button_ok_network = GET_WIDGET(builder, "button_ok_network");
	button_cancel_network = GET_WIDGET(builder, "button_cancel_network");

	entry_IP_0 = GET_WIDGET(builder, "entry_IP_0");
	entry_IP_1 = GET_WIDGET(builder, "entry_IP_1");
	entry_IP_2 = GET_WIDGET(builder, "entry_IP_2");
	entry_IP_3 = GET_WIDGET(builder, "entry_IP_3");

	entry_mask_0 = GET_WIDGET(builder, "entry_mask_0");
	entry_mask_1 = GET_WIDGET(builder, "entry_mask_1");
	entry_mask_2 = GET_WIDGET(builder, "entry_mask_2");
	entry_mask_3 = GET_WIDGET(builder, "entry_mask_3");

	entry_gateway_0 = GET_WIDGET(builder, "entry_gateway_0");
	entry_gateway_1 = GET_WIDGET(builder, "entry_gateway_1");
	entry_gateway_2 = GET_WIDGET(builder, "entry_gateway_2");
	entry_gateway_3 = GET_WIDGET(builder, "entry_gateway_3");

	entry_dns_0 = GET_WIDGET(builder, "entry_dns_0");
	entry_dns_1 = GET_WIDGET(builder, "entry_dns_1");
	entry_dns_2 = GET_WIDGET(builder, "entry_dns_2");
	entry_dns_3 = GET_WIDGET(builder, "entry_dns_3");	

	gw_pppoeChecker = GET_WIDGET(builder, "checkbutton_PPPOE_Open");

	read_configs(&config, sizeof(config));
	printf("read from configs  IPAddress : %s\r\n", config.szLocalIpAddr);
	printf("read from configs  IPMask    : %s\r\n", config.szLocalIpMask);
	printf("read from configs  Gateway   : %s\r\n", config.szLocalGatewayIp);
	printf("read from configs  DNSServer : %s\r\n", config.szDnsServer);
	printf("read from configs  UseDHCP   : %d\r\n", config.nUseDHCP);

	/* set entry_IP */
	char *entry_IP;	
	entry_IP = strtok(config.szLocalIpAddr, ".");
	set_entry_context_of_account(entry_IP_0, entry_IP);

	entry_IP = strtok(NULL, ".");
	set_entry_context_of_account(entry_IP_1, entry_IP);
	
	entry_IP = strtok(NULL, ".");
	set_entry_context_of_account(entry_IP_2, entry_IP);
	
	entry_IP = strtok(NULL, ".");
	set_entry_context_of_account(entry_IP_3, entry_IP);

	/* set entry_mask */
	char *entry_mask;	
	entry_mask = strtok(config.szLocalIpMask, ".");
	set_entry_context_of_account(entry_mask_0, entry_mask);

	entry_mask = strtok(NULL, ".");
	set_entry_context_of_account(entry_mask_1, entry_mask);
	
	entry_mask = strtok(NULL, ".");
	set_entry_context_of_account(entry_mask_2, entry_mask);
	
	entry_mask = strtok(NULL, ".");
	set_entry_context_of_account(entry_mask_3, entry_mask);

	/* set entry_gateway */
	char *entry_gateway;	
	entry_gateway = strtok(config.szLocalGatewayIp, ".");
	set_entry_context_of_account(entry_gateway_0, entry_gateway);

	entry_gateway = strtok(NULL, ".");
	set_entry_context_of_account(entry_gateway_1, entry_gateway);
	
	entry_gateway = strtok(NULL, ".");
	set_entry_context_of_account(entry_gateway_2, entry_gateway);
	
	entry_gateway = strtok(NULL, ".");
	set_entry_context_of_account(entry_gateway_3, entry_gateway);

	/* set entry_dns */
	char *entry_dns;	
	entry_dns = strtok(config.szDnsServer, ".");
	set_entry_context_of_account(entry_dns_0, entry_dns);

	entry_dns = strtok(NULL, ".");
	set_entry_context_of_account(entry_dns_1, entry_dns);
	
	entry_dns = strtok(NULL, ".");
	set_entry_context_of_account(entry_dns_2, entry_dns);
	
	entry_dns = strtok(NULL, ".");
	set_entry_context_of_account(entry_dns_3, entry_dns);
	
	if(!config.nUseDHCP)
	{
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radiobutton_auto), TRUE);   
		/* set all the entry can not editable */
		not_editable();
	}
	else
	{
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radiobutton_static), TRUE);		
		editable();
	}
	
	/* Connect signals */
	g_signal_connect( G_OBJECT(radiobutton_auto), "clicked", G_CALLBACK(on_radiobutton_auto_group_changed), (gpointer)radiobutton_auto);
	g_signal_connect( G_OBJECT(button_ok_network), "clicked", G_CALLBACK(on_button_ok_network_clicked), (gpointer)button_ok_network);
	g_signal_connect( G_OBJECT(button_cancel_network), "clicked", G_CALLBACK(on_button_cancel_network_clicked), (gpointer)button_cancel_network);
	
}


int set_entry_context_of_network(GtkWidget* entry, const char*context)
{
    gint tmp_pos = GTK_ENTRY (entry)->text_length;
    gtk_editable_insert_text (GTK_EDITABLE (entry), context, -1, &tmp_pos);
	return tmp_pos;
}

void on_radiobutton_auto_group_changed(GtkWidget *widget, gpointer radiobutton)
{
	if( gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(radiobutton)) )
	{
		config.nUseDHCP = 0;
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(gw_pppoeChecker),FALSE);  
		not_editable();
	}
	else
	{
		config.nUseDHCP = 1;
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(gw_pppoeChecker), TRUE);
		editable();
	}
}

void on_button_ok_network_clicked(GtkWidget *widget, gpointer button_ok)
{
	/* save all the changed */
	CONFIGUPDATE item;
	gchar entry_text_tmp[32];

	memset(entry_text_tmp, 0, sizeof(entry_text_tmp));

	if(config.nUseDHCP == 0 || config.nUseDHCP == 1)
	{
		item.configType = USE_DHCP;
		item.nUseDHCP = config.nUseDHCP;
		write_configs_item(&item);
	}

	/* �ж��Ƿ�ʹ�þ�̬IP��ַ�������˳������б���*/
	if(config.nUseDHCP != 1)
	{
		return NULL;
	}

	const gchar *tmp;

	/* ���ؾ�����IP */
	tmp = gtk_entry_get_text( (GtkEntry*)entry_IP_0 );
	if( tmp != NULL )
	{
		sprintf(entry_text_tmp, "%s", tmp);
		tmp = gtk_entry_get_text( (GtkEntry*)entry_IP_1 );
		if( tmp != NULL )
		{
			sprintf(entry_text_tmp, "%s.%s", entry_text_tmp, tmp);
			tmp = gtk_entry_get_text( (GtkEntry*)entry_IP_2 );
			if( tmp != NULL )
			{
				sprintf(entry_text_tmp, "%s.%s", entry_text_tmp, tmp); 
				tmp = gtk_entry_get_text( (GtkEntry*)entry_IP_3 );
				if( tmp != NULL )
				{
					//strcat(entry_text_tmp, ".");
					//strcat(entry_text_tmp, tmp);
					sprintf(entry_text_tmp, "%s.%s", entry_text_tmp, tmp); 
					if( entry_text_tmp != config.szLocalIpAddr )
					{
						item.configType = LOCALIP_ADDR;
						strcpy( item.szLocalIpAddr, entry_text_tmp );	
						//��ʾ���
						printf("\nitem.szLocalIpAddr   : %s\n", item.szLocalIpAddr);	
						write_configs_item(&item);
					}
				}
			}
		}		
	}
	//*/

	/* ���ؾ��������� */
	tmp = gtk_entry_get_text( (GtkEntry*)entry_mask_0 );
	if( tmp != NULL )
	{
		sprintf(entry_text_tmp, "%s", tmp);
		tmp = gtk_entry_get_text( (GtkEntry*)entry_mask_1 );
		if( tmp != NULL )
		{
			sprintf(entry_text_tmp, "%s.%s", entry_text_tmp, tmp);
			tmp = gtk_entry_get_text( (GtkEntry*)entry_mask_2 );
			if( tmp != NULL )
			{
				sprintf(entry_text_tmp, "%s.%s", entry_text_tmp, tmp); 
				tmp = gtk_entry_get_text( (GtkEntry*)entry_mask_3 );
				if( tmp != NULL )
				{
					sprintf(entry_text_tmp, "%s.%s", entry_text_tmp, tmp); 
					if( entry_text_tmp != config.szLocalIpMask )
					{
						item.configType = LOCALIP_MASK;
						strcpy( item.szLocalIpMask, entry_text_tmp );	
						//��ʾ���
						printf("item.szLocalIpMask   : %s\n", item.szLocalIpMask);	
						write_configs_item(&item);
					}
				}
			}
		}		
	}
	//*/

	/* ���ؾ��������� */
	tmp = gtk_entry_get_text( (GtkEntry*)entry_gateway_0 );
	if( tmp != NULL )
	{
		sprintf(entry_text_tmp, "%s", tmp);
		tmp = gtk_entry_get_text( (GtkEntry*)entry_gateway_1 );
		if( tmp != NULL )
		{
			sprintf(entry_text_tmp, "%s.%s", entry_text_tmp, tmp);
			tmp = gtk_entry_get_text( (GtkEntry*)entry_gateway_2 );
			if( tmp != NULL )
			{
				sprintf(entry_text_tmp, "%s.%s", entry_text_tmp, tmp); 
				tmp = gtk_entry_get_text( (GtkEntry*)entry_gateway_3 );
				if( tmp != NULL )
				{
					sprintf(entry_text_tmp, "%s.%s", entry_text_tmp, tmp); 
					if( entry_text_tmp != config.szLocalGatewayIp )
					{
						item.configType = LOCAL_GATEWAY;
						strcpy( item.szLocalGatewayIp, entry_text_tmp );	
						//��ʾ���
						printf("item.szLocalGatewayIp   : %s\n", item.szLocalGatewayIp);	
						write_configs_item(&item);
					}
				}
			}
		}		
	}
	//*/

	/* DNS������IP */
	tmp = gtk_entry_get_text( (GtkEntry*)entry_dns_0 );
	if( tmp != NULL )
	{
		sprintf(entry_text_tmp, "%s", tmp);
		tmp = gtk_entry_get_text( (GtkEntry*)entry_dns_1 );
		if( tmp != NULL )
		{
			sprintf(entry_text_tmp, "%s.%s", entry_text_tmp, tmp);
			tmp = gtk_entry_get_text( (GtkEntry*)entry_dns_2 );
			if( tmp != NULL )
			{
				sprintf(entry_text_tmp, "%s.%s", entry_text_tmp, tmp); 
				tmp = gtk_entry_get_text( (GtkEntry*)entry_dns_3 );
				if( tmp != NULL )
				{
					sprintf(entry_text_tmp, "%s.%s", entry_text_tmp, tmp); 
					if( entry_text_tmp != config.szDnsServer )
					{
						item.configType = DNS_SERVER;
						strcpy( item.szDnsServer, entry_text_tmp );	
						//��ʾ���
						printf("item.szDnsServer   : %s\n", item.szDnsServer);	
						write_configs_item(&item);
					}
				}
			}
		}		
	}
	//*/
}

void on_button_cancel_network_clicked(GtkWidget *widget, gpointer button_cancel)
{
	printf("Cancel network setting \n");
}

void not_editable()
{
	gtk_entry_set_editable( (GtkEntry*)entry_IP_0, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_IP_1, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_IP_2, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_IP_3, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_mask_0, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_mask_1, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_mask_2, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_mask_3, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_gateway_0, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_gateway_1, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_gateway_2, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_gateway_3,FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_dns_0, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_dns_1, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_dns_2, FALSE );
	gtk_entry_set_editable( (GtkEntry*)entry_dns_3, FALSE );
}

void editable()
{
	gtk_entry_set_editable( (GtkEntry*)entry_IP_0, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_IP_1, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_IP_2, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_IP_3, TRUE);
	gtk_entry_set_editable( (GtkEntry*)entry_mask_0, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_mask_1, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_mask_2, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_mask_3, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_gateway_0, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_gateway_1, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_gateway_2, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_gateway_3, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_dns_0, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_dns_1, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_dns_2, TRUE );
	gtk_entry_set_editable( (GtkEntry*)entry_dns_3, TRUE );
}
