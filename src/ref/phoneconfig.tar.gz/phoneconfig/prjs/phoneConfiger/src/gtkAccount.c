#include <stdlib.h>
#include <gtk/gtk.h>
#include "AppConfigApi.h"

#define GET_WIDGET(builder, widgetname) GTK_WIDGET(gtk_builder_get_object(builder, widgetname))
/*********************************************
�ʺ�����ҳ��
*********************************************/

/*********************************************
init account page
*********************************************/

void add_phoneType_combobox(GtkWidget *fixed, int index);
int set_entry_context_of_account(GtkWidget* entry, const char*context);
void on_checkbutton_PPPOE_Open_changed(GtkWidget *widget, gpointer checkbutton);
void on_button_ok_account_clicked(GtkWidget *widget, gpointer button_ok);
void on_button_cancel_account_clicked(GtkWidget *widget, gpointer button_cancel);

LOCALAPPCONFIG config;

GtkWidget  *fixed;
GtkWidget  *gw_phone_num;
GtkWidget  *gw_phone_type;
GtkWidget  *gw_phone_exnum;
GtkWidget  *gw_phone_exkey;
GtkWidget  *gw_pppoeChecker;
GtkWidget  *gw_pppoe_account;
GtkWidget  *gw_pppoe_password;
GtkWidget  *button_ok_account;
GtkWidget  *button_cancel_account;

GtkWidget  *label_PPPOE_open_tips;
GtkWidget  *label_PPPOE_close_tips;
GtkWidget  *label_PPPOE_tips;

GtkWidget  *radiobutton_auto;
GtkWidget  *radiobutton_static;

int init_account_page(GtkBuilder *builder)
{	
	gw_phone_num = GET_WIDGET(builder, "entry_phone_num");
	gw_phone_exnum = GET_WIDGET(builder, "entry_outside_phone_num");
	gw_phone_exkey = GET_WIDGET(builder, "entry_outside_phone_key");
	gw_pppoeChecker = GET_WIDGET(builder, "checkbutton_PPPOE_Open");
	gw_pppoe_account = GET_WIDGET(builder, "entry_PPPOE_account");
	gw_pppoe_password = GET_WIDGET(builder, "entry_PPPOE_password");
	button_ok_account = GET_WIDGET(builder, "button_ok_account");
	button_cancel_account = GET_WIDGET(builder, "button_cancel_account");

	label_PPPOE_open_tips = GET_WIDGET(builder, "label_PPPOE_open_tips");
	label_PPPOE_close_tips = GET_WIDGET(builder, "label_PPPOE_close_tips");
	label_PPPOE_tips = GET_WIDGET(builder, "label_PPPOE_tips");

	radiobutton_auto = GET_WIDGET(builder, "radiobutton_auto");
	radiobutton_static = GET_WIDGET(builder, "radiobutton_static");

	fixed = GTK_WIDGET(gtk_builder_get_object(builder, "fixed_phoneInfo")); 
	
	read_configs(&config, sizeof(config));
	printf("read from configs  PhoneNum      : %s\r\n", config.szPhoneNum);
	printf("read from configs  ExtenNum      : %s\r\n", config.szExtenNum);
	printf("read from configs  ExtenKey      : %s\r\n", config.szExtenKey);
	printf("read from configs  PPPoeAccount  : %s\r\n", config.szPPPoeAccount);
	printf("read from configs  PPPoePassword : %s\r\n", config.szPPPoePassword);

	add_phoneType_combobox(fixed, config.wPhoneNumType);

	set_entry_context_of_account(gw_phone_num, config.szPhoneNum);
	set_entry_context_of_account(gw_phone_exnum, config.szExtenNum);
	set_entry_context_of_account(gw_phone_exkey, config.szExtenKey);
	set_entry_context_of_account(gw_pppoe_account, config.szPPPoeAccount);
	set_entry_context_of_account(gw_pppoe_password, config.szPPPoePassword);
	
	if(!config.nUsePPPoe)
	{
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(gw_pppoeChecker),FALSE);
		gtk_label_set_text(label_PPPOE_tips, gtk_label_get_text( (GtkLabel*)label_PPPOE_close_tips));
	}
	else
	{
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(gw_pppoeChecker), TRUE);
		gtk_label_set_text(label_PPPOE_tips, gtk_label_get_text( (GtkLabel*)label_PPPOE_open_tips));
	}

	/* Connect signals */
	g_signal_connect( G_OBJECT(gw_pppoeChecker), "clicked", G_CALLBACK(on_checkbutton_PPPOE_Open_changed), (gpointer)gw_pppoeChecker);
	g_signal_connect( G_OBJECT(button_ok_account), "clicked", G_CALLBACK(on_button_ok_account_clicked), (gpointer)button_ok_account);
	g_signal_connect( G_OBJECT(button_cancel_account), "clicked", G_CALLBACK(on_button_cancel_account_clicked), (gpointer)button_cancel_account);

}
static GtkWidget *combobox_phonetype;
gboolean combo_changed(GtkComboBox *comboBox, gpointer *gdata);
void add_phoneType_combobox(GtkWidget *fixed, int index)
{
	/*create combobox , append items */
	combobox_phonetype = gtk_combo_box_new_text();
	gtk_combo_box_append_text( GTK_COMBO_BOX(combobox_phonetype ), "普通电话" );
    gtk_combo_box_append_text( GTK_COMBO_BOX(combobox_phonetype ), "汇线通电话" );
    
	gtk_combo_box_set_active( GTK_COMBO_BOX(combobox_phonetype ), index);


	g_signal_connect(GTK_OBJECT(combobox_phonetype), "changed",
		G_CALLBACK(combo_changed), NULL);

	gtk_fixed_put( GTK_FIXED( fixed ), combobox_phonetype, 115, 55 );
	/*show combobox*/
	gtk_widget_show(combobox_phonetype);
	
}

gboolean combo_changed(GtkComboBox *comboBox, gpointer *gdata)
{
	gchar *active = gtk_combo_box_get_active_text(comboBox);

	int reindex = gtk_combo_box_get_active(GTK_COMBO_BOX(combobox_phonetype));
	//gtk_label_set_text(label, active);
	printf("get commbo box active text : %d : %s\r\n", reindex, active);

	config.wPhoneNumType = reindex;

	/*CONFIGUPDATE item;
	item.configType = PhoneNum_Type;
	item.wPhoneNumType = reindex;

	write_configs_item(&item);*/
}

int set_entry_context_of_account(GtkWidget* entry, const char*context)
{
    gint tmp_pos = GTK_ENTRY (entry)->text_length;
    gtk_editable_insert_text (GTK_EDITABLE (entry), context, -1, &tmp_pos);
	return tmp_pos;
}

void on_checkbutton_PPPOE_Open_changed(GtkWidget *widget, gpointer checkbutton)
{
	if(GTK_TOGGLE_BUTTON(widget)->active)
	{
		config.nUsePPPoe = 1;
		gtk_label_set_text(label_PPPOE_tips, gtk_label_get_text( (GtkLabel*)label_PPPOE_open_tips));
		/* change DHCP status */
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radiobutton_static), TRUE);	
		printf("set pppoe check : TRUE\n");
	}
	else
	{
		config.nUsePPPoe = 0;
		gtk_label_set_text(label_PPPOE_tips, gtk_label_get_text( (GtkLabel*)label_PPPOE_close_tips));
		/* change DHCP status */
		gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(radiobutton_auto), TRUE);
		printf("set pppoe check : FALSE\n");
	}
}

void on_button_ok_account_clicked(GtkWidget *widget, gpointer button_ok)
{
	/* save all the changed */
	CONFIGUPDATE item;
	const gchar* entry_text_tmp;

	entry_text_tmp = gtk_entry_get_text( (GtkEntry*)gw_phone_num );
	if( entry_text_tmp != NULL )
	{
		if( entry_text_tmp != config.szPhoneNum )
		{
			item.configType = PHONE_NUM;
			strcpy( item.szPhoneNum, entry_text_tmp );		
			write_configs_item(&item);
		}
	}

	entry_text_tmp = gtk_entry_get_text( (GtkEntry*)gw_phone_exnum );
	if( entry_text_tmp != NULL )
	{
		if( entry_text_tmp != config.szExtenNum )
		{
			item.configType = EXTEN_NUM;
			strcpy( item.szExtenNum, entry_text_tmp );		
			write_configs_item(&item);
		}
	}

	entry_text_tmp = gtk_entry_get_text( (GtkEntry*)gw_phone_exkey );
	if( entry_text_tmp != NULL )
	{
		if( entry_text_tmp != config.szExtenKey )
		{
			item.configType = Exten_Key;
			strcpy( item.szExtenKey, entry_text_tmp );		
			write_configs_item(&item);
		}
	}

	if(config.wPhoneNumType == 0 || config.wPhoneNumType == 1)
	{
		item.configType = PhoneNum_Type;
		item.wPhoneNumType = config.wPhoneNumType;
		write_configs_item(&item);
	}

	if(config.nUsePPPoe == 0 || config.nUsePPPoe == 1)
	{
		item.configType = USE_PPPOE;
		item.nUsePPPoe = config.nUsePPPoe;		
		write_configs_item(&item);

		if(config.nUsePPPoe == 0)
		{
			config.nUseDHCP = 0;
		}
		else
			config.nUseDHCP = 1;

		item.configType = USE_DHCP;
		item.nUseDHCP = config.nUseDHCP;	
		write_configs_item(&item);
	}	

	entry_text_tmp = gtk_entry_get_text( (GtkEntry*)gw_pppoe_account );
	if( entry_text_tmp != NULL )
	{
		if( entry_text_tmp != config.szPPPoeAccount )
		{
			item.configType = PPPOE_ACCOUNT;
			strcpy( item.szPPPoeAccount, entry_text_tmp );		
			write_configs_item(&item);
		}
	}

	entry_text_tmp = gtk_entry_get_text( (GtkEntry*)gw_pppoe_password );
	if( entry_text_tmp != NULL )
	{
		if( entry_text_tmp != config.szPPPoePassword )
		{
			item.configType = PPPOE_PASSWORD;
			strcpy( item.szPPPoePassword, entry_text_tmp );		
			write_configs_item(&item);
		}
	}
}

void on_button_cancel_account_clicked(GtkWidget *widget, gpointer button_cancel)
{
	printf("Cancel account setting \n");
}



