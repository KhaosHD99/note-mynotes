#include <stdlib.h>
#include <gtk/gtk.h>
#include "AppConfigApi.h"

#define GET_WIDGET(builder, widgetname) GTK_WIDGET(gtk_builder_get_object(builder, widgetname))
/*********************************************
�绰��Ϣҳ��
*********************************************/

/*********************************************
init sysinfo page
*********************************************/

int init_sysinfo_page(GtkBuilder *builder)
{
	GtkWidget  *label_body_code;
	GtkWidget  *label_local_phone_number;
	GtkWidget  *label_hardware_version;
	GtkWidget  *label_software_version;
	GtkWidget  *labe_sys_language;
	
	label_body_code = GET_WIDGET(builder, "label_body_code");
	label_local_phone_number = GET_WIDGET(builder, "label_local_phone_number");
	label_hardware_version = GET_WIDGET(builder, "label_hardware_version");
	label_software_version = GET_WIDGET(builder, "label_software_version");
	labe_sys_language = GET_WIDGET(builder, "labe_sys_language");

	LOCALAPPCONFIG config;
	read_configs(&config, sizeof(config));
	printf("read from configs %s\r\n", config.szPhoneMacode);

	gtk_label_set_text(label_body_code, config.szPhoneMacode);
	gtk_label_set_text(label_local_phone_number, config.szPhoneNum);
	//gtk_label_set_text(label_hardware_version, config.nHardWareVersion);
	//gtk_label_set_text(label_software_version, config.szPhoneNum);
	//gtk_label_set_text(labe_sys_language, config.szPhoneNum);
	
	
}



