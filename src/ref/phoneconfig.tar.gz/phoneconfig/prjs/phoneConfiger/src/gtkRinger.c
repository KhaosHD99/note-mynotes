#include <stdlib.h>
#include <gtk/gtk.h>
#include "AppConfigApi.h"

#define GET_WIDGET(builder, widgetname) GTK_WIDGET(gtk_builder_get_object(builder, widgetname))
/*********************************************
��������ҳ��
*********************************************/

enum{
	clo_num = 0,
    col_name,
    n_cols
};

void model_data_new(GtkTreeModel* store, const guint num, const gchar* name ) {
    GtkTreeIter iter;
    gtk_list_store_append(GTK_LIST_STORE(store), &iter);
    gtk_list_store_set(GTK_LIST_STORE(store), &iter,
					   clo_num, num,
                       col_name, name,
                       -1);
}

GtkTreeModel* create_model() {
    GtkListStore  *store;
    store = gtk_list_store_new ( n_cols, G_TYPE_UINT, G_TYPE_STRING );
    return GTK_TREE_MODEL( store );
}

void arrange_tree_view(GtkWidget* view) {
    GtkCellRenderer* renderer;	
	
    renderer = gtk_cell_renderer_text_new ();
    // col 1: date
    gtk_tree_view_insert_column_with_attributes(
        GTK_TREE_VIEW(view), -1, "Number", renderer, "text", clo_num, NULL);

    // col 2: name
    gtk_tree_view_insert_column_with_attributes(
        GTK_TREE_VIEW(view), -1, "Song name", renderer, "text", col_name, NULL);

}

/*********************************************
init ringer page
*********************************************/

int init_ringer_page(GtkBuilder *builder)
{
	GtkWidget  *view;
	
	view = GET_WIDGET(builder, "treeview_ringer");

	LOCALAPPCONFIG config;
	read_configs(&config, sizeof(config));
	printf("read from configs %s\r\n", config.szRingFile);

	char *RingFileName;	
	RingFileName = config.szRingFile;
	if ( !strrchr(RingFileName,'/') )
		return -1;
	/*char *RingFileName;	
	RingFileName = strtok(config.szRingFile, "/");
	RingFileName = strtok(NULL, "");
	printf("RingFileName  : %s \n", RingFileName);
	while(1)
	{	
		if(strchr( RingFileName, '/' ))
		{
			RingFileName = strtok(NULL, "/");
		}
		else
			break;
	}*/

	/* arrange view columns */
	arrange_tree_view(view);

    /* set model */
    GtkTreeModel* store = create_model();
    gtk_tree_view_set_model ( GTK_TREE_VIEW(view),  store);
    model_data_new(store, 0, "天使的翅膀");
    model_data_new(store, 1, "北京欢迎你");
    model_data_new(store, 2, "光辉岁月");
    model_data_new(store, 3, "真的爱你");
	model_data_new(store, 4, RingFileName);

	//g_signal_connect( G_OBJECT(gw_pppoeChecker), "clicked", G_CALLBACK(on_checkbutton_PPPOE_Open_changed), (gpointer)gw_pppoeChecker);
	
}

