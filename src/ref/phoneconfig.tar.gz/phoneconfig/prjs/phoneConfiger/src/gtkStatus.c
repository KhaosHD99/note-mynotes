#include <stdlib.h>
#include <gtk/gtk.h>
#include "AppConfigApi.h"

#define GET_WIDGET(builder, widgetname) GTK_WIDGET(gtk_builder_get_object(builder, widgetname))
/*********************************************
����״̬ҳ��
*********************************************/

/*********************************************
init status page
*********************************************/

int init_status_page(GtkBuilder *builder)
{
	GtkWidget  *label_register;
	GtkWidget  *label_link;
	GtkWidget  *label_login;
	GtkWidget  *label_internet;
	GtkWidget  *labe_network;
	
	label_register = GET_WIDGET(builder, "label_register");
	label_link = GET_WIDGET(builder, "label_link");
	label_login = GET_WIDGET(builder, "label_login");
	label_internet = GET_WIDGET(builder, "label_internet");
	labe_network = GET_WIDGET(builder, "labe_network");

	LOCALAPPCONFIG config;
	read_configs(&config, sizeof(config));
	printf("read from configs %s\r\n", config.szPhoneNum);

	/*gtk_label_set_text(label_register, config.szPhoneMacode);
	gtk_label_set_text(label_link, config.szPhoneNum);
	gtk_label_set_text(label_login, config.nHardWareVersion);
	gtk_label_set_text(label_internet, config.szPhoneNum);
	gtk_label_set_text(labe_network, config.szPhoneNum);*/
	
	
}



