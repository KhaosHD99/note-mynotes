export PRX=/home/yaoquan/opt/x86-usr

./configure \
	--prefix=$PRX \
	--host=arm-linux


