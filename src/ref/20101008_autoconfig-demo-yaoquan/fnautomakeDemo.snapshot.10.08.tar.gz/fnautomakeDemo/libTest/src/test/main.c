#include <stdlib.h>
#include <stdio.h>
#include "ClassAApi.h"

int main(int argc, char *argv[])
{

	printf("run test prj\r\n");

	showClassATest();

	return 0;
}



