#include <stdio.h>
#include<stdlib.h>
#include <string.h>
#include "ClassA.h"


ClassA::ClassA() 
{

		printf("create Class A\r\n");
}

ClassA::~ClassA()
{
	printf("release Class A\r\n");

}

int ClassA::showTest()
{

	printf("call function : %s\r\n", __FUNCTION__);
	return 0;
}



