/*
 wooyaoquan
 2008/01/04
 
 to realize a stack storing bytes array which sustain the mutitread and sycronization.
*/
#include <stdio.h>
#include <string.h>
#include "ClassA.h"
#include "ClassAApi.h"

//int showClassATest( )
extern "C" int showClassATest( )
{
	ClassA *a = new ClassA();
  
  if(a)
	{
    int ret = a->showTest();
		
		delete a;

		return ret;
  }
	return -1;

}



