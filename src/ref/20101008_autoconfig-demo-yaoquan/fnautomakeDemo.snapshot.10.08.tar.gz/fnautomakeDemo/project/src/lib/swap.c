#ifdef __cplusplus
extern "C"
{
#endif

#include <stdio.h>
void swap(int* x, int* y)
{
	int temp = 0;
	temp = *x;
	*x = *y;
	*y = temp;
}


#ifdef __cplusplus
}
#endif

