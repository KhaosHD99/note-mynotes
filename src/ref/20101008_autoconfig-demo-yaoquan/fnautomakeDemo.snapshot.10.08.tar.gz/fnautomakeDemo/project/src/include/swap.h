#ifndef _SWAP_H
#define _SWAP_H

#ifdef __cplusplus
extern "C"
{
#endif


void swap(int*,int*);


#ifdef _cplusplus
}
#endif

#endif

