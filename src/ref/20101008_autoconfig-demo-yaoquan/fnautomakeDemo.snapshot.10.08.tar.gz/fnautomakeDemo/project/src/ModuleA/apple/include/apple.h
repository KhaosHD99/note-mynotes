#ifndef _APPLE_H
#define _APPLE_H

#ifdef __cplusplus
extern "C"
{
#endif

struct number
{
	int x;
	int y;
	pthread_rwlock_t rwLock;
};

int addvec(struct number* num);
void swqpvec(struct number* num);

#ifdef __cplusplus
}
#endif

#endif
