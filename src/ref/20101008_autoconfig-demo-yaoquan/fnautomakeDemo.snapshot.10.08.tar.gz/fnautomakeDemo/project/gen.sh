#!/bin/bash
aclocal
autoheader
autoconf
automake -a

