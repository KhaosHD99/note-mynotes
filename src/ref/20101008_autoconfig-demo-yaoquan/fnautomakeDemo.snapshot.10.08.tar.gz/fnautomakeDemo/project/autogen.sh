#! /bin/sh
set -x

aclocal

#libtoolize --force # share lib 

autoheader

automake --foreign --add-missing --copy

autoconf

