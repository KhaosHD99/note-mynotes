#!/bin/bash -x

VERSION="0.52"

if [ -d src ] 
then
	if [ ! -f configure ] 
	then
		echo building configure script before creating tarball
		sh autogen.sh
	fi
	echo Building distribution files for AP Radar $VERSION
	cd ..
	rm -rf apradar-$VERSION
	cp -r apradar apradar-$VERSION
	cd apradar-$VERSION
	make clean
	rm -rf CVS */CVS 
	rm -rf autom4te.cache
	cd ..
	pwd
	tar czf apradar-$VERSION.tar.gz apradar-$VERSION

	# The tarball fed to the RPM Builder needs to have a makefile
	cd apradar-$VERSION
	if [ ! -f Makefile ] 
	then
		echo building makefile
		./configure
	fi
	cd ..
	tar cvzf /usr/src/RPM/SOURCES/apradar-$VERSION.tar.gz apradar-$VERSION
	ls -l /usr/src/RPM/SOURCES/apradar-$VERSION.tar.gz

	# build it
	rpm --ba apradar/misc/apradar-$VERSION.spec
	mv /usr/src/RPM/RPMS/i586/apradar-$VERSION-1.i586.rpm .
	mv /usr/src/RPM/SRPMS/apradar-$VERSION-1.src.rpm .

else
		echo run this from the main apradar directory
fi


