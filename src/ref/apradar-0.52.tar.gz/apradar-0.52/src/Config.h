/* AP Radar
 * June 2002
 * donald.g.park@iname.com
 *
 * Released under the MIT Open Source Licence
 * http://www.opensource.org/licenses/mit-license.php
 */

#ifndef _APRADAR_CONFIG_H
#define _APRADAR_CONFIG_H

#include <vector>
#include "AccessPoint.h"
#include "NetworkInterface.h"
#include "Main.h"

class AccessPointList;
class Window;

class Config
{
    private:
        Window* win;
        Main* main;
        AccessPointList* aplist;
        NetworkInterface* interface;
        bool PhantomAPs;
        string* dirname;
        int skfd;
        string* dhcpCommand;
        bool config_ping_gateway;
        bool config_run_dhcp;

    public:
        Config();

        vector<AccessPoint*> APs;
        void setMain(Main*);
        Main* getMain();
        void setSkfd(int);
        int getSkfd();
        void setDirname(string*);
        string* getDirname();
        void setPhantomAPs(bool);
        bool getPhantomAPs();
        void setWindow(Window*);
        Window* getWindow();
        void setInterface(NetworkInterface*);
        NetworkInterface* getInterface();
        void setAPs(AccessPointList*);
        void syncAPList(AccessPointList*);
        AccessPointList* getAPs();
        NetworkInterface* findInterface();
        void setDhcpCommand(string*);
        string* getDhcpCommand();
        void setPingGateway(bool);
        bool getPingGateway();
        void setRunDhcp(bool);
        bool getRunDhcp();
        void saveConfigOptions();
        void loadConfigOptions();
};

#include "Window.h"
#endif

/*
 * Copyright (c) 2002 Donald G. Park
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
