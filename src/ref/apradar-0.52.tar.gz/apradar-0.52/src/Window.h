/* AP Radar
 * June 2002
 * donald.g.park@iname.com
 *
 * Released under the MIT Open Source Licence
 * http://www.opensource.org/licenses/mit-license.php
 */
#ifndef _APRADAR_WINDOW_H
#define _APRADAR_WINDOW_H

#include <gtkmm-2.0/gtkmm/window.h>
#include <gtkmm-2.0/gtkmm/button.h>
#include <gtkmm-2.0/gtkmm/box.h>
#include <gtkmm-2.0/gtkmm/frame.h>
#include <gtkmm-2.0/gtkmm/menu.h>
#include <gtkmm-2.0/gtkmm/tooltips.h>

#include "Config.h"
#include "NetworkInterface.h"

class Window : public Gtk::Window
{
    Config* conf;
    AccessPointList* aplist;

    //    Gtk::Button *button;
    Gtk::Box *main_vbox;
    Gtk::Box *logo_hbox;
    Gtk::Box *aplist_vbox;
    Gtk::Box *eth_vbox;
    Gtk::Box *dhcp_vbox;
    Gtk::Frame *eth_frame;
    Gtk::Frame *aplist_frame;
    Gtk::Frame *config_frame;
    Gtk::Menu* menu;
    bool config_frame_flag;
    Gtk::Tooltips tooltips;                       // note not a pointer
    Gtk::Button *default_delay_button;
    int width, height;

    public:
        Window ();
        ~Window ();

        virtual gint delete_event_impl (GdkEventAny*);
        void init();
        void on_button_clicked (char*);
        void wrench_button_clicked(int);
        void ping_config_clicked(Gtk::CheckButton*);
        void dhclient_config_clicked(Gtk::CheckButton*);
        void AP_button_clicked (AccessPoint*);
        void add_AP(AccessPoint*);
        void refresh_AP(AccessPoint*);
        void remove_AP(AccessPoint*);
        void setConfig(Config*);
        void syncAPList(AccessPointList*);
        void setInterface(NetworkInterface*);
        bool goIdle();
        void DHCPon();
        void DHCPoff();

};
#endif
