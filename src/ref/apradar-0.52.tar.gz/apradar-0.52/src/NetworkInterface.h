/* AP Radar
 * June 2002
 * donald.g.park@iname.com
 *
 * Released under the MIT Open Source Licence
 * http://www.opensource.org/licenses/mit-license.php
 */

#ifndef _APRADAR_NETWORKINTERFACE_H
#define _APRADAR_NETWORKINTERFACE_H

#include <string>
#include <time.h>
#include "AccessPoint.h"
#include "Parent.h"
#include "Ipv4Address.h"

class NetworkInterface : public Parent
{
    private:
        string* name;                             // UNIX Interface name
        string* drivername;
        // This class does not keep this data locally.
        // Getters and setters read and write directly to
        // the wireless driver.
        //string* essid;
        //int mode;
        //int wep;
        //float frequency
        //char bssid[6];

        // state variables for ping
        int nPingId;
        int nPingSeq;
        time_t gatewayPingTime;

    public:
        NetworkInterface();
        void setName(string*);
        string* getName();
        void associate(AccessPoint*);
        void setEssid(string*);
        string* getEssid();
        void setBssid(char*);
        char* getBssid();
        void setMode(int);
        int getMode();
        string* getModeString();
        void setWEP(int);
        int getWEP();
        void setFrequency(float);
        float getFrequency();
        void ping(string*);
        void ping(Ipv4Address*);
        Ipv4Address* getIpv4Address();
        Ipv4Address* getIpv4Gateway();
        void getStats();
        string* getDriverName();
        string* findDefaultRoute();
        const time_t getGatewayPingTime();
        void setGatewayPingTime(time_t);

    private:
        unsigned short ipchecksum(unsigned short*, int);
};
#endif

/*
 * Copyright (c) 2002 Donald G. Park
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
