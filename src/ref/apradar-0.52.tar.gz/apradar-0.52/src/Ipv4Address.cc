/* AP Radar
 * June 2002
 * donald.g.park@iname.com
 *
 * Released under the MIT Open Source Licence
 * http://www.opensource.org/licenses/mit-license.php
 */

#include <iostream>
#include <sstream>
#include <string>
#include "Ipv4Address.h"

// The constructor
Ipv4Address::Ipv4Address()
{
    o[0] = 0;
    o[1] = 0;
    o[2] = 0;
    o[3] = 0;
}


Ipv4Address::Ipv4Address(int a, int b, int c, int d)
{
    //    cout << "Ipv4Address here - " << a << "."
    //        << b << "."
    //        << c << "."
    //        << d << endl;

    o[0] = a;
    o[1] = b;
    o[2] = c;
    o[3] = d;
}


// The destructor
Ipv4Address::~Ipv4Address()
{
}


void Ipv4Address::setOctet(int i, int a)
{
    if(i >=0 && i <=3) {
        o[i] = a;
    }
}


unsigned int Ipv4Address::getOctet(int i)
{
    if(i >=0 && i <=3) {
        return o[i];
    }
    return 0;
}


string* Ipv4Address::toString()
{
    ostringstream o;
    o << getOctet(0);
    o << ".";
    o << getOctet(1);
    o << ".";
    o << getOctet(2);
    o << ".";
    o << getOctet(3);
    return new string(o.str());
}


/*
 * Copyright (c) 2002 Donald G. Park
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
