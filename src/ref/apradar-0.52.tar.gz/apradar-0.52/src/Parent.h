/* AP Radar
 * June 2002
 * donald.g.park@iname.com
 *
 * Released under the MIT Open Source Licence
 * http://www.opensource.org/licenses/mit-license.php
 */
#ifndef _APRADAR_PARENT_H
#define _APRADAR_PARENT_H

//#include "Config.h"
class Config;

class Parent
{
    protected:
        Config* config;

    public:
        void setConfig(Config*);
        Config* getConfig();
};
#endif
