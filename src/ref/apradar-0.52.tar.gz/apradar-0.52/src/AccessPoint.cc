/* AP Radar
 * June 2002
 * donald.g.park@iname.com
 *
 * Released under the MIT Open Source Licence
 * http://www.opensource.org/licenses/mit-license.php
 */

#include "AccessPoint.h"
#include <iostream>
#include <string>
#include <stdio.h>

AccessPoint::AccessPoint()
{
    wep = -1;                                     // unknown
    essid = new string("uninitialized essid");
    mode = -1;
    frequency = 0;

};

void AccessPoint::setEssid(string *id)
{
    essid = id;
}


string* AccessPoint::getEssid()
{
    return essid;
}


void AccessPoint::setWEP(int wepyesno)
{
    wep = wepyesno;
}


int AccessPoint::getWEP()
{
    return wep;
}


void AccessPoint::setBssid(char* id)
{
    bssid[0] = id[0];
    // colon
    bssid[1] = id[1];
    // colon
    bssid[2] = id[2];
    // colon
    bssid[3] = id[3];
    // colon
    bssid[4] = id[4];
    // colon
    bssid[5] = id[5];
}


char* AccessPoint::getBssid()
{
    return bssid + '\0';
}


void AccessPoint::setMode(int m)
{
    mode = m;
}


int AccessPoint::getMode()
{
    return mode;
}


string* AccessPoint::getModeString()
{
    if(mode == 1) {
        return new string("ad-hoc");
    }
    if(mode == 2) {
        return new string("managed");
    }
    if(mode == 3) {
        return new string("master");
    }
    return new string("unknown");
}


string* AccessPoint::getBssidString()
{
    char buf[17];
    sprintf(buf, "%hhX:%hhX:%hhX:%hhX:%hhX:%hhX", bssid[0], bssid[1], bssid[2], bssid[3], bssid[4], bssid[5]);
    return new string(buf);
}


bool AccessPoint::operator==(AccessPoint b)
{
    // the BSSID is a unique identifier for a wireless node
    for(int i=0; i<6; i++) {
        if(getBssid()[i] != (b.getBssid())[i]) {
            return false;
        }
    }
    return true;
}


void AccessPoint::setFrequency(float f)
{
    frequency = f;
}


float AccessPoint::getFrequency()
{
    return frequency;
}


unsigned int AccessPoint::getChannel()
{
    unsigned int channel;
    unsigned int freq;

    freq = (unsigned int)getFrequency() / 1000000;

    channel = (unsigned int)(freq - 2407U) / 5U;

    return channel;
}


void AccessPoint::printValues()
{
    cout << " BSSID " << *getBssidString() ;
    cout <<  " ESSID " << *getEssid();
    cout << " mode: " << getMode();
    cout << " wep: " << getWEP() << endl;
}


void AccessPoint::setSignalStrength(int ss)
{
    signalStrength = ss;
}


int AccessPoint::getSignalStrength()
{
    return signalStrength;
}


void AccessPoint::sampleValues()
{
    // Set sample values for testing
    setEssid(new string("Simulation Mode"));
    setMode(0);
    setWEP(0);
    setFrequency(2410000000.0);
    char bssid[6] = { 0, 0, 0, 0, 0, 0 };
    setBssid(bssid);

}


void AccessPoint::setUiRow(Gtk::Box* row)
{
    uiRow = row;
}


Gtk::Box* AccessPoint::getUiRow()
{
    return uiRow;
}


bool AccessPoint::hasDifferences(AccessPoint* o)
{
    // compare the values
    if(getSignalStrength() != o->getSignalStrength()) {
        cout << "new signal strength" << endl;
        return true;
    }

    return false;
}


void AccessPoint::updateValues(AccessPoint* o)
{
    // update the values from a scan

    // signal strength
    setSignalStrength(o->getSignalStrength());
}


/*
 * Copyright (c) 2002 Donald G. Park
 * The MIT License
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */
