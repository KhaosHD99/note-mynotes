# i made this myself. its probably all wrong
aclocal
autoconf
automake -a
echo now run ./configure and make
