#ifndef CLASS_A_DEF_H
#define CLASS_A_DEF_H

class ClassA
{
public:
	ClassA();
	~ClassA();
	int showTest();
};

#endif

