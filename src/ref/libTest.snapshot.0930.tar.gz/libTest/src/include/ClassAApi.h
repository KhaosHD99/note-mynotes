/*
 wooyaoquan
 2008/01/04
 
 to realize a stack storing bytes array which sustain the mutitread and sycronization.
*/
#ifndef API_
#define API_

#include <stdio.h>
#include <string.h>

#ifdef __cplusplus
extern"C"
{
#endif

	int showClassATest( );

#ifdef __cplusplus
}
#endif

#endif

