#ifndef CONTACT_DEF
#define CONTACT_DEF

#include "lpconfig.h"
#ifdef HAVE_GLIB
#include <glib.h>
#else
#include "uglib.h"
#endif

#define MAX_CONTACT_COUNT	10
#define MAX_NAME_LEN		64	//��������
#define MAX_PHONE_COUNT		10	//��ϵ�˿�ӵ�еĺ�����
#define MAX_PHONENUM_LEN	64	//�绰���볤��
#define MAX_EMAIL_COUNT		10	//��ϵ�˿�ӵ�е��ʺ���
#define MAX_EMAIL_LEN		64	//�ʺų���
#define MAX_VOIP_LEN		64	//voip�ʺų���
#define MAX_IM_LEN			64	//IM�ʺų���
#define MAX_ADDRESS_LEN		128	//��ַ����

#define CONTACT_PATHNAME       "Contacts.cfg"
#define CONTACT_INDEX_PREFIX   "contact_"
#define PHONE_INDEX_PREFIX     "phone_"
#define EMAIL_INDEX_PREFIX     "email_"
#define CONTACT_FAMILY_NAME    "family_name"
#define CONTACT_GIVEN_NAME     "given_name"
#define CONTACT_GROUP          "group"
#define CONTACT_PHONE_COUNT    "phonecount"
#define CONTACT_EMAIL_COUNT    "emailcount"
#define CONTACT_VOIP           "voip"
#define CONTACT_IM             "im"
#define CONTACT_ADDRESS        "address"

//enum str
#define GT_FAMILY_STR          "GT_FAMILY"
#define GT_RELATIVES_STR       "GT_RELATIVES"
#define GT_COLLEAGUES_STR      "GT_COLLEAGUES"
#define GT_FRIENDS_STR         "GT_FRIENDS"
#define GT_MANUFACTURERS_STR   "GT_MANUFACTURERS"
#define GT_OTHER_STR           "GT_OTHER"
#define GT_CUSTOM_STR          "GT_CUSTOM"

#define PT_HOME_STR            "PT_HOME"
#define PT_MOBILE_STR          "PT_MOBILE"
#define PT_WORK_STR            "PT_WORK"
#define PT_WORK_FAX_STR        "PT_WORK_FAX"
#define PT_HOME_FAX_STR        "PT_HOME_FAX"
#define PT_OTHER_STR           "PT_OTHER"
#define PT_CUSTOM_STR          "PT_CUSTOM"

#define EMT_HOME_STR           "EMT_HOME"
#define EMT_WORK_STR           "EMT_WORK"
#define EMT_OTHER_STR          "EMT_OTHER"
#define EMT_CUSTOM_STR         "EMT_CUSTOM"
                        
typedef enum PhoneType
{
    PT_NONE,
	PT_HOME,					//��ͥ
	PT_MOBILE,					//�ƶ�
	PT_WORK,					//��λ
	PT_WORK_FAX,				//��λ����
	PT_HOME_FAX,				//סլ����
	PT_OTHER,					//����
	PT_CUSTOM					//�Զ���
}PhoneType;

typedef enum EMailType
{
    EMT_NONE,                   
	EMT_HOME,					//��ͥ
	EMT_WORK,					//��λ
	EMT_OTHER,					//����
	EMT_CUSTOM					//�Զ���
}EMailType;

typedef enum GroupType
{
	GT_FAMILY,					//��ͥ
	GT_RELATIVES,				//����
	GT_COLLEAGUES,				//ͬ��
	GT_FRIENDS,					//����
	GT_MANUFACTURERS,			//����
	GT_OTHER,					//����
	GT_CUSTOM					//�Զ���
}GroupType;

typedef struct stName
{
	char szgiven_name[MAX_NAME_LEN];	//��
	char szfamily_name[MAX_NAME_LEN];	//��
}Name;

typedef struct stPhone
{
	PhoneType type;
	char szphone[MAX_PHONENUM_LEN];
}Phone;

typedef struct stEmail
{
	EMailType type;
	char szemail[MAX_EMAIL_LEN];
}Email;

typedef struct stContact
{
	Name name;
	GroupType type;					      
	Phone phones[MAX_PHONE_COUNT];
	Email emails[MAX_EMAIL_COUNT];
	char szvoip[MAX_VOIP_LEN];
	char szim[MAX_IM_LEN];
	char szaddress[MAX_ADDRESS_LEN];
}Contact;

class CContactsManager
{
	private:
		LpConfig *contacts_lpconfig;
	 	int buf_count;
	 	Contact **contact_buf;
	 	static CContactsManager *contacts_instance;
		
    private:
		CContactsManager();
		~CContactsManager();
	 	void init();
	    void uninit();
 
	public:
	 	static CContactsManager *get_instance();

		//basic
		void read_contact();
		Contact* get_section_from_config_file(int index);
		int write_contact_item(Contact *item, int index);
		int sync_contact_config();
		
		//CRUD
		int get_contact_count();
		int get_contact_buf_count();
	 	int get_contact_by_index(Contact **contact,	int index);					 
	 	int get_contact_by_name(Contact **contact,	const char *szname);
	 	int get_contact_by_letter(Contact **contact, const char *szletter);		 
	 	int get_contact_by_phone(Contact **contact,	const char *szphone);		 
	 									
	 	int update_contact_by_index(Contact *contact, int index);				
	 
	 	int add_contact(Contact *contact);
	 	int add_contact_by_index(Contact *contact, int index);
	 	int delete_contact_by_index(int index);
	 	int delete_contact_all();

		//help
		void update_buf_count();
		
		//validate
        int validate();
		
		//sort
	 	void sort_by_name();													 						
	 	void sort_by_letter();

		//enum
		const gchar* __grouptype_enum_to_str(int enum_val);
		const gchar* __phonetype_enum_to_str(int enum_val);
		const gchar* __emailtype_enum_to_str(int enum_val);

		GroupType __grouptype_str_to_enum(const gchar *enum_str);
		PhoneType __phonetype_str_to_enum(const gchar *enum_str);
		EMailType __emailtype_str_to_enum(const gchar *enum_str);
};
#endif
