#include <string.h>
#include <stdio.h>
#include <time.h>

#include "contact.hpp"
#include "calllog.hpp"
#include "quickdial.hpp"
#include "blacklist.hpp"
#include "commonphone.hpp"
#include "config.hpp"
#include "LogMsg.hpp"

#ifdef __cplusplus
extern "C" 
{
#endif

/**************************************************************************************************/
/**************************************** contact ***************************************************/
/**************************************************************************************************/
int get_contact_count()
{
	CContactManager *manager = CContactManager::get_instance();
   
    return manager->get_contact_count();
}

int get_contact_by_index(Contact *contact,	int index)
{
	CContactManager *manager = CContactManager::get_instance();
    
    return manager->get_contact_by_index(contact, index);
}		
	 
int get_contact_by_name(Contact *contact,	const char *szname)
{
	CContactManager *manager = CContactManager::get_instance();
		
    return manager->get_contact_by_name(contact, szname);
}

int get_contact_by_letter(Contact *contact, const char *szletter) 
{
	CContactManager *manager = CContactManager::get_instance();

	return manager->get_contact_by_letter(contact, szletter);
}

int get_contact_by_phone(Contact *contact,	const char *szphone) 
{
	CContactManager *manager = CContactManager::get_instance();
    
    return manager->get_contact_by_phone(contact, szphone);
}			 									

int add_contact(Contact* contact)
{
    CContactManager *manager = CContactManager::get_instance();
    
    return manager->add_contact(contact);
}

int add_contact_by_index(Contact *contact, int index)
{
	CContactManager *manager = CContactManager::get_instance();
    
	return manager->add_contact_by_index(contact, index);
}

int update_contact_by_index(Contact *contact, int index)
{
  	CContactManager *manager = CContactManager::get_instance();
    
	return manager->update_contact_by_index(contact, index);
}
			 	
int delete_contact_by_index(int index)
{
	CContactManager *manager = CContactManager::get_instance();
    
	return manager->delete_contact_by_index(index);
}
int delete_contact_all()
{
	CContactManager *manager = CContactManager::get_instance();
    
    return manager->delete_contact_all();
}

/**************************************************************************************************/
/**************************************** calllog *************************************************/
/**************************************************************************************************/
int get_calllog_count()
{
	CCalllogManager *manager = CCalllogManager::get_instance();
    
    return manager->get_calllog_count();
}
int get_calllog_count_by_type(CLSTATUS status)
{
	CCalllogManager *manager = CCalllogManager::get_instance();
    
    return manager->get_calllog_count_by_type(status);
}

int get_calllog_by_index(CallLog *calllog, int index, CLSTATUS status)
{
	CCalllogManager *manager = CCalllogManager::get_instance();
    
    return manager->get_calllog_by_index(calllog, index, status);
}

int get_unread_missed_callog_count()
{
	CCalllogManager *manager = CCalllogManager::get_instance();
    
    return manager->get_unread_missed_callog_count();
}

int add_calllog(CallLog *calllog)
{
	CCalllogManager *manager = CCalllogManager::get_instance();
    
    return manager->add_calllog(calllog);
}

int update_calllog_by_index(CallLog *calllog, int index, CLSTATUS status)
{
	CCalllogManager *manager = CCalllogManager::get_instance();
	
	return manager->update_calllog_by_index(calllog, index, status);
}

int delete_calllog_by_index(int index, CLSTATUS status)
{
	CCalllogManager *manager = CCalllogManager::get_instance();
    
    return manager->delete_calllog_by_index(index, status);
}

int delete_calllog_by_status(CLSTATUS status)
{
	CCalllogManager *manager = CCalllogManager::get_instance();
    
    return manager->delete_calllog_by_status(status);
}

/********************************************************************************
                                                       Missed Phone
*********************************************************************************/
int got_missed_phone(char *phone_num)
{
    if(!phone_num)
    {
		showWarning("%s Phonenum is NULL, \n", __FUNCTION__);
		return -1;
	}
	
	Contact contact;
    CallLog calllog;
	char full_name[64];
    
	struct tm *local;
	time_t t;
	char year[8];
	char mon[8];
	char day[8];
	char hour[8];
	char min[8];
	char sec[8];
    
	memset(&calllog, 0, sizeof(CallLog));
	t=time(NULL);

	local=localtime(&t);
	sprintf(year, "%d", local->tm_year + 1900);
	sprintf(mon, "%d", local->tm_mon + 1);
	sprintf(day, "%d", local->tm_mday);
	sprintf(hour, "%d", local->tm_hour);
	sprintf(min, "%d", local->tm_min);
	sprintf(sec, "%d", local->tm_sec);
	
    strcpy(calllog.szremote, phone_num); 
	strcpy(calllog.date.year, year);
	strcpy(calllog.date.month, mon);
	strcpy(calllog.date.day, day);
	strcpy(calllog.date.hour, hour);
	strcpy(calllog.date.minute,min);
	strcpy(calllog.date.second, sec);
	
	calllog.status = CL_MISSED;
	
    if(add_calllog(&calllog))
    {
		printf("Add calllog error\n");
		return -1;	
	}
	
	return 0;
}


/********************************************************************************
                                                       phone incoming
*********************************************************************************/
int got_received_phone(char *phone_num)
{
	if(!phone_num)
    {
		showWarning("%s Phonenum is NULL, \n", __FUNCTION__);
		return -1;
	}
	
	Contact contact;
    CallLog calllog;
	char full_name[64];
    
	struct tm *local;
	time_t t;
	char year[8];
	char mon[8];
	char day[8];
	char hour[8];
	char min[8];
	char sec[8];
    
	memset(&calllog, 0, sizeof(CallLog));
	t=time(NULL);

	local=localtime(&t);
	sprintf(year, "%d", local->tm_year + 1900);
	sprintf(mon, "%d", local->tm_mon + 1);
	sprintf(day, "%d", local->tm_mday);
	sprintf(hour, "%d", local->tm_hour);
	sprintf(min, "%d", local->tm_min);
	sprintf(sec, "%d", local->tm_sec);

    strcpy(calllog.szremote, phone_num); 
	strcpy(calllog.date.year, year);
	strcpy(calllog.date.month, mon);
	strcpy(calllog.date.day, day);
	strcpy(calllog.date.hour, hour);
	strcpy(calllog.date.minute,min);
	strcpy(calllog.date.second, sec);

	calllog.status = CL_RECEIVED;
	
    if(add_calllog(&calllog))
    {
		printf("Add calllog error\n");
		return -1;	
	}

	return 0;
}

/********************************************************************************
                                                  phone dial
*********************************************************************************/
int got_dialed_phone(char *phone_num)
{
	if(!phone_num)
    {
		showWarning("%s Phonenum is NULL, \n", __FUNCTION__);
		return -1;
	}
	
	//Contact contact;
    CallLog calllog;
	char full_name[64];
	//CContactManager *contactManager = CContactManager::get_instance();
	//CCalllogManager *calllogManager = CCalllogManager::get_instance();
    
	struct tm *local;
	time_t t;
	char year[8];
	char mon[8];
	char day[8];
	char hour[8];
	char min[8];
	char sec[8];
    
	memset(&calllog, 0, sizeof(CallLog));
	t=time(NULL);

	local=localtime(&t);
	sprintf(year, "%d", local->tm_year + 1900);
	sprintf(mon, "%d", local->tm_mon + 1);
	sprintf(day, "%d", local->tm_mday);
	sprintf(hour, "%d", local->tm_hour);
	sprintf(min, "%d", local->tm_min);
	sprintf(sec, "%d", local->tm_sec);

    strcpy(calllog.szremote, phone_num); 
	strcpy(calllog.date.year, year);
	strcpy(calllog.date.month, mon);
	strcpy(calllog.date.day, day);
	strcpy(calllog.date.hour, hour);
	strcpy(calllog.date.minute,min);
	strcpy(calllog.date.second, sec);
	calllog.status = CL_DIALED;
	
    if(add_calllog(&calllog))
    {
		printf("Add calllog error!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
		return -1;	
	}
	
	return 0;
}

/**************************************************************************************************/
/**************************************** quickdail **************************************************/
/**************************************************************************************************/
int get_quickdial_count()
{
	CQuickdialManager *manager = CQuickdialManager ::get_instance();
			
	return manager->get_quickdial_count();		
}

int get_quickdial_by_index(Quickdial* quickdial, int index)
{	
	CQuickdialManager *manager = CQuickdialManager::get_instance();
			
	return manager->get_quickdial_by_index(quickdial, index);
}

int add_quickdial(Quickdial *quickdial)
{
	CQuickdialManager *manager = CQuickdialManager::get_instance();
			
	return manager->add_quickdial(quickdial);
}

int delete_quickdial_by_index(int index)
{
	CQuickdialManager *manager = CQuickdialManager::get_instance();
				
	return manager->delete_quickdial_by_index(index);
}

/**************************************************************************************************/
/**************************************** black list **************************************************/
/**************************************************************************************************/
int get_blacklist_count()
{
	CBlacklistManager *manager = CBlacklistManager::get_instance();
				
	return manager->get_blacklist_count();
}

int get_blacklist_by_index(Blacklist *blacklist, int index)
{
	CBlacklistManager *manager = CBlacklistManager::get_instance();
				
	return manager->get_blacklist_by_index(blacklist, index);
}

int add_blacklist(Blacklist *blacklist)
{
	CBlacklistManager *manager = CBlacklistManager::get_instance();
				
	return manager->add_blacklist(blacklist);
}

int delete_blacklist_by_index(int index)
{
	CBlacklistManager *manager = CBlacklistManager::get_instance();
				
	return manager->delete_blacklist_by_index(index);
}

/**************************************************************************************************/
/**************************************** commonphone*********************************************/
/**************************************************************************************************/
int get_commonphone_count()
{
	CCommonphoneManager *manager = CCommonphoneManager::get_instance();
		
	return manager->get_commonphone_count();
}

int get_commonphone_by_index(Commonphone *commonphone, int index)
{
	CCommonphoneManager *manager = CCommonphoneManager::get_instance();
    
    return manager->get_commonphone_by_index(commonphone, index);
}

/**************************************************************************************************/
/******************************************* config *************************************************/
/**************************************************************************************************/
const char *get_value_from_key(const char *key)
{
	CConfigManager *manager = CConfigManager::get_instance();
    
    return manager->get_value_from_key(key);
}

/**************************************************************************************************/
/******************************************* Common *************************************************/
/**************************************************************************************************/
int validate_phonenum(char *phonenum)
{
	if(!phonenum)
	{	
		printf("%s Phonenum is NULL\n", __FUNCTION__);
		return -1;
	}
	int phonenum_len;
	
	phonenum_len = strlen(phonenum);
	for(int i=0; i<phonenum_len; i++)
	{	
		//printf("phonenum %c value %d\n", phonenum[i], phonenum[i]);
		if(phonenum[i] < '0' || phonenum[i] > '9')
			return -1;
	}	
	
	return 0;
}

#ifdef __cplusplus
}
#endif

