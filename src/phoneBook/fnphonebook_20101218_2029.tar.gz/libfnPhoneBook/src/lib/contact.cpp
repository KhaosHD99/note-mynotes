#include <stdio.h>
#include <string.h>
#include <iostream>
#include <stdlib.h>
#include <locale.h>

#include "contact.hpp"
#include "LogMsg.hpp"

/********************************************************************************
                                                      constructor
********************************************************************************/
CContactManager::CContactManager()
{
    init();
}

/********************************************************************************
                                                      destructor
********************************************************************************/
CContactManager::~CContactManager()
{
	uninit();
}

/********************************************************************************
                                                        initialization
********************************************************************************/
void CContactManager::init()
{
	//init contact buffer and lpconfig
	contact_buf = new Contact*[MAX_CONTACT_COUNT];
    
	contact_lpconfig = lp_config_new(CONTACT_FILE_PATH); 
	if(!contact_lpconfig)
	{
		showError("contact lpconfig init fail\n");
		return;
	}
    
	for(int i = 0; i < MAX_CONTACT_COUNT; i++)
		contact_buf[i] = NULL;
    
    
	//init lock
	int ret = init_mutex();
	if(ret != 0)
		return;
			
	//init contact buffer
	load_contact_from_file();
}

/********************************************************************************
                                                           uninitialization
********************************************************************************/
void CContactManager::uninit()
{
	lp_config_destroy(contact_lpconfig);

	for(int i = 0; i < get_contact_count();	i++)
	{
			delete contact_buf[i];
			contact_buf[i] = NULL;
	}
	delete contact_buf;
	contact_buf = NULL;
}

/********************************************************************************
                                                         get instance
********************************************************************************/
CContactManager* CContactManager::contact_instance = NULL;
CContactManager *CContactManager::get_instance()
{
	if(!contact_instance)
		contact_instance = new CContactManager;

	return contact_instance;
}

/**********************************************************************************************************/
/************************************************* inner function  ********************************************/
/**********************************************************************************************************/

/********************************************************************************
                                     get section item from file by index
********************************************************************************/
Contact* CContactManager::get_section_from_config_file(int index)
{	
	Contact *contact;
	const char *tmp;
	char *tmpcpy;
	int phone_count;
	int email_count;
	char phone_index[32];
	char email_index[32];
	char section_index[64];
	char *part_str;
	const char * split = ":"; 

	sprintf(section_index, "%s%i", CONTACT_INDEX_PREFIX, index);

	if (!lp_config_has_section(contact_lpconfig, section_index))
	return NULL;
	
	contact = new Contact;
	memset(contact, 0, sizeof(Contact));
	
	//name, group
	tmp = lp_config_get_string(contact_lpconfig, section_index, CONTACT_FAMILY_NAME, NULL);
	if(tmp != NULL && strlen(tmp) <= MAX_NAME_LEN)
	strcpy(contact->name.szfamily_name, tmp);

	tmp = lp_config_get_string(contact_lpconfig, section_index, CONTACT_GIVEN_NAME, NULL);
	if(tmp != NULL && strlen(tmp) <= MAX_NAME_LEN)
	strcpy(contact->name.szgiven_name, tmp);

	tmp = lp_config_get_string(contact_lpconfig, section_index, CONTACT_GROUP, NULL);
	if(tmp)
	contact->type = __grouptype_str_to_enum(tmp);
	
	//phone
	phone_count = lp_config_get_int(contact_lpconfig, section_index, CONTACT_PHONE_COUNT, NULL);
    contact->phone_count = phone_count;
	
	for(int i=0; i<phone_count; i++)
	{
		sprintf(phone_index,"%s%d", PHONE_INDEX_PREFIX, i + 1);
		tmp = lp_config_get_string(contact_lpconfig,section_index,phone_index, NULL);

		tmpcpy = new char[strlen(tmp)];
		strcpy(tmpcpy, tmp);

		//type
		part_str = strtok (tmpcpy, split);
		if(__phonetype_str_to_enum((const char*)part_str) != NULL)
		{
			contact->phones[i].type = __phonetype_str_to_enum((const char*)part_str);
		}

		//szphone
		part_str = strtok(NULL,split);
		if((const char*)part_str != NULL)
		{
			strcpy(contact->phones[i].szphone, (const char*)part_str);
		}

		free(tmpcpy);
	}

	//email
	email_count = lp_config_get_int(contact_lpconfig, section_index, CONTACT_EMAIL_COUNT, NULL);
    contact->email_count = email_count;

	for(int j=0;j < email_count; j++)
	{
		sprintf(email_index,"%s%d", EMAIL_INDEX_PREFIX, j + 1);
		tmp = lp_config_get_string(contact_lpconfig,section_index,email_index, NULL);
		tmpcpy = new char[strlen(tmp)];
		strcpy(tmpcpy, tmp);

		//type
		part_str = strtok (tmpcpy, split);
		if(__emailtype_str_to_enum((const char*)part_str) != NULL)
		contact->emails[j].type = __emailtype_str_to_enum((const char*)part_str);

		//szemail
		part_str = strtok(NULL,split);
		if((const char*)part_str != NULL)
		strcpy(contact->emails[j].szemail, (const char*)part_str);

		free(tmpcpy);
	}

	//avatar, voip, im, address
	/*
       tmp = lp_config_get_string(contact_lpconfig, section_index, CONTACT_AVATAR, NULL);
	if(tmp != NULL && strlen(tmp) <= MAX_AVATAR_LEN)
		strcpy(contact->szavatar, tmp);*/
	
	tmp = lp_config_get_string(contact_lpconfig, section_index, CONTACT_VOIP, NULL);
	if(tmp != NULL && strlen(tmp) <= MAX_VOIP_LEN)
		strcpy(contact->szvoip, tmp);

	tmp = lp_config_get_string(contact_lpconfig, section_index, CONTACT_IM, NULL);
	if(tmp != NULL && strlen(tmp) <= MAX_IM_LEN)
		strcpy(contact->szim, tmp);

	tmp = lp_config_get_string(contact_lpconfig, section_index, CONTACT_ADDRESS, NULL);
	if(tmp != NULL && strlen(tmp) <= MAX_ADDRESS_LEN)
		strcpy(contact->szaddress, tmp);
	
	contact->is_in_blacklist = lp_config_get_int(contact_lpconfig, section_index, CONTACT_IS_IN_BLACKLIST, NULL);
							
	contact->is_in_quickdial = lp_config_get_int(contact_lpconfig, section_index, CONTACT_IS_IN_QUICKDIAL, NULL);
	
	return contact;
}

/********************************************************************************
                          write contact item to config file by index without sync
********************************************************************************/
int CContactManager::write_contact_item(Contact *item, int index)
{
	char section[64];
	char phone_index[32];
	char email_index[32];
	char phone_mix_info[32];
	char email_mix_info[32];
	
	char *tmp;
	int a = 5;
	
	sprintf(section,"%s%i", CONTACT_INDEX_PREFIX, index);
	
	//name, group
	lp_config_set_string(contact_lpconfig, section, CONTACT_FAMILY_NAME, item->name.szfamily_name);
	lp_config_set_string(contact_lpconfig, section, CONTACT_GIVEN_NAME, item->name.szgiven_name);
	lp_config_set_string(contact_lpconfig, section, CONTACT_GROUP, __grouptype_enum_to_str(item->type));

	//phone
	lp_config_set_int(contact_lpconfig, section, CONTACT_PHONE_COUNT, item->phone_count);
		              
	for(int i = 0; i < item->phone_count; i++)
	{
		sprintf(phone_index,"%s%d", PHONE_INDEX_PREFIX, i + 1);
		if(__phonetype_enum_to_str(item->phones[i].type) != NULL)
			sprintf(phone_mix_info, "%s:%s", 
		       		__phonetype_enum_to_str(item->phones[i].type), 
		        	item->phones[i].szphone);
		else
			sprintf(phone_mix_info, "%s", item->phones[i].szphone);
		
		lp_config_set_string(contact_lpconfig, section, phone_index, phone_mix_info);
	}

	//email
	lp_config_set_int(contact_lpconfig, section, CONTACT_EMAIL_COUNT, item->email_count);
    
	for(int i=0; i<item->email_count; i++)
	{
		sprintf(email_index,"%s%d", EMAIL_INDEX_PREFIX, i + 1);
		if(__emailtype_enum_to_str(item->emails[i].type) != NULL)
			sprintf(email_mix_info, "%s:%s", 
		        	__emailtype_enum_to_str(item->emails[i].type), 
		        	item->emails[i].szemail);
		else
			sprintf(email_mix_info, "%s", item->emails[i].szemail);
		
		lp_config_set_string(contact_lpconfig, section, email_index, email_mix_info);
	}
	
	//voip, im, address
	lp_config_set_string(contact_lpconfig, section, CONTACT_VOIP, item->szvoip);
	lp_config_set_string(contact_lpconfig, section, CONTACT_IM, item->szim);
	lp_config_set_string(contact_lpconfig, section, CONTACT_ADDRESS, item->szaddress);
	lp_config_set_int(contact_lpconfig, section, CONTACT_IS_IN_BLACKLIST, item->is_in_blacklist);
	lp_config_set_int(contact_lpconfig, section, CONTACT_IS_IN_QUICKDIAL, item->is_in_quickdial);
	
	return 0;
}

/********************************************************************************
                                                    synchronization
********************************************************************************/
int CContactManager::sync_contact_config()
{ 
	int writeindex = 0;
	char section[32];

	if(contact_lpconfig == NULL)
	{
		showError("contact_lpconfig is null\n");
		return -1;
	}

	if(contact_buf == NULL)
	{
		//g_error("no contact_buf, save contact error!");
		return -1;
	}

	//clear
	for(int i = 0; i < MAX_CONTACT_COUNT; i++)
	{
	    sprintf(section, "%s%i", CONTACT_INDEX_PREFIX, i);
	    if(lp_config_has_section(contact_lpconfig, section))
	    	lp_config_clean_section(contact_lpconfig, section);
	}
    
	//sort
	sort_by_pinyin();
	
	//write item
	for(int i = 0; i < buf_count; i++)
		write_contact_item(contact_buf[i], i);
    
	return lp_config_sync(contact_lpconfig);	
}

/********************************************************************************
                                                sort contact buffer by letter
********************************************************************************/
void CContactManager::sort_by_letter()	
{
	int len;
	int tmp_buf_index = 0;
	const char letter_set[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m',
							   'n','o','p','q','r','s','t','u','v','w','x','y','z'};

	Contact **contact_tmp_buf = new Contact*[MAX_CONTACT_COUNT];

	len = get_contact_count();
	if(len <= 0)
		return;

	for(int letter_index = 0;letter_index < 26; letter_index++)
	{
	    const char cmp_letter[] = {letter_set[letter_index], '\0'};
		for(int i = 0;i < len; i++)
		{
			const char initial_letter[] = {contact_buf[i]->name.szfamily_name[0], '\0'};
			if(strcmp(cmp_letter, initial_letter) == 0)
			{
 				contact_tmp_buf[tmp_buf_index] = contact_buf[i];
   				tmp_buf_index++;
			}
	    }
	}

	for(int i = 0; i < len; i++)
		contact_buf[i] = contact_tmp_buf[i];

	//sync
	sync_contact_config();
}

int CContactManager::comp(const void *p, const void *q)
{
	return (*(int *)p - *(int *)q);
}


/********************************************************************************
                                                sort contact buffer by pinyin
********************************************************************************/
void CContactManager::sort_by_pinyin()
{   
	Contact **contact_buf_tmp;
	char contact_name[MAX_CONTACT_COUNT][MAX_NAME_LEN];
	contact_buf_tmp = new Contact*[buf_count];
	
    //duplicate
    for(int i = 0; i < buf_count; i++)
    	strcpy(contact_name[i], contact_buf[i]->name.szfamily_name);
    
	
	for(int i = 0;  i < buf_count; i++)    
	{
	    contact_buf_tmp[i] = new Contact;
		memcpy(contact_buf_tmp[i], contact_buf[i], sizeof(Contact));
	}
 
	//release contact_buf[i] 
	for(int i = 0; i < get_contact_count();	i++)    
	{
			delete contact_buf[i];
			contact_buf[i] = NULL;
	}
    
    //sort
	qsort(contact_name, buf_count, MAX_NAME_LEN, (__compar_fn_t)strcoll);
  
    #if 1
    for(int i = 0; i < buf_count; i++)
    {
		for(int j = 0; j < buf_count; j++)
		{
        	if(!strcmp(contact_buf_tmp[j]->name.szfamily_name, contact_name[i]))
        	{
        	    //printf("contact_buf_tmp %d == contact_name %d\n", j, i); 
            	contact_buf[i] = new Contact;
				memcpy(contact_buf[i], contact_buf_tmp[j], sizeof(Contact));
			}
		}
	}

	//release contact_buf_tmp and contact_name
    for(int i = 0;i < buf_count;i++)    
	{
		delete contact_buf_tmp[i];
		contact_buf_tmp[i] = NULL;
	}

	delete contact_buf_tmp;
    contact_buf_tmp = NULL;
	
	#endif
}

/**********************************************************************************************************/
/****************************************    mutex    *****************************************************/
/**********************************************************************************************************/

/********************************************************************************
                                                     initial lock mutex
********************************************************************************/
int CContactManager::init_mutex()
{
	return pthread_mutex_init(&mutex, NULL);
}

/********************************************************************************
                                                           lock mutex
********************************************************************************/
void CContactManager::lock_mutex()
{
	pthread_mutex_lock(&mutex);
}

/********************************************************************************
 					              unlock mutex
********************************************************************************/
void CContactManager::unlock_mutex()
{
	pthread_mutex_unlock(&mutex);
}

/**********************************************************************************************************/
/*******************************************   CURD  ******************************************************/
/**********************************************************************************************************/

/********************************************************************************
                                      read contact from config file to buffer
********************************************************************************/
int CContactManager::load_contact_from_file()
{ 
	if(contact_lpconfig == NULL)
		return -1;
			
	Contact *contact;

	//lock
	lock_mutex();

	buf_count = 0;
	for (int i=0; (contact = get_section_from_config_file(i)) != NULL; i++)
	{
	    contact_buf[i] = contact;
	    buf_count++;
	}
	
	//unlock
	unlock_mutex();
}

/********************************************************************************
                                get contact count from inner  variable buf_count
********************************************************************************/
int CContactManager::get_contact_count()
{	
	return buf_count;
}

/********************************************************************************
                                                get contact by index
********************************************************************************/
int CContactManager::get_contact_by_index(Contact *contact, int index)
{
	//validate
	if(buf_count == 0)
		return -1;

	if(index >= buf_count)
		return -1;
		
	if(!contact)
		return -1;

	//lock
	lock_mutex();

	//copy
	memcpy(contact, contact_buf[index], sizeof(Contact));

	//unlock
	unlock_mutex();
	
	return 0;
}

/********************************************************************************
                               get contact by name
********************************************************************************/
int CContactManager::get_contact_by_name(Contact *contact, const char *szname)
{	
	//validate
	if(buf_count == 0)
		return -1;
	
	if(!contact)
		return -1;
 
    char full_name[64];
	
	//lock
	lock_mutex();
	
	for(int i = 0;i < buf_count; i++)
	{
	    sprintf(full_name, "%s%s", contact_buf[i]->name.szfamily_name, contact_buf[i]->name.szgiven_name);
		if(!strcmp(full_name, szname))
		{	
			memcpy(contact, contact_buf[i], sizeof(Contact));
			
			//unlock
			unlock_mutex();
			
			return 0;
		}
	}
	
	//unlock
	unlock_mutex();
	
	return -1;
}

/********************************************************************************
                               get contact by letter
********************************************************************************/
int CContactManager::get_contact_by_letter(Contact *contact, const char *szletter)
{
    //validate
	if(buf_count == 0)
		return -1;
	
	if(!contact)
		return -1;
	
	//lock
	lock_mutex();
	
	for(int i = 0;i < buf_count; i++)
	{
		const char str[] = {contact_buf[buf_count]->name.szfamily_name[0], '\0'};
		
	    if(!strcmp(str, szletter))
	    {
			memcpy(contact, contact_buf[i], sizeof(Contact));	
			
			//unlock
			unlock_mutex();
			
			return 0;
	    }
	}
	
    //unlock
	unlock_mutex();
	return -1;
}

/********************************************************************************
                                 get contact by phone
********************************************************************************/
int CContactManager::get_contact_by_phone(Contact *contact, const char *szphone)
{
	//validate
	if(buf_count == 0)
		return -1;

	if(!contact)
		return -1;
			
	int phone_count;
	char phone_index[32];
	char section_index[32];
	
    //lock
    lock_mutex();
	
	for(int i = 0;i < buf_count; i++)
	{
		sprintf(section_index,"%s%i", CONTACT_INDEX_PREFIX, i);
	    phone_count = lp_config_get_int(contact_lpconfig, section_index, CONTACT_PHONE_COUNT, NULL);

		for(int j = 0; j < phone_count; j++)
		{
        	if(!strcmp(contact_buf[i]->phones[j].szphone, szphone))
        	{   
	 	    	memcpy(contact, contact_buf[i], sizeof(Contact));
		
			    //unlock
	    		unlock_mutex();
				 
				return 0;
			}
		}
	}

	//unlock
    unlock_mutex();
	
	return -1;
}

/********************************************************************************
                           add contact item to buffer
********************************************************************************/
int CContactManager::add_contact(Contact *contact)
{
	//validate
	if(!contact)
		return -1;
	
	if(get_contact_count() >= MAX_CONTACT_COUNT)
		return -1;
	
	int section_index;
	contact_buf[buf_count] = new Contact;

	if(!contact_buf[buf_count])
		return -1;
	
	//lock
	lock_mutex();

	//copy
	memcpy(contact_buf[buf_count], contact, sizeof(Contact));
	
	//sync
	buf_count++;
	sync_contact_config();

	//unlock
	unlock_mutex();

	return 0;
}

/********************************************************************************
                         add contact item to spec position
********************************************************************************/
int CContactManager::add_contact_by_index(Contact *contact, int index)
{
	
}

/********************************************************************************
                             update contact by index
********************************************************************************/
int CContactManager::update_contact_by_index(Contact *contact, int index)
{
	//validate
	if(buf_count == 0)
		return -1;
			
	if(index >= buf_count)
		return -1;

	if(!contact)
		return -1;

	//lock
	lock_mutex();

	//copy
	if(contact_buf[index])
	{
		memset(contact_buf[index], 0, sizeof(Contact));
		memcpy(contact_buf[index], contact, sizeof(Contact));
	}
	
	//sync
	sync_contact_config();

	//unlock
	unlock_mutex();
    
	return 0;
}

/********************************************************************************
                             delete contact by index
********************************************************************************/
int CContactManager::delete_contact_by_index(int index)
{
	//validate
	int section_index;

	if(buf_count == 0)
		return -1;

	if(buf_count <= index)
		return -1;

	//lock
	lock_mutex();

    for(int i = index; i < buf_count - 1; i++)
    {
 		if(contact_buf[i] && contact_buf[i+1])
 		{
        	memset(contact_buf[i], 0, sizeof(Contact));
			memcpy(contact_buf[i], contact_buf[i+1], sizeof(Contact));
 		}
	}
	
	delete(contact_buf[buf_count - 1]);
	contact_buf[buf_count - 1] = NULL;
	
	//sync
	buf_count--;
	sync_contact_config();

	//unlock
	unlock_mutex();

	return 0;
}

/********************************************************************************
                                                       delete all contact
********************************************************************************/
int CContactManager::delete_contact_all()
{
	//validate
	if(buf_count == 0)
			return -1;

	int section_index;

	//lock
	lock_mutex();

	for(int i = 0; i < buf_count; i++)
	{
		if(contact_buf[i])
		{
	    	delete(contact_buf[i]);
			contact_buf[i] = NULL;
		}
	}
	//sync
	buf_count = 0;
	sync_contact_config();

	//unlock
	unlock_mutex();

	return 0;
}

/**********************************************************************************************************/
/****************************************  validate  ******************************************************/
/**********************************************************************************************************/

/********************************************************************************
                                     validate input
********************************************************************************/
int CContactManager::validate()
{
    
}

/**********************************************************************************************************/
/****************************************    enum    ******************************************************/
/**********************************************************************************************************/

/********************************************************************************
  												convert grouptype enum to str
********************************************************************************/
const char* CContactManager::__grouptype_enum_to_str(int enum_val)
{
	switch(enum_val)
	{
		case GT_FAMILY:
			return GT_FAMILY_STR;
			break;
		case GT_RELATIVES:
			return GT_RELATIVES_STR;
			break;
		case GT_COLLEAGUES:
			return GT_COLLEAGUES_STR;
			break;
		case GT_FRIENDS:
			return GT_FRIENDS_STR;
			break;
		case GT_MANUFACTURERS:
			return GT_MANUFACTURERS_STR;
			break;
		case GT_OTHER:
			return GT_OTHER_STR;
			break;
		case GT_CUSTOM:
			return GT_CUSTOM_STR;
			break;
	}
	showWarning("Invalid grouptype enum value.\n");
	
	return "NULL";
}

/********************************************************************************
  													convert phonetype enum to str
********************************************************************************/
const char* CContactManager::__phonetype_enum_to_str(int enum_val)
{
	switch(enum_val)
	{
	    case PT_HOME:
			return PT_HOME_STR;
			break;
		case PT_MOBILE:
			return PT_MOBILE_STR;
			break;
		case PT_WORK:
			return PT_WORK_STR;
			break;
		case PT_WORK_FAX:
			return PT_WORK_FAX_STR;
			break;
		case PT_HOME_FAX:
			return PT_HOME_FAX_STR;
			break;
		case PT_OTHER:
			return PT_OTHER_STR;
			break;
		case PT_CUSTOM:
			return PT_CUSTOM_STR;
			break;
		}
		showWarning("Invalid phonetype enum value.\n");
		
		return "NULL";
}

/********************************************************************************
  													convert emailtype enum to str
********************************************************************************/
const char* CContactManager::__emailtype_enum_to_str(int enum_val)
{
	switch(enum_val)
	{
	    case EMT_HOME:
			return EMT_HOME_STR;
			break;
		case EMT_WORK:
			return EMT_WORK_STR;
			break;
		case EMT_OTHER:
			return EMT_OTHER_STR;
			break;
		case EMT_CUSTOM:
			return EMT_CUSTOM_STR;
			break;
	}
	showWarning("Invalid emailtype enum value.\n");
	
	return "NULL";
}

/********************************************************************************
 												 convert phonetype str to enum
********************************************************************************/
GroupType CContactManager::__grouptype_str_to_enum(const char *enum_str)
{
	if(strcmp(enum_str, GT_FAMILY_STR) == 0)
		 return GT_FAMILY;

	if(strcmp(enum_str, GT_RELATIVES_STR) == 0)
		 return GT_RELATIVES;

	if(strcmp(enum_str, GT_COLLEAGUES_STR) == 0)
		  return GT_COLLEAGUES;

	if(strcmp(enum_str, GT_FRIENDS_STR) == 0)
		  return GT_FRIENDS;
	 
	if(strcmp(enum_str, GT_MANUFACTURERS_STR) == 0)
		  return GT_MANUFACTURERS;

	if(strcmp(enum_str, GT_OTHER_STR) == 0)
		  return GT_OTHER;

	if(strcmp(enum_str, GT_CUSTOM_STR) == 0)
		  return GT_CUSTOM;

	showWarning("Invalid grouptype enum value %s\n", enum_str);
	
	return (GroupType)-1;
 }

/********************************************************************************
 													 convert phonetype str to enum
********************************************************************************/
PhoneType CContactManager::__phonetype_str_to_enum(const char *enum_str)
{
	if(strcmp(enum_str, PT_HOME_STR) == 0)
		return PT_HOME;

	if(strcmp(enum_str, PT_MOBILE_STR) == 0)
		return PT_MOBILE;

	if(strcmp(enum_str, PT_WORK_STR) == 0)
		return PT_WORK;

	if(strcmp(enum_str, PT_WORK_FAX_STR) == 0)
		return PT_WORK;

	if(strcmp(enum_str, PT_WORK_FAX_STR) == 0)
		return PT_WORK_FAX;

	if(strcmp(enum_str, PT_HOME_FAX_STR) == 0)
		return PT_HOME_FAX;

	if(strcmp(enum_str, PT_OTHER_STR) == 0)
		return PT_OTHER;

	if(strcmp(enum_str, PT_CUSTOM_STR) == 0)
		return PT_CUSTOM;

	showWarning("Invalid phonetype enum value %s\n", enum_str);
	
	return (PhoneType)-1;
}

/********************************************************************************
  													convert emailtype str to enum
********************************************************************************/
EMailType CContactManager::__emailtype_str_to_enum(const char *enum_str)
{
	if(strcmp(enum_str, EMT_HOME_STR) == 0)
		return EMT_HOME;

	if(strcmp(enum_str, EMT_WORK_STR) == 0)
		return EMT_WORK;

	if(strcmp(enum_str, EMT_OTHER_STR) == 0)
		return EMT_OTHER;

	if(strcmp(enum_str, EMT_CUSTOM_STR) == 0);
		return EMT_CUSTOM;
	
	showWarning("Invalid emailtype enum value %s\n", enum_str);
	
	return (EMailType)-1;
}

