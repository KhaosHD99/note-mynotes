//#include <stdlib.h>
#include <gtk/gtk.h>
#include <windowstack.h>
#include "MessageStack.h"

static MSS_Handle mss_window_handle = NULL;

/****************************************************************************************
                                    create stack
****************************************************************************************/
int creat_window_stack()
{
		MSS_Attrs attrs;
		memset(&attrs, 0, sizeof(attrs));
		sprintf(attrs.mssName, "WindowStack");
		mss_window_handle = MSS_create(sizeof(GtkWindowInfo), 128, &attrs);
		if( mss_window_handle == NULL)	
		{
				printf("Creat mss_window_handle Error\r\n");
				return -1;
		}
		else
		{
			  return 0;
		}
}

/****************************************************************************************
                          put window into stack with block
****************************************************************************************/
int put_window_into_stack(GtkWidget *window)
{			
	int ret;
	
	GtkWindowInfo window_info;
	if(NULL == window)
	{
			printf("put stack error : window null\r\n");	
			return -1;
	}
	
	const char *name = gtk_window_get_title((GtkWindow *)window);
	
	window_info.window = (GtkWindow *)window;
	
	if(name != NULL)
			snprintf(window_info.window_name,
						   sizeof(window_info.window_name) - 1,
						   name);
	else
		  window_info.window_name[0] = '\0';
		
	ret = MSS_put((MSS_Handle)mss_window_handle, (void*)&window_info, -1);
	
	return ret;
}

/****************************************************************************************
                          read top window without block
****************************************************************************************/
int read_top_window_stack(GtkWindowInfo *pwindow_info)
{
		int ret;
		if(pwindow_info == NULL)
		{
				printf("read stack top error : window_info null\r\n");
				return -1;
		}
	
		if(MSS_getCount((MSS_Handle)mss_window_handle) > 0)
		{
				ret = MSS_getTop((MSS_Handle)mss_window_handle, (void*)pwindow_info);
				return ret;
		}
		else
		{
				printf("stack empty!\r\n");
				return -2;	
		}
}

/****************************************************************************************
                             get top window with block
****************************************************************************************/
int get_window_out_stack(GtkWindowInfo *pwindow_info)
{
		int ret;
		if(pwindow_info == NULL)
		{
				printf("get stack error : window_info null\r\n");	
				return -1;
		}
		if(MSS_getCount((MSS_Handle)mss_window_handle) > 0)
		{
				ret = MSS_get((MSS_Handle)mss_window_handle, (void*)pwindow_info, -1);
				printf("%s ret : %d\r\n", __FUNCTION__, ret);
				return ret;	
		}
		else
		    return -2;
}

/****************************************************************************************
                                    show top window
****************************************************************************************/
#if 0
int show_top_window(GtkWindow* window)
{
		extern GtkWidget *rootWindow;
		GtkWindowInfo window_info;
		int ret = read_top_window_stack(&window_info);
		
		if(ret != 0)
		{
				g_print("read top window out error\r\n");
				return FALSE;
		}
		if(window_info.window != rootWindow && window_info.window != window)
		{
				if(window_info.window)
				{
						gtk_widget_hide(window_info.window);
						gtk_widget_show(window_info.window);
				}
				g_print("show_top_window show window : %s\r\n", window_info.window_name);
		}
		else
		{
			  g_print("its the self_window : %s\r\n", window_info.window_name);
		}
}
#endif
	
#if 1
int show_top_window()
{	
	extern GtkWidget *rootWindow;
	GtkWindowInfo window_info;
	int ret = read_top_window_stack(&window_info);
	//int ret = get_window_out_stack(&window_info);
	
	if(ret != 0)
	{
		g_print("read top window out error\r\n");
		return FALSE;
	}
	
	if(window_info.window)
	{
		gtk_widget_hide(GTK_WIDGET(window_info.window));
		gtk_widget_show(GTK_WIDGET(window_info.window));
	}
	//g_print("show_top_window show window : %s\r\n", window_info.window_name);
}

#endif
