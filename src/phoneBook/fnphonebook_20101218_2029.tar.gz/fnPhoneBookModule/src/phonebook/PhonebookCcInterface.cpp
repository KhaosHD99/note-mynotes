#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "PhonebookModule.h"
#include "ModuleID.hpp"

//VialSystem *sendVialSys = NULL;
//PhonebookModule *adver_send_test = NULL;
VialSystem *vialsys_phonebook;

/**************************************************************
                             thread_adv_play_module
**************************************************************/
static void *thread_phonebook_module(void *data)
{
	VialSystem vialSys(FN_PHONE_BOOK_MODULE_ID);
	vialsys_phonebook = &vialSys;
	PhonebookModule *phonebook_module = PhonebookModule::get_instance(vialsys_phonebook);
	
	if(phonebook_module)
	{	
		phonebook_module->init();
		phonebook_module->run();
	}
	else
		return NULL;
}

/***********************************************************************************************
                                                             creat_and_run_prompter_module
***********************************************************************************************/
#ifdef __cplusplus
extern"C"
{
#endif
int creat_and_run_phonebook_module()
{	
	pthread_t phonebook_module_thread;

	if(pthread_create(&phonebook_module_thread, NULL, thread_phonebook_module, NULL) == 0)
	{
		printf("thread create Ok, phonebookmoudule thread start \n");
		return 0;
	}
	else
	{
		printf("thread phonebookmoudule create Err\n");
		return -1;
	}
#if 0

	pthread_t adv_play_module_thread;
	
#ifdef APP_ONE
	if(pthread_create(&adv_play_module_thread, NULL, thread_adv_play_module, NULL) == 0)
	{
		printf("thread create Ok, promptermodule thread start \n");
		return 0;
	}
	else
	{
		printf("thread promptermodule create Err\n");
		return -1;
	}
#elif defined(APP_TWO)   /* Post Test */
	#if 1 /* Require CC */
	VialSystem vialSys(FN_PHONE_BOOK_MODULE_ID);
	adver_send_test = PhonebookModule::get_instance(&vialSys);
	
	if(adver_send_test)
		adver_send_test->init();
	else
		return -1;
	
	if(pthread_create(&adv_play_module_thread, NULL, thread_adv_play_module, NULL) == 0)
	{
		printf("thread create Ok, promptermodule thread start \n");
	}
	else
	{
		printf("thread promptermodule create Err\n");
	}
	
	adver_send_test->run();
	#endif
	
    #if 0 /* No Require CC */
	VialSystem vialSystem(FN_PHONE_BOOK_MODULE_ID);
	sendVialSys = &vialSystem;
    MyClass myReceiver;
	sendVialSys->addReceiver(&myReceiver);
	
	if(pthread_create(&adv_play_module_thread, NULL, thread_adv_play_module, NULL) == 0)
	{
		printf("thread create Ok, promptermodule thread start \n");
	}
	else
	{
		printf("thread promptermodule create Err\n");
	}
	sendVialSys->run();
	#endif
#else
	#error no def APP_ONE or APP_TWO
#endif

#endif
}

int send_dial_vial(const char* phonenum)
{	
	if(!phonenum)
		return -1;
	
	PhonebookModule *phonebook_module = PhonebookModule::get_instance(vialsys_phonebook);

	PhoneDialCmdVial phone_dial_cmd_vial;
	strcpy(phone_dial_cmd_vial.cCode, phonenum);
	phone_dial_cmd_vial.nLen = strlen(phone_dial_cmd_vial.cCode);
	
	phonebook_module->post_vial(&phone_dial_cmd_vial, FN_PHONE_CONTROL_MODULE_ID);
	
	return 0;
}

#ifdef __cplusplus
}
#endif

