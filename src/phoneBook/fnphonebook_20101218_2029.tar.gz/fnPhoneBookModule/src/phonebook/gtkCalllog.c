#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>

#include "phonebookapi.h"
#include "phonebookskin.h"
#include "windowstack.h"
#include "LogMsg.hpp"
//#define _(STRING) g_convert(STRING, -1, "UTF-8", "GB2312", NULL, NULL, NULL)

GtkListStore *missed_store;
GtkListStore *received_store;
GtkListStore *dialed_store;

GtkTreeView *treeview_missed;
GtkTreeView *treeview_received;
GtkTreeView *treeview_dialed;
GtkNotebook *notebook;

enum 
{
	MISSED_PAGE,
	RECEIVED_PAGE,
	DIALED_PAGE,
	CALLLOG_INDEX_COL = 0,
	REMOTE_COL,
	DATETIME_COL
};

/********************************************************************************
                                                           event
********************************************************************************/
void on_button_calllog_dialed_clicked(GtkWidget *widget, gpointer user_data)
{
	//showDebug("Get in %s\n", __FUNCTION__);
	int index;
    GtkTreeModel *model;
	GtkTreeIter iter;
	GtkTreeSelection *selection;
    int currentPage;
	CallLog calllog;
   
	memset(&calllog, 0, sizeof(CallLog));
	currentPage = gtk_notebook_get_current_page(notebook);
	
	switch(currentPage)
	{
		case MISSED_PAGE:		
			if(!get_calllog_count_by_type(CL_MISSED))
			{
				show_message_window("当前没有任何未接记录");
				return;
			}

			selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_missed));
			if(selection == NULL)
			{
				showError("%s Selection is NULL\n", __FUNCTION__);
				return;
			}
			
			if (gtk_tree_selection_get_selected(selection, &model, &iter))
			{
			    gtk_tree_model_get(model, &iter,
			                       CALLLOG_INDEX_COL, &index,
			                       -1);
				
				if(get_calllog_by_index(&calllog, index, CL_MISSED))
				{
					showWarning("%s Get Calllog Fail\n", __FUNCTION__);
					return;
				}
				showInfo("calllog num: %s\n", calllog.szremote);
			}
			else
			{
				show_message_window(get_value_from_key(DISPLAY_NO_SELECT));
				return;
			}

			if(validate_phonenum(calllog.szremote))
			{
				show_message_window("无效的号码");
				return;
			}
			
			if(send_dial_vial(calllog.szremote))
				showWarning("%s Send Dial Vial Fail\n", __FUNCTION__);
			else
	    		showInfo("%s Send Dial Vial Successfully, phonenum: %s\n", __FUNCTION__, calllog.szremote);
			
			break;

		case RECEIVED_PAGE:		
			if(!get_calllog_count_by_type(CL_RECEIVED))
			{
				show_message_window("当前没有任何已接记录");
				return;
			}

			selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_received));
			if(selection == NULL)
			{
				showError("%s Selection is NULL\n", __FUNCTION__);
				return;
			}
			
			if (gtk_tree_selection_get_selected(selection, &model, &iter))
			{
			    gtk_tree_model_get(model, &iter,
			                       CALLLOG_INDEX_COL, &index,
			                       -1);
				if(get_calllog_by_index(&calllog, index, CL_RECEIVED))
				{
					showWarning("%s Get Calllog Fail\n", __FUNCTION__);
					return;
				}
				showInfo("calllog num: %s\n", calllog.szremote);
			}
			else
			{
				show_message_window(get_value_from_key(DISPLAY_NO_SELECT));
				return;
			}

			if(validate_phonenum(calllog.szremote))
			{
				show_message_window("无效的号码");
				return;
			}
			
			if(send_dial_vial(calllog.szremote))
				showWarning("%s Send Dial Vial Fail\n", __FUNCTION__);
			else
	    		showInfo("%s Send Dial Vial Successfully, phonenum: %s\n", __FUNCTION__, calllog.szremote);
			
			break;

		case DIALED_PAGE:		
			if(!get_calllog_count_by_type(CL_DIALED))
			{
				show_message_window("当前没有任何未接记录");
				return;
			}

			selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_dialed));
			if(selection == NULL)
			{
				showError("%s Selection is NULL\n", __FUNCTION__);
				return;
			}
			
			if (gtk_tree_selection_get_selected(selection, &model, &iter))
			{
			    gtk_tree_model_get(model, &iter,
			                       CALLLOG_INDEX_COL, &index,
			                       -1);
				if(get_calllog_by_index(&calllog, index, CL_DIALED))					
				{	
					showWarning("%s Get Calllog Fail\n", __FUNCTION__);
					return;
				}
				showInfo("calllog num: %s\n", calllog.szremote);
			}
			else
			{
				show_message_window(get_value_from_key(DISPLAY_NO_SELECT));
				return;
			}

			if(validate_phonenum(calllog.szremote))
			{
				show_message_window("无效的号码");
				return;
			}
			
			if(send_dial_vial(calllog.szremote))
				showWarning("%s Send Dial Vial Fail\n", __FUNCTION__);
			else
	    		showInfo("%s Send Dial Vial Successfully, phonenum: %s\n", __FUNCTION__, calllog.szremote);
	    
			break;

		default:
			showError("%s Invalide Calllog Notebook Page\n", __FUNCTION__);
		
	}
}

void on_button_calllog_addToContact_clicked(GtkWidget *widget, gpointer user_data)
{
	int index;
	char *remote;
	Contact contact;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;
    int currentPage;
	
	currentPage = gtk_notebook_get_current_page(notebook);
	
    #if 1
    if(currentPage == MISSED_PAGE)
	{
		selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_missed));
		
		if(selection == NULL)
		return;
		
		if (gtk_tree_selection_get_selected(selection, &model, &iter))
		{
		    gtk_tree_model_get(model, &iter,
				               CALLLOG_INDEX_COL, &index,
							   REMOTE_COL, &remote,
		                       -1);

			if(!get_contact_by_name(&contact, remote))
			{
				showDebug("already exist\n", remote);
				
			}
			else
				show_contact_detail_window(ADD, remote);
		}
	}
	else if(currentPage == RECEIVED_PAGE)
	{
		selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_received));

		if(selection == NULL)
		return;
		
		if (gtk_tree_selection_get_selected(selection, &model, &iter))
		{
		    gtk_tree_model_get(model, &iter,
				               CALLLOG_INDEX_COL, &index,
							   REMOTE_COL, &remote,
		                       -1);

			if(!get_contact_by_name(&contact, remote))
			{
				showDebug("already exist\n", remote);
			}
			else
				show_contact_detail_window(ADD, remote);
		}
	}
	else if(currentPage == DIALED_PAGE)
	{
		selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_dialed));

		if(selection == NULL)
		return;
		
		if (gtk_tree_selection_get_selected(selection, &model, &iter))
		{
		    gtk_tree_model_get(model, &iter,
				               CALLLOG_INDEX_COL, &index,
                               REMOTE_COL, &remote,
		                       -1);

			if(!get_contact_by_name(&contact, remote))
			{
				showDebug("already exist\n", remote);
			}
			else
				show_contact_detail_window(ADD, remote);
		}
	}
	#endif
}

void on_button_calllog_delete_clicked(GtkWidget *widget, gpointer user_data)
{ 
    int index;
    GtkTreeModel *model;
	GtkTreeIter iter;
	GtkTreeSelection *selection;
    
    int currentPage = gtk_notebook_get_current_page(notebook);
    
    //item count validate
	if(currentPage == MISSED_PAGE && get_calllog_count_by_type(CL_MISSED) == 0)
	{
		show_message_window("当前没有任何未接记录");
		return;
	}
	else if(currentPage == RECEIVED_PAGE && get_calllog_count_by_type(CL_RECEIVED) == 0)
	{
		show_message_window("当前没有任何已接记录");
		return;
	}
	else if(currentPage == DIALED_PAGE && get_calllog_count_by_type(CL_DIALED) == 0)
	{
		show_message_window("当前没有任何拨出记录");
		return;
	}
	
	//selection validate
	if(currentPage == MISSED_PAGE)
	{
		selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_missed));
	    if(!gtk_tree_selection_get_selected(selection, &model, &iter))
		{
			show_message_window(get_value_from_key(DISPLAY_NO_SELECT));
			return;
	    }
	}
	else if(currentPage == RECEIVED_PAGE)
	{
		selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_received));
	    if(!gtk_tree_selection_get_selected(selection, &model, &iter))
		{	
			show_message_window(get_value_from_key(DISPLAY_NO_SELECT));
			return;
	    }
	}
	else if(currentPage == DIALED_PAGE)
	{
		selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_dialed));
	    if(!gtk_tree_selection_get_selected(selection, &model, &iter))
		{	
			show_message_window(get_value_from_key(DISPLAY_NO_SELECT));
			return;
	    }
	}
	
    if(!(show_confirm_window(get_value_from_key(DISPLAY_DELETE_CONFIRM)) ==	GTK_RESPONSE_OK))
   		return;
    
    if(currentPage == MISSED_PAGE)
	{
		selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_missed));

		if(selection == NULL)
		return;
		
		if (gtk_tree_selection_get_selected(selection, &model, &iter))
		{
		    gtk_tree_model_get(model, &iter,
		                       CALLLOG_INDEX_COL, &index,
		                       -1);
			
			delete_calllog_by_index(index, CL_MISSED);
			sync_calllog_list();
		}
	}
	else if(currentPage == RECEIVED_PAGE)
	{
		selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_received));

		if(selection == NULL)
		return;
		
		if (gtk_tree_selection_get_selected(selection, &model, &iter))
		{
		    gtk_tree_model_get(model, &iter,
		                       CALLLOG_INDEX_COL, &index,
		                       -1);

			delete_calllog_by_index(index, CL_RECEIVED);
			sync_calllog_list();
		}
	}
	else if(currentPage == DIALED_PAGE)
	{
		selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_dialed));

		if(selection == NULL)
		return;
		
		if (gtk_tree_selection_get_selected(selection, &model, &iter))
		{
		    gtk_tree_model_get(model, &iter,
		                       CALLLOG_INDEX_COL, &index,
		                       -1);
			
			delete_calllog_by_index(index, CL_DIALED);

			sync_calllog_list();
		}
	}
}

void on_button_calllog_close_clicked(GtkWidget *widget, gpointer user_data)
{
    GtkWindowInfo pwindow_info;
    
	get_window_out_stack(&pwindow_info);
	gtk_widget_destroy(GTK_WIDGET(pwindow_info.window));

	show_top_window();
}

void on_treeview_calllog_missed_row_activated(GtkWidget *widget, gpointer user_data)
{
	int index;
    GtkTreeModel *model;
	GtkTreeIter iter;
	GtkTreeSelection *selection;
	int currentPage;
	CallLog calllog;
    
    currentPage = gtk_notebook_get_current_page(notebook);
	memset(&calllog, 0, sizeof(CallLog));

	if(currentPage != MISSED_PAGE)
	{
		showError("%s, Wrong Page Wrong Treeview\n", __FUNCTION__);
		return;
	}	
	if(!get_calllog_count_by_type(CL_MISSED))
	{
		showError("%s, No MISSED Callog\n", __FUNCTION__);
		return;
	}
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_missed));
	if(selection == NULL)
	{
		showError("%s, Selection is NULL\n", __FUNCTION__);
		return;
	}
	
	if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	                       CALLLOG_INDEX_COL, &index,
	                       -1);
		
		get_calllog_by_index(&calllog, index, CL_MISSED);
		showDebug("calllog num: %s\n", calllog.szremote);
	}
}

void on_treeview_calllog_received_row_activated(GtkWidget *widget, gpointer user_data)
{
	int index;
    GtkTreeModel *model;
	GtkTreeIter iter;
	GtkTreeSelection *selection;
	int currentPage;
	CallLog calllog;
    
    currentPage = gtk_notebook_get_current_page(notebook);
	memset(&calllog, 0, sizeof(CallLog));
	
	if(currentPage != RECEIVED_PAGE)
	{	
		showError("%s, Wrong Page Wrong Treeview\n", __FUNCTION__);
		return;
	}
	if(!get_calllog_count_by_type(CL_RECEIVED))
	{
		showError("%s, No RECEIVED Callog\n", __FUNCTION__);
		return;
	}
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_received));
	if(selection == NULL)
	{
		showError("%s, Selection is NULL\n", __FUNCTION__);
		return;
	}
	
	if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	                       CALLLOG_INDEX_COL, &index,
	                       -1);
		
		get_calllog_by_index(&calllog, index, CL_RECEIVED);
		showDebug("calllog num: %s\n", calllog.szremote);
	}}

void on_treeview_calllog_dialed_row_activated(GtkWidget *widget, gpointer user_data)
{
	int index;
    GtkTreeModel *model;
	GtkTreeIter iter;
	GtkTreeSelection *selection;
	int currentPage;
	CallLog calllog;
    
    currentPage = gtk_notebook_get_current_page(notebook);
	memset(&calllog, 0, sizeof(CallLog));

	if(currentPage != DIALED_PAGE)
	{
		showError("%s, Wrong Page Wrong Treeview\n", __FUNCTION__);
		return;
	}	
	if(!get_calllog_count_by_type(CL_DIALED))
	{
		showError("%s, No DIALED Callog\n", __FUNCTION__);
		return;
	}
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_dialed));
	if(selection == NULL)
	{
		showError("%s, Selection is NULL\n", __FUNCTION__);
		return;
	}
	
	if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{	
	    gtk_tree_model_get(model, &iter,
	                       CALLLOG_INDEX_COL, &index,
	                       -1);
		
		get_calllog_by_index(&calllog, index, CL_DIALED);
		showDebug("calllog num: %s\n", calllog.szremote);
	}	
}

/********************************************************************************
                                                       focus in/out event
********************************************************************************/
void on_button_calllog_dialed_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_calllog_dialed_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_calllog_addToContact_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_calllog_addToContact_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_calllog_delete_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_calllog_delete_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_calllog_close_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_calllog_close_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

/********************************************************************************
                                                        list store
********************************************************************************/
static GtkListStore* create_missed_store(void)
{
	GtkListStore *missed_store;
	missed_store = gtk_list_store_new(3, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING);
	
	return missed_store;
}

static GtkListStore* create_received_store(void)
{
	GtkListStore *received_store;
	received_store = gtk_list_store_new(3, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING);
	
	return received_store;
}

static GtkListStore* create_dialed_store(void)
{
	GtkListStore *dialed_store;
	dialed_store = gtk_list_store_new(3, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING);
	
	return dialed_store;
}

static GtkTreeModel* fill_missed_store(GtkListStore *missed_store)
{   
    int i;
    CallLog calllog;
	Contact contact;
	GtkTreeIter iter;
	char datetime[128];
    char full_name[128];

	for(i = get_calllog_count_by_type(CL_MISSED) - 1; i > -1 ; i--)
	{   
	    memset(&calllog, 0, sizeof(CallLog));
		memset(&contact, 0, sizeof(Contact));
        get_calllog_by_index(&calllog, i, CL_MISSED);
	   
		if(!get_contact_by_phone(&contact, calllog.szremote))
		{
			sprintf(full_name, "%s%s", contact.name.szfamily_name, contact.name.szgiven_name);
		}
		else
		{
			//showDebug("Can not get contact\n");
			sprintf(full_name, "%s", calllog.szremote);
		}
		
		#if 1
        sprintf(datetime, "%s年%s月%s日%s时%s分%s秒",
	   	                 calllog.date.year,
        			     calllog.date.month,
        			     calllog.date.day,
    					 calllog.date.hour,
 						 calllog.date.minute,
 						 calllog.date.second);
	   
	    gtk_list_store_append (missed_store, &iter);
	    gtk_list_store_set (missed_store, &iter,
                            CALLLOG_INDEX_COL, i,
	                        //REMOTE_COL, _(full_name),
	                        REMOTE_COL, full_name,
	                        //DATETIME_COL, _(datetime),
	                        DATETIME_COL, datetime,
			                -1);
	    #endif
        //printf("remote: %s\n", _
	    //free(&contact);
	}


	return GTK_TREE_MODEL (missed_store);
}

static GtkTreeModel* fill_received_store(GtkListStore *received_store)
{   
    int i;
    CallLog calllog;
	Contact contact;
	GtkTreeIter iter;
	char datetime[128];
	char full_name[128];
    
#if 1
	for(i = get_calllog_count_by_type(CL_RECEIVED) - 1; i > -1 ; i--)
	{  
	   memset(&calllog, 0, sizeof(CallLog));
	   memset(&contact, 0, sizeof(Contact));
       get_calllog_by_index(&calllog, i, CL_RECEIVED);

	   if(!get_contact_by_phone(&contact, calllog.szremote))
	   {
		   showDebug("Contact: %s%s\n", contact.name.szfamily_name, contact.name.szgiven_name);
		   sprintf(full_name, "%s%s", contact.name.szfamily_name, contact.name.szgiven_name);
	   }
	   else
	   {
		   //showDebug("Can not get contact\n");
		   sprintf(full_name, "%s", calllog.szremote);
	   }
	   
       sprintf(datetime, "%s年%s月%s日%s时%s分%s秒",
	   	                 calllog.date.year,
        			     calllog.date.month,
        			     calllog.date.day,
    					 calllog.date.hour,
 						 calllog.date.minute,
 	   					 calllog.date.second);
	   
	   gtk_list_store_append (received_store, &iter);
	   gtk_list_store_set(received_store, &iter,
                          CALLLOG_INDEX_COL, i,
                          REMOTE_COL, full_name,
                          DATETIME_COL, datetime,
		                  -1);
	}
#endif

	return GTK_TREE_MODEL (received_store);
}

static GtkTreeModel* fill_dialed_store(GtkListStore *dialed_store)
{
    int i;
    CallLog calllog;
	Contact contact;
	GtkTreeIter iter;
	char datetime[128];
	char full_name[128];
	
#if 1
	for(i = get_calllog_count_by_type(CL_DIALED) - 1; i > -1 ; i--)
	{
		memset(&calllog, 0, sizeof(CallLog));
		memset(&contact, 0, sizeof(Contact));
		get_calllog_by_index(&calllog, i, CL_DIALED);

		if(!get_contact_by_phone(&contact, calllog.szremote))
		{	
			//showDebug("Contact: %s%s\n", contact.name.szfamily_name, contact.name.szgiven_name);
			sprintf(full_name, "%s%s", contact.name.szfamily_name, contact.name.szgiven_name);
		}
		else
		{
			//showDebug("Can not get contact\n");
			sprintf(full_name, "%s", calllog.szremote);
		}
		
		sprintf(datetime, "%s年%s月%s日%s时%s分%s秒",
			              calllog.date.year,
					      calllog.date.month,
					      calllog.date.day,
						  calllog.date.hour,
					      calllog.date.minute,
						  calllog.date.second);

		gtk_list_store_append (dialed_store, &iter);
		gtk_list_store_set (dialed_store, &iter,
		                    CALLLOG_INDEX_COL, i,
		                    //REMOTE_COL, _(full_name),
		                    //DATETIME_COL, _(datetime),
		                    REMOTE_COL, full_name,
		                    DATETIME_COL, datetime,
			                -1);
	}
#endif

	return GTK_TREE_MODEL (dialed_store);
}

static void selection_changed(GtkTreeSelection *selection)
{
#if 0
	GtkTreeView *treeview;
	ContactItemDetail* display;
	GtkTreeModel *model;
	GtkTreeIter iter;
	Contact contact;

	treeview = gtk_tree_selection_get_tree_view(selection);
	display = g_object_get_data(G_OBJECT(treeview), "ContactDetail");

	if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    int i = 0;
	    gint index;
	    GdkPixbuf *image;
	    char phoneInfo[128];

	    gtk_tree_model_get(model, &iter,
	                       2, &index,
	                       -1);

	    //get contact
	    get_contact_by_index(&contact, index);
	  
	    gtk_label_set_text (GTK_LABEL(display->given_name), contact.name.szgiven_name);
	    gtk_label_set_text (GTK_LABEL(display->family_name), contact.name.szfamily_name);
	    gtk_label_set_text (GTK_LABEL(display->group), NULL);

	    //phone
	    //while(contact.phones[i].szphone[0] != '\0')
	    //  {
	    //  		strcat(phoneInfo, contact.phones[i].szphone);
	    //		i++;
	    //  }
	    //  gtk_label_set_text (GTK_LABEL(display->phone), phoneInfo);

	    //image
	    image = gdk_pixbuf_new_from_file(ZHENJIE_PATH	, NULL);
	    gtk_image_set_from_pixbuf (GTK_IMAGE(display->image), image);
	   
	    //release
	}
	else
	{
	   
	}
#endif
}

static void set_remote_text (GtkTreeViewColumn *tree_column,
						       GtkCellRenderer   *cell,
						       GtkTreeModel      *model,
						       GtkTreeIter       *iter,
						       gpointer           data)
{
	char *remote;

	gtk_tree_model_get(model, iter,    
	                   REMOTE_COL, &remote,
	                   -1);
	
	g_object_set(GTK_CELL_RENDERER(cell),
   	    		 "text", remote,
	 			 NULL);
	g_free(remote);
}

static void set_datetime_text (GtkTreeViewColumn *tree_column,
							     GtkCellRenderer   *cell,
							     GtkTreeModel      *model,
							     GtkTreeIter       *iter,
							     gpointer           data)
{
	char *datetime;
    
	gtk_tree_model_get(model, iter,
	                   DATETIME_COL, &datetime,
	                   -1);
	
	g_object_set(GTK_CELL_RENDERER(cell),
	             "text", datetime,
	             NULL);
    
	free(datetime);
}

int sync_calllog_list()
{
    gtk_list_store_clear(missed_store);
	gtk_list_store_clear(received_store);
	gtk_list_store_clear(dialed_store);

	//set model
	gtk_tree_view_set_model(treeview_missed, fill_missed_store(missed_store));
	gtk_tree_view_set_model(treeview_received, fill_received_store(received_store));
	gtk_tree_view_set_model(treeview_dialed, fill_dialed_store(dialed_store));
}

int show_calllog_window()
{
    GtkBuilder *builder;
    GtkWidget *window;
	//GtkWidget *notebook;
	GtkTreeViewColumn *column_missed_remote;
	GtkTreeViewColumn *column_received_remote;
	GtkTreeViewColumn *column_dialed_remote;
	GtkTreeViewColumn *column_missed_datetime;
	GtkTreeViewColumn *column_received_datetime;
	GtkTreeViewColumn *column_dialed_datetime;
    GtkCellRenderer *cell_renderer;
	GtkTreeSelection *selection;
    
    //window
    builder = gtk_builder_new();
    gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
    window = GTK_WIDGET(gtk_builder_get_object(builder, "window_calllog"));
	gtk_window_set_title(window, "window_calllog");
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	notebook = (GtkNotebook *)gtk_builder_get_object(builder, "notebook_calllog");
	
    put_window_into_stack(window);

    //missed store and treeview
	missed_store = create_missed_store();
	treeview_missed = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_calllog_missed");
	gtk_tree_view_set_model(treeview_missed, fill_missed_store(missed_store));
	
	//received store and treeview
	received_store = create_received_store();
	treeview_received = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_calllog_received");
	gtk_tree_view_set_model(treeview_received, fill_received_store(received_store));
    
	//dialed store and treeview
	dialed_store = create_dialed_store();
	treeview_dialed = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_calllog_dialed");
	gtk_tree_view_set_model(treeview_dialed, fill_dialed_store(dialed_store));
	
#if 1
	//column  
	column_missed_remote = gtk_tree_view_column_new();
	column_received_remote = gtk_tree_view_column_new();
	column_dialed_remote = gtk_tree_view_column_new();

	column_missed_datetime = gtk_tree_view_column_new();
	column_received_datetime = gtk_tree_view_column_new();
	column_dialed_datetime = gtk_tree_view_column_new();
    
	//column title
	#if 0
    gtk_tree_view_column_set_title(column_missed_remote, _(DISPLAY_RECEIVED_FROM));
	gtk_tree_view_column_set_title(column_received_remote, _(DISPLAY_RECEIVED_FROM));
	gtk_tree_view_column_set_title(column_dialed_remote, _(DISPLAY_DIALED_TO));

	gtk_tree_view_column_set_title(column_missed_datetime, _(DISPLAY_DATETIME));
	gtk_tree_view_column_set_title(column_received_datetime, _(DISPLAY_DATETIME));
	gtk_tree_view_column_set_title(column_dialed_datetime, _(DISPLAY_DATETIME));
    #endif
	
	gtk_tree_view_column_set_title(column_missed_remote, DISPLAY_RECEIVED_FROM);
	gtk_tree_view_column_set_title(column_received_remote, DISPLAY_RECEIVED_FROM);
	gtk_tree_view_column_set_title(column_dialed_remote, DISPLAY_DIALED_TO);
	
	gtk_tree_view_column_set_title(column_missed_datetime, DISPLAY_DATETIME);
	gtk_tree_view_column_set_title(column_received_datetime, DISPLAY_DATETIME);
	gtk_tree_view_column_set_title(column_dialed_datetime, DISPLAY_DATETIME);
	
	//cell render missed
	cell_renderer = gtk_cell_renderer_text_new();
    gtk_tree_view_column_pack_start(column_missed_remote,
								    cell_renderer,
									TRUE);
    
    gtk_tree_view_column_set_cell_data_func(column_missed_remote, cell_renderer,
		                              	    set_remote_text, NULL, NULL);
    
	cell_renderer = gtk_cell_renderer_text_new();
    gtk_tree_view_column_pack_start(column_missed_datetime,
								    cell_renderer,
									TRUE);
    
    gtk_tree_view_column_set_cell_data_func(column_missed_datetime, cell_renderer,
		                              	    set_datetime_text, NULL, NULL);

	//cell render received
	cell_renderer = gtk_cell_renderer_text_new();
    gtk_tree_view_column_pack_start(column_received_remote,
								    cell_renderer,
									TRUE);
    
    gtk_tree_view_column_set_cell_data_func(column_received_remote, cell_renderer,
		                              	    set_remote_text, NULL, NULL);
	
	cell_renderer = gtk_cell_renderer_text_new();
    gtk_tree_view_column_pack_start(column_received_datetime,
								    cell_renderer,
									TRUE);
    
    gtk_tree_view_column_set_cell_data_func(column_received_datetime, cell_renderer,
		                              	    set_datetime_text, NULL, NULL);
	
	//cell render dialed
	cell_renderer = gtk_cell_renderer_text_new();
    gtk_tree_view_column_pack_start(column_dialed_remote,
								    cell_renderer,
									TRUE);
    
    gtk_tree_view_column_set_cell_data_func(column_dialed_remote, cell_renderer,
		                              	    set_remote_text, NULL, NULL);
	
	cell_renderer = gtk_cell_renderer_text_new();
    gtk_tree_view_column_pack_start(column_dialed_datetime,
								    cell_renderer,
									TRUE);
    
    gtk_tree_view_column_set_cell_data_func(column_dialed_datetime, cell_renderer,
		                              	    set_datetime_text, NULL, NULL);
	
	//bingding column to tree view                              		      
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_missed),
					            column_missed_remote);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_received),
					            column_received_remote);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_dialed),
					            column_dialed_remote);

	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_missed),
					            column_missed_datetime);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_received),
					            column_received_datetime);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_dialed),
					            column_dialed_datetime);
	
	//event
	gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
#endif
	show_top_window();
    
    return 0;
}

