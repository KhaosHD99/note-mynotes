#include <stdio.h>
//#include <string.h>
#include "phonebook.h"
//#include "calllog.hpp"
//#include <gtk/gtk.h>
//#include<libintl.h>
//#include<locale.h>
//#include <glib/gi18n.h>

/*const char *list_item_data_key = "list_item_data";

extern "C" void on_list1_select_child(GtkWidget *gtklist, gpointer user_data)
{
	  GList   *dlist;
    dlist = GTK_LIST (gtklist)->selection;
    const char *item_data_string;
    
    if (!dlist) 
				return;
    
	  item_data_string = (const char*)g_object_get_data (G_OBJECT (dlist->data), list_item_data_key);
	 	g_print("The selection is %s ", item_data_string);
 	 
    g_print ("\n");
}*/

int main(int argc, char *argv[])
{  
	//   load_contact_from_file();
	  printf("result is %d\n", test(2, 5));
	  //test(2,6);
	   //printf("add is %d\n",add(2,6));
   // CCalllogManager *manager = CCalllogManager::get_instance();
   // CContactManager *manager = CContactManager::get_instance();
    
    //test();
    //read
		//manager->load_contact_from_file();
   // printf("%d\n", manager->get_contact_count());
    //gtk
    /*GtkBuilder *builder;
    GtkWidget *window;
    GtkWidget *gtklist;
    GtkWidget *list_item;
    int i;
    char buffer[64];
    
    //builder
    gtk_init (&argc, &argv);
    builder = gtk_builder_new ();
    gtk_builder_add_from_file (builder, "list.xml", NULL);
	  
	  //window
    window = GTK_WIDGET(gtk_builder_get_object(builder, "window1"));
    gtk_window_set_title (GTK_WINDOW (window), "GtkList Example");
    g_signal_connect (G_OBJECT (window), "destroy",
		                  G_CALLBACK (gtk_main_quit),
		                  NULL);
		
    //list
    gtklist = GTK_WIDGET(gtk_builder_get_object(builder, "list1"));
    
    //list item
    for (i = 0; i < 20; i++) 
    {
				GtkWidget *label;
				char *string;
				
			 	//Contact contact;
		    //int ret = manager->get_contact_by_name(&contact, "镇杰");
			  //	sprintf(buffer, contact.name.szgiven_name, i);
				sprintf(buffer, "中文%d", i);
				label=gtk_label_new (buffer);
				list_item=gtk_list_item_new ();
				gtk_container_add (GTK_CONTAINER (list_item), label);
				gtk_container_add (GTK_CONTAINER (gtklist), list_item);
				gtk_label_get (GTK_LABEL (label), &string);
				g_object_set_data (G_OBJECT (list_item), list_item_data_key, string);
    }
    
    //event
    gtk_builder_connect_signals (builder, NULL);
    g_object_unref (G_OBJECT (builder));
    
    gtk_widget_show_all (window);
    gtk_main();*/
    
    //add contact
	  /*Contact *section = new Contact;
		memset(section, 0, sizeof(Contact));
	
		strcpy(section->name.szfamily_name,"徐");
		strcpy(section->name.szgiven_name,"镇杰");
	
		section->phones[0].type = PT_HOME;
		strcpy(section->phones[0].szphone, "31325201");
		section->phones[1].type = PT_MOBILE;
		strcpy(section->phones[1].szphone, "13539982758");
		section->phones[2].type = PT_WORK;
		strcpy(section->phones[2].szphone, "12345678");
	
		section->emails[0].type = EMT_WORK;
		strcpy(section->emails[0].szemail, "xujiekoo@qq.com");
	  section->emails[1].type = EMT_HOME;
		strcpy(section->emails[1].szemail, "163.com");
	    
		strcpy(section->szvoip,"172.17");
		strcpy(section->szim,"466795229");
		strcpy(section->szaddress,"yuexu");
	
	  manager->add_contact(section);
		manager->add_contact(section);
		manager->add_contact(section);*/
    
    //delete
	 //manager->delete_calllog_by_status(CL_DIALED);
	 // manager->delete_calllog_by_status(CL_MISSED);
		//manager->delete_calllog_by_index(CL_MISSED, 0);
	 // manager->delete_contact_all();
    //manager->delete_contact_by_index(0);
    //manager->sort_by_letter();
    //manager->read_contact();
		//manager->get_section_from_config_file(0);
		
  //  printf("%d\n", manager->get_contact_count());
	  //add calllog
    /*CallLog *calllog = new CallLog;
	
	  calllog->status = CL_DIALED;
	  const char *str = "8";
	  const char *str2 = "中文";
	
	  strcpy(calllog->szremote, str2); 
	  strcpy(calllog->date.year, str); 
    strcpy(calllog->date.month, str);
    strcpy(calllog->date.day, str);
    strcpy(calllog->date.hour, str);
    strcpy(calllog->date.minute,str);
    strcpy(calllog->date.second, str);

	  manager->add_calllog(CL_DIALED, calllog);
	  manager->add_calllog(CL_MISSED, calllog);
	  manager->add_calllog(CL_DIALED, calllog);
	  manager->add_calllog(CL_RECEIVED, calllog);*/

  
    
	  //get
    /*Contact *contact = new Contact;
		int ret = manager->get_contact_by_name(&contact, "徐镇杰");
		//int ret = manager->get_contact_by_phone(&contact, "135399858");
		//int ret = manager->get_contact_by_letter(&contact, "x");
		//int ret = manager->get_contact_by_index(&contact, 0);
    if(ret == -1)
		cout << "\ncan not find any thing " << endl; 
		else
		{
				cout << "\nsame at: " << ret << endl; 
   		 	cout << "show: " << contact->name.szfamily_name << endl;
		}*/
    
  	//update
  	/*Contact *section = new Contact;
		memset(section, 0, sizeof(Contact));

		strcpy(section->name.szfamily_name,"wu");
		strcpy(section->name.szgiven_name,"yaoquan");

		section->phones[0].type = PT_HOME;
		strcpy(section->phones[0].szphone, "31325201");
		section->phones[1].type = PT_MOBILE;
		strcpy(section->phones[1].szphone, "13539982758");
    
		section->emails[0].type = EMT_WORK;
		strcpy(section->emails[0].szemail, "xujiekoo@qq.com");
    section->emails[1].type = EMT_HOME;
		strcpy(section->emails[1].szemail, "163.com");
    
		strcpy(section->szvoip,"172.17");
		strcpy(section->szim,"466795229");
		strcpy(section->szaddress,"yuexu");

  	int ret = manager->update_contact_by_index(section, 0);
		if(ret == -1)
		printf("fail");*/
	
    return 0;
}

