#ifndef PHONEBOOKSKIN_DEF
#define PHONEBOOKSKIN_DEF

/*
#define GLADE_FILE_PATH             "../share/data/appfile/phonebook/phonebook.glade"
#define GTK_RC_FILE_PATH            "../share/data/appfile/phonebook/.gtkrc-2.0"
#define CONTACT_FILE_PATH           "../share/data/appfile/phonebook/Contact.cfg"
#define CALLLOG_FILE_PATH           "../share/data/appfile/phonebook/Calllog.cfg"
#define QUICK_DIAL_FILE_PATH        "../share/data/appfile/phonebook/Quickdial.cfg"
#define BLACK_LIST_FILE_PATH        "../share/data/appfile/phonebook/Blacklist.cfg"
#define COMMON_PHONE_FILE_PATH      "../share/data/appfile/phonebook/Common.cfg"
#define CONFIG_FILE_PATH            "../share/data/appfile/phonebook/Config.cfg"
*/

#define IMAGE_FILE_PATH             "../share/data/appfile/phonebook/images/"

//img name
#define IMG_MAIN_MENU_CONTACT_NORMAL			"pb_main_menu_contact_normal_image.jpg"			//联系人
#define IMG_MAIN_MENU_CONTACT_ACTIVE			"pb_main_menu_contact_active_image.jpg"	
#define IMG_MAIN_MENU_CALLLOG_NORMAL			"pb_main_menu_calllog_normal_image.jpg"			//通话记录
#define IMG_MAIN_MENU_CALLLOG_ACTIVE			"pb_main_menu_calllog_active_image.jpg"
#define IMG_MAIN_MENU_BACKLIST_NORMAL			"pb_main_menu_backlist_normal_image.jpg"		//黑名单
#define IMG_MAIN_MENU_BACKLIST_ACTIVE			"pb_main_menu_backlist_active_image.jpg"
#define IMG_MAIN_MENU_QUICKDIAL_NORMAL			"pb_main_menu_quickdial_normal_image.jpg"    	//快速拨号
#define IMG_MAIN_MENU_QUICKDIAL_ACTIVE			"pb_main_menu_quickdial_active_image.jpg"       
#define IMG_MAIN_MENU_COMMONPHONEDIAL_NORMAL    "pb_main_menu_commonphonedial_normal_image.jpg"	//公共服务拨号commonphonedial
#define IMG_MAIN_MENU_COMMONPHONEDIAL_ACTIVE    "pb_main_menu_commonphonedial_active_image.jpg"	

//button color
#define BUTTON_NORMAL_COLOR               "#434343"
#define BUTTON_FOCUSED_COLOR              "#898989"
#define BUTTON_ACTIVE_COLOR               "#"
#define MAIN_WINDOW_TITLE                 "window_main"

#define DIALOG_SIZE_WIDTH                 280
#define DIALOG_SIZE_HEIGHT                120	
#define DIALOG_POS_X                      350
#define DIALOG_POS_Y                      200
	
#define PROGRESS_BAR_SIZE_WIDTH                 150
#define PROGRESS_BAR_SIZE_HEIGHT                25
#define PROGRESS_BAR_POS_X                      350
#define PROGRESS_BAR_POS_Y                      230

#define DISPLAY_ADD_NEW_ITEM      "添加新项"

enum
{
    CONTACT_BUF,
    CALLLOG_BUF,
    BLACKLIST_BUF,
    QUICKDIAL_BUF,
    COMMONPHONE_BUF
};

/*
enum
{	
	NO,
	YES
};	
*/

#endif
