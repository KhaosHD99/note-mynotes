#ifndef PROMPTER_MODULE_DEF
#define PROMPTER_MODULE_DEF

#include <stdio.h>
#include <unistd.h>

#include "Vial.hpp"
#include "AbstractModule.hpp"
#include "CodeConvert.hpp"
#include "VialType_Common.hpp"
#include "LogMsg.hpp"
#include "VialType_PhoneIntf.hpp"
#include "VialType_Phonebook.hpp"
#include "phonebookapi.h"
#include "CCST.hpp"

#define PHONENUM_LEN1 8
#define PHONENUM_LEN2 11
#define AREA_CODE_COUNT 1
#define AREA_CODE_LEN 4

#define MAX_DIAL_WAIT_TIME 5

const char AREA_CODE[AREA_CODE_COUNT][AREA_CODE_LEN] =
{
	"020"
};

const char STATE_INFO[5][32]=
{	
	"ON_HOOK",
	"DIALING",
	"RINGING",
	"NOVIDEO",
	"VIDEO",
};

/********************************************************************
					     Play Advertisement Module
*********************************************************************/
class PhonebookModule : public AbstractModule
{
#define __CLASS__ "PhonebookModule"
#define VIAL_PHONECODE_LEN	32
	struct
	{	
		int nPhoneMode;
		int nCallType;
		int nCodelen;
		char cPhoneCode[VIAL_PHONECODE_LEN];
	}PhoneCode;
	
	private:
		CCST::ST cur_state;
		VialSystem *vialSys;
		static PhonebookModule  *adverModule_instance;
	
	private:
		PhonebookModule (VialSystem *vialSys);
		virtual ~PhonebookModule (){};
		bool on_on_hook(StateChangeVial *vial);
		bool on_dialing(StateChangeVial *vial);
		bool on_ringing(StateChangeVial *vial);
		bool on_novideoconn(StateChangeVial *vial);
		bool on_videoconn(StateChangeVial *vial);

		int get_contact_info_by_phonenum(Contact *contact, const char *phonenum);
			
	protected:
		bool on_vial_state_change(StateChangeVial *vial);
		bool on_vial_dial_notify(DialNotifyVial *vial);
		bool on_vial_caller_phonecode(CallerPhoneCodeVial *vial);
			
	public:
		void run();
	 	static PhonebookModule *get_instance(VialSystem *vialSys);
		virtual bool localInit();
		virtual bool onExit();
		virtual bool OnReceive(Vial *vial);
		
		bool post_vial(Vial *vial, NodeID dstID);
		int send_dial_vial(Vial *vial, NodeID dstID);
		bool is_standby();
		bool is_callout();
};
#endif
