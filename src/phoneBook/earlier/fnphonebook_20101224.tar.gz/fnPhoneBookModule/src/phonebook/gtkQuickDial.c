#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>

#include "phonebookapi.h"
#include "phonebookskin.h"
#include "windowstack.h"
#include "LogMsg.hpp"

//#define _(STRING) g_convert(STRING, -1, "UTF-8", "GB2312", NULL, NULL, NULL)
//#define _to_asc(STRING) g_convert(STRING, -1, "GB2312", "UTF-8", NULL, NULL, NULL)

GtkListStore *quickdial_store;
GtkListStore *contact_store;

GtkTreeView *treeview_quickdial_main;
GtkTreeView *treeview_quickdial;
GtkTreeView *treeview_contact;

enum 
{
	QUICK_DIAL_INDEX_COL,
    QUICK_DIAL_PHONENUM_COL,
    CONTACT_INDEX_COL = 0,
    FAMILY_NAME_COL,
    GIVEN_NAME_COL
};

//extern int is_has_focus;
//extern char HAS_FOCUS[2][32];
extern int lose_focus_mode;

on_treeview_quickdial_row_activated(GtkWidget *window, gpointer user_data)
{
	showDebug("Active\n");
}

void on_button_quickdial_dial_clicked(GtkWidget *window, gpointer user_data)
{
	int index;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;
	
	if(!get_quickdial_count())
    {	
        show_message_window("黑名单为空\n");
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_quickdial_main));
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window("没有选择任何项\n");
		return;
	}
	
	gtk_tree_model_get(model, &iter,
	                   CONTACT_INDEX_COL, &index,
	                   -1);

	showDebug("Contact index: %d\n", index);

	show_phonenum_selector_window(CONTACT_BUF, index);
}

void on_button_quickdial_delete_clicked(GtkWidget *window, gpointer user_data)
{
	int index;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;
	Contact contact;
	
    if(!get_quickdial_count())
    {
        show_message_window("没有任何快速拨号选项");
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_quickdial_main));
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window("没有选中任何选项");
		return;
	}
	
    if(!(show_confirm_window("确认删除 ?") == GTK_RESPONSE_OK))
   		return;

	memset(&contact, 0, sizeof(Contact));
    if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	                       QUICK_DIAL_INDEX_COL, &index,
	                       -1);

		get_contact_by_index(&contact, index);
		contact.is_in_quickdial = NO;
		update_contact_by_index(&contact, index);
    }
	
	//sync quickdial list
    sync_quickdial_list();
}

void on_button_quickdial_cancel_clicked(GtkWidget *window, gpointer user_data)
{
    GtkWindowInfo pwindow_info;
	
	if(get_window_out_stack(&pwindow_info) >= 0)
		destroy_widget(GTK_WIDGET(pwindow_info.window));
	else
		showError("%s XXXXXXXXXXXXXXXXXXX get_window_out_stack Error\n", __FUNCTION__);
	
	//show_top_window();
}

void on_button_quickdial_edit_clicked(GtkWidget *window, gpointer user_data)
{
    showDebug("edit clicked\n");
	show_quick_dial_edit_window();
}

void on_button_quickdial_edit_add_clicked(GtkWidget *window, gpointer user_data)
{
    int index;
	int i;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;
	Contact contact;
	Blacklist blacklist;
	char full_name[64];
	
    if(!get_contact_count())
    {
        show_message_window("没有任何联系人");
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_contact));
	
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window("没有选中任何选项");
		return;
	}

	if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{	
	    gtk_tree_model_get(model, &iter,
	                       CONTACT_INDEX_COL, &index,
	                       -1);
		
        if(!get_contact_by_index(&contact, index))
		{
		    if(contact.is_in_quickdial)
		    {
				show_message_window("已经存在");
				return;
			}
			contact.is_in_quickdial = YES;
			update_contact_by_index(&contact, index);
		}
				
		//sync quickdial list
        sync_quickdial_list();
    }
}

void on_button_quickdial_edit_delete_clicked(GtkWidget *window, gpointer user_data)
{	
	int index;
	Contact contact;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;

    if(!get_quickdial_count())
    {
        show_message_window("没有任何快速拨号选项");
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_quickdial));
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window("没有选中任何选项");
		return;
	}
	
    if(!(show_confirm_window("确认删除 ?") == GTK_RESPONSE_OK))
   		return;

	memset(&contact, 0, sizeof(Contact));
    if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	                       QUICK_DIAL_INDEX_COL, &index,
	                       -1);
		
		get_contact_by_index(&contact, index);
		contact.is_in_quickdial = NO;
		update_contact_by_index(&contact, index);
    }	
    
	//sync quickdial list
    sync_quickdial_list();
}

void on_button_quickdial_edit_cancel_clicked(GtkWidget *window, gpointer user_data)
{
	GtkWindowInfo pwindow_info;
	
    get_window_out_stack(&pwindow_info);
	gtk_widget_destroy(GTK_WIDGET(pwindow_info.window));

	//show_top_window();
}

/********************************************************************************
                                                       focus in/out event
********************************************************************************/
void on_window_quickdial_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	/*is_has_focus = YES;
	showDebug("%s Is Has Focus %s\n", __FUNCTION__, HAS_FOCUS[is_has_focus]);*/
	//destory_window();
}

void on_window_quickdial_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	showDebug("XXXXXXXXXXXXXX %s Lose Mode: %d\n", __FUNCTION__, lose_focus_mode);
	
	if(!lose_focus_mode)
	{	
		destory_window_except_root();
	}
	else
		lose_focus_mode = 0;
}

on_window_quickdial_edit_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	/*is_has_focus = YES;
	showDebug("%s Is Has Focus %s\n", __FUNCTION__, HAS_FOCUS[is_has_focus]);*/
	//destory_window();
}

void on_window_quickdial_edit_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	showDebug("XXXXXXXXXXXXXX %s Lose Mode: %d\n", __FUNCTION__, lose_focus_mode);
	
	if(!lose_focus_mode)
	{	
		destory_window_except_root();
	}
	else
		lose_focus_mode = 0;
}

void on_button_quickdial_edit_add_focus_in_event(GtkWidget *widget, gpointer user_data)
{	
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

on_button_quickdial_edit_add_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}	
	
void on_button_quickdial_dial_focus_in_event(GtkWidget *widget, gpointer user_data)
{	
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}
	
void on_button_quickdial_dial_focus_out_event(GtkWidget *widget, gpointer user_data)
{	
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}
	
void on_button_quickdial_edit_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_quickdial_edit_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_quickdial_delete_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_quickdial_delete_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_quickdial_cancel_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_quickdial_cancel_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_quickdial_edit_cancel_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_quickdial_edit_cancel_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_quickdial_edit_delete_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_quickdial_edit_delete_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

#if 1
/********************************************************************************
                                                      comonphone treeview
********************************************************************************/
GtkListStore* create_quickdial_store(void)
{
	GtkListStore *quickdial_store;
	quickdial_store = gtk_list_store_new(3, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING);
	
	return quickdial_store;
}

GtkTreeModel* fill_quickdial_store(GtkListStore *quickdial_store)
{
	int i;
	char full_name[128];
	
    for(i = 0; i < get_contact_count(); i++)
	{
		Contact contact;
		GtkTreeIter iter;
		memset(&contact, 0, sizeof(Contact));

		if(get_contact_by_index(&contact, i))
		{
			showWarning("%s, Get Contact Fail\n", __FUNCTION__);
			continue;
		}
		
		if(contact.is_in_quickdial)
		{		
			sprintf(full_name, "%s%s", contact.name.szfamily_name, contact.name.szgiven_name);
			gtk_list_store_append(quickdial_store, &iter);
			gtk_list_store_set(quickdial_store, &iter,
			 	               QUICK_DIAL_INDEX_COL, i,
				               QUICK_DIAL_PHONENUM_COL, full_name,
												 		   -1);
		}
	}
	
	return GTK_TREE_MODEL (quickdial_store);
}
#endif

/********************************************************************************
                                          set commonphone phonenum to column
********************************************************************************/
void set_quickdial_phonenum(GtkTreeViewColumn *tree_column,
							      GtkCellRenderer   *cell,
							      GtkTreeModel      *model,
							      GtkTreeIter       *iter,
							      gpointer           data)
{
    #if 1
	int index;
	char *contact_name;
	
	gtk_tree_model_get(model, iter,
	                   QUICK_DIAL_PHONENUM_COL, &contact_name,
					   -1);
	
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", contact_name,
                 //"text", "elon",
                 NULL);

	g_free(contact_name);
    #endif
}

void set_contact_name (GtkTreeViewColumn *tree_column,
					      GtkCellRenderer   *cell,
					      GtkTreeModel      *model,
					      GtkTreeIter       *iter,
					      gpointer           data)
{
    #if 1
	char *given_name;
	char *family_name;
	char strCombine[64];
	
	gtk_tree_model_get(model, iter,
	                 FAMILY_NAME_COL, &family_name,
	                 GIVEN_NAME_COL, &given_name,
	                 -1);
	
	sprintf(strCombine, "%s%s", family_name, given_name);
	
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", strCombine,
                 NULL);	
	
	g_free(family_name);
	g_free(given_name);
    #endif
}

int sync_quickdial_list()
{
	//sync main quickdial list
	gtk_list_store_clear(quickdial_store);
	gtk_tree_view_set_model(treeview_quickdial_main, fill_quickdial_store(quickdial_store));
	
    //sync quickdial
    gtk_list_store_clear(quickdial_store);
 	gtk_tree_view_set_model(treeview_quickdial, fill_quickdial_store(quickdial_store));
}

int show_quick_dial_edit_window()
{	
	GtkBuilder *builder;
    GtkWidget *window;
	GtkTreeViewColumn *column_contact;
	GtkTreeViewColumn *column_quickdial;
	GtkCellRenderer *cell_renderer;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_quickdial_edit"));
	gtk_window_set_title(GTK_WINDOW(window), "window_quickdial_edit");
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	put_window_into_stack(window);
	
    #if 1
	//add  model to tree view
	quickdial_store = create_quickdial_store();
	contact_store = create_contact_store();
	
	treeview_quickdial = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_quickdial_edit_quickdiallist");
	gtk_tree_view_set_model(treeview_quickdial, fill_quickdial_store(quickdial_store));
	
	treeview_contact = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_quickdial_edit_contactlist");
    gtk_tree_view_set_model(treeview_contact, fill_contact_store(contact_store));
	#if 1
	//column  
	column_contact = gtk_tree_view_column_new();
	column_quickdial = gtk_tree_view_column_new();
    
	// quickdial
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_quickdial,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_quickdial, cell_renderer,
		                              	    set_quickdial_phonenum,
		                              	    NULL, NULL);
	
	//contact
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_contact,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_contact, cell_renderer,
		                              	    set_contact_name,
		                              	    NULL, NULL);
	
	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_quickdial),
					            column_quickdial);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_contact),
					            column_contact);
	#endif
    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();
	
	return 0;
	#endif
}

int show_quick_dial_window()
{
	GtkBuilder *builder;
    GtkWidget *window;
	GtkTreeViewColumn *column_phonenum;
	GtkCellRenderer *cell_renderer;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_quickdial"));
	
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	put_window_into_stack(window);
	
    #if 1
	//add  model to tree view
	quickdial_store = create_quickdial_store();
	
	treeview_quickdial_main = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_quickdial");
	gtk_tree_view_set_model(treeview_quickdial_main, fill_quickdial_store(quickdial_store));
	
	//column  
	column_phonenum = gtk_tree_view_column_new();
    
	// phonenum cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_phonenum,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_phonenum, cell_renderer,
		                              	    set_quickdial_phonenum, 
		                              	    NULL, NULL);
		
	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_quickdial_main),
					            column_phonenum);
	#endif
    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();
	
	return 0;
}

