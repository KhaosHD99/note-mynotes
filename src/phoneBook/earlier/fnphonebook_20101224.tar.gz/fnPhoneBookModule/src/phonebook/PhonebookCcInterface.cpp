#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "PhonebookModule.h"
#include "ModuleID.hpp"

//VialSystem *sendVialSys = NULL;
//PhonebookModule *adver_send_test = NULL;

VialSystem *vialsys_phonebook;

/**************************************************************
                             thread_adv_play_module
**************************************************************/
static void *thread_phonebook_module(void *data)
{
	VialSystem vialSys(FN_PHONE_BOOK_MODULE_ID);
	vialsys_phonebook = &vialSys;
	PhonebookModule *phonebook_module = PhonebookModule::get_instance(vialsys_phonebook);
	
	if(phonebook_module)
	{	
		phonebook_module->init();
		phonebook_module->run();
	}	
	else
	{
		showError("%s Create Phonebookmoudule Fail\n", __FUNCTION__);
		return NULL;
	}
}

/***********************************************************************************************
                                                             creat_and_run_prompter_module
***********************************************************************************************/
#ifdef __cplusplus
extern"C"
{	
#endif
int creat_and_run_phonebook_module()
{	
	pthread_t phonebook_module_thread;
	
	if(pthread_create(&phonebook_module_thread, NULL, thread_phonebook_module, NULL) == 0)
	{
		showInfo("%s thread create Ok, phonebookmoudule thread start\n", __FUNCTION__);
		return 0;
	}
	else
	{	
		showError("%s thread phonebookmoudule create Err\n", __FUNCTION__);
		return -1;	
	}	
}

int dial(const char* phonenum)
{		
	if(!phonenum)
		return -1;
	
	#if 1
	PhonebookModule *phonebook_module = PhonebookModule::get_instance(vialsys_phonebook);
	
	PhoneDialCmdVial phone_dial_cmd_vial;
	strcpy(phone_dial_cmd_vial.cCode, phonenum);
	phone_dial_cmd_vial.nLen = strlen(phone_dial_cmd_vial.cCode);
	
	return phonebook_module->send_dial_vial(&phone_dial_cmd_vial, FN_PHONE_CONTROL_MODULE_ID);
	#endif
		
	#if 0
		PhonebookModule *phonebook_module = PhonebookModule::get_instance(vialsys_phonebook);
		ContactPrompterVial contact_prompter_vial;
		//memset(&contact_prompter_vial, 0, sizeof(ContactPrompterVial));
		strcpy(contact_prompter_vial.szContactName, "Test Name");
		strcpy(contact_prompter_vial.szPhoneNum, "8888999999999");
		
		showDebug("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX Post Standby\n");
		phonebook_module->post_vial(&contact_prompter_vial, FN_PROMPTER_MODULE_ID);
		showDebug("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX Post Over\n");
	#endif
	
	return 0;
}

#ifdef __cplusplus
}
#endif

