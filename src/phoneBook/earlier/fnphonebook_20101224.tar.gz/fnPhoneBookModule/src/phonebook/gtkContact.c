#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

#include "phonebookapi.h"
#include "phonebookskin.h"
#include "windowstack.h"
#include "LogMsg.hpp"

//#define DISPLAY_GROUPTYPE_DEFAULT "--﻿添加新组--  "
static GtkWidget *fixed_addcontact;

GtkListStore *store;
GtkListStore *combo_group_store;
GtkListStore *combo_phonenum_store;
GtkListStore *combo_email_store;

GtkTreeIter current_phonenum_iter;
GtkTreeIter current_email_iter;

GtkTreeView *contact_treeview;
GtkComboBox *combo_group;
GtkComboBox *combo_contact_detail_phonenum;
GtkComboBox *combo_contact_detail_email;

GtkEntry *entry_familyname;
GtkEntry *entry_givenname;
GtkEntry *entry_phonenum;
GtkEntry *entry_email;
GtkEntry *entry_im;
GtkEntry *entry_voip;
GtkEntry *entry_address;
	
//extern int is_has_focus;
extern int lose_focus_mode;

char phonenum_tmp_buf[128] = {0};
int phonenum_seletion_flag = YES;
	
char email_tmp_buf[128] = {0};
int email_seletion_flag = YES;
	
extern char HAS_FOCUS[2][32];
	
enum
{	
	CONTACT_INDEX_COL,
    FAMILY_NAME_COL,
    GIVEN_NAME_COL,
    GROUP_COL = 0,
    PHONENUM_INDEX_COL = 0,
    PHONENUM_COL,
    EMAIL_INDEX_COL = 0,
    EMAIL_COL
};	
	
typedef struct stModeInfo
{
	ContactDetailMode mode;
	int index;
}ModeInfo;

/********************************************************************************
                                                      contact treeview
********************************************************************************/
GtkListStore* create_contact_store(void)
{
	GtkListStore *store;
	store = gtk_list_store_new(3, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING);
	
	return store;
}

GtkTreeModel* fill_contact_store(GtkListStore *store)
{	
    int i;
	
    for(i = 0; i < get_contact_count(); i++)
	{	
	   #if 1
	   Contact contact;
	   GtkTreeIter iter;
	   memset(&contact, 0, sizeof(Contact));
       get_contact_by_index(&contact, i);
		
	   
	   gtk_list_store_append(store, &iter);
	   gtk_list_store_set(store, &iter,
			              CONTACT_INDEX_COL, i,
			              FAMILY_NAME_COL, contact.name.szfamily_name,
			              GIVEN_NAME_COL, contact.name.szgiven_name,
			              -1);
	   #endif
	}
    
	return GTK_TREE_MODEL (store);
}

void set_index(GtkTreeViewColumn *tree_column,
		        GtkCellRenderer   *cell,
		        GtkTreeModel      *model,
		        GtkTreeIter       *iter,
		        gpointer           data)
{	
	int index;
	char index_str[16];
		
	gtk_tree_model_get(model, iter,
	                   CONTACT_INDEX_COL, &index,
	                   -1);
   
	sprintf(index_str, "%i", index + 1);
	
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", index_str,
                 NULL);
}

void set_name (GtkTreeViewColumn *tree_column,
				      GtkCellRenderer   *cell,
				      GtkTreeModel      *model,
				      GtkTreeIter       *iter,
				      gpointer           data)
{	
    #if 1
	char *given_name;
	char *family_name;
	char strCombine[64];
	
	gtk_tree_model_get(model, iter,
	                   FAMILY_NAME_COL, &family_name,
	                   GIVEN_NAME_COL, &given_name,
	                   -1);
	
	sprintf(strCombine, "%s%s", family_name, given_name);
	
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", strCombine,
                 NULL);	
	
	g_free(family_name);
	g_free(given_name);
    #endif
}

void set_contact_selector_phonenum(GtkTreeViewColumn *tree_column,
									      GtkCellRenderer   *cell,
									      GtkTreeModel      *model,
									      GtkTreeIter       *iter,
									      gpointer           data)
{
    #if 1
	char *phonenum;
	
	gtk_tree_model_get(model, iter,
	                   PHONENUM_COL, &phonenum,
	                   -1);
		
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", phonenum,
                 NULL);
	
	g_free(phonenum);
    #endif
}

/********************************************************************************
                                                               event
********************************************************************************/
void on_button_contact_dial_clicked(GtkWidget *widget, gpointer user_data)
{	
	int index;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;
	
	if(!get_contact_count())
    {
        show_message_window("没有联系人\n");
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(contact_treeview));
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window("没有选择任何项\n");
		return;
	}
	
	gtk_tree_model_get(model, &iter,
	                   CONTACT_INDEX_COL, &index,
	                   -1);

	showDebug("Contact index: %d\n", index);

	show_phonenum_selector_window(CONTACT_BUF, index);
}

void on_button_contact_add_clicked(GtkWidget *widget, gpointer user_data)
{
	show_contact_detail_window(ADD, NULL);
}

void on_button_contact_edit_clicked(GtkWidget *widget, gpointer user_data)
{	
    GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(contact_treeview));
    if(!gtk_tree_selection_get_selected(selection, &model, &iter))
    {
		show_message_window(get_value_from_key(DISPLAY_NO_SELECT));
		return;
	}
	
	show_contact_detail_window(EDIT, NULL);
}

void on_button_contact_delete_clicked(GtkWidget *widget, gpointer user_data)
{   
	int index;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;

    if(!get_contact_count())
    {
        show_message_window(get_value_from_key(DISPLAY_NO_CONTACT));
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(contact_treeview));
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window(get_value_from_key(DISPLAY_NO_SELECT));
		return;
	}
	
    if(!(show_confirm_window(get_value_from_key(DISPLAY_DELETE_CONFIRM)) ==	GTK_RESPONSE_OK))
   		return;
	
    #if 1
	if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	                       CONTACT_INDEX_COL, &index,
	                       -1);
		
		//delete contact by index
		delete_contact_by_index(index);
    }
    #endif
	
	//sync contact list
    sync_contact_list();
}

void on_treeview_contactlist_row_activated(GtkWidget *widget, gpointer user_data)
{	
	//on_button_contact_edit_clicked(widget, user_data);
	on_button_contact_dial_clicked(widget, user_data);
}	

void on_button_contact_close_clicked(GtkWidget *widget, gpointer user_data)
{	
    GtkWindowInfo pwindow_info;
	
    if(get_window_out_stack(&pwindow_info) >= 0)
		destroy_widget(GTK_WIDGET(pwindow_info.window));
	else
		showError("%s XXXXXXXXXXXXXXXXXXX get_window_out_stack Error\n", __FUNCTION__);

	//show_top_window();
}

/********************************************************************************
                                                       contact detail
********************************************************************************/
void on_button_contact_detail_cancel_clicked(GtkWidget *widget, gpointer user_data)
{
	GtkWindowInfo pwindow_info;
	
	get_window_out_stack(&pwindow_info);	
	destroy_widget(GTK_WIDGET(pwindow_info.window));
	
	gtk_list_store_clear (combo_group_store);
	gtk_list_store_clear (combo_phonenum_store);
	gtk_list_store_clear (combo_email_store);

	//show_top_window();
}

void on_button_contact_detail_save_clicked(GtkWidget *savebutton, gpointer user_data)
{	
    if(validate_input())
		return;

    ModeInfo *mode_info = (ModeInfo *)user_data;
	const gchar *group_name;
    Contact contact;
    GtkEntry *entry;
	const gchar *tmpStr;
	const gchar *phonenum;
	const gchar *email;
	int i;
    
	memset(&contact, 0, sizeof(Contact));
	
	//family name
    tmpStr = gtk_entry_get_text(entry_familyname);
	strcpy(contact.name.szfamily_name, tmpStr);
	
	//given name
	tmpStr = gtk_entry_get_text(entry_givenname);
	strcpy(contact.name.szgiven_name, tmpStr);
   	
    //group
	GtkTreeIter iter;
	
	gtk_combo_box_get_active_iter(combo_group, &iter);
	gtk_tree_model_get(gtk_combo_box_get_model(combo_group), &iter,
					   GROUP_COL, &group_name,
					   -1);
	
	if(!strcmp(group_name, DISPLAY_GROUPTYPE_FAMILY))
		contact.type = GT_FAMILY;
	else if(!strcmp(group_name, DISPLAY_GROUPTYPE_COLLEAGUES))
		contact.type = GT_COLLEAGUES;
	else if(!strcmp(group_name, DISPLAY_GROUPTYPE_FRIENDS))
		contact.type = GT_FRIENDS;
	else if(!strcmp(group_name, DISPLAY_GROUPTYPE_RELATIVES))
		contact.type = GT_RELATIVES;
	else if(!strcmp(group_name, DISPLAY_GROUPTYPE_OTHER))
		contact.type = GT_OTHER;
    else
		contact.type = GT_NONE;
	g_free((gpointer)group_name);
	
	//save
	if(gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	{	   
		
	    for(i = 0; i < MAX_PHONE_COUNT; i++)
		{	
			#if 1
			gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
						       PHONENUM_COL, &phonenum,
						       -1);
			showDebug("%s Phonenum: %s\n", __FUNCTION__, phonenum);
			
	        if(phonenum)
	        {
				strcpy(contact.phones[i].szphone, phonenum);	
				g_free((gpointer)phonenum);
			}
			
			contact.phones[i].type = PT_HOME;
			
		    if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_phonenum_store), &iter))
		    {
				break;
		    }
			#endif
		}
		showDebug("XXXXXXXXXXXXXXXXXXXX Phonenum count: %d\n", contact.phone_count);
		contact.phone_count = get_phonenum_count();
		
	}
	
	//save
	#if 1
	if(gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_email_store), &iter))
	{   
	    for(i = 0; i < MAX_EMAIL_COUNT; i++)
		{
			gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
						       EMAIL_COL, &email,
						       -1);
			showDebug("%s Email: %s\n", __FUNCTION__, email);
	        if(email)
	        {
				strcpy(contact.emails[i].szemail, email);
				g_free((gpointer)email);
			}
			contact.emails[i].type = EMT_HOME;
			
		    if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_email_store), &iter))
			{	
				break;
		    }
		}
		
		contact.email_count = get_email_count();
		showDebug("XXXXXXXXXXXXXXXXXXXX Email count: %d\n", contact.email_count);
	} 
	#endif
	
	//voip
	tmpStr = gtk_entry_get_text(entry_voip);
	strcpy(contact.szvoip, tmpStr);
    
	//im
	tmpStr = gtk_entry_get_text(entry_im);
	strcpy(contact.szim,tmpStr);
    
	//address
    tmpStr = gtk_entry_get_text(entry_address);
	strcpy(contact.szaddress, tmpStr);

	#if 1
	if(mode_info->mode == ADD)
	{
		if(add_contact(&contact))
		{
			show_message_window(get_value_from_key(DISPLAY_SAVE_FAIL));
			goto end;
		}
	}
	else if(mode_info->mode == EDIT)
	{
		if(update_contact_by_index(&contact, mode_info->index))
		{
			show_message_window(get_value_from_key(DISPLAY_SAVE_FAIL));
			goto end;
		}
	}
	
    //sync contact list
	if(sync_contact_list())
    	show_message_window(get_value_from_key(DISPLAY_SAVE_SUCCESSFULLY));
	else
		show_message_window(get_value_from_key(DISPLAY_SAVE_FAIL));

end:
	//close window
	on_button_contact_detail_cancel_clicked(NULL, NULL);
	#endif
}

void on_button_contact_detail_reset_clicked(GtkWidget *window, gpointer user_data)
{	
    if(!(show_confirm_window(DISPLAY_RESET_CONFIRM) ==	GTK_RESPONSE_OK))
   		return;
	
	//family name
    gtk_entry_set_text(entry_familyname, "");
    
	//given name
	gtk_entry_set_text(entry_givenname, "");
	
    //phone num
	gtk_entry_set_text(entry_phonenum, "");
	
	//email
	gtk_entry_set_text(entry_email, "");
	
	//voip
	gtk_entry_set_text(entry_voip, "");
	
	//im
	gtk_entry_set_text(entry_im, "");
	
	//address
    gtk_entry_set_text(entry_address, "");

	#if 0
	gtk_list_store_clear (phonenum_store);
	gtk_list_store_clear (email_store);
	gtk_combo_box_set_model (combo_phonenum_index, GTK_TREE_MODEL(phonenum_store));
	gtk_combo_box_set_model (combo_email_index, GTK_TREE_MODEL(email_store));
	
	gtk_combo_box_set_active (GTK_COMBO_BOX (combo_email_index), 0);
	gtk_combo_box_set_active (GTK_COMBO_BOX (combo_phonenum_index), 0);
	
	#endif
}

//combo event
void on_combobox_contact_detail_phonenum_index_changed(GtkWidget *window, gpointer user_data)
{
    #if 0
	int index;
	const gchar *phonenum;
	int phonenum_index;
	GtkTreeIter iter;
	int i;
	
	if(!combo_phonenum_store)
   	{
	    showDebug("phonenum store is null\n");
    	return;
	}
	
    //save phonenum
	phonenum = gtk_entry_get_text(entry_phonenum);
	gtk_list_store_set (combo_phonenum_store, &current_phonenum_iter,
				        PHONENUM_COL, phonenum,
				        -1);
	
	//change text
	if(!gtk_combo_box_get_active_iter (combo_phonenum_index, &iter))
	{
		showError("get active phonenum iter fail\n");
		return;
	}
    
    gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
				       PHONENUM_COL, &phonenum,
				       PHONENUM_INDEX_COL, &phonenum_index,
		    	       -1);
	
	if(!phonenum)
	{
		showDebug("change: phonenum is null\n");
		gtk_entry_set_text(entry_phonenum, "");
	}
	else
	{
		showDebug("phonenum is not null\n");
		gtk_entry_set_text(entry_phonenum, phonenum);
		showDebug("phonenum: %s\n", phonenum);
		showDebug("phonenum_index: %d\n", phonenum_index);
	}
	
	gtk_combo_box_get_active_iter (combo_phonenum_index, &current_phonenum_iter);
	#endif
}

void on_combobox_contact_detail_email_index_changed(GtkWidget *window, gpointer user_data)
{	
    #if 0
	int index;
	int email_index;
	const gchar *email;
	GtkTreeIter iter;
	int i;
	
	if(!combo_email_store)
   	{
	    showDebug("email store is null\n");
    	return;
	}

    //save phonenum 
	email = gtk_entry_get_text(entry_email);
	gtk_list_store_set (combo_email_store, &current_email_iter,
				        EMAIL_COL, email,
				        -1);
	
	//change text
	if(!gtk_combo_box_get_active_iter (combo_email_index, &iter))
	{
	    showDebug("get active email iter fail\n");
    	return;
	}
    gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
				       EMAIL_COL, &email,
				       EMAIL_INDEX_COL, &email_index,
				       -1);
	
	if(!email)
	{
		showDebug("change: email is null\n");
		gtk_entry_set_text(entry_email, "");
	}
	else
	{
		showDebug("phonenum is not null\n");
		gtk_entry_set_text(entry_email, email);
		showDebug("email: %s\n", email);
		showDebug("email_index: %d\n", email_index);
	}
	
	gtk_combo_box_get_active_iter (combo_email_index, &current_email_iter);
	#endif
}

void on_combobox_contact_detail_phonenum_index_move_active(GtkWidget *window, gpointer user_data)
{
	showDebug("phone move active evnet\n");
}

void on_combobox_contact_detail_email_index_move_active(GtkWidget *window, gpointer user_data)
{
    showDebug("email move active evnet\n");
}

void on_combobox_contact_detail_phonenum_index_popdown(GtkWidget *window, gpointer user_data)
{
	showDebug("phone popdown evnet\n");
}

void on_combobox_contact_detail_phonenum_index_popup(GtkWidget *window, gpointer user_data)
{
	showDebug("phone popup evnet\n");
}

void on_combobox_contact_detail_email_index_popdown(GtkWidget *window, gpointer user_data)
{
	showDebug("email popdown evnet\n");
}

void on_combobox_contact_detail_email_index_popup(GtkWidget *window, gpointer user_data)
{
	showDebug("email popup evnet\n");
}

//combo button
void on_button_contact_detail_addPhonenum_clicked(GtkWidget *window, gpointer user_data)
{
	#if 0
    int i;
	int index;
	const gchar *phonenum;
	GtkTreeIter iter;
	
    //phonenum
    phonenum = gtk_entry_get_text(entry_phonenum);
	
	if(strlen(phonenum) == 0)
    {
		show_message_window(get_value_from_key(DISPLAY_CAN_NOT_EMPTY));
		return;
	}

	if(get_phonenum_index_count() == MAX_PHONE_COUNT)
	{
	    show_message_window(get_value_from_key(DISPLAY_EXCEED_LIMIT));
		return;
	}
	
	if(!gtk_combo_box_get_active_iter (combo_phonenum_index, &iter))
	{	
        printf("get active phonenum iter fail\n");
		return;
	}	
	else
		showDebug("Get Active Phonenum Suc\n");
	
	if(combo_phonenum_store == NULL)
		return;
	
	//save 
	gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
				       PHONENUM_INDEX_COL, &index,
				       -1);
	
    add_phonenum_to_store(phonenum , index);
    #if 1
	
	//check 
	if(get_phonenum_count() != get_phonenum_index_count())
	{
		show_message_window(get_value_from_key(DISPLAY_UNFINISHED_INPUT));
		return;
	}
	
	//add index
	add_phonenum_index_to_store();
    gtk_combo_box_set_model (combo_phonenum_index, GTK_TREE_MODEL(combo_phonenum_store));
	gtk_combo_box_set_active (combo_phonenum_index, get_phonenum_index_count() - 1);
	#endif
	#endif
}

void on_button_contact_detail_addEmail_clicked(GtkWidget *window, gpointer user_data)
{	
	
	#if 0
	showDebug("Get in %s\n", __FUNCTION__);
	
	//gtk_combo_box_append_text (GTK_COMBO_BOX (combo_contact_detail_email), "tttttttt");
	int i;
	int index;
	const gchar *email;
	GtkTreeIter iter;
	
	email = gtk_entry_get_text(GTK_BIN (combo_contact_detail_email)->child);
	showDebug("Email: %s\n", email);
	
	if(strlen(email) == 0)
    {
		show_message_window(get_value_from_key(DISPLAY_CAN_NOT_EMPTY));
		return;
	}
	
	if(get_email_index_count() == MAX_EMAIL_COUNT)
	{
	    show_message_window(get_value_from_key(DISPLAY_EXCEED_LIMIT));
		return;
	}
		
	if(combo_email_store == NULL)
	{	
		showError("Combo Email Store is NULL\n");
		return;
	}
	
	//save 
	gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &current_email_iter,
				       EMAIL_INDEX_COL, &index,
				       -1);
	
	showDebug("Active email Index: %d\n", index);
    add_email_to_store(email , index);
	
	//add index
	add_email_index_to_store();
	
	showDebug("Email Index Count: %d\n", get_email_index_count());
	showDebug("Email Count: %d\n", get_email_count());
	#endif
	
	#if 0
	int i;
	int index;
	const gchar *email;
	GtkTreeIter iter;
	
    //phonenum
    email = gtk_entry_get_text(entry_email);
	
	if(strlen(email) == 0)
    {
		show_message_window(get_value_from_key(DISPLAY_CAN_NOT_EMPTY));
		return;
	}
	
	if(get_email_index_count() == MAX_EMAIL_COUNT)
	{
	    show_message_window(get_value_from_key(DISPLAY_EXCEED_LIMIT));
		return;
	}

	if(!gtk_combo_box_get_active_iter (combo_email_index, &iter))
	{
        showDebug("get active email iter fail\n");
		return;
	}
	
	if(combo_email_store == NULL)
		return;
	
	//save 
	gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
				       EMAIL_INDEX_COL, &index,
				       -1);
	
    add_email_to_store(email , index);
    #if 1
	
	//check 
	if(get_email_count() != get_email_index_count())
	{
		show_message_window(get_value_from_key(DISPLAY_UNFINISHED_INPUT));
		return;
	}
	
	//add index
	add_email_index_to_store();
    gtk_combo_box_set_model (combo_email_index, GTK_TREE_MODEL(combo_email_store));
	gtk_combo_box_set_active (combo_email_index, get_email_index_count() - 1);
    #endif
	#endif
}

/********************************************************************************
                                                       focus in/out event
********************************************************************************/
/*void on_window_contact_focus_in_event(GtkWidget *widget, gpointer user_data)
{	
	is_has_focus = YES;
	showDebug("%s XXXXXXXXXXXX Is Has Focus %s\n", __FUNCTION__, HAS_FOCUS[is_has_focus]);
	//destory_window();
}*/
	
void on_window_contact_focus_out_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("XXXXXXXXXXXXXX %s Lose Mode: %d\n", __FUNCTION__, lose_focus_mode);
	if(!lose_focus_mode)
	{
		destory_window_except_root();
	}
	else
		lose_focus_mode = 0;
	
	showDebug("XXXXXXXXXXXXXX %s Lose Mode After Handle: %d\n", __FUNCTION__, lose_focus_mode);
}
	

void on_window_contact_detail_focus_in_event(GtkWidget *widget, gpointer user_data)
{		
	//is_has_focus = YES;
	//showDebug("%s Is Has Focus %s\n", __FUNCTION__, HAS_FOCUS[is_has_focus]);
	//destory_window();
}

void on_window_contact_detail_focus_out_event(GtkWidget *widget, gpointer user_data)
{		
	showDebug("XXXXXXXXXXXXXX %s Lose Mode: %d\n", __FUNCTION__, lose_focus_mode);
	
	if(!lose_focus_mode)
	{	
		destory_window_except_root();
	}
	else
		lose_focus_mode = 0;
}
	
void on_button_contact_dial_focus_in_event(GtkWidget *widget, gpointer user_data)
{	
	GtkWindowInfo pwindow_info;
	
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}	

void on_button_contact_dial_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_contact_edit_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_contact_edit_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_contact_add_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_contact_add_focus_out_event(GtkWidget *widget, gpointer user_data)
{	
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_contact_delete_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_contact_delete_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_contact_close_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_contact_close_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_contact_detail_save_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_contact_detail_save_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_contact_detail_reset_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_contact_detail_reset_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_contact_detail_cancel_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_contact_detail_cancel_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_treeview_phonenum_row_activated(GtkWidget *widget, gpointer user_data)
{
	showDebug("row active\n");
}

/********************************************************************************
                                                       group combo
********************************************************************************/
GtkTreeModel* fill_group_store()
{
    #if 1
    int i;
	GtkTreeIter iter;
	char label[5][32] = { DISPLAY_GROUPTYPE_FAMILY,
 		                  DISPLAY_GROUPTYPE_RELATIVES,
 		                  DISPLAY_GROUPTYPE_COLLEAGUES,
		                  DISPLAY_GROUPTYPE_FRIENDS,
		                  DISPLAY_GROUPTYPE_OTHER};
	
    if(combo_group_store == NULL)
    	combo_group_store = gtk_list_store_new(1, G_TYPE_STRING);
    
	for(i = 0; i < 5; i++)
	{
		gtk_list_store_append (combo_group_store, &iter);
		gtk_list_store_set (combo_group_store, &iter,
					        GROUP_COL, label[i],
					        -1);
	}
	#endif
	
	return GTK_TREE_MODEL (combo_group_store);
}

/********************************************************************************
                                                    phonenum combo
********************************************************************************/
//phonenum store
int get_phonenum_count()
{
	char *phonenum;
	GtkTreeIter iter;
	int i;
	
	if(combo_phonenum_store == NULL)
    	return 0;
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &iter))
		return 0;

	
	for(i = 0; i < MAX_PHONE_COUNT; i++)
	{   
		gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
					       PHONENUM_COL, &phonenum,
					       -1);
		
	    if(!phonenum || !strcmp(phonenum, DISPLAY_ADD_NEW_ITEM))
	    	return i;
	    
		if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	    	return i + 1;
	}
	
	return MAX_PHONE_COUNT;
}

int get_phonenum_index_count()
{
	char *phonenum;
	GtkTreeIter iter;
	int i;
	
	if(combo_phonenum_store == NULL)
	{
		showDebug(" phonenum store is null\n");	
    	return 0;
	}
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	{
	    //showDebug("get first phonenum iter fail\n");
		return 0;
	}
	
	for(i = 0; i < MAX_PHONE_COUNT; i++)
	{   
		gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
					       PHONENUM_COL, &phonenum,
					       -1);
		
	    if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	    {
	        showDebug("phone index count: %d\n", i + 1);
			return i + 1;
	    }
	}
	
	return MAX_PHONE_COUNT;
}

int add_phonenum_to_store(char *phonenum, int display_index_para)
{	
    #if 1
    int i;
	int display_index;
	GtkTreeIter iter;
	
	if(combo_phonenum_store == NULL)
	    combo_phonenum_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING);
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	{
	    showDebug("get first phonenum iter fail\n");
		return -1;
	}
	
	for(i = 0; i < MAX_PHONE_COUNT; i++)
	{   
		gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
					       PHONENUM_INDEX_COL, &display_index,
					       -1);
		
		if(display_index == display_index_para)
			gtk_list_store_set (combo_phonenum_store, &iter,
		             			//  PHONENUM_INDEX_COL, phonenum_count,
				                PHONENUM_COL, phonenum,
				                -1);
		
		if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_phonenum_store), &iter))
			return -1;;
	}
   	
	#endif
	
	return 0;
}

int add_phonenum_index_to_store()
{	
    #if 1
    int i;
	GtkTreeIter iter;
	
	if(combo_phonenum_store == NULL)
	    combo_phonenum_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING);

    if(get_phonenum_index_count() != get_phonenum_count())
    {
		showWarning("index count != phonenum count\n");
		return -1;
	}
	
    //phonenum_count = get_phonenum_count();
    gtk_list_store_append (combo_phonenum_store, &iter);
	gtk_list_store_set (combo_phonenum_store, &iter,
		                PHONENUM_INDEX_COL, get_phonenum_count() + 1,
		                PHONENUM_COL, DISPLAY_ADD_NEW_ITEM,
				        -1);
	#endif
	
	return 0;
}

char *get_phonenum_by_index(int index)
{
	char *phonenum;
	GtkTreeIter iter;
	int i;
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	{
	    showError("get first iter error\n");
		return NULL;
	}
	for(i = 0; i < MAX_PHONE_COUNT; i++)
	{   
		gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
					       PHONENUM_COL, &phonenum,
					       -1);
		
		if(i == index)
			return phonenum;

		g_free(phonenum);
		
	    if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	    {
	        showDebug("phonum count: %d\n", i + 1);
			return NULL;
	    }
	}
}

/********************************************************************************
                                                       email combo
********************************************************************************/
//phonenum store
int get_email_count()
{
	char *email;
	GtkTreeIter iter;
	int i;

	if(combo_email_store == NULL)
	{
	    showDebug("email store is null\n");
		return 0;
	}
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_email_store), &iter))
	{   
	    //showDebug("get first email iter fail\n");
		return 0;
	} 
	
	for(i = 0; i < MAX_EMAIL_COUNT; i++)
	{	
		gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
						   EMAIL_COL, &email,
						   -1);
		
		if(!email || !strcmp(email, DISPLAY_ADD_NEW_ITEM))
			return i;

		g_free(email);
		
		if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_email_store), &iter))
			return i + 1;
	}
	
	return MAX_EMAIL_COUNT;
}

int get_email_index_count()
{
	char *email;
	GtkTreeIter iter;
	int i;

	if(combo_email_store == NULL)
	{
	    showDebug("email store is null\n");
		return 0;
	}
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_email_store), &iter))
	{   
	    //showDebug("get first email iter fail\n");
		return 0;
	} 

	for(i = 0; i < MAX_EMAIL_COUNT; i++)
	{	
		gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
						   EMAIL_COL, &email,
						   -1);

		g_free(email);
		if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_email_store), &iter))
		{
			//printf("phone index count: %d\n", i + 1);
			
			return i + 1;
		}
	}
	
	return MAX_EMAIL_COUNT;
}

int add_email_to_store(char *email, int index_para)
{
#if 1
	int i;
	int index;
	GtkTreeIter iter;
	
	if(combo_email_store == NULL)
	    combo_email_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING);
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_email_store), &iter))
	{   
	    showDebug("get first email iter fail\n");
		return -1;
	} 
	
	for(i = 0; i < MAX_EMAIL_COUNT; i++)
	{	
		gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
						   EMAIL_INDEX_COL, &index,
						   -1);
	
		if(index == index_para)
			gtk_list_store_set (combo_email_store, &iter,
								EMAIL_COL, email,
								-1);
		
		if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_email_store), &iter))
			return -1;
	}
	
#endif
	return 0;
}

int add_email_index_to_store()
{
#if 1
	int i;
	GtkTreeIter iter;
	
	if(combo_email_store == NULL)
	    combo_email_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING);

    if(get_email_index_count() != get_email_count())
    {
		showDebug("index count != email count\n");
		return -1;
	}
	
	gtk_list_store_append (combo_email_store, &iter);
	gtk_list_store_set (combo_email_store, &iter,
						EMAIL_INDEX_COL, get_email_count() + 1,
						EMAIL_COL, DISPLAY_ADD_NEW_ITEM,
						-1);
#endif
	
	return 0;
}

char *get_email_by_index(int index)
{
	char *email;
	GtkTreeIter iter;
	int i;
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_email_store), &iter))
	{   
	    showDebug("get first email iter fail\n");
		return NULL;
	} 
	
	for(i = 0; i < MAX_EMAIL_COUNT; i++)
	{	
		gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
						   EMAIL_COL, &email,
						   -1);
		
		if(i == index)
			return email;
		
		if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_email_store), &iter))
		{
		    g_free(email);
			return NULL;
		}
	}
}

void* release_resource(void)
{
	
}

void selection_changed(GtkTreeSelection *selection)
{
	
}

gboolean phonenum_selection_changed()
{	
	showDebug("Get in %s\n", __FUNCTION__);
	char *phonenum;
	GtkTreeIter iter;
	int index;
	
	if(phonenum_seletion_flag)
	{	
		strcpy(phonenum_tmp_buf, gtk_entry_get_text(GTK_ENTRY(GTK_BIN (combo_contact_detail_phonenum)->child)));
		showDebug("%s Tmp Buf: %s\n", __FUNCTION__, phonenum_tmp_buf);
		
		if(!gtk_combo_box_get_active_iter (combo_contact_detail_phonenum, &iter))	
		{   
			showWarning("%s, get active phonenum iter fail!!!!!!!!!!\n", __FUNCTION__);
			
			gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &current_phonenum_iter,
							   0, &index,
							   1, &phonenum,
							   -1);
			
			add_phonenum_to_store(phonenum_tmp_buf, index);
			showDebug("%s Phonenum Count: %d, Index Count: %d\n", __FUNCTION__,
																	get_phonenum_count(),
																 	get_phonenum_index_count());
			if(get_phonenum_count() == get_phonenum_index_count())
			{	
				add_phonenum_index_to_store();
			}	
			showDebug("%s Active phonenum Index: %d, Active Text: %s\n", __FUNCTION__, index, phonenum);
		}
		else
		{
			showInfo("%s, get active phonenum iter Suc\n", __FUNCTION__);
			current_phonenum_iter = iter;
			
			gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &current_phonenum_iter,
							   0, &index,
							   1, &phonenum,
							   -1);
				
			if(index == get_phonenum_index_count())
			{	
				showInfo("Index is == get_phonenum_index_count()\n");
				
				phonenum_seletion_flag = NO;
				gtk_entry_set_text(GTK_ENTRY(GTK_BIN (combo_contact_detail_phonenum)->child), "");

				//lose_focus_mode = 1;
				gtk_widget_grab_focus(GTK_WIDGET(GTK_BIN (combo_contact_detail_phonenum)->child));
				phonenum_seletion_flag = YES;
			}
			showDebug("%s Active email Index: %d, Active Text: %s\n", __FUNCTION__, index, phonenum);
		}
	}
	else
		showDebug("%s RunFlag is NO\n", __FUNCTION__);
}

gboolean email_selection_changed()
{
	showDebug("Get in %s\n", __FUNCTION__);
	char *email;
	GtkTreeIter iter;
	int index;

	if(email_seletion_flag)
	{	
		strcpy(email_tmp_buf, gtk_entry_get_text(GTK_ENTRY(GTK_BIN (combo_contact_detail_email)->child)));
		showDebug("%s Tmp Buf: %s\n", __FUNCTION__, email_tmp_buf);
		
		if(!gtk_combo_box_get_active_iter (combo_contact_detail_email, &iter))	
		{   
			showWarning("%s, get active email iter fail!!!!!!!!!!\n", __FUNCTION__);
			
			gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &current_email_iter,
							   0, &index,
							   1, &email,
							   -1);
			
			add_email_to_store(email_tmp_buf, index);
			showDebug("%s Email Count: %d, Index Count: %d\n", __FUNCTION__,
																	get_email_count(),
																	get_email_index_count());
			
			if(get_email_count() == get_email_index_count())
			{	
				add_email_index_to_store();
			}
			
			showDebug("%s Active email Index: %d, Active Text: %s\n", __FUNCTION__, index, email);
		}
		else
		{
			showInfo("%s, get active email iter Suc\n", __FUNCTION__);
			current_email_iter = iter;
			
			gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &current_email_iter,
							   0, &index,
							   1, &email,
							   -1);
			
			if(index == get_email_index_count())
			{	
				showInfo("Index is == get_email_index_count()\n");
				
				email_seletion_flag = NO;
				gtk_entry_set_text(GTK_ENTRY(GTK_BIN (combo_contact_detail_email)->child), "");
				//lose_focus_mode = 1;
				gtk_widget_grab_focus(GTK_WIDGET(GTK_BIN (combo_contact_detail_email)->child));
				email_seletion_flag = YES;
			}
			showDebug("%s Active email Index: %d, Active Text: %s\n", __FUNCTION__, index, email);
		}	
	}
	else
		showDebug("%s RunFlag is NO\n", __FUNCTION__);
}

gboolean combo_popup()
{
	//showDebug("XXXXXXXXXXX Get in %s \n", __FUNCTION__);
	//lose_focus_mode = 1;
	set_lose_focus_mode(1);
}

int validate_input()
{	
	if(strlen(gtk_entry_get_text(entry_familyname)) == 0)
    {
		//show_message_window(_(get_value_from_key(DISPLAY_CAN_NOT_EMPTY)));
		show_message_window(get_value_from_key(DISPLAY_CAN_NOT_EMPTY));
		return -1;
	}

	if(strlen(gtk_entry_get_text(entry_givenname)) == 0)
    {
		//show_message_window(_(get_value_from_key(DISPLAY_CAN_NOT_EMPTY)));
		show_message_window(get_value_from_key(DISPLAY_CAN_NOT_EMPTY));
		return -1;
	}

	if(!strlen(gtk_entry_get_text(GTK_ENTRY(GTK_BIN (combo_contact_detail_phonenum)->child))))
    {
		//show_message_window(_(get_value_from_key(DISPLAY_CAN_NOT_EMPTY)));
		show_message_window(get_value_from_key(DISPLAY_CAN_NOT_EMPTY));
		return -1;
	}
	
	int i;
	int index;
	gchar *phonenum;
	GtkTreeIter iter;

	#if 1
	if(gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	{   
	    for(i = 0; i < MAX_PHONE_COUNT; i++)
		{	
			gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
						       PHONENUM_COL, &phonenum,
						       -1);
			
			showDebug("%s Phonenum: %s\n", __FUNCTION__, phonenum);
			if(validate_phonenum(phonenum) && 
			   phonenum != NULL &&
			   strcmp(phonenum, DISPLAY_ADD_NEW_ITEM))
			{	
				showError("%s Validate Phonum Fail Phonenum: %s\n", __FUNCTION__, phonenum);
				show_message_window("号码不合法");
				return -1;
			}
				
			if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_phonenum_store), &iter))
		    {
				break;
		    }
		}
	}
	g_free(phonenum);
	#endif

	Contact contact;
    char* family_name;
	char* given_name;
    char full_name[64];
	
    //family name
    family_name = gtk_entry_get_text(entry_familyname);
	
	//given name
	given_name = gtk_entry_get_text(entry_givenname);
	
	sprintf(full_name, "%s%s", family_name, given_name);
	//if(!get_contact_by_name(&contact, full_name))
	//{
	//	show_message_window(_(get_value_from_key(DISPLAY_NAME_EXISTED)));
	//	return -1;
	//}
	
	return 0;
}

int sync_contact_list()
{	
    gtk_list_store_clear(store);
	gtk_tree_view_set_model(contact_treeview, fill_contact_store(store));
}

int show_contact_detail_window(ContactDetailMode mode_val, gpointer *pdata)
{	
	GtkBuilder *builder;
	GtkWidget *window;
	Contact contact;
	GtkEntry *entry;
	GtkWidget *button_save;
	int index;
	GtkTreeModel *model;
	GtkTreeIter iter;
	GtkCellRenderer *renderer;
	GtkTreeSelection *selection;
    ModeInfo *mode_info = (ModeInfo *)malloc(sizeof(ModeInfo));
	int i;
    
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file(builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_contact_detail"));
	gtk_window_set_title(GTK_WINDOW(window), "window_contact_detail");
    gtk_window_move(GTK_WINDOW(window), 200, 0);

	fixed_addcontact = GTK_WIDGET(gtk_builder_get_object(builder, "fixed_addcontact"));
    
	put_window_into_stack(window);
    
	button_save = GTK_WIDGET(gtk_builder_get_object(builder, "button_contact_detail_save"));
	
	#if 1
    //add mode
    if(mode_val == ADD)
    {    
    	//family name
		entry_familyname = (GtkEntry *)gtk_builder_get_object(builder, "entry_familyname");
	    
		//given name
	    entry_givenname = (GtkEntry *)gtk_builder_get_object(builder, "entry_givenname");
		
		//phone num
		entry_phonenum = (GtkEntry *)gtk_builder_get_object(builder, "entry_phonenum");
		
        if(pdata != NULL)
	    	gtk_entry_set_text(entry_phonenum, (const gchar *)pdata);
	    
		//email
		entry_email = (GtkEntry *)gtk_builder_get_object(builder, "entry_email");
		
		//voip
		entry_voip = (GtkEntry *)gtk_builder_get_object(builder, "entry_voip");
		
		//im
		entry_im = (GtkEntry *)gtk_builder_get_object(builder, "entry_im");
		
		//address
		entry_address = (GtkEntry *)gtk_builder_get_object(builder, "entry_address");
	 	
        //group combo
		combo_group = (GtkComboBox *)gtk_builder_get_object(builder, "combobox_concact_detail_group");
		
		gtk_combo_box_set_model (combo_group, fill_group_store(combo_group_store));
        
		renderer = gtk_cell_renderer_text_new ();
		gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_group), renderer, TRUE);
		gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_group), renderer,
										"text", GROUP_COL,
										NULL);
		
		gtk_combo_box_set_active (GTK_COMBO_BOX (combo_group), 0);
		g_signal_connect(GTK_OBJECT(combo_group), "popup", G_CALLBACK(combo_popup), NULL);
		
		//phone num index combo
		add_phonenum_index_to_store();
		combo_contact_detail_phonenum = gtk_combo_box_entry_new_with_model(GTK_TREE_MODEL(combo_phonenum_store), 1);
		gtk_widget_set_size_request(GTK_WIDGET(combo_contact_detail_phonenum), 220, 30);
	    gtk_fixed_put(GTK_FIXED(fixed_addcontact), GTK_WIDGET(combo_contact_detail_phonenum), 130, 175);
		
		gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &current_phonenum_iter);
		g_signal_connect(GTK_OBJECT(combo_contact_detail_phonenum), "changed", G_CALLBACK(phonenum_selection_changed), NULL);
		g_signal_connect(GTK_OBJECT(combo_contact_detail_phonenum), "popup", G_CALLBACK(combo_popup), NULL);
		gtk_widget_show(GTK_WIDGET(combo_contact_detail_phonenum));
		
		//email index combo
		//combo_contact_detail_email = gtk_combo_box_entry_new_text();//(GtkComboBox *)gtk_builder_get_object(builder, "combobox_contact_detail_email");
		add_email_index_to_store();
		combo_contact_detail_email = gtk_combo_box_entry_new_with_model(GTK_TREE_MODEL(combo_email_store), 1);
		gtk_widget_set_size_request(GTK_WIDGET(combo_contact_detail_email), 220, 30);
	    gtk_fixed_put( GTK_FIXED(fixed_addcontact), GTK_WIDGET(combo_contact_detail_email), 130, 215);
		
		gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_email_store), &current_email_iter);
		g_signal_connect(GTK_OBJECT(combo_contact_detail_email), "changed", G_CALLBACK(email_selection_changed), NULL);
		g_signal_connect(GTK_OBJECT(combo_contact_detail_email), "popup", G_CALLBACK(combo_popup), NULL);
		gtk_widget_show(GTK_WIDGET(combo_contact_detail_email));

		//fill_email_store(combo_combo_detail_email);
		/*renderer = gtk_cell_renderer_text_new ();
		gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_contact_detail_email), renderer, TRUE);
		gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_contact_detail_email), renderer,
										"text", EMAIL_INDEX_COL,
										NULL);*/
		
		//gtk_combo_box_set_active (GTK_COMBO_BOX (combo_contact_detail_email), 0);
		//gtk_combo_box_get_active_iter (combo_contact_detail_email, &current_email_iter);
		/*if(!gtk_combo_box_get_active_iter (combo_contact_detail_email, &iter))
		{
	        showDebug("get active email iter fail\n");
			return;
		}
		else
			showDebug("get active email iter suc!!\n");
		
		gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
					       EMAIL_INDEX_COL, &index,
					       -1);
		
		showDebug("Active email Index: %d\n", index);*/
    }
	else if(mode_val == EDIT)
	{
	    #if 1
	    memset(&contact, 0, sizeof(Contact));

		selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(contact_treeview));
		if(gtk_tree_selection_get_selected(selection, &model, &iter))
		{
		    gtk_tree_model_get(model, &iter,
		                       CONTACT_INDEX_COL, &index,
		                       -1);
			
	        get_contact_by_index(&contact, index);
	    }
		
		//family name
		entry_familyname = (GtkEntry *)gtk_builder_get_object(builder, "entry_familyname");
	    gtk_entry_set_text(entry_familyname, contact.name.szfamily_name);
        
		//given name
	    entry_givenname = (GtkEntry *)gtk_builder_get_object(builder, "entry_givenname");
		gtk_entry_set_text(entry_givenname, contact.name.szgiven_name);

        //phone num
		entry_phonenum = (GtkEntry *)gtk_builder_get_object(builder, "entry_phonenum");

		//email
		entry_email = (GtkEntry *)gtk_builder_get_object(builder, "entry_email");
	    
		//voip
		entry_voip = (GtkEntry *)gtk_builder_get_object(builder, "entry_voip");
		gtk_entry_set_text(entry_voip, contact.szvoip);
		
		//im
		entry_im = (GtkEntry *)gtk_builder_get_object(builder, "entry_im");
		gtk_entry_set_text(entry_im, contact.szim);
		
		//address
		entry_address = (GtkEntry *)gtk_builder_get_object(builder, "entry_address");
	    gtk_entry_set_text(entry_address, contact.szaddress);


		//group combo
		combo_group = (GtkComboBox *)gtk_builder_get_object(builder, "combobox_concact_detail_group");
		
		gtk_combo_box_set_model (combo_group, fill_group_store(combo_group_store));
        
		renderer = gtk_cell_renderer_text_new ();
		gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_group), renderer, TRUE);
		gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_group), renderer,
										"text", GROUP_COL,
										NULL);
		g_signal_connect(GTK_OBJECT(combo_group), "popup", G_CALLBACK(combo_popup), NULL);
		
        if(contact.type == GT_FAMILY)
			gtk_combo_box_set_active (GTK_COMBO_BOX (combo_group), 0);
		else if(contact.type == GT_RELATIVES)
			gtk_combo_box_set_active (GTK_COMBO_BOX (combo_group), 1);
		else if(contact.type == GT_COLLEAGUES)
			gtk_combo_box_set_active (GTK_COMBO_BOX (combo_group), 2);
		else if(contact.type == GT_FRIENDS)
			gtk_combo_box_set_active (GTK_COMBO_BOX (combo_group), 3);
		else if(contact.type == GT_OTHER)
			gtk_combo_box_set_active (GTK_COMBO_BOX (combo_group), 4);

		//phonenum index combo
		for(i = 0; i < contact.phone_count; i++)
		{
			add_phonenum_index_to_store();
            add_phonenum_to_store(contact.phones[i].szphone, i + 1);
		}
		add_phonenum_index_to_store();
		
		combo_contact_detail_phonenum = gtk_combo_box_entry_new_with_model(GTK_TREE_MODEL(combo_phonenum_store), 1);
		gtk_widget_set_size_request(GTK_WIDGET(combo_contact_detail_phonenum), 220, 30);
	    gtk_fixed_put( GTK_FIXED(fixed_addcontact), GTK_WIDGET(combo_contact_detail_phonenum), 130, 175);

		gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &current_phonenum_iter);
		gtk_combo_box_set_active(GTK_COMBO_BOX (combo_contact_detail_phonenum), 0);
		
		g_signal_connect(GTK_OBJECT(combo_contact_detail_phonenum), "changed", G_CALLBACK(phonenum_selection_changed), NULL);
		g_signal_connect(GTK_OBJECT(combo_contact_detail_phonenum), "popup", G_CALLBACK(combo_popup), NULL);
		gtk_widget_show(GTK_WIDGET(combo_contact_detail_phonenum));
		
		//email index combo
		#if 1
		for(i = 0; i < contact.email_count; i++)
		{
			add_email_index_to_store();
            add_email_to_store(contact.emails[i].szemail, i + 1);
		}
		add_email_index_to_store();
		
		combo_contact_detail_email = gtk_combo_box_entry_new_with_model(GTK_TREE_MODEL(combo_email_store), 1);
		gtk_widget_set_size_request(GTK_WIDGET(combo_contact_detail_email), 220, 30);
	    gtk_fixed_put( GTK_FIXED(fixed_addcontact), GTK_WIDGET(combo_contact_detail_email), 130, 215);
		
		gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_email_store), &current_email_iter);
		gtk_combo_box_set_active(GTK_COMBO_BOX (combo_contact_detail_email), 0);
		
		g_signal_connect(GTK_OBJECT(combo_contact_detail_email), "changed", G_CALLBACK(email_selection_changed), NULL);
		g_signal_connect(GTK_OBJECT(combo_contact_detail_email), "popup", G_CALLBACK(combo_popup), NULL);
		gtk_widget_show(GTK_WIDGET(combo_contact_detail_email));
		#endif
			
		#endif
	}
		
	//event
	if(mode_val == ADD)
	{
	    mode_info->index = -1;
        mode_info->mode = ADD;
		
		g_signal_connect(G_OBJECT (button_save), "clicked",
                 		 G_CALLBACK (on_button_contact_detail_save_clicked),
		                 mode_info);
	}
	else if(mode_val == EDIT)
	{
    	mode_info->index = index;
		mode_info->mode = EDIT;
		
		g_signal_connect(G_OBJECT (button_save), "clicked",
                  		 G_CALLBACK (on_button_contact_detail_save_clicked),
						 mode_info);
	}
	
	gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	#endif
	//show
	show_top_window();

	//lose_focus_mode = 1;
		
	return 0;
}

int show_contact_window()
{	
    GtkBuilder *builder;
	GtkWidget *window;
	GtkTreeViewColumn *column_index;
	GtkTreeViewColumn *column_name;
	GtkCellRenderer *cell_renderer;
	GtkTreeSelection *selection;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_contact"));
	gtk_window_set_title(GTK_WINDOW(window), "window_contact");
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	if(put_window_into_stack(window) < 0)
		showError("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX Put Contact Window Into Stack Error\n");
		
	//add  model to tree view
	
	store = create_contact_store();
	
	contact_treeview = (GtkTreeView *)gtk_builder_get_object(builder, ("treeview_contactlist"));

	#if 1
	gtk_tree_view_set_model(contact_treeview, fill_contact_store(store));
	
	//column  
	column_index = gtk_tree_view_column_new();
	column_name = gtk_tree_view_column_new();
    gtk_tree_view_column_set_title(column_name, DISPLAY_CONTACT);
    
	//index cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_index,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_index, cell_renderer,
		                              	    set_index, NULL, NULL);
	
	//name cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_name,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_name, cell_renderer,
		                              	    set_name, NULL, NULL);

	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(contact_treeview),
					            column_index);
	gtk_tree_view_append_column(GTK_TREE_VIEW(contact_treeview),
					            column_name);

    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();
	#endif
	
	return 0;
}

