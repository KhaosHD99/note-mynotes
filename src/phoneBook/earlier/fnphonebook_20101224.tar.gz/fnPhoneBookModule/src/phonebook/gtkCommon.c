#include <stdio.h>
#include <gtk/gtk.h>
#include <string.h>

#include "phonebookapi.h"
#include "phonebookskin.h"
#include "windowstack.h"
#include "LogMsg.hpp"
#include "fnGtkApplicationDef.h"

int lose_focus_mode;

enum
{
	PASSITIVE,
	INITIACTIVE
};

//dialog
void show_message_window(char *msg)
{		
	GtkBuilder *builder;
	GtkWidget *dialog;
	GtkWidget *label;
	int rtn;
	
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	
	dialog = (GtkMessageDialog *)gtk_builder_get_object(builder, "dialog_message");
	gtk_window_set_title(GTK_WINDOW(dialog), "dialog_message");
	gtk_widget_set_size_request(dialog, DIALOG_SIZE_WIDTH, DIALOG_SIZE_HEIGHT);
	gtk_window_move(GTK_WINDOW(dialog), DIALOG_POS_X, DIALOG_POS_Y);
	
	gtk_dialog_add_button(dialog,
						  GTK_STOCK_OK,
						  GTK_RESPONSE_OK);
	
	label = gtk_builder_get_object(builder, "label_message");
	gtk_label_set_text(label, msg);

	//Show
	put_window_into_stack(dialog);
	set_lose_focus_mode(INITIACTIVE);
	gtk_dialog_run (GTK_DIALOG (dialog));
	
	//Destroy
	GtkWindowInfo pwindow_info;
	if(get_window_out_stack(&pwindow_info) >= 0)
		destroy_widget(GTK_WIDGET(pwindow_info.window));
	else
		showError("%s XXXXXXXXXXXXXXXXXXX get_window_out_stack Error\n", __FUNCTION__);
	
	g_object_unref(G_OBJECT (builder));
}
	
void on_dialog_message_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	showDebug("XXXXXXXXXXXXXX %s Lose Mode: %d\n", __FUNCTION__, lose_focus_mode);
	if(!lose_focus_mode)
	{	
		destory_window_except_root();
	}	
	else
		lose_focus_mode = 0;
}	
	
int show_confirm_window(char *msg)
{	
	GtkBuilder *builder;
	GtkWidget *dialog;
	GtkWidget *label;
	int rtn;
	
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	
	dialog = (GtkMessageDialog *)gtk_builder_get_object(builder, "dialog_confirm");
	gtk_window_set_title(GTK_WINDOW(dialog), "dialog_confirm");
	gtk_widget_set_size_request(dialog, DIALOG_SIZE_WIDTH, DIALOG_SIZE_HEIGHT);
	gtk_window_move(GTK_WINDOW(dialog), DIALOG_POS_X, DIALOG_POS_Y);
	
	gtk_dialog_add_button(dialog,
						  GTK_STOCK_OK,
						  GTK_RESPONSE_OK);
	
	gtk_dialog_add_button(dialog,
						  GTK_STOCK_CANCEL,
						  GTK_RESPONSE_CANCEL);
	
	label = gtk_builder_get_object(builder, "label_confirm");
	gtk_label_set_text(label, msg);

	//Show
	put_window_into_stack(dialog);
	set_lose_focus_mode(INITIACTIVE);
	rtn = gtk_dialog_run (GTK_DIALOG (dialog));
	
	//Destroy
	GtkWindowInfo pwindow_info;
	if(get_window_out_stack(&pwindow_info) >= 0)
		destroy_widget(GTK_WIDGET(pwindow_info.window));
	else
		showError("%s XXXXXXXXXXXXXXXXXXX get_window_out_stack Error\n", __FUNCTION__);
	
	g_object_unref(G_OBJECT (builder));
	
	return rtn;
}

void on_dialog_confirm_focus_out_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("XXXXXXXXXXXXXX %s Lose Mode: %d\n", __FUNCTION__, lose_focus_mode);
	if(!lose_focus_mode)
	{
		
		destory_window_except_root();
	}
	else
		lose_focus_mode = 0;
}
	
void set_lose_focus_mode(int mode)
{		
	switch(mode)
	{		
		case PASSITIVE:
			showDebug("XXXXXXX %s Set Passitive Lose Focus Mode\n", __FUNCTION__);
			lose_focus_mode = mode;
			break;

		case INITIACTIVE:
			showDebug("XXXXXXX %s Set Initiative Lose Focus Mode\n", __FUNCTION__);
			lose_focus_mode = mode;
			break;
			
		default:
			showError("XXXXXXXXXXXXXXXXXXXXXXXXXXXX %s Can not Set Specific Lose Focus Mode\n", __FUNCTION__);	
	}
}

int destroy_widget(GtkWidget *widget)
{	
	gtk_widget_destroy(widget);
	show_top_window();
	
	set_lose_focus_mode(PASSITIVE);
}

int destory_window_except_root()
{	
	GtkWindowInfo pwindow_info;
	
	while(1)
	{
		int ret = get_window_out_stack(&pwindow_info);
		if(ret >= 0)
		{	
		    if(pwindow_info.window && strcmp(pwindow_info.window_name, MAIN_WINDOW_TITLE))
			{	
				showDebug("Destory Window: %s\n", pwindow_info.window_name);
				destroy_widget(GTK_WIDGET(pwindow_info.window));
			}	
			else
			{	
				showDebug("Keep Window: %s\n", pwindow_info.window_name);
				break;
			}
		}
		else
		{	
			showError("XXXXXXXXXXXXXXXXXXXXXXXXXXXX Get Window From Stack Error\n");
			break;
		}	
	}
	set_somebody_top(ADVERTISEMENT_ID);
}	


