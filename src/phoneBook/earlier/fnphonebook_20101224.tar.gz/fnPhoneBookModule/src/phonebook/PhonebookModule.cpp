#include "PhonebookModule.h"

extern "C" int sync_calllog_list();

/********************************************************************************
                                      					get instance
********************************************************************************/
PhonebookModule* PhonebookModule::adverModule_instance = NULL;
PhonebookModule* PhonebookModule::get_instance(VialSystem *vialSys)
{	
	if(vialSys == NULL)
	{	
		showWarning("VialSys Null\r\n");
		return NULL;	
	}	
	
	if(!adverModule_instance)
			adverModule_instance = new PhonebookModule(vialSys);
		
	return adverModule_instance;
}

/**************************************************************
**PrompterModule
**(电话状态)提示模块
**
**************************************************************/
PhonebookModule::PhonebookModule(VialSystem *vialSys) : AbstractModule(vialSys)
{
	this->vialSys = vialSys;
}

/**************************************************************
**run
**启动run循环
**
**************************************************************/
void PhonebookModule::run()
{
	vialSys->run();
}

/**************************************************************
**localInit
**模块内部初始化
**该函数被init()调用
**************************************************************/
bool PhonebookModule::localInit()
{
	showInfo("%s localInit\n", __CLASS__);
	memset(&PhoneCode, 0, sizeof(PhoneCode));
	
	return true;
}

/**************************************************************
**onExit
**接收状态改变消息
**内部自行处理状态
**************************************************************/
bool PhonebookModule::onExit()
{	
	showInfo("%s onExit\n", __CLASS__);
	return false;
}
int PhonebookModule::send_dial_vial(Vial *vial, NodeID dstID)
{
	int i = 0;
	
	vialSys->postVial(vial, dstID);		
	while(1)
	{
		showDebug("Wait For Callout\n");
		if(is_callout())
			break;
		
		if(i == MAX_DIAL_WAIT_TIME)
		{	
			showWarning("XXXXXXXXXXXXXXXXX Dial Time Out\n");
			return -1;
		}	
		i++;
		sleep(1);
	}
	
	return 0;
}

bool PhonebookModule::post_vial(Vial *vial, NodeID dstID)
{	
	vialSys->postVial(vial, dstID);
		
	
	//vialSys->postReturnVial(vial, dstID);
	//memset(&PhoneCode, 0, sizeof(PhoneCode));
}

/**************************************************************
1.	待机  			[ON_HOOK, NON_PHONE] 				: StateChangeVial
2.	摘机  			[OFF_HOOK, V_PHONE] 				: StateChangeVial
3.	拨出号码		[OFF_HOOK, V_PHONE, 号码] 	: StateDailVial
4.	振铃状态		[RRINGING， V_PHONE]				: StateChangeVial
5.	接听状态		[NOVIDEO_CONN， V_PHONE]		: StateChangeVial

6. 振铃号码			[RINGING, V_PHONE, 号码]		: CallerIDVial 
7. 挂机					[ON_HOOK, NON_PHONE]				: StateChangeVial
8. 互通..  			[VIDEO_CONN, NON_PHONE]			: StateChangeVial
**************************************************************/
bool PhonebookModule::OnReceive(Vial *vial)
{	
	/*Vial *vial;
	
	vial = VialFactory_Phonebook::createVialByCopy(inputVial);
	if (vial == NULL)
	{
		showWarning("Vial is NULL\n");
		delete vial;
		return false;
	}*/
	if(!vial)
	{
		showWarning("%s::%s Vial is NULL\n", __CLASS__, __FUNCTION__);
		return true;
	}
	
	#if 1
	switch (vial->vialType)
	{
		case GETVT(StateChangeVial):
			showInfo("%s, Get StateChangeVial\n", __FUNCTION__);
			return on_vial_state_change((StateChangeVial *)vial);
		
		case GETVT(DialNotifyVial):
			showInfo("%s, Get DialNotifyVial\n", __FUNCTION__);
			return on_vial_dial_notify((DialNotifyVial *)vial);
		
		case GETVT(CallerPhoneCodeVial):
			showInfo("%s, Get CallerPhonecodeVial\n", __FUNCTION__);
			return on_vial_caller_phonecode((CallerPhoneCodeVial *)vial);
		
		default:
			showWarning("Can not distiguish vial\n");
			return false;
	}
	#endif
	
	return false;
}

bool PhonebookModule::on_vial_state_change(StateChangeVial *vial)
{	
	if(!vial)
	{
		showWarning("%s::%s StateChangeVial is NULL\n", __CLASS__, __FUNCTION__);
		return true;
	}
	
	cur_state = vial->curState.st;
	switch(vial->curState.st)
	{
		case CCST::ON_HOOK:
			return on_on_hook(vial);
		case CCST::DIALING:
			return on_dialing(vial);
		case CCST::RINGING:
			return on_ringing(vial);
		case CCST::NOVIDEO_CONN:
			return on_novideoconn(vial);
		case CCST::VIDEO_CONN:
			return on_videoconn(vial);
			
		default:
			showWarning("%s::%s, Invalid State\n", __CLASS__, 
												   __FUNCTION__, 
												   vial->curState);
			return true;			
	}

	#if 0
	if(vial->curState.st == CCST::ON_HOOK && 
	   vial->oldState.st == CCST::DIALING)
	{	
		printf("Clear Dial Num Buf\n");
		memset(&PhoneCode, 0, sizeof(PhoneCode));
		
		showInfo("%s, PhoneCode: %s, CodeLen: %d\n", __FUNCTION__, 
													 PhoneCode.cPhoneCode,
													 PhoneCode.nCodelen);
	}
	#endif
	
	return true;
}

bool PhonebookModule::on_vial_dial_notify(DialNotifyVial *vial)
{		
	if(!vial)
	{
		showWarning("%s::%s DialNotifyVial is NULL\n", __CLASS__, __FUNCTION__);
		return true;
	}
		
	Contact contact;
	char full_name[128];
	memset(&contact, 0, sizeof(Contact));
	
	PhoneCode.cPhoneCode[PhoneCode.nCodelen] = vial->code;
	if(PhoneCode.nCodelen < 0 || PhoneCode.nCodelen >= (VIAL_PHONECODE_LEN - 1))
	{
		showWarning("PhoneCode is Invalid [%d:%d%s]\n", PhoneCode.nCodelen, VIAL_PHONECODE_LEN-1, PhoneCode.cPhoneCode);
		return true;
	}
	
	PhoneCode.nCodelen++;
	PhoneCode.cPhoneCode[PhoneCode.nCodelen]= '\0';
	
	showInfo("%s, phoneCode: %d -> %s, CodeLen: %d\n", __FUNCTION__,
													   vial->code-'0',
													   PhoneCode.cPhoneCode,
													   PhoneCode.nCodelen);
	
	if(!get_contact_by_phone(&contact, PhoneCode.cPhoneCode))
	{	
		sprintf(full_name, "%s%s", contact.name.szfamily_name, contact.name.szgiven_name);
		printf("name: %s\n", full_name);
				
		ContactPrompterVial contact_prompter_vial;
		
		strcpy(contact_prompter_vial.szContactName, full_name);
		showDebug("contact_prompter_vial.szContactName: %s\n", contact_prompter_vial.szContactName);
		strcpy(contact_prompter_vial.szPhoneNum, PhoneCode.cPhoneCode);
		
		//showDebug("phonecode: %s\n", PhoneCode.cPhoneCode);
		post_vial(&contact_prompter_vial, FN_PROMPTER_MODULE_ID);
		showDebug("Send Over\n");
	}
	else
		printf("No Contact\n");
	
	return true;
}

bool PhonebookModule::on_vial_caller_phonecode(CallerPhoneCodeVial *vial)
{	
	if(!vial)
	{
		showWarning("%s::%s CallerPhoneCodeVial is NULL\n", __CLASS__, __FUNCTION__);
		return true;
	}
	
	ContactPrompterVial contact_prompter_vial;
	Contact contact;
	char full_name[128];
	memset(&contact, 0, sizeof(Contact));
	
	/* Clear Phonecode */
	PhoneCode.nCallType = 0;
	PhoneCode.nCodelen = 0;
	memset(PhoneCode.cPhoneCode, 0, sizeof(PhoneCode.cPhoneCode));
	
	if(vial->cPhoneCode)
	{	
		PhoneCode.nCallType = 0;
		strncpy(PhoneCode.cPhoneCode, vial->cPhoneCode, VIAL_PHONECODE_LEN - 1);
		PhoneCode.nCodelen = vial->nLen;
		PhoneCode.cPhoneCode[PhoneCode.nCodelen]= '\0';
		
		showInfo("%s::%s, Get Caller Phonecode: %s\n", __CLASS__, 
											 		   __FUNCTION__, 
											 		   PhoneCode.cPhoneCode);
	}	
	else
	{	
		showWarning("%s::%s, Vial Phonecode is NULL\n", __CLASS__,
													   __FUNCTION__);
		return true;
	}
	
	/* Send ContactPrompterVial to Prompter */
	if(!get_contact_by_phone(&contact, PhoneCode.cPhoneCode))
	{		
		sprintf(full_name, "%s%s", contact.name.szfamily_name, contact.name.szgiven_name);
		printf("Get Contact Name: %s\n", full_name);
		
		ContactPrompterVial contact_prompter_vial;
		strcpy(contact_prompter_vial.szContactName, full_name);
		strcpy(contact_prompter_vial.szPhoneNum, PhoneCode.cPhoneCode);
		
		post_vial(&contact_prompter_vial, FN_PROMPTER_MODULE_ID);
	}
	else
	{	
		printf("No Contact\n");
		return true;
	}
	
	return true;
}

/************************************************************************************
									onOnHook 
*************************************************************************************/
bool PhonebookModule::on_on_hook(StateChangeVial *vial)
{	
	if(!vial)
	{
		showWarning("%s::%s StateChangeVial is NULL\n", __CLASS__, __FUNCTION__);
		return true;
	}
	
    switch(vial->oldState.st)
	{
		case CCST::ON_HOOK:		
			showInfo("%s::%s, Curren State: %s, State Already is %s\n", __CLASS__, 
																	    __FUNCTION__, 
																	    STATE_INFO[vial->curState.st],
																	    STATE_INFO[vial->oldState.st]);
			break;

		/* Got Dialed Call */
		case CCST::DIALING:
			showInfo("%s::%s, Curren State: %s, Hang Up Without Conn\n", __CLASS__, 
														  				 __FUNCTION__, 
														  		         STATE_INFO[vial->curState.st]);
			if(!PhoneCode.nCodelen)
			{
				showWarning("%s::%s, get_dialed_phone::PhoneCode::nCodelen is 0\n", __CLASS__, 
																 					__FUNCTION__);
				break;
			}	
			if(got_dialed_phone(PhoneCode.cPhoneCode))
			{	
				showWarning("%s::%s, Add Calllog Fail!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n", __CLASS__, 
																 					  __FUNCTION__);
				break;
			}
			sync_calllog_list();
			break;
		
		/* Got Missed Call */
		case CCST::RINGING:		
			showInfo("%s::%s, Curren State: %s, Missed a Call\n", __CLASS__, 
														  		  __FUNCTION__, 
														  		  STATE_INFO[vial->curState.st]);
			if(!PhoneCode.nCodelen)
			{
				showWarning("%s::%s, got_missed_phone::PhoneCode::nCodelen is 0\n", __CLASS__, 
																 					  __FUNCTION__);
				got_missed_phone("未知");
				sync_calllog_list();
				break;
			}
				
			if(got_missed_phone(PhoneCode.cPhoneCode))
			{	
				showWarning("%s::%s, Add Calllog Fail!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n", __CLASS__, 
																 					  __FUNCTION__);
				break;
			}
			sync_calllog_list();
			break;
		
		case CCST::NOVIDEO_CONN:		
			showInfo("%s::%s, Curren State: %s, Hang Up From Novideo Conn\n", __CLASS__, 
														  		  __FUNCTION__, 
														  		  STATE_INFO[vial->curState.st]);
			break;
			
		case CCST::VIDEO_CONN:
			showInfo("%s::%s, Curren State: %s, Hang Up From video Conn\n", __CLASS__, 
														  		  			  __FUNCTION__, 
														  		              STATE_INFO[vial->curState.st]);
			break;
			
		default:
			showWarning("%s::%s, Not Suitable State Change: %s to %s\n", __CLASS__, 
																	     __FUNCTION__, 
																	     vial->oldState.st,
																	     vial->curState.st);
			return true;
	}

	PhoneCode.nCallType = 0;
	PhoneCode.nCodelen = 0;
	memset(PhoneCode.cPhoneCode, 0, sizeof(PhoneCode.cPhoneCode));
	
	return true;
}	

/*************************************************************************************
							on_dialing
**************************************************************************************/
bool PhonebookModule::on_dialing(StateChangeVial *vial)
{
	if(!vial)
	{
		showWarning("%s::%s StateChangeVial is NULL\n", __CLASS__, __FUNCTION__);
		return true;
	}

	#if 0
	if(PhoneCode.nCodelen)
	{
	    #if 0
		PhoneCode.nCallType = 0;
		strcpy(PhoneCode.cPhoneCode, PhoneCode.cPhoneCode);
		PhoneCode.cPhoneCode[PhoneCode.nCodelen]= '\0';
		PhoneCode.nCodelen = PhoneCode.nCodelen;
		#endif
		
		showInfo("%s::%s Phonecode: %s\n", __CLASS__,
										   __FUNCTION__,
										   PhoneCode.cPhoneCode);
	}
	else
	{	
		showWarning("%s::%s, Phonecode is Nothing\n", __CLASS__, 
												   	  __FUNCTION__);
	}
	#endif
	
	switch(vial->oldState.st)
	{
		case CCST::ON_HOOK:	
			showInfo("%s::%s, Curren State: %s, Start to Call ...\n", __CLASS__, 
														  		      __FUNCTION__, 
														  		      STATE_INFO[vial->curState.st]);
			break;

		case CCST::DIALING:
			showInfo("%s::%s, Curren State: %s, State Already is %s\n", __CLASS__, 
																	    __FUNCTION__, 
																	    STATE_INFO[vial->curState.st],
																	    STATE_INFO[vial->oldState.st]);
			break;
			
		case CCST::NOVIDEO_CONN:
			showInfo("%s::%s, Curren State: %s, Remote Side Hang UP From Novideo Conn\n", __CLASS__, 
										  		      									  __FUNCTION__, 
										  		      									  STATE_INFO[vial->curState.st]);
			break;
		
		case CCST::VIDEO_CONN:
			showInfo("%s::%s, Curren State: %s, Remote Side Hang UP From Video Conn\n", __CLASS__, 
																						__FUNCTION__, 
													 									STATE_INFO[vial->curState.st]);
			break;
			
		default:
			showWarning("%s::%s, Not Suitable State Change: %s to %s\n", __CLASS__, 
																		 __FUNCTION__, 
																		 vial->oldState.st,
																		 vial->curState.st);
			break;
	}

	return true;
}

/**********************************************************************************************
						               	onRinging
***********************************************************************************************/
bool PhonebookModule::on_ringing(StateChangeVial *vial)
{	
	if(!vial)
	{
		showWarning("%s::%s StateChangeVial is NULL\n", __CLASS__, __FUNCTION__);
		return true;
	}
	
	if(PhoneCode.nCodelen)
	{
		#if 0
		PhoneCode.nCallType = 0;
		strcpy(PhoneCode.cPhoneCode, vial->cPhoneCode);
		PhoneCode.cPhoneCode[PhoneCode.nCodelen]= '\0';
		PhoneCode.nCodelen = vial->nLen;
		#endif
		
		showInfo("%s::%s Phonecode: %s\n", __CLASS__,
													  __FUNCTION__,
													  PhoneCode.cPhoneCode);
	}
	else
	{	
		showWarning("%s::%s, Phonecode is Nothing\n", __CLASS__, 
												   __FUNCTION__);
		return true;
	}

	
	switch(vial->oldState.st)
	{
		case CCST::ON_HOOK:		
			showInfo("%s::%s, Curren State: %s, Now is Ringing\n", __CLASS__, 
														  		   __FUNCTION__, 
														           STATE_INFO[vial->curState.st]);
			break;

		case CCST::RINGING:		
			showInfo("%s::%s, Curren State: %s, State Already is %s\n", __CLASS__, 
																	  __FUNCTION__, 
																	  STATE_INFO[vial->curState.st],
																	  STATE_INFO[vial->oldState.st]);
			break;
			
		default:
			showWarning("%s::%s, Not Suitable State Change: %s to %s\n", __CLASS__, 
																		 __FUNCTION__, 
																		 vial->oldState.st,
																		 vial->curState.st);
			break;
	}
	
	return true;
}

/************************************************************************************************
					                               	onNoVideoConn
*************************************************************************************************/
bool PhonebookModule::on_novideoconn(StateChangeVial *vial)
{
	if(!vial)
	{
		showWarning("%s::%s StateChangeVial is NULL\n", __CLASS__, __FUNCTION__);
		return true;
	}

	switch(vial->oldState.st)
	{
		/* Got Dialed Call */
		case CCST::DIALING:
			showInfo("%s::%s, Curren State: %s, Now is Novideo Conn\n", __CLASS__, 
																	    __FUNCTION__, 
																	    STATE_INFO[vial->curState.st]);

			if(!PhoneCode.nCodelen)
			{
				showWarning("%s::%s, get_dialed_phone::PhoneCode::nCodelen is 0\n", __CLASS__, 
																 					__FUNCTION__);
				got_dialed_phone("未知");
				sync_calllog_list();
				break;
			}
			
			if(got_dialed_phone(PhoneCode.cPhoneCode))
			{	
				showWarning("%s::%s, Add Calllog Fail!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n", __CLASS__, 
																 					  __FUNCTION__);
				break;
			}
			sync_calllog_list();
			break;
			
		/* Got Receive Call */
		case CCST::RINGING:
			showInfo("%s::%s, Curren State: %s, Now is Novideo Conn\n", __CLASS__,
											  							__FUNCTION__, 
											  							STATE_INFO[vial->curState.st]);			
			if(!PhoneCode.nCodelen)
			{
				showWarning("%s::%s, get_received_phone::PhoneCode::nCodelen is 0\n", __CLASS__,
																 					  __FUNCTION__);
				got_received_phone("未知");
				sync_calllog_list();
				break;
			}

			if(got_received_phone(PhoneCode.cPhoneCode))
			{
				showWarning("%s::%s, Add Calllog Fail!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n", __CLASS__, 
																 					  __FUNCTION__);
				break;
			}
			sync_calllog_list();
			break;
		
		case CCST::NOVIDEO_CONN:
		showInfo("%s::%s, Curren State: %s, State Already is %s\n", __CLASS__, 
																	__FUNCTION__, 
																	STATE_INFO[vial->curState.st],
																	STATE_INFO[vial->oldState.st]);
			break;
			
		default:
			showWarning("%s::%s, Not Suitable State Change: %s to %s\n", __CLASS__, 
																	__FUNCTION__, 
																	vial->oldState.st,
																	vial->curState.st);
			return true;
	}
	
	return true;
}

bool PhonebookModule::on_videoconn(StateChangeVial *vial)
{
	if(!vial)
	{
		showWarning("%s::%s StateChangeVial is NULL\n", __CLASS__, __FUNCTION__);
		return true;
	}

	switch(vial->oldState.st)
	{
		/* Got Dialed Call */
		case CCST::DIALING:
			showInfo("%s::%s, Curren State: %s, Now is Video Conn\n", __CLASS__, 
																	  __FUNCTION__, 
																	  STATE_INFO[vial->curState.st]);
			if(!PhoneCode.nCodelen)
			{
				showWarning("%s::%s, get_dialed_phone::PhoneCode::nCodelen is 0\n", __CLASS__, 
																 					  __FUNCTION__);
				got_dialed_phone("未知");
				sync_calllog_list();
				break;
			}
			
			if(got_dialed_phone(PhoneCode.cPhoneCode))
			{
				showWarning("%s::%s, Add Calllog Fail!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n", __CLASS__, 
																 					  __FUNCTION__);
				break;
			}
			sync_calllog_list();
			break;
			
		/* Got Receive Call */
		case CCST::RINGING:		
			showInfo("%s::%s, Curren State: %s, Now is Video Conn\n", __CLASS__, 
										  							  __FUNCTION__, 
										  							  STATE_INFO[vial->curState.st]);			
			if(!PhoneCode.nCodelen)
			{
				showWarning("%s::%s, get_received_phone::PhoneCode::nCodelen is 0\n", __CLASS__, 
																 					  __FUNCTION__);
				got_received_phone("未知");
				sync_calllog_list();
				break;
			}
			
			if(got_received_phone(PhoneCode.cPhoneCode))
			{
				showWarning("%s::%s, Add Calllog Fail!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n", __CLASS__, 
																	 				  __FUNCTION__);
				break;
			}
			sync_calllog_list();
			break;
		
		case CCST::VIDEO_CONN:
			showInfo("%s::%s, Curren State: %s, State Already is %s\n", __CLASS__, 
																	__FUNCTION__, 
																	STATE_INFO[vial->curState.st],
																	STATE_INFO[vial->oldState.st]);
			break;
			
		default:
			showWarning("%s::%s, Not Suitable State Change: %s to %s\n", __CLASS__, 
																		 __FUNCTION__, 
																		 vial->oldState.st,
																		 vial->curState.st);
			break;
	}

	return true;
}

bool PhonebookModule::is_standby()
{
	if(CCST::ON_HOOK == cur_state)
		return true;
	else
		return false;
}	
	
bool PhonebookModule::is_callout()
{	
	if(CCST::DIALING == cur_state)
		return true;
	
	if(CCST::NOVIDEO_CONN == cur_state || CCST::VIDEO_CONN == cur_state)
	{
		if(PhoneCode.nCallType == 1)
			return true;
		else
		{
			printf("TALKING but not callout");
			return false;
		}
	}
	return false;
}

