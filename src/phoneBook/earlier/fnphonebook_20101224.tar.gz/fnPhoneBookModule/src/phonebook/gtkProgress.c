#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>

#include "phonebookapi.h"
#include "phonebookskin.h"
#include "windowstack.h"
#include "LogMsg.hpp"

pthread_t backgroud_thread;
GtkWidget *progress_bar;
int timer;

//extern int is_has_focus;
//extern char HAS_FOCUS[2][32];
extern int lose_focus_mode;

gint progress_timeout( gpointer data )
{	
	gdouble new_val;
	//gtk_progress_bar_pulse (GTK_PROGRESS_BAR (progress_bar));
	new_val = gtk_progress_bar_get_fraction (GTK_PROGRESS_BAR (progress_bar)) + 0.02;
	
	if (new_val > 1.0)
		new_val = 0.0;
	gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (progress_bar), new_val);
			
	return TRUE;
}

void destroy_progress()
{	
    GtkWindowInfo pwindow_info;
	
	gtk_timeout_remove (timer);
    if(get_window_out_stack(&pwindow_info) >= 0)
		destroy_widget(GTK_WIDGET(pwindow_info.window));
	else
		showError("%s XXXXXXXXXXXXXXXXXXX get_window_out_stack Error\n", __FUNCTION__);
	//show_top_window();
}

int show_progress(char *msg)
{	
	GtkWidget *window;
			
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_modal(window, TRUE);
	gtk_widget_set_size_request(window, PROGRESS_BAR_SIZE_WIDTH, PROGRESS_BAR_SIZE_HEIGHT);
	gtk_window_move(GTK_WINDOW(window), PROGRESS_BAR_POS_X, PROGRESS_BAR_POS_Y);
	put_window_into_stack(window);

	progress_bar = gtk_progress_bar_new();
	if(msg)
		gtk_progress_bar_set_text (GTK_PROGRESS_BAR (progress_bar), msg);
	gtk_container_add(window, progress_bar);
	gtk_widget_show(progress_bar);
	timer = gtk_timeout_add (200, progress_timeout, NULL);
				
	show_top_window();
	gtk_main();
}

int do_some_thing_async(void *function, void *p_data, char *msg)
{	
	int rtn;
	char *rtn_ch;
	
	if(!pthread_create(&backgroud_thread, NULL, function, p_data))
	{
		showInfo("%s thread create Ok\n", __FUNCTION__);
	}
	else
	{
		showError("%s thread create Err\n", __FUNCTION__);
		return -1;	
	}
	show_progress(msg);
	
	destroy_progress();
	if(pthread_join(backgroud_thread, &rtn))
		showError("%s XXXXXXXXXXXXXXXXX Can not Join With Backgroud Thread\n", __FUNCTION__);
	//showDebug("%s Rtn: %d\n", __FUNCTION__, rtn);
	
	return rtn;
}	
	
