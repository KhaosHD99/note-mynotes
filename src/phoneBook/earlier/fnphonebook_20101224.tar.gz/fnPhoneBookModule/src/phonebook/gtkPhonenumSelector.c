#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>

#include "phonebookapi.h"
#include "phonebookskin.h"
#include "windowstack.h"
#include "LogMsg.hpp"

GtkListStore *phonenum_selector_store;
GtkTreeView *phonenum_selector_treeview;

enum 
{
	SELECTOR_INDEX_COL,
    SELECTOR_PHONENUM_COL,
};

//extern int is_has_focus;
//extern char HAS_FOCUS[2][32];
extern int lose_focus_mode;

on_window_select_phonenum_focus_out_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("XXXXXXXXXXXXXX %s Lose Mode: %d\n", __FUNCTION__, lose_focus_mode);
	if(!lose_focus_mode)
	{
		
		destory_window_except_root();
	}
	else
		lose_focus_mode = 0;
}

void on_button_select_phonenum_dial_focus_in_event(GtkWidget *widget, gpointer user_data)
{	
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_select_phonenum_dial_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_select_phonenum_cancel_focus_in_event(GtkWidget *widget, gpointer user_data)
{	
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_select_phonenum_cancel_focus_out_event(GtkWidget *widget, gpointer user_data)
{	
	GdkColor color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}	

GtkListStore* create_phonenum_selector_store(void)
{
	GtkListStore *store;
	store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING);
	
	return store;
}

GtkTreeModel* fill_phonenum_selector_store(GtkListStore *store, int phonenum_flag, int index)
{	
	int i;
	Contact contact;
	
	switch(phonenum_flag)
	{
		case CONTACT_BUF:		
			
			get_contact_by_index(&contact, index);
			for(i = 0; i < contact.phone_count; i++)
		    {	
		       GtkTreeIter iter;
			   gtk_list_store_append(store, &iter);
			   gtk_list_store_set(store, &iter,
			     	              SELECTOR_INDEX_COL, i,
					              SELECTOR_PHONENUM_COL, contact.phones[i].szphone,
					              -1);
			}

		#if 0
		case CALLLOG_BUF:		
			CallLog calllog;
			get_calllog_by_index(&calllog, index);
			for(i = 0; i < calllog.phone_count; i++)
		    {	
		       GtkTreeIter iter;
			   gtk_list_store_append(store, &iter);
			   gtk_list_store_set(store, &iter,
			     	              SELECTOR_INDEX_COL, i,
					              SELECTOR_PHONENUM_COL, calllog.phones[i].szphone,
					              -1);
			}	

		case BLACKLIST_BUF:		
			Blacklist blacklist;
			get_contact_by_index(&blacklist, index);
			for(i = 0; i < blacklist.phone_count; i++)
		    {	
		       GtkTreeIter iter;
			   gtk_list_store_append(store, &iter);
			   gtk_list_store_set(store, &iter,
			     	              SELECTOR_INDEX_COL, i,
					              SELECTOR_PHONENUM_COL, blacklist.phones[i].szphone,
					              -1);
			}	

		case QUICKDIAL_BUF:		
			Quickdial quickdial;
			get_contact_by_index(&quickdial, index);
			for(i = 0; i < quickdial.phone_count; i++)
		    {	
		       GtkTreeIter iter;
			   gtk_list_store_append(store, &iter);
			   gtk_list_store_set(store, &iter,
			     	              SELECTOR_INDEX_COL, i,
					              SELECTOR_PHONENUM_COL, quickdial.phones[i].szphone,
					              -1);
			}	

		case COMMONPHONE_BUF:		
			Commonphone commonphone;
			get_contact_by_index(&commonphone, index);
			for(i = 0; i < commonphone.phone_count; i++)
		    {	
		       GtkTreeIter iter;
			   gtk_list_store_append(store, &iter);
			   gtk_list_store_set(store, &iter,
			     	              SELECTOR_INDEX_COL, i,
					              SELECTOR_PHONENUM_COL, commonphone.phones[i].szphone,
					              -1);
			}
		#endif
		
		default:
			showWarning("%s Invalid Phonenum Buf\n", __FUNCTION__);
	}

	//showDebug("phonum count: %d, index col: %d, phonenum col: %d\n", contact.phone_count
	//										     				   , CONTACT_INDEX_COL
	//										  	 				   , PHONENUM_COL)
	
	return GTK_TREE_MODEL (store);
}

void set_selector_phonenum(GtkTreeViewColumn *tree_column,
						        GtkCellRenderer   *cell,
						        GtkTreeModel      *model,
						        GtkTreeIter       *iter,
						        gpointer           data)
{
    #if 1
	char *phonenum;
	
	gtk_tree_model_get(model, iter,
	                   SELECTOR_PHONENUM_COL, &phonenum,
	                   -1);
		
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", phonenum,
                 NULL);
	
	g_free(phonenum);
    #endif
}

int dial_async(void *p_data)
{	
	int rtn;
	char phonenum[128];
	
	strcpy(phonenum ,(char *)p_data);
	rtn = dial(phonenum);	
	
	gtk_main_quit();
	pthread_exit(rtn);
}
	
void on_button_select_phonenum_dial_clicked(GtkWidget *widget, gpointer user_data)
{	
	//do_some_thing_async(dial_async, "正在拨号...");
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;
	const gchar *phonenum;
	
   	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(phonenum_selector_treeview));
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window(get_value_from_key(DISPLAY_NO_SELECT));
		return;
	}
	
	if(gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	  		               SELECTOR_PHONENUM_COL, &phonenum,
	                       -1);
	}
	else
	{	
		showWarning("Can not get phonenum_treeview selection\n");
		return;
	}
		
	if(validate_phonenum(phonenum))
	{	
		showError("%s XXXXXXXXX Validate Phonum Fail\n", __FUNCTION__);
		show_message_window("无效的号码");
		return;
	}	
	#if 1
	if(do_some_thing_async(dial_async, phonenum, "正在拨号..."))
	{
		showWarning("%s XXXXXXXXXXXXXXXXXXXXXXX Send Dial Vial Fail\n", __FUNCTION__);
		show_message_window("拨号失败");
		return;
	}
	else
	    showInfo("%s Send Dial Vial Successfully, phonenum: %s\n", __FUNCTION__, phonenum);
	#endif
	
	if(phonenum)
		g_free(phonenum);
	
	destory_window_except_root();
}

void on_button_select_phonenum_cancel_clicked(GtkWidget *widget, gpointer user_data)
{	
	GtkWindowInfo pwindow_info;
	
    if(get_window_out_stack(&pwindow_info) >= 0)
		destroy_widget(GTK_WIDGET(pwindow_info.window));
	else
		showError("%s XXXXXXXXXXXXXXXXXXX get_window_out_stack Error\n", __FUNCTION__);
	
	//show_top_window();
}

int show_phonenum_selector_window(int phonenum_flag, int index)
{	
	GtkBuilder *builder;
	GtkWidget *window;
	GtkTreeViewColumn *column_phonenum;
	GtkCellRenderer *cell_renderer;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_select_phonenum"));
	gtk_window_set_title(GTK_WINDOW(window), "window_select_phonenum");
	gtk_window_move(GTK_WINDOW(window), 300, 80);
	
	if(put_window_into_stack(window) < 0)
		showError("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX Put Phonenum_selector Into Stack Error!!!!!!!!!!!\n");
	
	//add  model to tree view	
	phonenum_selector_store = create_phonenum_selector_store();
	phonenum_selector_treeview = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_phonenum");
	gtk_tree_view_set_model(phonenum_selector_treeview, 
							fill_phonenum_selector_store(phonenum_selector_store, phonenum_flag, index));

	#if 1
	column_phonenum = gtk_tree_view_column_new();
    gtk_tree_view_column_set_title(column_phonenum, DISPLAY_CONTACT);
    
	//name cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_phonenum,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_phonenum, cell_renderer,
		                              	    set_selector_phonenum, NULL, NULL);
	
	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(phonenum_selector_treeview),
					            column_phonenum);
	#endif
    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();	
	return 0;
}

