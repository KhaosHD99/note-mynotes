#ifndef CALLLOG_DEF
#define CALLLOG_DEF

#include <lpconfig.h>
#include <pthread.h>
#include "phonebookinfo.h"

class CCalllogManager
{
		private:
				LpConfig *calllog_lpconfig;
				pthread_mutex_t mutex;
				CallLog_Info calllog_missed, calllog_received, calllog_dialed;
				static CCalllogManager *calllog_instance;
		
		private:
				CCalllogManager();
				~CCalllogManager();
				void init();	
				void init_log(CallLog_Info *calllog_info);
				void uninit();
				void uninit_log(CallLog_Info *calllog_info);
			
				//inner function
				CallLog* get_section_from_config_file(int index);
		    	int write_calllog_item(CallLog *item, int index, int status_index);
				int sync_calllog_config();
				
				//mutex
				int init_mutex();
				void lock_mutex();
				void unlock_mutex();
			    
		public: 
				static CCalllogManager *get_instance();
				
				//CURD
				int load_calllog_from_file();
				int get_calllog_count();
		        int get_calllog_count_by_type(CLSTATUS status);	 
	      		int get_calllog_by_index(CallLog *calllog, int index, CLSTATUS status); 
	      		int get_unread_missed_callog_count();
				
				int add_calllog(CallLog *calllog);

				int update_calllog_by_index(CallLog *calllog, int index, CLSTATUS status);

	      		int delete_calllog_by_index(int index, CLSTATUS status);
	      		int delete_calllog_by_status(CLSTATUS status);
				
				//sort
				int sort_by_date();

                //helper
				int comp(const void *p, const void *q);

	      		//enum
				CLSTATUS __clstatus_str_to_enum(const char *enum_str);
				const char* __clstatus_enum_to_str(int enum_val);
};
#endif
