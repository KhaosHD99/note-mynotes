#include <stdio.h>
#include <string.h>
#include "config.hpp"
#include "iostream"
#include <stdlib.h>

/********************************************************************************
                                                      constructor
********************************************************************************/
CConfigManager::CConfigManager()
{
    init();
}

/********************************************************************************
                                                      destructor
********************************************************************************/
CConfigManager::~CConfigManager()
{
	uninit();
}

/********************************************************************************
                                                        initialization
********************************************************************************/
void CConfigManager::init()
{	
	//init contact buffer and lpconfig
	config_lpconfig = lp_config_new(CONFIG_FILE_PATH); 
	
	if(!config_lpconfig)
		printf("config_lpconfig is null");
	
	//init lock
	//int ret = init_mutex();
	//if(ret != 0)
	//	return;
		
	//init contact buffer
}

/********************************************************************************
                                                           uninitialization
********************************************************************************/
void CConfigManager::uninit()
{
	lp_config_destroy(config_lpconfig);
}

/********************************************************************************
                                                         get instance
********************************************************************************/
CConfigManager* CConfigManager::config_instance = NULL;
CConfigManager *CConfigManager::get_instance()
{	
	if(!config_instance)
			config_instance = new CConfigManager;
	
	return config_instance;
}

/**********************************************************************************************************/
/************************************************* inner function  ********************************************/
/**********************************************************************************************************/

/********************************************************************************
                                     get section item from file by index
********************************************************************************/
const char* CConfigManager::get_value_from_key(const char *key)
{
	const char *tmp;
	char *tmpcpy;
	char section[64];
	char *part_str;
	const char * split = ":";
	
	sprintf(section, "%s", CONFIG_DISPLAY_SECTION);
	
	if (!lp_config_has_section(config_lpconfig, section))
	{
		printf("has not section\n");
		return NULL;
	}
	//name, group
	tmp = lp_config_get_string(config_lpconfig, section, key, NULL);
	//if(tmp != NULL)
	//strcpy(contact->name.szfamily_name, tmp);
	//	printf("confirm: %s\n", tmp);
//	else
	//	printf("tmp is null\n");
    #if 0
	//phone
	phone_count = lp_config_get_int(contact_lpconfig, section_index, CONTACT_PHONE_COUNT, NULL);
	
	for(int i=0; i<phone_count; i++)
	{
	sprintf(phone_index,"%s%d", PHONE_INDEX_PREFIX, i + 1);
	tmp = lp_config_get_string(contact_lpconfig,section_index,phone_index, NULL);

	tmpcpy = new char[strlen(tmp)];
	strcpy(tmpcpy, tmp);

	//type
	part_str = strtok (tmpcpy, split);
	if(__phonetype_str_to_enum((const char*)part_str) != NULL)
	{
	contact->phones[i].type = __phonetype_str_to_enum((const char*)part_str);
	}

	//szphone
	part_str = strtok(NULL,split);
	if((const char*)part_str != NULL)
	{
	strcpy(contact->phones[i].szphone, (const char*)part_str);
	}

	free(tmpcpy);
	}

	//email
	email_count = lp_config_get_int(contact_lpconfig, section_index, CONTACT_EMAIL_COUNT, NULL);

	for(int j=0;j < email_count; j++)
	{
		sprintf(email_index,"%s%d", EMAIL_INDEX_PREFIX, j + 1);
		tmp = lp_config_get_string(contact_lpconfig,section_index,email_index, NULL);
		tmpcpy = new char[strlen(tmp)];
		strcpy(tmpcpy, tmp);

		//type
		part_str = strtok (tmpcpy, split);
		if(__emailtype_str_to_enum((const char*)part_str) != NULL)
		contact->emails[j].type = __emailtype_str_to_enum((const char*)part_str);

		//szemail
		part_str = strtok(NULL,split);
		if((const char*)part_str != NULL)
		strcpy(contact->emails[j].szemail, (const char*)part_str);

		free(tmpcpy);
	}

	//avatar, voip, im, address
    tmp = lp_config_get_string(contact_lpconfig, section_index, CONTACT_AVATAR, NULL);
	if(tmp != NULL && strlen(tmp) <= MAX_AVATAR_LEN)
		strcpy(contact->szavatar, tmp);
	
	tmp = lp_config_get_string(contact_lpconfig, section_index, CONTACT_VOIP, NULL);
	if(tmp != NULL && strlen(tmp) <= MAX_VOIP_LEN)
		strcpy(contact->szvoip, tmp);

	tmp = lp_config_get_string(contact_lpconfig, section_index, CONTACT_IM, NULL);
	if(tmp != NULL && strlen(tmp) <= MAX_IM_LEN)
		strcpy(contact->szim, tmp);

	tmp = lp_config_get_string(contact_lpconfig, section_index, CONTACT_ADDRESS, NULL);
	if(tmp != NULL && strlen(tmp) <= MAX_ADDRESS_LEN)
		strcpy(contact->szaddress, tmp);
	#endif
    
	return tmp;
}

#if 0
/********************************************************************************
                          write contact item to config file by index without sync
********************************************************************************/
int CConfigManager::write_contact_item(Contact *item, int index)
{
	char section[64];
	char phone_index[32];
	char email_index[32];
	char phone_mix_info[32];
	char email_mix_info[32];
	int phone_count;
	int email_count;

	char *tmp;
	int a = 5;

	sprintf(section,"%s%i", CONTACT_INDEX_PREFIX, index);
	
	//name, group
	lp_config_set_string(contact_lpconfig, section, CONTACT_FAMILY_NAME, item->name.szfamily_name);
	lp_config_set_string(contact_lpconfig, section, CONTACT_GIVEN_NAME, item->name.szgiven_name);
	lp_config_set_string(contact_lpconfig, section, CONTACT_GROUP, __grouptype_enum_to_str(item->type));

	//phone
	phone_count = 0;

	while(item->phones[phone_count].szphone[0] != '\0')
	{
		phone_count++;
		if(phone_count == MAX_PHONE_COUNT)
			break;
	}

	lp_config_set_int(contact_lpconfig, section, CONTACT_PHONE_COUNT, phone_count);
		             
	for(int i=0; i<phone_count; i++)
	{
	sprintf(phone_index,"%s%d", PHONE_INDEX_PREFIX, i + 1);
	  if(__phonetype_enum_to_str(item->phones[i].type) != NULL)
		sprintf(phone_mix_info, "%s:%s", 
		        __phonetype_enum_to_str(item->phones[i].type), 
		        item->phones[i].szphone);
	  else
				sprintf(phone_mix_info, "%s", item->phones[i].szphone);

	lp_config_set_string(contact_lpconfig, section, phone_index, phone_mix_info);
	}

	//email
	email_count = 0;
	while(*item->emails[email_count].szemail != 0)
	{
		email_count++;
	if(email_count == MAX_EMAIL_COUNT)
			break;
	}

	lp_config_set_int(contact_lpconfig, section, CONTACT_EMAIL_COUNT, email_count);
		             
	for(int i=0; i<email_count; i++)
	{
		sprintf(email_index,"%s%d", EMAIL_INDEX_PREFIX, i + 1);
	  if(__emailtype_enum_to_str(item->emails[i].type) != NULL)
				sprintf(email_mix_info, "%s:%s", 
		        		__emailtype_enum_to_str(item->emails[i].type), 
		        		item->emails[i].szemail);
	  else
		sprintf(email_mix_info, "%s", item->emails[i].szemail);

		lp_config_set_string(contact_lpconfig, section, email_index, email_mix_info);
	}

    
	//avatar, voip, im, address
	lp_config_set_string(contact_lpconfig, section, CONTACT_AVATAR, item->szavatar);
	lp_config_set_string(contact_lpconfig, section, CONTACT_VOIP, item->szvoip);
	lp_config_set_string(contact_lpconfig, section, CONTACT_IM, item->szim);
	lp_config_set_string(contact_lpconfig, section, CONTACT_ADDRESS, item->szaddress);
	
	return 0;
}

/********************************************************************************
                                                    synchronization
********************************************************************************/
int CConfigManager::sync_contact_config()
{ 
	int writeindex = 0;
	char section[32];

	if(contact_lpconfig == NULL)
	{
		//g_error("contacts_lpconfig = (null)");
		return -1;
	}

	if(contact_buf == NULL)
	{
		//g_error("no contact_buf, save contact error!");
		return -1;
	}

	//clear
	for(int i = 0; i < MAX_CONTACT_COUNT; i++)
	{
	    sprintf(section, "%s%i", CONTACT_INDEX_PREFIX, i);
	    if(lp_config_has_section(contact_lpconfig, section))
	    	lp_config_clean_section(contact_lpconfig, section);
	}
    
	//sort
	sort_by_pinyin();
	
	//write item
	for(int i = 0; i < buf_count; i++)
		write_contact_item(contact_buf[i], i);
    
	return lp_config_sync(contact_lpconfig);	
}

/********************************************************************************
                                                sort contact buffer by letter
********************************************************************************/
void CConfigManager::sort_by_letter()	
{
	int len;
	int tmp_buf_index = 0;
	const char letter_set[] = {'a','b','c','d','e','f','g','h','i','j','k','l','m',
							   'n','o','p','q','r','s','t','u','v','w','x','y','z'};

	Contact **contact_tmp_buf = new Contact*[MAX_CONTACT_COUNT];

	len = get_contact_count();
	if(len <= 0)
		return;

	for(int letter_index = 0;letter_index < 26; letter_index++)
	{
	    const char cmp_letter[] = {letter_set[letter_index], '\0'};
		for(int i = 0;i < len; i++)
		{
			const char initial_letter[] = {contact_buf[i]->name.szfamily_name[0], '\0'};
			if(strcmp(cmp_letter, initial_letter) == 0)
			{
 				contact_tmp_buf[tmp_buf_index] = contact_buf[i];
   				tmp_buf_index++;
			}
	    }
	}

	for(int i = 0; i < len; i++)
		contact_buf[i] = contact_tmp_buf[i];

	//sync
	sync_contact_config();
}

int CConfigManager::comp(const void *p, const void *q)
{
	return (*(int *)p - *(int *)q);
}


/********************************************************************************
                                                sort contact buffer by pinyin
********************************************************************************/
void CConfigManager::sort_by_pinyin()
{   
	Contact **contact_buf_tmp;
	char contact_name[MAX_CONTACT_COUNT][MAX_NAME_LEN];
	contact_buf_tmp = new Contact*[buf_count];
	
    //duplicate
    for(int i = 0; i < buf_count; i++)
    	strcpy(contact_name[i], contact_buf[i]->name.szfamily_name);
    
	
	for(int i = 0;  i < buf_count; i++)    
	{
	    contact_buf_tmp[i] = new Contact;
		memcpy(contact_buf_tmp[i], contact_buf[i], sizeof(Contact));
	}
 
	//release contact_buf[i] 
	for(int i = 0; i < get_contact_count();	i++)    
	{
			delete contact_buf[i];
			contact_buf[i] = NULL;
	}
    
    //sort
	qsort(contact_name, buf_count, MAX_NAME_LEN, (__compar_fn_t)strcoll);
  
    #if 1
    for(int i = 0; i < buf_count; i++)
    {
		for(int j = 0; j < buf_count; j++)
		{
        	if(!strcmp(contact_buf_tmp[j]->name.szfamily_name, contact_name[i]))
        	{
        	    //printf("contact_buf_tmp %d == contact_name %d\n", j, i); 
            	contact_buf[i] = new Contact;
				memcpy(contact_buf[i], contact_buf_tmp[j], sizeof(Contact));
			}
		}
	}

	//release contact_buf_tmp and contact_name
    for(int i = 0;i < buf_count;i++)    
	{
		delete contact_buf_tmp[i];
		contact_buf_tmp[i] = NULL;
	}

	delete contact_buf_tmp;
    contact_buf_tmp = NULL;
	
	#endif
}

/**********************************************************************************************************/
/****************************************    mutex    *****************************************************/
/**********************************************************************************************************/

/********************************************************************************
                                                          init lock mutex
********************************************************************************/
int CConfigManager::init_mutex()
{
	return pthread_mutex_init(&mutex, NULL);
}

/********************************************************************************
                                                            lock mutex
********************************************************************************/
void CConfigManager::lock_mutex()
{
	pthread_mutex_lock(&mutex);
}

/********************************************************************************
 					                      unlock mutex
********************************************************************************/
void CConfigManager::unlock_mutex()
{
	pthread_mutex_unlock(&mutex);
}
#endif
