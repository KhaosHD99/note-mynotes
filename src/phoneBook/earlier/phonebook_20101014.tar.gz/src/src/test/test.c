#include <stdio.h>
#include <gtk/gtk.h>
#include "phonebookapi.h"
#include "windowstack.h"
#include "MessageStack.h"

GtkWidget *rootWindow;
GtkWidget *contactWindow;
GtkWidget *calllogWindow;
GtkBuilder *builder;

void on_button_contact_clicked(GtkWidget *gtklist, gpointer user_data)
{
	show_contact_window();
}

void on_button_missed_clicked(GtkWidget *gtklist, gpointer user_data)
{
     show_missed_calllog_window();
}

void on_button_received_clicked(GtkWidget *gtklist, gpointer user_data)
{
     show_received_calllog_window();
}
void on_button_dialed_clicked(GtkWidget *gtklist, gpointer user_data)
{
     show_dialed_calllog_window();
}

int main(int argc, char *argv[])
{
	  gtk_init(&argc, &argv);

	  #if 1
	  GtkWidget *window;
	  builder = gtk_builder_new();
      gtk_builder_add_from_file (builder, "phonebook.glade", NULL);

	  if(!rootWindow)
	  {
	  	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_main"));
	  	gtk_window_move(GTK_WINDOW(window), 200, 0);
	  	rootWindow = window;
		gtk_builder_connect_signals(builder, NULL);
		gtk_widget_show(rootWindow);
	  }
      else if(!GTK_WIDGET_VISIBLE(rootWindow))
	  	gtk_widget_show_all(rootWindow);
	  
      #endif

	  #if 0
	  //add contact
		Contact section;
		memset(&section, 0, sizeof(Contact));
	
		strcpy(section.name.szfamily_name,"何");
		strcpy(section.name.szgiven_name,"桂");
	    
		section.phones[0].type = PT_HOME;
		strcpy(section.phones[0].szphone, "31325201");
		section.phones[1].type = PT_MOBILE;
		strcpy(section.phones[1].szphone, "13539982758");
		section.phones[2].type = PT_WORK;
		strcpy(section.phones[2].szphone, "12345678");
	
		section.emails[0].type = EMT_WORK;
		strcpy(section.emails[0].szemail, "xujiekoo@qq.com");
	    section.emails[1].type = EMT_HOME;
		strcpy(section.emails[1].szemail, "163.com");
	    
		strcpy(section.szvoip,"172.17");
		strcpy(section.szim,"466795229");
		strcpy(section.szaddress,"yuexu");

    add_contact(&section);
    add_contact(&section);
    add_contact(&section);

	  creat_window_stack();
    GtkWidget *window;
    GtkWidget *window2;
    GtkWidget *window3;
    
    //builder
    /*gtk_init (&argc, &argv);
    
    builder = gtk_builder_new();
    gtk_builder_add_from_file (builder, "phonebook.glade", NULL);
    
	  //window
	  window = (GtkWidget *)gtk_builder_get_object(builder, "window_main");
    
    if(window == NULL || window2 == NULL)
    {
    		printf("control is NULL\n");
    		return;			
    } 	
    
    rootWindow = window;
	  //childWindow = window2;
		//childWindow2 = window3;
		
		put_window_into_stack(rootWindow);
		//put_window_into_stack(childWindow);
		//put_window_into_stack(childWindow2);
		
		//gtk_window_set_position(GTK_WINDOW(window),GTK_WIN_POS_CENTER);
		gtk_window_move(GTK_WINDOW(window), 200, 0);
		
    //event
    gtk_builder_connect_signals(builder, NULL);
    //g_object_unref(G_OBJECT (builder));
    
    gtk_widget_show(rootWindow);*/
    #endif
    
    gtk_main();
    
    return 0;
}

