#ifndef PROMPTER_CCINTERFACE_DEF
#define PROMPTER_CCINTERFACE_DEF
//#include "PrompterGui.h"
//#include "CCST.hpp"

#ifdef __cplusplus
extern"C"
{
#endif

	int creat_and_run_adv_play_module();
	
#ifdef __cplusplus
}
#endif
	
#endif
