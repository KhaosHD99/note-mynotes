#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>

#include "phonebookapi.h"
#include "MessageStack.h"
#include "windowstack.h"
#include "LogMsg.hpp"

#define _(STRING) g_convert(STRING, -1, "UTF-8", "GB2312", NULL, NULL, NULL)
#define _to_asc(STRING) g_convert(STRING, -1, "GB2312", "UTF-8", NULL, NULL, NULL)

GtkListStore *quickdial_store;
GtkListStore *contact_store;

GtkTreeView *treeview_quickdial_main;
GtkTreeView *treeview_quickdial;
GtkTreeView *treeview_contact;

enum 
{
	QUICK_DIAL_INDEX_COL,
    QUICK_DIAL_PHONENUM_COL,
    CONTACT_INDEX_COL = 0,
    FAMILY_NAME_COL,
    GIVEN_NAME_COL
};

on_treeview_quickdial_row_activated(GtkWidget *window, gpointer user_data)
{
	showDebug("Active\n");
}

void on_button_quickdial_dial_clicked(GtkWidget *window, gpointer user_data)
{
	//sync_quickdial_list();
}

void on_button_quickdial_delete_clicked(GtkWidget *window, gpointer user_data)
{
	int index;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;

    if(!get_quickdial_count())
    {
        show_message_window(_("û���κο��ٲ���ѡ��"));
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_quickdial_main));
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window(_("û��ѡ���κ�ѡ��"));
		return;
	}
	
    if(!(show_confirm_window(_("ȷ��ɾ�� ?")) == GTK_RESPONSE_OK))
   		return;
	
    #if 1
	if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	                       QUICK_DIAL_INDEX_COL, &index,
	                       -1);
		
		//delete quickdial by index
		delete_quickdial_by_index(index);
    }
    #endif
	
	//sync quickdial list
    sync_quickdial_list();
}

void on_button_quickdial_cancel_clicked(GtkWidget *window, gpointer user_data)
{
    GtkWindowInfo pwindow_info;
	
	get_window_out_stack(&pwindow_info);
	gtk_widget_destroy(GTK_WIDGET(pwindow_info.window));
}

void on_button_quickdial_edit_clicked(GtkWidget *window, gpointer user_data)
{
    showDebug("edit clicked\n");
	show_quick_dial_edit_window();
}

void on_button_quickdial_edit_add_clicked(GtkWidget *window, gpointer user_data)
{
    //sync_quickdial_list();
    #if 1
	int index;
	int i;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;
	Contact contact;
	Quickdial quickdial;
	char full_name[64];
	
    if(!get_contact_count())
    {
        show_message_window(_("û���κ���ϵ��"));
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_contact));
	
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window(_("û��ѡ���κ�ѡ��"));
		return;
	}

	if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	                       CONTACT_INDEX_COL, &index,
	                       -1);

        if(!get_contact_by_index(&contact, index))
		{
		    sprintf(full_name, "%s%s", contact.name.szfamily_name, contact.name.szgiven_name);
 
			for(i = 0;i < get_quickdial_count(); i++)
			{
			    get_quickdial_by_index(&quickdial,i);
				if(!strcmp(quickdial.contact_name, full_name))
				{
					show_message_window(_("��ǰ��ϵ���Ѵ���"));
					return;
				}
			}
			strcpy(quickdial.contact_name, full_name);
		}
				
		add_quickdial(&quickdial);
		
		//sync quickdial list
        sync_quickdial_list();
    }
	#endif
}

void on_button_quickdial_edit_cancel_clicked(GtkWidget *window, gpointer user_data)
{
	GtkWindowInfo pwindow_info;
	
    get_window_out_stack(&pwindow_info);
	gtk_widget_destroy(GTK_WIDGET(pwindow_info.window));
}

void on_button_quickdial_edit_delete_clicked(GtkWidget *window, gpointer user_data)
{	
	showDebug("delete\n");

	int index;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;

    if(!get_quickdial_count())
    {
        show_message_window(_("û���κο��ٲ���ѡ��"));
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_quickdial));
	
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window(_("û��ѡ���κ�ѡ��"));
		return;
	}
	
    if(!(show_confirm_window(_("ȷ��ɾ�� ?")) == GTK_RESPONSE_OK))
   		return;
	
    #if 1
	if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	                       QUICK_DIAL_INDEX_COL, &index,
	                       -1);
		
		//delete quickdial by index
		delete_quickdial_by_index(index);
    }
    #endif
	
	//sync quickdial list
    sync_quickdial_list();
}

/********************************************************************************
                                                       focus in/out event
********************************************************************************/
void on_button_quickdial_dial_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_quickdial_dial_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_quickdial_edit_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_quickdial_edit_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_quickdial_delete_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_quickdial_delete_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_quickdial_cancel_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_quickdial_cancel_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_quickdial_edit_cancel_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_quickdial_edit_cancel_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_quickdial_edit_delete_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse(BUTTON_FOCUSED_COLOR, &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_quickdial_edit_delete_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse(BUTTON_NORMAL_COLOR, &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

#if 1
/********************************************************************************
                                                      comonphone treeview
********************************************************************************/
GtkListStore* create_quickdial_store(void)
{
	GtkListStore *quickdial_store;
	quickdial_store = gtk_list_store_new(3, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING);
	
	return quickdial_store;
}

GtkTreeModel* fill_quickdial_store(GtkListStore *quickdial_store)
{
    #if 1
    int i;
	
    for(i = 0; i < get_quickdial_count(); i++)
	{
	   Quickdial quickdial;
	   GtkTreeIter iter;
	   memset(&quickdial, 0, sizeof(Quickdial));
       
	   if(!get_quickdial_by_index(&quickdial, i))
	   {
	   	   showDebug("quickdial: %s\n", quickdial.contact_name);
	   }
	   else
			showDebug("Fail\n");
	   
	   gtk_list_store_append(quickdial_store, &iter);
	   gtk_list_store_set(quickdial_store, &iter,
	     	              QUICK_DIAL_INDEX_COL, i,
			              QUICK_DIAL_PHONENUM_COL, _(quickdial.contact_name) == NULL ? 
			                                         quickdial.contact_name : _(quickdial.contact_name),
	   					  -1);
	}
    #endif
	
	return GTK_TREE_MODEL (quickdial_store);
}
#endif

#if 0
/********************************************************************************
                              contact treeview
********************************************************************************/
GtkListStore* create_contact_store(void)
{
    #if 1
	GtkListStore *contact_store;
	contact_store = gtk_list_store_new(3, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING);
	
	return contact_store;
	#endif
}

GtkTreeModel* fill_contact_store(GtkListStore *contact_store)
{
   // get_contact_count();
    int i;
	#if 1
    for(i = 0; i < get_contact_count(); i++)
	{
	   Contact contact;
	   GtkTreeIter iter;
	   memset(&contact, 0, sizeof(Contact));
       get_contact_by_index(&contact, i);
	   
	   #if 1
	   gtk_list_store_append(contact_store, &iter);
	   gtk_list_store_set(contact_store, &iter,
	    	              CONTACT_INDEX_COL, i,
	     	              FAMILY_NAME_COL, _(contact.name.szfamily_name) == NULL ? 
			                                 contact.name.szfamily_name : _(contact.name.szfamily_name),
			              GIVEN_NAME_COL, _(contact.name.szgiven_name),
			              -1);
	   #endif
	}
    #endif
	
	return GTK_TREE_MODEL (contact_store);
}
#endif

/********************************************************************************
                                          set commonphone phonenum to column
********************************************************************************/
void set_quickdial_phonenum(GtkTreeViewColumn *tree_column,
							      GtkCellRenderer   *cell,
							      GtkTreeModel      *model,
							      GtkTreeIter       *iter,
							      gpointer           data)
{
    #if 1
	int index;
	char *contact_name;
	
	gtk_tree_model_get(model, iter,
	                   QUICK_DIAL_PHONENUM_COL, &contact_name,
					   -1);
	
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", _(contact_name),
                 //"text", "elon",
                 NULL);

	g_free(contact_name);
    #endif
}

void set_contact_name (GtkTreeViewColumn *tree_column,
					      GtkCellRenderer   *cell,
					      GtkTreeModel      *model,
					      GtkTreeIter       *iter,
					      gpointer           data)
{
    #if 1
	char *given_name;
	char *family_name;
	char strCombine[64];
	
	gtk_tree_model_get(model, iter,
	                 FAMILY_NAME_COL, &family_name,
	                 GIVEN_NAME_COL, &given_name,
	                 -1);
	
	sprintf(strCombine, "%s%s", family_name, given_name);
	
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", strCombine,
                 NULL);	
	
	g_free(family_name);
	g_free(given_name);
    #endif
}

int sync_quickdial_list()
{
	//sync main quickdial list
	gtk_list_store_clear(quickdial_store);
	gtk_tree_view_set_model(treeview_quickdial_main, fill_quickdial_store(quickdial_store));
	
    //sync quickdial
    gtk_list_store_clear(quickdial_store);
 	gtk_tree_view_set_model(treeview_quickdial, fill_quickdial_store(quickdial_store));
}

int show_quick_dial_edit_window()
{	
	GtkBuilder *builder;
    GtkWidget *window;
	GtkTreeViewColumn *column_contact;
	GtkTreeViewColumn *column_quickdial;
	GtkCellRenderer *cell_renderer;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_quickdial_edit"));
	gtk_window_set_title(GTK_WINDOW(window), "window_quickdial_edit");
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	put_window_into_stack(window);
	
    #if 1
	//add  model to tree view
	quickdial_store = create_quickdial_store();
	contact_store = create_contact_store();
	
	treeview_quickdial = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_quickdial_edit_quickdiallist");
	gtk_tree_view_set_model(treeview_quickdial, fill_quickdial_store(quickdial_store));
	
	treeview_contact = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_quickdial_edit_contactlist");
    gtk_tree_view_set_model(treeview_contact, fill_contact_store(contact_store));
	#if 1
	//column  
	column_contact = gtk_tree_view_column_new();
	column_quickdial = gtk_tree_view_column_new();
    
	// quickdial
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_quickdial,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_quickdial, cell_renderer,
		                              	    set_quickdial_phonenum,
		                              	    NULL, NULL);
	
	//contact
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_contact,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_contact, cell_renderer,
		                              	    set_contact_name,
		                              	    NULL, NULL);
	
	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_quickdial),
					            column_quickdial);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_contact),
					            column_contact);
	#endif
    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();
	
	return 0;
	#endif
}

int show_quick_dial_window()
{
	GtkBuilder *builder;
    GtkWidget *window;
	GtkTreeViewColumn *column_phonenum;
	GtkCellRenderer *cell_renderer;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_quickdial"));
	
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	put_window_into_stack(window);
	
    #if 1
	//add  model to tree view
	quickdial_store = create_quickdial_store();
	
	treeview_quickdial_main = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_quickdial");
	gtk_tree_view_set_model(treeview_quickdial_main, fill_quickdial_store(quickdial_store));
	
	//column  
	column_phonenum = gtk_tree_view_column_new();
    
	// phonenum cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_phonenum,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_phonenum, cell_renderer,
		                              	    set_quickdial_phonenum, 
		                              	    NULL, NULL);
		
	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_quickdial_main),
					            column_phonenum);
	#endif
    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();
	
	return 0;
}

