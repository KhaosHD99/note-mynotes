#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>

#include "phonebookapi.h"
#include "MessageStack.h"
#include "windowstack.h"
#include "LogMsg.hpp"

#define _(STRING) g_convert(STRING, -1, "UTF-8", "GB2312", NULL, NULL, NULL)
#define _to_asc(STRING) g_convert(STRING, -1, "GB2312", "UTF-8", NULL, NULL, NULL)

enum
{
	BLACK_LIST_INDEX_COL,
    BLACK_LIST_CONTACT_NAME_COL,
    CONTACT_INDEX_COL = 0,
    FAMILY_NAME_COL,
    GIVEN_NAME_COL
};

GtkListStore *blacklist_store;
GtkListStore *contact_store;

GtkTreeView *treeview_blacklist_main;
GtkTreeView *treeview_blacklist;
GtkTreeView *treeview_contact;

void on_button_blacklist_dial_clicked(GtkWidget *widget, gpointer user_data)
{
	
}

void on_button_blacklist_edit_clicked(GtkWidget *widget, gpointer user_data)
{
	show_blacklist_edit_window();
}

void on_button_blacklist_delete_clicked(GtkWidget *widget, gpointer user_data)
{
#if 1
	int index;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;

    if(!get_blacklist_count())
    {
        show_message_window(_("û���κο��ٲ���ѡ��"));
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_blacklist_main));
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window(_("û��ѡ���κ�ѡ��"));
		return;
	}
	
    if(!(show_confirm_window(_("ȷ��ɾ�� ?")) == GTK_RESPONSE_OK))
   		return;
	
    if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	                       BLACK_LIST_INDEX_COL, &index,
	                       -1);
		
		//delete quickdial by index
		delete_blacklist_by_index(index);
    }
    
	//sync quickdial list
    sync_blacklist_list();
	#endif
}

void on_button_blacklist_cancel_clicked(GtkWidget *widget, gpointer user_data)
{
    GtkWindowInfo pwindow_info;
	
	get_window_out_stack(&pwindow_info);		
	gtk_widget_destroy(GTK_WIDGET(pwindow_info.window));
}

void on_button_blacklist_edit_add_clicked(GtkWidget *widget, gpointer user_data)
{
	#if 1
	int index;
	int i;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;
	Contact contact;
	Blacklist blacklist;
	char full_name[64];
	
    if(!get_contact_count())
    {
        show_message_window(_("û���κ���ϵ��"));
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_contact));
	
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window(_("û��ѡ���κ�ѡ��"));
		return;
	}

	if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	                       CONTACT_INDEX_COL, &index,
	                       -1);

        if(!get_contact_by_index(&contact, index))
		{
		    sprintf(full_name, "%s%s", contact.name.szfamily_name, contact.name.szgiven_name);
 
			for(i = 0;i < get_blacklist_count(); i++)
			{
			    get_blacklist_by_index(&blacklist,i);
				if(!strcmp(blacklist.contact_name, full_name))
				{
					show_message_window(_("��ǰ��ϵ���Ѵ���"));
					return;
				}
			}
			strcpy(blacklist.contact_name, full_name);
		}
		
		add_blacklist(&blacklist);
		
		//sync blacklist list
        sync_blacklist_list();
    }
	#endif
}

void on_button_blacklist_edit_cancel_clicked(GtkWidget *widget, gpointer user_data)
{
	GtkWindowInfo pwindow_info;
	
    get_window_out_stack(&pwindow_info);
	gtk_widget_destroy(GTK_WIDGET(pwindow_info.window));
}

void on_button_blacklist_edit_delete_clicked(GtkWidget *widget, gpointer user_data)
{
	int index;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;

    if(!get_blacklist_count())
    {
        show_message_window(_("û���κο��ٲ���ѡ��"));
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_blacklist));
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window(_("û��ѡ���κ�ѡ��"));
		return;
	}
	
    if(!(show_confirm_window(_("ȷ��ɾ�� ?")) == GTK_RESPONSE_OK))
   		return;
	
    if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	                       BLACK_LIST_INDEX_COL, &index,
	                       -1);
		
		//delete quickdial by index
		delete_blacklist_by_index(index);
    }
    
	//sync quickdial list
    sync_blacklist_list();
}

/********************************************************************************
                                                       focus in/out event
********************************************************************************/
void on_button_blacklist_dial_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse("#FF0000", &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_blacklist_dial_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse( "#EEEE00", &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_blacklist_add_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse("#FF0000", &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_blacklist_add_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse( "#EEEE00", &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_blacklist_delete_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse("#FF0000", &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_blacklist_delete_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse( "#EEEE00", &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

void on_button_blacklist_cancel_focus_in_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor color;
	gdk_color_parse("#FF0000", &color);
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color);
}

void on_button_blacklist_cancel_focus_out_event(GtkWidget *widget, gpointer user_data)
{
	GdkColor  color;
	gdk_color_parse( "#EEEE00", &color );
	gtk_widget_modify_bg(widget, GTK_STATE_NORMAL, &color );
}

#if 1
/********************************************************************************
                                                      blacklist treeview
********************************************************************************/
GtkListStore* create_blacklist_store(void)
{
	GtkListStore *blacklist_store;
	blacklist_store = gtk_list_store_new(3, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING);
	
	return blacklist_store;
}

GtkTreeModel* fill_blacklist_store(GtkListStore *blacklist_store)
{
    
    int i;
	
    for(i = 0; i < get_blacklist_count(); i++)
	{
	   Blacklist blacklist;
	   GtkTreeIter iter;
	   memset(&blacklist, 0, sizeof(Blacklist));
       
	   if(!get_blacklist_by_index(&blacklist, i))
	   {
	   	   showDebug("blacklist: %s\n", blacklist.contact_name);
	   }
	   else
	   		showDebug("Fail\n");
	   
	   gtk_list_store_append(blacklist_store, &iter);
	   gtk_list_store_set(blacklist_store, &iter,
	     	              BLACK_LIST_INDEX_COL, i,
			              BLACK_LIST_CONTACT_NAME_COL, _(blacklist.contact_name) == NULL ? 
			                                         blacklist.contact_name : _(blacklist.contact_name),
	   					  -1);
	}
	
	return GTK_TREE_MODEL (blacklist_store);
}
#endif


/********************************************************************************
                                          set blacklist contact name to column
********************************************************************************/
void set_blacklist_contact_name(GtkTreeViewColumn *tree_column,
							        GtkCellRenderer   *cell,
							        GtkTreeModel      *model,
							        GtkTreeIter       *iter,
							        gpointer           data)
{
    #if 1
	int index;
	char *contact_name;
	
	gtk_tree_model_get(model, iter,
	                   BLACK_LIST_CONTACT_NAME_COL, &contact_name,
					   -1);
	
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", _(contact_name),
                 NULL);
	
	g_free(contact_name);
    #endif
}

void set_blacklist_contactlist_name (GtkTreeViewColumn *tree_column,
								        GtkCellRenderer   *cell,
								        GtkTreeModel      *model,
								        GtkTreeIter       *iter,
								        gpointer           data)
{
    #if 1
	char *given_name;
	char *family_name;
	char strCombine[64];
	
	gtk_tree_model_get(model, iter,
		               FAMILY_NAME_COL, &family_name,
		               GIVEN_NAME_COL, &given_name,
		               -1);
	
	sprintf(strCombine, "%s%s", family_name, given_name);
	
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", strCombine,
                 NULL);
	
	g_free(family_name);
	g_free(given_name);
    #endif
}

int sync_blacklist_list()
{	
	//sync main quickdial list
	gtk_list_store_clear(blacklist_store);
	gtk_tree_view_set_model(treeview_blacklist_main, fill_blacklist_store(blacklist_store));
	
    //sync quickdial
    gtk_list_store_clear(blacklist_store);
 	gtk_tree_view_set_model(treeview_blacklist, fill_blacklist_store(blacklist_store));
}

int show_blacklist_edit_window()
{	
	#if 1
	GtkBuilder *builder;
    GtkWidget *window;
	GtkTreeViewColumn *column_contact_name;
	GtkTreeViewColumn *column_blacklist;
	GtkCellRenderer *cell_renderer;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_blacklist_edit"));
	gtk_window_set_title(GTK_WINDOW(window), "window_blacklist_edit");
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	put_window_into_stack(window);
	
	//add  model to tree view
	blacklist_store = create_blacklist_store();
	contact_store = create_contact_store();
	
	treeview_blacklist = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_blacklist_edit_blacklist");
	gtk_tree_view_set_model(treeview_blacklist, fill_blacklist_store(blacklist_store));
	
	treeview_contact = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_blacklist_edit_contactlist");
    gtk_tree_view_set_model(treeview_contact, fill_contact_store(contact_store));
	
	//column  
	column_contact_name = gtk_tree_view_column_new();
	column_blacklist = gtk_tree_view_column_new();
    
	// quickdial
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_blacklist,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_blacklist, cell_renderer,
		                              	    set_blacklist_contact_name,
		                              	    NULL, NULL);
	
	//contact
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_contact_name,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_contact_name, cell_renderer,
		                              	    set_blacklist_contactlist_name,
		                              	    NULL, NULL);
	
	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_blacklist),
					            column_blacklist);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_contact),
					            column_contact_name);
    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();
	
	return 0;
	#endif
}

int show_blacklist_window()
{	
	#if 1
	GtkBuilder *builder;
    GtkWidget *window;
	GtkTreeViewColumn *column_contact_name;
	GtkCellRenderer *cell_renderer;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_blacklist"));
	
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	put_window_into_stack(window);
	
	//add  model to tree view
	blacklist_store = create_blacklist_store();
	
	treeview_blacklist_main = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_blacklist");
	gtk_tree_view_set_model(treeview_blacklist_main, fill_blacklist_store(blacklist_store));
	
	//column  
	column_contact_name = gtk_tree_view_column_new();
    
	// phonenum cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_contact_name,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_contact_name, cell_renderer,
		                              	    set_blacklist_contact_name, 
		                              	    NULL, NULL);
	
	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_blacklist_main),
					            column_contact_name);
	
    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();
	#endif
	return 0;
}

