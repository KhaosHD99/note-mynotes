#ifndef QUICK_DIAL_DEF
#define QUICK_DIAL_DEF

#include "lpconfig.h"
#include <pthread.h>
#include "phonebookinfo.h"

class CQuickdialManager
{		
	private:
		LpConfig *quickdial_lpconfig;
		pthread_mutex_t mutex;
		static CQuickdialManager *quickdial_instance;
		Quickdial **quickdial_buf;
		int buf_count;
		
	private:
		CQuickdialManager();
		~CQuickdialManager();
		void init();
		void uninit();
		Quickdial* get_section_from_config_file(int index);
		int write_quickdial_item(Quickdial *item, int index);
		int sync_quickdial_config();
		
        //mutex
		int init_mutex();
		void lock_mutex();
		void unlock_mutex();
	public:
		static CQuickdialManager *get_instance();
		
		int load_quickdial_from_file();
		int get_quickdial_count();
		int get_quickdial_by_index(Quickdial *quickdial, int index);

		int add_quickdial(Quickdial *quickdial);
			
		int delete_quickdial_by_index(int index);
	    //const char *get_value_from_key(const char *key);
};
#endif
