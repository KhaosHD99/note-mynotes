#ifndef BLACK_LIST_DEF
#define BLACK_LIST_DEF
#include "lpconfig.h"
#include <pthread.h>
#include "phonebookinfo.h"

class CBlacklistManager
{		
	private:
		LpConfig *blacklist_lpconfig;
		pthread_mutex_t mutex;
		static CBlacklistManager *blacklist_instance;
		Blacklist **blacklist_buf;
		int buf_count;
		
	private:
		CBlacklistManager();
		~CBlacklistManager();
		void init();
		void uninit();
		Blacklist* get_section_from_config_file(int index);
		int write_blacklist_item(Blacklist *item, int index);
		int sync_blacklist_config();
		
        //mutex
		int init_mutex();
		void lock_mutex();
		void unlock_mutex();
	public:
		static CBlacklistManager *get_instance();
		
		int load_blacklist_from_file();
		int get_blacklist_count();
		int get_blacklist_by_index(Blacklist *blacklist, int index);

		int add_blacklist(Blacklist *blacklist);
			
		int delete_blacklist_by_index(int index);
	    //const char *get_value_from_key(const char *key);
};
#endif

