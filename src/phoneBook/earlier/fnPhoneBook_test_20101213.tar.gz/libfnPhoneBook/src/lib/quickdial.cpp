#include <stdio.h>
#include <string.h>
#include "iostream"
#include <stdlib.h>

#include "LogMsg.hpp"
#include "quickdial.hpp"

/********************************************************************************
                                                      constructor
********************************************************************************/
CQuickdialManager::CQuickdialManager()
{
    init();
}

/********************************************************************************
                                                      destructor
********************************************************************************/
CQuickdialManager::~CQuickdialManager()
{
	uninit();
}

/********************************************************************************
                                                        initialization
********************************************************************************/
void CQuickdialManager::init()
{	
	//init contact buffer and lpconfig
	quickdial_buf = new Quickdial*[MAX_QUICK_DIAL_COUNT];
    
	quickdial_lpconfig = lp_config_new(QUICK_DIAL_FILE_PATH); 
	if(!quickdial_lpconfig)
	{
		showError("contact lpconfig init fail\n");
		return;
	}
    
	for(int i = 0; i < MAX_QUICK_DIAL_COUNT; i++)
		quickdial_buf[i] = NULL;
    
	//init lock
	int ret = init_mutex();
	if(ret != 0)
		return;
			
	//init contact buffer
	load_quickdial_from_file();
}

/********************************************************************************
                                                           uninitialization
********************************************************************************/
void CQuickdialManager::uninit()
{
	lp_config_destroy(quickdial_lpconfig);
}

/********************************************************************************
                                                         get instance
********************************************************************************/
CQuickdialManager* CQuickdialManager::quickdial_instance = NULL;
CQuickdialManager *CQuickdialManager::get_instance()
{	
	if(!quickdial_instance)
			quickdial_instance  = new CQuickdialManager;
		
	return quickdial_instance;
}	
	
/**********************************************************************************************************/
/************************************************* inner function  ********************************************/
/**********************************************************************************************************/

/**********************************************************************************************************/
/****************************************    mutex    *****************************************************/
/**********************************************************************************************************/

/********************************************************************************
                                                     initial lock mutex
********************************************************************************/
int CQuickdialManager::init_mutex()
{
	return pthread_mutex_init(&mutex, NULL);
}

/********************************************************************************
                                                           lock mutex
********************************************************************************/
void CQuickdialManager::lock_mutex()
{
	pthread_mutex_lock(&mutex);
}

/********************************************************************************
 					              unlock mutex
********************************************************************************/
void CQuickdialManager::unlock_mutex()
{
	pthread_mutex_unlock(&mutex);
}

/********************************************************************************
                                     get section item from file by index
********************************************************************************/
Quickdial* CQuickdialManager::get_section_from_config_file(int index)
{	
	Quickdial *quickdial;
	const char *tmp;
	char section_index[64];
	
	sprintf(section_index, "%s%i", QUICK_DIAL_INDEX_PREFIX, index);
	
	if (!lp_config_has_section(quickdial_lpconfig, section_index))
		return NULL;
	
	quickdial = new Quickdial;
	memset(quickdial, 0, sizeof(Quickdial));
	
	//name, group
	tmp = lp_config_get_string(quickdial_lpconfig, section_index, QUICK_DIAL_CONTACT, NULL);
	if(tmp != NULL)
		strcpy(quickdial->contact_name, tmp);
	
	return quickdial;
}

/********************************************************************************
                          write quickdial item to config file by index without sync
********************************************************************************/
int CQuickdialManager::write_quickdial_item(Quickdial *item, int index)
{
	char section[64];
	char *tmp;
	
	sprintf(section,"%s%i", QUICK_DIAL_INDEX_PREFIX, index);
	
	//phonenum
	lp_config_set_string(quickdial_lpconfig, section, QUICK_DIAL_CONTACT, item->contact_name);
	
	return 0;
}

/********************************************************************************
                                                    synchronization
********************************************************************************/
int CQuickdialManager::sync_quickdial_config()
{ 
	int writeindex = 0;
	char section[32];
	
	if(quickdial_lpconfig == NULL)
	{
		showError("contact_lpconfig is null\n");
		return -1;
	}
	
	if(quickdial_buf == NULL)
	{
		return -1;
	}
	
	//clear
	for(int i = 0; i < MAX_QUICK_DIAL_COUNT; i++)
	{
	    sprintf(section, "%s%i", QUICK_DIAL_INDEX_PREFIX, i);
	    if(lp_config_has_section(quickdial_lpconfig, section))
	    	lp_config_clean_section(quickdial_lpconfig, section);
	}
	
	//write item
	for(int i = 0; i < buf_count; i++)
		write_quickdial_item(quickdial_buf[i], i);
    
	return lp_config_sync(quickdial_lpconfig);
}


int CQuickdialManager::load_quickdial_from_file()
{
	if(quickdial_lpconfig == NULL)
		return -1;
			
	Quickdial* quickdial;

	//lock
	lock_mutex();

	buf_count = 0;
	for (int i=0; (quickdial = get_section_from_config_file(i)) != NULL; i++)
	{
	    quickdial_buf[i] = quickdial;
	    buf_count++;
	}
	
	//showDebug("Commonphone Buf Count: %d\n", buf_count);
	
	//unlock
	unlock_mutex();
}

/********************************************************************************
                                get commonphone count  from inner  variable buf_count
********************************************************************************/
int CQuickdialManager::get_quickdial_count()
{	
	return buf_count;
}

/********************************************************************************
                                                get commonphone by index
********************************************************************************/
int CQuickdialManager::get_quickdial_by_index(Quickdial *quickdial, int index)
{
	//validate
	if(buf_count == 0)
		return -1;

	if(index >= buf_count)
		return -1;
		
	if(!quickdial)
		return -1;

	//lock
	lock_mutex();

    //showDebug("buf: %s\n", commonphone_buf[index]->phonenum);
	//copy
	memcpy(quickdial, quickdial_buf[index], sizeof(Quickdial));

	//unlock
	unlock_mutex();
	
	return 0;
}

/********************************************************************************
                           add quickdial item to buffer
********************************************************************************/
int CQuickdialManager::add_quickdial(Quickdial *quickdial)
{
	//validate
	if(!quickdial)
		return -1;
			
	int section_index;
	quickdial_buf[buf_count] = new Quickdial;
	
	//lock
	lock_mutex();

	//copy
	memcpy(quickdial_buf[buf_count], quickdial, sizeof(Quickdial));

	//sync
	buf_count++;
	sync_quickdial_config();

	//unlock
	unlock_mutex();

	return 0;
}

/********************************************************************************
                                                   delete quickdial by index
********************************************************************************/
int CQuickdialManager::delete_quickdial_by_index(int index)
{
	//validate
	int section_index;
	
	if(buf_count == 0)
		return -1;
	
	if(buf_count <= index)
		return -1;
	
	//lock
	lock_mutex();
	
    for(int i = index; i < buf_count - 1; i++)
    {
        memset(quickdial_buf[i], 0, sizeof(Quickdial));
    	memcpy(quickdial_buf[i], quickdial_buf[i+1], sizeof(Quickdial));
	}

	delete(quickdial_buf[buf_count - 1]);
	quickdial_buf[buf_count - 1] = NULL;
	
	//sync
	buf_count--;
	sync_quickdial_config();

	//unlock
	unlock_mutex();

	return 0;
}

