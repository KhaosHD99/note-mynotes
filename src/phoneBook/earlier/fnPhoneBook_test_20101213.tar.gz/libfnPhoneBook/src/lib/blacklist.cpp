#include <stdio.h>
#include <string.h>
#include "iostream"
#include <stdlib.h>

#include "LogMsg.hpp"
#include "blacklist.hpp"

/********************************************************************************
                                                      constructor
********************************************************************************/
CBlacklistManager::CBlacklistManager()
{
    init();
}

/********************************************************************************
                                                      destructor
********************************************************************************/
CBlacklistManager::~CBlacklistManager()
{
	uninit();
}

/********************************************************************************
                                                        initialization
********************************************************************************/
void CBlacklistManager::init()
{	
	//init contact buffer and lpconfig
	blacklist_buf = new Blacklist*[MAX_BLACK_LIST_COUNT];
    
	blacklist_lpconfig = lp_config_new(BLACK_LIST_FILE_PATH); 
	if(!blacklist_lpconfig)
	{
		showError("blacklist lpconfig init fail\n");
		return;
	}
    
	for(int i = 0; i < MAX_BLACK_LIST_COUNT; i++)
		blacklist_buf[i] = NULL;
    
	//init lock
	int ret = init_mutex();
	if(ret != 0)
		return;
			
	//init blacklist buffer
	load_blacklist_from_file();
}

/********************************************************************************
                                                           uninitialization
********************************************************************************/
void CBlacklistManager::uninit()
{
	lp_config_destroy(blacklist_lpconfig);
}

/********************************************************************************
                                                         get instance
********************************************************************************/
CBlacklistManager* CBlacklistManager::blacklist_instance = NULL;
CBlacklistManager *CBlacklistManager::get_instance()
{	
	if(!blacklist_instance )
			blacklist_instance  = new CBlacklistManager;
		
	return blacklist_instance ;
}	
	
/**********************************************************************************************************/
/************************************************* inner function  ********************************************/
/**********************************************************************************************************/

/**********************************************************************************************************/
/****************************************    mutex    *****************************************************/
/**********************************************************************************************************/

/********************************************************************************
                                                     initial lock mutex
********************************************************************************/
int CBlacklistManager::init_mutex()
{
	return pthread_mutex_init(&mutex, NULL);
}

/********************************************************************************
                                                           lock mutex
********************************************************************************/
void CBlacklistManager::lock_mutex()
{
	pthread_mutex_lock(&mutex);
}

/********************************************************************************
 					              unlock mutex
********************************************************************************/
void CBlacklistManager::unlock_mutex()
{
	pthread_mutex_unlock(&mutex);
}

/********************************************************************************
                                     get section item from file by index
********************************************************************************/
Blacklist* CBlacklistManager::get_section_from_config_file(int index)
{	
	Blacklist *blacklist;
	const char *tmp;
	char section_index[64];
	
	sprintf(section_index, "%s%i", BLACK_LIST_INDEX_PREFIX, index);
	
	if (!lp_config_has_section(blacklist_lpconfig, section_index))
		return NULL;
	
	blacklist = new Blacklist;
	memset(blacklist, 0, sizeof(Blacklist));
	
	//name, group
	tmp = lp_config_get_string(blacklist_lpconfig, section_index, BLACK_LIST_CONTACT, NULL);
	if(tmp != NULL)
		strcpy(blacklist->contact_name, tmp);
	
	return blacklist;
}

/********************************************************************************
                          write blacklist item to config file by index without sync
********************************************************************************/
int CBlacklistManager::write_blacklist_item(Blacklist *item, int index)
{
	char section[64];
	char *tmp;
	
	sprintf(section,"%s%i", BLACK_LIST_INDEX_PREFIX, index);
	
	//phonenum
	lp_config_set_string(blacklist_lpconfig, section, BLACK_LIST_CONTACT, item->contact_name);
	
	return 0;
}

/********************************************************************************
                                                    synchronization
********************************************************************************/
int CBlacklistManager::sync_blacklist_config()
{ 
	int writeindex = 0;
	char section[32];
	
	if(blacklist_lpconfig == NULL)
	{
		showError("contact_lpconfig is null\n");
		return -1;
	}
	
	if(blacklist_buf == NULL)
	{
		return -1;
	}
	
	//clear
	for(int i = 0; i < MAX_BLACK_LIST_COUNT; i++)
	{
	    sprintf(section, "%s%i", BLACK_LIST_INDEX_PREFIX, i);
	    if(lp_config_has_section(blacklist_lpconfig, section))
	    	lp_config_clean_section(blacklist_lpconfig, section);
	}
	
	//write item
	for(int i = 0; i < buf_count; i++)
		write_blacklist_item(blacklist_buf[i], i);
    
	return lp_config_sync(blacklist_lpconfig);
}


int CBlacklistManager::load_blacklist_from_file()
{
	if(blacklist_lpconfig == NULL)
		return -1;
			
	Blacklist* blacklist;

	//lock
	lock_mutex();

	buf_count = 0;
	for (int i=0; (blacklist = get_section_from_config_file(i)) != NULL; i++)
	{
	    blacklist_buf[i] = blacklist;
	    buf_count++;
	}
	
	//showDebug("Commonphone Buf Count: %d\n", buf_count);
	
	//unlock
	unlock_mutex();
}

/********************************************************************************
                                get blacklist count  from inner  variable buf_count
********************************************************************************/
int CBlacklistManager::get_blacklist_count()
{	
	return buf_count;
}

/********************************************************************************
                                                get blacklist by index
********************************************************************************/
int CBlacklistManager::get_blacklist_by_index(Blacklist *blacklist, int index)
{
	//validate
	if(buf_count == 0)
		return -1;

	if(index >= buf_count)
		return -1;
		
	if(!blacklist)
		return -1;

	//lock
	lock_mutex();

    //showDebug("buf: %s\n", commonphone_buf[index]->phonenum);
	//copy
	memcpy(blacklist, blacklist_buf[index], sizeof(Blacklist));

	//unlock
	unlock_mutex();
	
	return 0;
}

/********************************************************************************
                                                   add blacklist item to buffer
********************************************************************************/
int CBlacklistManager::add_blacklist(Blacklist *blacklist)
{
	//validate
	if(!blacklist)
		return -1;
			
	int section_index;
	blacklist_buf[buf_count] = new Blacklist;
	
	//lock
	lock_mutex();

	//copy
	memcpy(blacklist_buf[buf_count], blacklist, sizeof(Blacklist));

	//sync
	buf_count++;
	sync_blacklist_config();

	//unlock
	unlock_mutex();

	return 0;
}

/********************************************************************************
                                                   delete blacklist by index
********************************************************************************/
int CBlacklistManager::delete_blacklist_by_index(int index)
{
	//validate
	int section_index;
	
	if(buf_count == 0)
		return -1;
	
	if(buf_count <= index)
		return -1;
	
	//lock
	lock_mutex();
	
    for(int i = index; i < buf_count - 1; i++)
    {
        memset(blacklist_buf[i], 0, sizeof(Blacklist));
    	memcpy(blacklist_buf[i], blacklist_buf[i+1], sizeof(Blacklist));
	}

	delete(blacklist_buf[buf_count - 1]);
	blacklist_buf[buf_count - 1] = NULL;
	
	//sync
	buf_count--;
	sync_blacklist_config();

	//unlock
	unlock_mutex();

	return 0;
}

