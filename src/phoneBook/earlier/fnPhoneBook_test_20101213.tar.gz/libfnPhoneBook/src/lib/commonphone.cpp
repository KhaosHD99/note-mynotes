#include <stdio.h>
#include <string.h>
#include "iostream"
#include <stdlib.h>

#include "LogMsg.hpp"
#include "commonphone.hpp"

/********************************************************************************
                                                      constructor
********************************************************************************/
CCommonphoneManager::CCommonphoneManager()
{
    init();
}

/********************************************************************************
                                                      destructor
********************************************************************************/
CCommonphoneManager::~CCommonphoneManager()
{
	uninit();
}

/********************************************************************************
                                                        initialization
********************************************************************************/
void CCommonphoneManager::init()
{
	//init contact buffer and lpconfig
	commonphone_buf = new Commonphone*[MAX_COMMON_PHONE_COUNT];
    
	commonphone_lpconfig = lp_config_new(COMMON_PHONE_FILE_PATH); 
	if(!commonphone_lpconfig)
	{
		showError("contact lpconfig init fail\n");
		return;
	}
    
	for(int i = 0; i < MAX_COMMON_PHONE_COUNT; i++)
		commonphone_buf[i] = NULL;
    
    
	//init lock
	int ret = init_mutex();
	if(ret != 0)
		return;
			
	//init contact buffer
	load_commonphone_from_file();
}

/********************************************************************************
                                                           uninitialization
********************************************************************************/
void CCommonphoneManager::uninit()
{
	lp_config_destroy(commonphone_lpconfig);
}

/********************************************************************************
                                                         get instance
********************************************************************************/
CCommonphoneManager* CCommonphoneManager::commonphone_instance = NULL;
CCommonphoneManager *CCommonphoneManager::get_instance()
{
	if(!commonphone_instance )
			commonphone_instance  = new CCommonphoneManager;
	
	return commonphone_instance ;
}

/**********************************************************************************************************/
/************************************************* inner function  ********************************************/
/**********************************************************************************************************/

/**********************************************************************************************************/
/****************************************    mutex    *****************************************************/
/**********************************************************************************************************/

/********************************************************************************
                                                     initial lock mutex
********************************************************************************/
int CCommonphoneManager::init_mutex()
{
	return pthread_mutex_init(&mutex, NULL);
}

/********************************************************************************
                                                           lock mutex
********************************************************************************/
void CCommonphoneManager::lock_mutex()
{
	pthread_mutex_lock(&mutex);
}

/********************************************************************************
 					              unlock mutex
********************************************************************************/
void CCommonphoneManager::unlock_mutex()
{
	pthread_mutex_unlock(&mutex);
}

#if 0
/********************************************************************************
                                     get section item from file by index
********************************************************************************/
const char* CConfigManager::get_value_from_key(const char *key)
{
	const char *tmp;
	char *tmpcpy;
	char section[64];
	char *part_str;
	const char * split = ":";
	
	sprintf(section, "%s", CONFIG_DISPLAY_SECTION);
	
	if (!lp_config_has_section(config_lpconfig, section))
	{
		printf("has not section\n");
		return NULL;
	}
	//name, group
	tmp = lp_config_get_string(config_lpconfig, section, key, NULL);
	//if(tmp != NULL)
	//strcpy(contact->name.szfamily_name, tmp);
	//	printf("confirm: %s\n", tmp);
//	else
	//	printf("tmp is null\n");
    
	return tmp;
}
#endif

/********************************************************************************
                                     get section item from file by index
********************************************************************************/
Commonphone* CCommonphoneManager::get_section_from_config_file(int index)
{	
	Commonphone *commonphone;
	const char *tmp;
	char section_index[64];
	
	sprintf(section_index, "%s%i", COMMON_PHONE_INDEX_PREFIX, index);
	
	if (!lp_config_has_section(commonphone_lpconfig, section_index))
		return NULL;
	
	commonphone = new Commonphone;
	memset(commonphone, 0, sizeof(Commonphone));
	
	//name, group
	tmp = lp_config_get_string(commonphone_lpconfig, section_index, COMMON_PHONE_PHONENUM, NULL);
	if(tmp != NULL)
	strcpy(commonphone->phonenum, tmp);
	
	tmp = lp_config_get_string(commonphone_lpconfig, section_index, COMMON_PHONE_DESC, NULL);
	if(tmp != NULL)
	strcpy(commonphone->desc, tmp);
	
	return commonphone;
}

int CCommonphoneManager::load_commonphone_from_file()
{
	if(commonphone_lpconfig == NULL)
		return -1;
			
	Commonphone* commonphone;

	//lock
	lock_mutex();

	buf_count = 0;
	for (int i=0; (commonphone = get_section_from_config_file(i)) != NULL; i++)
	{
	    commonphone_buf[i] = commonphone;
	    buf_count++;
	}
	
	//unlock
	unlock_mutex();
}

/********************************************************************************
                                get commonphone count  from inner  variable buf_count
********************************************************************************/
int CCommonphoneManager::get_commonphone_count()
{	
	return buf_count;
}

/********************************************************************************
                                                get commonphone by index
********************************************************************************/
int CCommonphoneManager::get_commonphone_by_index(Commonphone *commonphone, int index)
{
	//validate
	if(buf_count == 0)
		return -1;

	if(index >= buf_count)
		return -1;
		
	if(!commonphone)
		return -1;

	//lock
	lock_mutex();

    //showDebug("buf: %s\n", commonphone_buf[index]->phonenum);
	//copy
	memcpy(commonphone, commonphone_buf[index], sizeof(Commonphone));

	//unlock
	unlock_mutex();
	
	return 0;
}

