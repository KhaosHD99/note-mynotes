#ifndef CALLLOG_DEF
#define CALLLOG_DEF

#include "lpconfig.h"
#include<pthread.h>

#define MAX_PHONENUM_LEN	64
#define MAX_REMOTE_LEN	    64	   
#define MAX_CALLLOG_COUNT   100    
#define MAX_DATE_YEAR_LEN   5     
#define MAX_DATE_LEN        3     

#define CL_NON_str          "NULL"
#define CL_MISSED_str       "missed"
#define CL_RECEIVED_str     "received"
#define CL_DIALED_str       "dialed"

#define CALLLOG_FILE_PATH      "CallLog.cfg"
#define CLOG_CALLLOG_INDEX     "calllog_"
#define CLOG_INDEX             "index"
#define CLOG_STATUS            "status"
#define CLOG_MISSED_INDEX      "missed_index"
#define CLOG_RECEIVED_INDEX    "received_index"
#define CLOG_DIALED_INDEX      "dialed_index"
#define CLOG_REMOTE_FROM       "from"
#define CLOG_REMOTE_TO         "to"
#define CLOG_START_DATE        "start_date"
#define CLOG_DURATION          "duration"

typedef enum CLSTATUS
{
	CL_NON,
	CL_MISSED,              
	CL_RECEIVED,            
	CL_DIALED               
}CLSTATUS;

//ʱ¼唫ʱ³¤
typedef struct stCLDate
{
	char year[MAX_DATE_YEAR_LEN];
	char month[MAX_DATE_LEN];
	char day[MAX_DATE_LEN];
	char hour[MAX_DATE_LEN];
	char minute[MAX_DATE_LEN];       
	char second[MAX_DATE_LEN];       
	int duration;
}CLDate;

//ɕ־хϢ
typedef struct stCallLog
{
		CLSTATUS status;
		int status_index;
		char szremote[MAX_REMOTE_LEN];
		CLDate date;
}CallLog;

typedef struct CallLog_Info
{	
		int count;
		CLSTATUS status;
		CallLog **calllog_buf;
}CallLog_Info;

class CCalllogManager
{
		private:
				LpConfig *calllog_lpconfig;
				pthread_mutex_t mutex;
				CallLog_Info calllog_missed, calllog_received, calllog_dialed;
				static CCalllogManager *calllog_instance;
		
		private:
				CCalllogManager();
				~CCalllogManager();
				void init();	
				void init_log(CallLog_Info *calllog_info);
				void uninit();
				void uninit_log(CallLog_Info *calllog_info);
			
				//inner function
				CallLog* get_section_from_config_file(int index);
		    int write_calllog_item(CallLog *item, int index, int status_index);
				int sync_calllog_config();
					
				//mutex
				int init_mutex();
				void lock_mutex();
				void unlock_mutex();
			
		public:
				static CCalllogManager *get_instance();
				
				//User API
				int load_calllog_from_file();
				int get_calllog_count();
		    int get_calllog_count_by_type(CLSTATUS status);	 
	      int get_calllog_by_index(CallLog *calllog, int index, CLSTATUS status); 
	      
				int add_calllog(CLSTATUS status, CallLog *calllog);
				
	      int delete_calllog_by_index(int index, CLSTATUS status);
	      int delete_calllog_by_status(CLSTATUS status);
				
				//sort
				int sort_by_date();
				int get_date_int(char *datetime);
				int get_time_int(char *datetime);
	
	      //enum
				CLSTATUS __clstatus_str_to_enum(const char *enum_str);
				const char* __clstatus_enum_to_str(int enum_val);
};
#endif