#ifndef PHONEBOOKINFO_DEF
#define PHONEBOOKINFO_DEF

#define GLADE_FILE_PATH             "data/phonebook.glade"
                                    //"/home/data/appfile/fnPhonebook/phonebook.glade"
#define CONTACT_FILE_PATH           "data/Contact.cfg"
								    //"/home/data/appfile/fnPhonebook/Contacts.cfg"
#define CALLLOG_FILE_PATH           "data/Calllog.cfg"
								    //"/home/data/appfile/fnPhonebook/CallLog.cfg"
#define QUICK_DIAL_FILE_PATH        "data/Quickdial.cfg"    
									//"/home/data/appfile/fnPhonebook/Quickdial.cfg"

#define BLACK_LIST_FILE_PATH        "data/Blacklist.cfg"
									//"/home/data/appfile/fnPhonebook/Blacklist.cfg"
									
#define COMMON_PHONE_FILE_PATH      "data/Common.cfg"
									//"/home/data/appfile/fnPhonebook/Commonphone.cfg"

#define CONFIG_FILE_PATH            "data/Config.cfg"
								    //"/home/data/appfile/fnPhonebook/Config.cfg"
                                  
#define IMAGE_FILE_PATH             "img/"
								    //"/home/data/appfile/skin/"

//img name
#define IMG_MAIN_MENU_ITEM            "pb_main_button_normal_image.jpg"
#define IMG_MAIN_MENU_ITEM_FOCUSED    "pb_main_button_active_image.jpg"
#define IMG_MAIN_BG                   "pc_main_bg_imag.jpg"


//contact
#define MAX_CONTACT_COUNT	1000
#define MAX_NAME_LEN		32
#define MAX_PHONE_COUNT		10
#define MAX_PHONENUM_LEN	64
#define MAX_EMAIL_COUNT		10
#define MAX_EMAIL_LEN		64
#define MAX_AVATAR_LEN		128
#define MAX_VOIP_LEN		64
#define MAX_IM_LEN			64
#define MAX_ADDRESS_LEN		128

#define CONTACT_INDEX_PREFIX      "contact_"
#define PHONE_INDEX_PREFIX        "phone_"
#define EMAIL_INDEX_PREFIX        "email_"
#define CONTACT_FAMILY_NAME       "family_name"
#define CONTACT_GIVEN_NAME        "given_name"
#define CONTACT_GROUP             "group"
#define CONTACT_PHONE_COUNT       "phonecount"
#define CONTACT_EMAIL_COUNT       "emailcount"
#define CONTACT_AVATAR            "avatar"
#define CONTACT_VOIP           	  "voip"
#define CONTACT_IM                "im"
#define CONTACT_ADDRESS           "address"

//enum str
#define GT_FAMILY_STR          "GT_FAMILY"
#define GT_RELATIVES_STR       "GT_RELATIVES"
#define GT_COLLEAGUES_STR      "GT_COLLEAGUES"
#define GT_FRIENDS_STR         "GT_FRIENDS"
#define GT_MANUFACTURERS_STR   "GT_MANUFACTURERS"
#define GT_OTHER_STR           "GT_OTHER"
#define GT_CUSTOM_STR          "GT_CUSTOM"

#define PT_HOME_STR            "PT_HOME"
#define PT_MOBILE_STR          "PT_MOBILE"
#define PT_WORK_STR            "PT_WORK"
#define PT_WORK_FAX_STR        "PT_WORK_FAX"
#define PT_HOME_FAX_STR        "PT_HOME_FAX"
#define PT_OTHER_STR           "PT_OTHER"
#define PT_CUSTOM_STR          "PT_CUSTOM"

#define EMT_HOME_STR           "EMT_HOME"
#define EMT_WORK_STR           "EMT_WORK"
#define EMT_OTHER_STR          "EMT_OTHER"
#define EMT_CUSTOM_STR         "EMT_CUSTOM"

//calllog
#define MAX_PHONENUM_LEN	64
#define MAX_REMOTE_LEN	    64	   
#define MAX_CALLLOG_COUNT   100
#define MAX_DATE_YEAR_LEN   5     
#define MAX_DATE_LEN        3     

#define CL_NON_str          "NULL"
#define CL_MISSED_str       "missed"
#define CL_RECEIVED_str     "received"
#define CL_DIALED_str       "dialed"

#define DISPLAY_MISSED                    "δ��"
#define DISPLAY_RECEIVED                  "�ѽ�"
#define DISPLAY_DIALED                    "����"
#define DISPLAY_CONTACT                   "��ϵ��"
#define DISPLAY_RECEIVED_FROM             "����"
#define DISPLAY_DIALED_TO                 "����"
#define DISPLAY_DATETIME                  "����"
#define DISPLAY_GROUPTYPE_FAMILY          "��ͥ"	
#define DISPLAY_GROUPTYPE_RELATIVES       "����"
#define DISPLAY_GROUPTYPE_COLLEAGUES      "ͬ��"
#define DISPLAY_GROUPTYPE_FRIENDS         "����"
#define DISPLAY_GROUPTYPE_OTHER           "����"

#define CLOG_CALLLOG_INDEX                "calllog_"
#define CLOG_INDEX                        "index"
#define CLOG_STATUS                       "status"
#define CLOG_MISSED_INDEX                 "missed_index"
#define CLOG_RECEIVED_INDEX               "received_index"
#define CLOG_DIALED_INDEX                 "dialed_index"
#define CLOG_REMOTE_FROM                  "from"
#define CLOG_REMOTE_TO                    "to"
#define CLOG_START_DATE                   "start_date"
#define CLOG_DURATION                     "duration"

//config
#define CONFIG_DISPLAY_SECTION            "display"
#define DISPLAY_DELETE_CONFIRM            "delete_confirm"
#define DISPLAY_NO_SELECT                 "no_select"
#define DISPLAY_NO_CONTACT                "no_contact"
#define DISPLAY_CAN_NOT_EMPTY             "can_not_empty"
#define DISPLAY_UNFINISHED_INPUT          "unfinished_input"
#define DISPLAY_EXCEED_LIMIT              "exceed_limit"
#define DISPLAY_NAME_EXISTED              "name_existed"
#define DISPLAY_SAVE_SUCCESSFULLY         "save_successfully"
#define DISPLAY_SAVE_FAIL                 "save_fail"
#define DISPLAY_RESET_CONFIRM             "reset_confirm"

//quickdial
#define MAX_QUICK_DIAL_COUNT            100

#define QUICK_DIAL_INDEX_PREFIX         "quickdial_"
#define QUICK_DIAL_CONTACT              "contact"

//blacklist
#define MAX_BLACK_LIST_COUNT            20

#define BLACK_LIST_INDEX_PREFIX         "blacklist_"
#define BLACK_LIST_CONTACT              "contact"

//commonphone
#define MAX_COMMON_PHONE_COUNT            100

#define COMMON_PHONE_INDEX_PREFIX         "commonphone_"
#define COMMON_PHONE_PHONENUM             "phonenum"
#define COMMON_PHONE_DESC                 "desc"

//skin
#define BUTTON_NORMAL_COLOR               "#EEEE00"
#define BUTTON_FOCUSED_COLOR              "#FF0000"
#define BUTTON_ACTIVE_COLOR               "#"

//contact               
typedef enum PhoneType
{
    PT_NONE,
	PT_HOME,					//家庭
	PT_MOBILE,					//移动
	PT_WORK,					//单位
	PT_WORK_FAX,				//单位传真
	PT_HOME_FAX,				//住宅传真
	PT_OTHER,					//其他
	PT_CUSTOM					//自定义
}PhoneType;

typedef enum EMailType
{
	EMT_NONE,                   
	EMT_HOME,					//家庭
	EMT_WORK,					//单位
	EMT_OTHER,					//其他
	EMT_CUSTOM					//自定义
}EMailType;

typedef enum GroupType
{
    GT_NONE,
	GT_FAMILY,					//家庭
	GT_RELATIVES,				//亲朋
	GT_COLLEAGUES,				//同事
	GT_FRIENDS,					//朋友
	GT_MANUFACTURERS,			//厂商
	GT_OTHER,					//其他
	GT_CUSTOM					//自定义
}GroupType;

typedef enum ContactDetailMode
{
    EDIT,                   			
	ADD	
}ContactDetailMode;


typedef struct stName
{
	char szgiven_name[MAX_NAME_LEN];	//名
	char szfamily_name[MAX_NAME_LEN];	//姓
}Name;

typedef struct stPhone
{
	PhoneType type;
	char szphone[MAX_PHONENUM_LEN];
}Phone;

typedef struct stEmail
{
	EMailType type;
	char szemail[MAX_EMAIL_LEN];
}Email;

typedef struct stContact
{
	Name name;
	GroupType type;
	int phone_count;
	int email_count;
	Phone phones[MAX_PHONE_COUNT];
	Email emails[MAX_EMAIL_COUNT];
	char szvoip[MAX_VOIP_LEN];
	char szim[MAX_IM_LEN];
	char szaddress[MAX_ADDRESS_LEN];
}Contact;

//calllog
typedef enum CLSTATUS
{
	CL_NON,
	CL_MISSED,              
	CL_RECEIVED,            
	CL_DIALED               
}CLSTATUS;

typedef struct stCLDate
{
	char year[MAX_DATE_YEAR_LEN];
	char month[MAX_DATE_LEN];
	char day[MAX_DATE_LEN];
	char hour[MAX_DATE_LEN];
	char minute[MAX_DATE_LEN];       
	char second[MAX_DATE_LEN];       
	int duration;
}CLDate;

typedef struct stCallLog
{
	CLSTATUS status;
	int status_index;
	char szremote[MAX_REMOTE_LEN];
	CLDate date;
}CallLog;

typedef struct CallLog_Info
{	
	int count;
	CLSTATUS status;
	CallLog **calllog_buf;
}CallLog_Info;

//quickdial
typedef struct stQuickdial
{
	char contact_name[MAX_NAME_LEN * 2];
}Quickdial;

//blacklist
typedef struct stBlacklist
{
	char contact_name[MAX_NAME_LEN * 2];
}Blacklist;

//commonphone
typedef struct stCommonphone
{
	char phonenum[MAX_PHONENUM_LEN];
	char desc[MAX_REMOTE_LEN];
}Commonphone;

#endif
