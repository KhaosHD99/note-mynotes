#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
//#include "lpconfig.h"
#include "contacts.hpp"
#include "calllog.hpp"
#include "iostream"
#include <gtk/gtk.h>
//#include <glib/gi18n.h>
//#include <locale.h>
using namespace std;

int main(int argc, char *argv[])
{   
    CContactsManager *manager = CContactsManager::get_instance();
    //CCalllogManager *manager = CCalllogManager::get_instance();
       
    //gtk
    GtkWidget *separator;
    GtkWidget *window;
    GtkWidget *vbox;
    GtkWidget *scrolled_window;
    GtkWidget *frame;
    GtkWidget *gtklist;
    GtkWidget *list_item;
    guint i;
    gchar buffer[64];
    
    gtk_init (&argc, &argv);
    
    window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title (GTK_WINDOW (window), "GtkList Example");
    g_signal_connect (G_OBJECT (window), "destroy",
		                  G_CALLBACK (gtk_main_quit),
		                  NULL);
    
    //vbox
    vbox=gtk_vbox_new (FALSE, 5);
    gtk_container_set_border_width (GTK_CONTAINER (vbox), 5);
    gtk_container_add (GTK_CONTAINER (window), vbox);
    gtk_widget_show (vbox);
    
    //scrolled window 
    scrolled_window = gtk_scrolled_window_new (NULL, NULL);
    gtk_widget_set_size_request (scrolled_window, 250, 150);
    gtk_container_add (GTK_CONTAINER (vbox), scrolled_window);
    gtk_widget_show (scrolled_window);
    
    //list
    gtklist=gtk_list_new ();
    gtk_scrolled_window_add_with_viewport (GTK_SCROLLED_WINDOW (scrolled_window),
                                          gtklist);
    gtk_widget_show (gtklist);
  
    //list item
    for (i = 0; i < 5; i++) 
    {
				GtkWidget       *label;
				gchar           *string;
				
//				Contact *contact = new Contact;
				Contact contact;
		    int ret = manager->get_contact_by_name(&contact, "镇杰");
				sprintf(buffer, contact.name.szgiven_name, i);
				label=gtk_label_new (buffer);
				list_item=gtk_list_item_new ();
				gtk_container_add (GTK_CONTAINER (list_item), label);
				gtk_widget_show (label);
				gtk_container_add (GTK_CONTAINER (gtklist), list_item);
				gtk_widget_show(list_item);
				gtk_label_get (GTK_LABEL (label), &string);
				//g_object_set_data (G_OBJECT (list_item), list_item_data_key, string);
    }
    
    gtk_widget_show (window);
    gtk_main ();
    
    //add contact
	  /*Contact *section = new Contact;
		memset(section, 0, sizeof(Contact));
	
		strcpy(section->name.szfamily_name,"徐");
		strcpy(section->name.szgiven_name,"镇杰");
	
		section->phones[0].type = PT_HOME;
		strcpy(section->phones[0].szphone, "31325201");
		section->phones[1].type = PT_MOBILE;
		strcpy(section->phones[1].szphone, "13539982758");
		section->phones[2].type = PT_WORK;
		strcpy(section->phones[2].szphone, "12345678");
	
		section->emails[0].type = EMT_WORK;
		strcpy(section->emails[0].szemail, "xujiekoo@qq.com");
	  section->emails[1].type = EMT_HOME;
		strcpy(section->emails[1].szemail, "163.com");
	    
		strcpy(section->szvoip,"172.17");
		strcpy(section->szim,"466795229");
		strcpy(section->szaddress,"yuexu");
	
	  manager->add_contact(section);
		manager->add_contact(section);
		manager->add_contact(section);*/
    
	  //add calllog
    /*CallLog *calllog = new CallLog;
	
	  calllog->status = CL_DIALED;
	  const char *str = "8";
	  const char *str2 = "中文";
	
	  strcpy(calllog->szremote, str2); 
	  strcpy(calllog->date.year, str); 
    strcpy(calllog->date.month, str);
    strcpy(calllog->date.day, str);
    strcpy(calllog->date.hour, str);
    strcpy(calllog->date.minute,str);
    strcpy(calllog->date.second, str);

	  manager->add_calllog(CL_DIALED, calllog);
	  manager->add_calllog(CL_MISSED, calllog);
	  manager->add_calllog(CL_DIALED, calllog);
	  manager->add_calllog(CL_RECEIVED, calllog);*/

    //delete
	  //manager->delete_calllog_by_status(CL_DIALED);
	  //manager->delete_calllog_by_status(CL_MISSED);
		//manager->delete_calllog_by_index(CL_MISSED, 0);
	  //manager->delete_contact_all();
    //manager->delete_contact_by_index(0);
    //manager->sort_by_letter();
    //manager->read_contact();
		//manager->get_section_from_config_file(0);
	
	  //read
		//manager->read_contact();
    //cout << manager->get_contact_buf_count() << endl;
    
	  //get
    /*Contact *contact = new Contact;
		int ret = manager->get_contact_by_name(&contact, "徐镇杰");
		//int ret = manager->get_contact_by_phone(&contact, "135399858");
		//int ret = manager->get_contact_by_letter(&contact, "x");
		//int ret = manager->get_contact_by_index(&contact, 0);
    if(ret == -1)
		cout << "\ncan not find any thing " << endl; 
		else
		{
				cout << "\nsame at: " << ret << endl; 
   		 	cout << "show: " << contact->name.szfamily_name << endl;
		}*/
    
  	//update
  	/*Contact *section = new Contact;
		memset(section, 0, sizeof(Contact));

		strcpy(section->name.szfamily_name,"wu");
		strcpy(section->name.szgiven_name,"yaoquan");

		section->phones[0].type = PT_HOME;
		strcpy(section->phones[0].szphone, "31325201");
		section->phones[1].type = PT_MOBILE;
		strcpy(section->phones[1].szphone, "13539982758");
    
		section->emails[0].type = EMT_WORK;
		strcpy(section->emails[0].szemail, "xujiekoo@qq.com");
    section->emails[1].type = EMT_HOME;
		strcpy(section->emails[1].szemail, "163.com");
    
		strcpy(section->szvoip,"172.17");
		strcpy(section->szim,"466795229");
		strcpy(section->szaddress,"yuexu");

  	int ret = manager->update_contact_by_index(section, 2);
		if(ret == -1)
		printf("fail");*/
	
    return 0;
}

