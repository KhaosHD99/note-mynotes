#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#include "calllog.hpp"
#include "LogMsg.hpp"

/******************************************************************************
                                                             constructor
******************************************************************************/
CCalllogManager::CCalllogManager()     
{
    init();
}

/******************************************************************************
                                                                destructor
******************************************************************************/
CCalllogManager::~CCalllogManager()
{
	uninit();
}

/********************************************************************************
                                  initialization
*********************************************************************************/
void CCalllogManager::init()
{
	calllog_lpconfig = lp_config_new(CALLLOG_FILE_PATH);
	if(!calllog_lpconfig)
	{
		showError("calllog lpconfig init fail\n");
		return;
	}
	
	init_log(&calllog_missed);
	init_log(&calllog_received);
	init_log(&calllog_dialed);
	
    //init lock
	int ret = init_mutex();
	if(ret != 0)
		return;
    
	//init calllog buffer
	load_calllog_from_file();
}

void CCalllogManager::init_log(CallLog_Info *calllog_info)
{
	calllog_info->count = 0;
	calllog_info->calllog_buf = new CallLog*[MAX_CALLLOG_COUNT];
	
	for(int i = 0; i < MAX_CALLLOG_COUNT; i++)
		calllog_info->calllog_buf[i] = NULL;
}

/********************************************************************************
                                uninitialization
*********************************************************************************/
void CCalllogManager::uninit()
{
	uninit_log(&calllog_missed);
	uninit_log(&calllog_received);
	uninit_log(&calllog_dialed);

	lp_config_destroy(calllog_lpconfig);
}

void CCalllogManager::uninit_log(CallLog_Info *calllog_info)
{
	for(int i = 0; i < calllog_info->count;	i++)
	{
		if(calllog_info->calllog_buf[i])
			delete calllog_info->calllog_buf[i];
		calllog_info->calllog_buf[i] = NULL;
	}
	delete calllog_info->calllog_buf;
	calllog_info->calllog_buf = NULL;
}

/********************************************************************************
                                                         get instance
*********************************************************************************/
CCalllogManager* CCalllogManager::calllog_instance =  NULL;
CCalllogManager* CCalllogManager::get_instance()
{
	if(!calllog_instance)
		calllog_instance = new CCalllogManager;
			
	return calllog_instance;
}

/**********************************************************************************************************/
/*******************************************    mutex    *****************************************************/
/**********************************************************************************************************/

/********************************************************************************
                                                       init lock mutex
********************************************************************************/
int CCalllogManager::init_mutex()
{
		return pthread_mutex_init(&mutex, NULL);
}

/********************************************************************************
                                                      lock mutex
********************************************************************************/
void CCalllogManager::lock_mutex()
{
		pthread_mutex_lock(&mutex);
}

/********************************************************************************
 				                         unlock mutex
********************************************************************************/
void CCalllogManager::unlock_mutex()
{
	  pthread_mutex_unlock(&mutex);
}

/********************************************************************************
                                                  get calllog item from file
*********************************************************************************/
CallLog* CCalllogManager::get_section_from_config_file(int index)
{
	int calllogindex = -1, 
    	statusIndex = -1, 
		duration = -1,
		is_read = -1;

	const char *tmp = NULL;
	char *tmpcpy;
	char section_title[64];

	CallLog *calllog = new CallLog;
	memset(calllog , 0, sizeof(CallLog));
	 		
	sprintf(section_title, "%s%i", CLOG_CALLLOG_INDEX, index);  
	
	//check
	if (!lp_config_has_section(calllog_lpconfig, section_title))
		return NULL;
	
	tmp = lp_config_get_string(calllog_lpconfig, section_title, CLOG_STATUS, NULL);

	if(tmp != NULL && __clstatus_str_to_enum(tmp) != CL_NON)
		calllog->status = __clstatus_str_to_enum(tmp);
	else
		return NULL;
	
	if(calllog->status == CL_MISSED)
	{
	    //status_index, remote
		statusIndex = lp_config_get_int(calllog_lpconfig, section_title, CLOG_MISSED_INDEX, NULL);
		if(statusIndex != -1)
		{
			calllog->status_index = statusIndex;	
			statusIndex = -1;
		}
		else
			return NULL;

		is_read = lp_config_get_int(calllog_lpconfig, section_title, CLOG_MISSED_IS_READ, NULL);
		if(is_read != -1)
			calllog->is_read = is_read;
		else
			return NULL;
		
		tmp = lp_config_get_string(calllog_lpconfig, section_title, CLOG_REMOTE_FROM, NULL);
		if(tmp)
			strcpy(calllog->szremote, tmp);
		else
			return NULL;
	   
	}
	else if(calllog->status == CL_RECEIVED)
	{
	    //status_index, remote
		statusIndex = lp_config_get_int(calllog_lpconfig, section_title, CLOG_RECEIVED_INDEX, NULL);
		if(statusIndex != -1)
		{
			calllog->status_index = statusIndex;
			statusIndex = -1;
		}
		else
			return NULL;
		
		tmp = lp_config_get_string(calllog_lpconfig, section_title, CLOG_REMOTE_FROM, NULL);
		if(tmp)
			strcpy(calllog->szremote, tmp);
		else
			return NULL;
	    
	}
	else if(calllog->status == CL_DIALED)
	{
	    //status_index, remote
		statusIndex = lp_config_get_int(calllog_lpconfig, section_title, CLOG_DIALED_INDEX, NULL);
		if(statusIndex != -1) 
		{
			calllog->status_index = statusIndex;
			statusIndex = -1;
		}
		else
			return NULL;
		
		tmp = lp_config_get_string(calllog_lpconfig,section_title, CLOG_REMOTE_TO, NULL);
		if(tmp)
			strcpy(calllog->szremote, tmp);
		else
			return NULL;
	    
	}	
	else
		return NULL;
	

	//date
	tmp = lp_config_get_string(calllog_lpconfig, section_title, CLOG_START_DATE, NULL);
    tmpcpy = (char*)malloc(strlen(tmp)); 
	strcpy(tmpcpy, tmp);
	
    char *p_date, *p_time;
	
	//division
	p_date = strtok(tmpcpy, " ");     
	p_time = strtok(NULL, "");        
	
	if(p_date) 
	{
		p_date = strtok(p_date, "-");
		strcpy(calllog->date.year, p_date);
		
		p_date = strtok(NULL, "-");
		strcpy(calllog->date.month, p_date);
		
		p_date = strtok(NULL, "-");
		strcpy(calllog->date.day, p_date);
	}
	else
		return NULL;

	if(p_time) 
	{
		p_time = strtok(p_time, ":");
		strcpy(calllog->date.hour, p_time);
		
		p_time = strtok(NULL, ":");
		strcpy(calllog->date.minute, p_time);
		
		p_time = strtok(NULL, ":");
		strcpy(calllog->date.second, p_time);
	}
	else
		return NULL;
	
	//duration
	duration = lp_config_get_int(calllog_lpconfig, section_title, CLOG_DURATION, NULL);
	if(duration >= 0)
		calllog->date.duration = duration;
	else
		return NULL;

	return calllog;
}

/********************************************************************************
                               write calllog item to config file by index without sync                 
*********************************************************************************/
int CCalllogManager::write_calllog_item(CallLog *item, int index, int status_index)
{	
	char section_title[64];
    sprintf(section_title, "%s%i", CLOG_CALLLOG_INDEX, index);

	if(item->status == CL_MISSED)
	{
		lp_config_set_string(calllog_lpconfig, section_title, CLOG_STATUS, __clstatus_enum_to_str(item->status));
		lp_config_set_int(calllog_lpconfig, section_title, CLOG_MISSED_INDEX, status_index);
		lp_config_set_string(calllog_lpconfig, section_title, CLOG_REMOTE_FROM, item->szremote);
		lp_config_set_int(calllog_lpconfig, section_title, CLOG_MISSED_IS_READ, 0);
	}
	else if(item->status == CL_RECEIVED)
	{
		lp_config_set_string(calllog_lpconfig, section_title, CLOG_STATUS, __clstatus_enum_to_str(item->status));
		lp_config_set_int(calllog_lpconfig, section_title, CLOG_RECEIVED_INDEX, status_index);
		lp_config_set_string(calllog_lpconfig, section_title, CLOG_REMOTE_FROM, item->szremote);
	}
	else if(item->status == CL_DIALED)
	{
		lp_config_set_string(calllog_lpconfig, section_title, CLOG_STATUS, __clstatus_enum_to_str(item->status));
		lp_config_set_int(calllog_lpconfig, section_title, CLOG_DIALED_INDEX, status_index);
		lp_config_set_string(calllog_lpconfig, section_title, CLOG_REMOTE_TO, item->szremote);
	}
	
	//time
	char datetime[64];
	
	sprintf(datetime, "%s-%s-%s %s:%s:%s", item->date.year, item->date.month,
			                               item->date.day, item->date.hour, 
			                               item->date.minute, item->date.second);
 
	lp_config_set_string(calllog_lpconfig, section_title, CLOG_START_DATE, datetime);
	
	//duration	
	lp_config_set_int(calllog_lpconfig, section_title, CLOG_DURATION, item->date.duration);
	
	return 0;
}

/********************************************************************************
                                                        synchronization
*********************************************************************************/
int CCalllogManager::sync_calllog_config()
{ 
    if(calllog_lpconfig == NULL)
    {   
    	showError("calllog lpconfig is null\n");
		return -1;
    }
	
    int writeindex = 0;
	char section_title[64];

	//clear
	for(int i = 0; i < MAX_CALLLOG_COUNT; i++)
	{
		sprintf(section_title, "%s%i", CLOG_CALLLOG_INDEX, i);
		if(lp_config_has_section(calllog_lpconfig, section_title))
			lp_config_clean_section(calllog_lpconfig, section_title);
	}
	
	//write
	for(int i = 0; i < calllog_missed.count; i++)
		write_calllog_item(calllog_missed.calllog_buf[i], i, i);
	
	for(int i = 0; i < calllog_received.count; i++)
		write_calllog_item(calllog_received.calllog_buf[i], 
	                       i + calllog_missed.count, i);
		
	for(int i = 0; i < calllog_dialed.count; i++)
		write_calllog_item(calllog_dialed.calllog_buf[i], 
			              		 i + calllog_missed.count + calllog_received.count, i);

	return lp_config_sync(calllog_lpconfig);
}

#if 0
int CCalllogManager::sort_by_date()
{
	int count;
	count = calllog_missed.count + calllog_received.count + calllog_dialed.count;
	if(count <= 0)
		 return 0;
		
	CallLog *calllog_tmp = new CallLog;
	char datetime[] = "";	
	int date_0=0,date_1=0;
	int time_0=0,time_1=0;

	for(int j=0; j<calllog_missed.count-1; j++)
	{
		for(int i=0; i<calllog_missed.count-1; i++)
		{
			CallLog *temp = calllog_missed.calllog_buf[i];
			sprintf(datetime, "%s%s%s%s%s%s", temp->date.year, temp->date.month,
											  temp->date.day, temp->date.hour, 
											  temp->date.minute, temp->date.second);
	
			date_0 = get_date_int(datetime);
			time_0 = get_time_int(datetime);
			
			temp = calllog_missed.calllog_buf[i+1];
			sprintf(datetime, "%s%s%s%s%s%s", temp->date.year, temp->date.month,
											  temp->date.day, temp->date.hour, 
											  temp->date.minute, temp->date.second);
			date_1 = get_date_int(datetime);
			time_1 = get_time_int(datetime);

			
			if(date_0 > date_1)
			{
					calllog_tmp = calllog_missed.calllog_buf[i];
					calllog_missed.calllog_buf[i] = calllog_missed.calllog_buf[i+1];
					calllog_missed.calllog_buf[i+1] = calllog_tmp;
			}
			else if(date_0 == date_1)
			{
					if(time_0 > time_1)
					{
							calllog_tmp = calllog_missed.calllog_buf[i];
							calllog_missed.calllog_buf[i] = calllog_missed.calllog_buf[i+1];
							calllog_missed.calllog_buf[i+1] = calllog_tmp;
					}
			}
			date_0=0,date_1=0;
			time_0=0,time_1=0;
		}
	}	

	date_0=0,date_1=0;
	time_0=0,time_1=0;
	for(int j=0; j<calllog_received.count-1; j++)
	{
		for(int i=0; i<calllog_received.count-1; i++)
		{
			CallLog *temp = calllog_received.calllog_buf[i];
			sprintf(datetime, "%s%s%s%s%s%s", temp->date.year, temp->date.month,
											  temp->date.day, temp->date.hour, 
											  temp->date.minute, temp->date.second);
			date_0 = get_date_int(datetime);
			time_0 = get_time_int(datetime);

			temp = calllog_received.calllog_buf[i+1];
			sprintf(datetime, "%s%s%s%s%s%s", temp->date.year, temp->date.month,
											  temp->date.day, temp->date.hour, 
											  temp->date.minute, temp->date.second);
			date_1 = get_date_int(datetime);
			time_1 = get_time_int(datetime);

			if(date_0 > date_1)
			{
				calllog_tmp = calllog_received.calllog_buf[i];
				calllog_received.calllog_buf[i] = calllog_received.calllog_buf[i+1];
				calllog_received.calllog_buf[i+1] = calllog_tmp;
			}
			else if(date_0 == date_1)
			{
				if(time_0 > time_1)
				{
					calllog_tmp = calllog_received.calllog_buf[i];
					calllog_received.calllog_buf[i] = calllog_received.calllog_buf[i+1];
					calllog_received.calllog_buf[i+1] = calllog_tmp;
				}
			}
			date_0=0,date_1=0;
			time_0=0,time_1=0;
		}
	}	

	date_0=0,date_1=0;
	time_0=0,time_1=0;
	for(int j=0; j<calllog_dialed.count-1; j++)
	{
		for(int i=0; i<calllog_dialed.count-1; i++)
		{
			CallLog *temp = calllog_dialed.calllog_buf[i];
			sprintf(datetime, "%s%s%s%s%s%s", temp->date.year, temp->date.month,
											  temp->date.day, temp->date.hour, 
											  temp->date.minute, temp->date.second);
			date_0 = get_date_int(datetime);
			time_0 = get_time_int(datetime);			
				
			temp = calllog_dialed.calllog_buf[i+1];
			sprintf(datetime, "%s%s%s%s%s%s", temp->date.year, temp->date.month,
											  temp->date.day, temp->date.hour, 
											  temp->date.minute, temp->date.second);
			date_1 = get_date_int(datetime);
			time_1 = get_time_int(datetime);
				
			if(date_0 > date_1)
			{
				calllog_tmp = calllog_dialed.calllog_buf[i];
				calllog_dialed.calllog_buf[i] = calllog_dialed.calllog_buf[i+1];
				calllog_dialed.calllog_buf[i+1] = calllog_tmp;
			}
			else if(date_0 == date_1)
			{
				if(time_0 > time_1)
				{
					calllog_tmp = calllog_dialed.calllog_buf[i];
					calllog_dialed.calllog_buf[i] = calllog_dialed.calllog_buf[i+1];
					calllog_dialed.calllog_buf[i+1] = calllog_tmp;
				}
			}
			date_0=0,date_1=0;
			time_0=0,time_1=0;
		}
	}	
	
	//sync
	sync_calllog_config();
		
    return 0;
}
#endif

/**********************************************************************************************************/
/*****************************************    CURD  *******************************************************/
/**********************************************************************************************************/

/********************************************************************************
                                        read contact from config file to buffer
********************************************************************************/
int CCalllogManager::load_calllog_from_file()
{
	if(calllog_lpconfig == NULL)
  		return -1;
	
	CallLog *calllog = NULL;	
	
    //lock
	lock_mutex();
		
	calllog_missed.count = 0;
	calllog_received.count = 0;
	calllog_dialed.count = 0;
	
	for (int i = 0; (calllog = get_section_from_config_file(i)) != NULL; i++)
	{
		if(calllog->status == CL_MISSED)
		{
			calllog_missed.status = CL_MISSED;
			calllog_missed.calllog_buf[calllog_missed.count] = calllog;
			calllog_missed.count++;
		}
		else if(calllog->status == CL_RECEIVED)
		{
			calllog_received.status = CL_RECEIVED;
			calllog_received.calllog_buf[calllog_received.count] = calllog;
			calllog_received.count++;
		}
		else if(calllog->status == CL_DIALED)
		{
			calllog_dialed.status = CL_DIALED;
			calllog_dialed.calllog_buf[calllog_dialed.count] = calllog;
			calllog_dialed.count++;
		}
	} 
	
    showDebug("missed: %d, received: %d, dialed; %d \n", get_calllog_count_by_type(CL_MISSED),
			                                             get_calllog_count_by_type(CL_RECEIVED),
			                                             get_calllog_count_by_type(CL_DIALED));
    sort_by_date();

	//unlock
	unlock_mutex();
	
	return 0;
}

/********************************************************************************
                                                            get all calllog count 
*********************************************************************************/
int CCalllogManager::get_calllog_count()
{	
    return calllog_missed.count + calllog_received.count + calllog_dialed.count;
}

/********************************************************************************
                                                      get calllog count by type
*********************************************************************************/
int CCalllogManager::get_calllog_count_by_type(CLSTATUS status)
{
	if(status == CL_MISSED)
		return calllog_missed.count;

    if(status == CL_RECEIVED)
		return calllog_received.count;

	if(status == CL_DIALED)
		return calllog_dialed.count;
			
	return -1;
}

/********************************************************************************
                                                          get  calllog by index
*********************************************************************************/
int CCalllogManager::get_calllog_by_index(CallLog *calllog, int index, CLSTATUS status)
{
    //validate
	if(!calllog)
		return -1;
			
	if(status == CL_MISSED)
	{
		if(index >= calllog_missed.count)
			return -1;

		//lock
	    lock_mutex();

		memcpy(calllog, calllog_missed.calllog_buf[index], sizeof(CallLog));

		//unlock
		unlock_mutex();
	}
    else if(status == CL_RECEIVED)
	{
		if(index >= calllog_received.count)
			return -1;

		//lock
	    lock_mutex();

		memcpy(calllog, calllog_received.calllog_buf[index], sizeof(CallLog));

		//unlock
		unlock_mutex();
	}
	else if(status == CL_DIALED)
	{
		if(index >= calllog_dialed.count)
			return -1;

		//lock
	    lock_mutex();
		
		memcpy(calllog, calllog_dialed.calllog_buf[index], sizeof(CallLog));

        //unlock
		unlock_mutex();
	}
	else
		return -1;
	
	
	//unlock
	unlock_mutex();
	
	return 0;
}

int get_unread_missed_callog_count()
{
	for(int i = 0; i < 
	calllog_missed.calllog_buf[calllog_missed.count] = calllog;
}

/********************************************************************************
                                                            add calllog item
*********************************************************************************/
int CCalllogManager::add_calllog(CallLog *calllog)
{
    if(!calllog)
		return -1;

    /* If Exceed The Max Count, Remote The Oldest One */
	if(get_calllog_count() >= MAX_CALLLOG_COUNT)
	{
		if(calllog->status && calllog->status == CL_MISSED)
		{
		    showDebug("Get in delete Missed\n");
			delete_calllog_by_index(0, calllog->status);
		}
		else if(calllog->status && calllog->status == CL_RECEIVED)
		{
		    showDebug("Get in delete Missed\n");
			delete_calllog_by_index(0, calllog->status);
		}
		else if(calllog->status && calllog->status == CL_DIALED)
		{
			showDebug("Get in delete CL_MISSED\n");
			delete_calllog_by_index(0, calllog->status);
		}
		else
			return -1;
	}
	
	int i = 0;
	
	//lock
	lock_mutex();
    
	if(calllog->status && calllog->status == CL_MISSED)
	{
	    if(calllog_missed.calllog_buf[calllog_missed.count] == NULL)
	    {
	        calllog_missed.calllog_buf[calllog_missed.count] = new CallLog;
			
			//copy
	        memcpy(calllog_missed.calllog_buf[calllog_missed.count], calllog, sizeof(CallLog));
		}
		calllog_missed.count++;
	}
	else if(calllog->status && calllog->status == CL_RECEIVED)
	{
		if(calllog_received.calllog_buf[calllog_received.count] == NULL)
	    {
	        calllog_received.calllog_buf[calllog_received.count] = new CallLog;

			//copy
	        memcpy(calllog_received.calllog_buf[calllog_received.count], calllog, sizeof(CallLog));
		}
	
		calllog_received.count++;
	}
	else if(calllog->status && calllog->status == CL_DIALED)
	{
	    if(calllog_dialed.calllog_buf[calllog_dialed.count] == NULL)
	    {
	        calllog_dialed.calllog_buf[calllog_dialed.count] = new CallLog;

			//copy
	        memcpy(calllog_dialed.calllog_buf[calllog_dialed.count], calllog, sizeof(CallLog));
		}
		calllog_dialed.count++;
	}	
	else
	{
		//unlock
		unlock_mutex();	

		return -1;
	}
	
	//sync
    sync_calllog_config();
	
	//unlock
	unlock_mutex();
	
	return 0;
}

/********************************************************************************
                                                Update CallLog by index
********************************************************************************/
int CCalllogManager::update_calllog_by_index(CallLog *calllog, int index, CLSTATUS status)
{
    showDebug("Get in update\n");
	//validate
	if((calllog_missed.count + calllog_received.count + calllog_dialed.count) == 0)
		return -1;
			
	if(status == CL_MISSED && index >= calllog_missed.count)
		return -1;
	
	if(status == CL_RECEIVED && index >= calllog_received.count)
		return -1;
	
	if(status == CL_DIALED && index >= calllog_dialed.count)
		return -1;
	
	if(!calllog)
		return -1;

	
	showDebug("Get in before lock\n");
	//lock
	lock_mutex();

	showDebug("Get in after lock\n");
    if(status == CL_MISSED)
    {
		showDebug("Get in copy\n");
		memcpy(calllog_missed.calllog_buf[index], calllog, sizeof(CallLog));
    }
	if(status == CL_RECEIVED)
	{
		
		memcpy(calllog_received.calllog_buf[index], calllog, sizeof(CallLog));
	}
	if(status == CL_DIALED)
	{
	    
		showDebug("Get in CL_DIALED copy\n");
		memcpy(calllog_dialed.calllog_buf[index], calllog, sizeof(CallLog));
	}
    
	//copy
	//memset(contact_buf[index], 0, sizeof(Contact));
	//memcpy(contact_buf[index], contact, sizeof(Contact));

	//sync
    sync_calllog_config();

	//unlock
	unlock_mutex();
    
	return 0;
}


/********************************************************************************
                         delete calllog item by index
*********************************************************************************/
int CCalllogManager::delete_calllog_by_index(int index, CLSTATUS status)
{
	//lock
	lock_mutex();

	if(status == CL_MISSED)
	{
	  	if(index >= calllog_missed.count || calllog_missed.count == 0)
		{
			unlock_mutex();
			return -1;
		}

		for(int i = index; i < calllog_missed.count - 1; i++)
    	{
	        memset(calllog_missed.calllog_buf[i], 0, sizeof(CallLog));
	    	memcpy(calllog_missed.calllog_buf[i], calllog_missed.calllog_buf[i+1], sizeof(CallLog));
			calllog_missed.calllog_buf[i]->status_index--;
		}

		delete(calllog_missed.calllog_buf[calllog_missed.count - 1]);
		calllog_missed.calllog_buf[calllog_missed.count - 1] = NULL;

		calllog_missed.count--;
	}
	else if(status == CL_RECEIVED)
	{
  		if(index >= calllog_received.count || calllog_received.count == 0)
		{
			unlock_mutex();
			return -1;
		}

		for(int i = index; i < calllog_received.count - 1; i++)
    	{
	        memset(calllog_received.calllog_buf[i], 0, sizeof(CallLog));
	    	memcpy(calllog_received.calllog_buf[i], calllog_received.calllog_buf[i+1], sizeof(CallLog));
			calllog_received.calllog_buf[i]->status_index--;
		}

		delete(calllog_received.calllog_buf[calllog_received.count - 1]);
		calllog_received.calllog_buf[calllog_received.count - 1] = NULL;

		calllog_received.count--;
	}
	else if(status == CL_DIALED)
	{		
		if(index >= calllog_dialed.count || calllog_dialed.count == 0)
		{
			unlock_mutex();
			return -1;
		}

		for(int i = index; i < calllog_dialed.count - 1; i++)
    	{
	        memset(calllog_dialed.calllog_buf[i], 0, sizeof(CallLog));
	    	memcpy(calllog_dialed.calllog_buf[i], calllog_dialed.calllog_buf[i+1], sizeof(CallLog));
			calllog_dialed.calllog_buf[i]->status_index--;
		}

		delete(calllog_dialed.calllog_buf[calllog_dialed.count - 1]);
		calllog_dialed.calllog_buf[calllog_dialed.count - 1] = NULL;

		calllog_dialed.count--;
		
	}
	else
	{
		//unlock
		unlock_mutex();

		return -1;
	}
	//sync
	sync_calllog_config();
	
	//unlock
	unlock_mutex();
	
	return 0;
}

/********************************************************************************
                          delete calllog item by status
*********************************************************************************/
int CCalllogManager::delete_calllog_by_status(CLSTATUS status)
{
	//lock
	lock_mutex();

	if(status == CL_MISSED)
	{

        if(calllog_missed.count == 0)
		{
				unlock_mutex();
				return -1;
		}
		
	    for(int i = 0; i < calllog_missed.count; i++)
	    {
    		delete(calllog_missed.calllog_buf[i]);
				calllog_missed.calllog_buf[i] = NULL;
	    }
		
		calllog_missed.count = 0;
	}
	else if(status == CL_RECEIVED)
	{
	    if(calllog_received.count == 0)
		{
			unlock_mutex();
			return -1;
		}
	    for(int i = 0; i < calllog_received.count; i++)
	    {
	    		delete(calllog_received.calllog_buf[i]);
					calllog_received.calllog_buf[i] = NULL;
	    }
		
		calllog_received.count = 0; 
	}
	else if(status == CL_DIALED)
	{
	    if(calllog_dialed.count == 0)
		{
			unlock_mutex();
			return -1;
		}
	    for(int i = 0; i < calllog_dialed.count; i++)
	    {
    		delete(calllog_dialed.calllog_buf[i]);
				calllog_dialed.calllog_buf[i] = NULL;
	    }
		
		calllog_dialed.count = 0;
	}
	else
	{
		//unlock
		unlock_mutex();

		return -1;
	}
	
	//sync
	sync_calllog_config();
	
	//unlock
	unlock_mutex();
	
	return 0;
}

/********************************************************************************
				                       	   helper
*********************************************************************************/
int CCalllogManager::comp(const void *p, const void *q)
{
	return (*(int *)p - *(int *)q);
}


/********************************************************************************
				                       	sort by date
*********************************************************************************/
int CCalllogManager::sort_by_date()
{
    #if 0
    long long date_int;
	long long year;
	long long  mon;
	long long  day;
	long long  hour;
	long long  min;
	long long  sec;

	long long calllog_missed_date[MAX_CALLLOG_COUNT];

	for(int i = 0; i < calllog_missed.count; i++)
	{
		sscanf(calllog_missed.calllog_buf[i]->date.year, "%lld", &year);
		sscanf(calllog_missed.calllog_buf[i]->date.month, "%lld", &mon);
		sscanf(calllog_missed.calllog_buf[i]->date.day, "%lld", &day);
		sscanf(calllog_missed.calllog_buf[i]->date.hour, "%lld", &hour);
		sscanf(calllog_missed.calllog_buf[i]->date.minute, "%lld", &min);
		sscanf(calllog_missed.calllog_buf[i]->date.second, "%lld", &sec);
	    
	    year = year * 10000000000LL;
	    mon = mon * 100000000;
		day = day * 1000000;
		hour = hour * 10000;
		min = min * 100;
	    
	    date_int = year + mon + day + hour + min + sec;
		
		printf("size: %lld\n", date_int); 
	}
	#endif
}

/**********************************************************************************************************/
/****************************************    enum    ******************************************************/
/**********************************************************************************************************/

/********************************************************************************
                         convert status enum to str
*********************************************************************************/
const char* CCalllogManager::__clstatus_enum_to_str(int enum_val)
{
	switch(enum_val)
	{		
		case CL_MISSED:
				return CL_MISSED_str;
				break;
		case CL_RECEIVED:
				return CL_RECEIVED_str;
				break;
		case CL_DIALED:
				return CL_DIALED_str;
				break;
		default:
				return CL_NON_str;
	}
}

/********************************************************************************
                                                    convert status str to enum
*********************************************************************************/
CLSTATUS CCalllogManager::__clstatus_str_to_enum(const char *enum_str)
{	
    if(strncmp(enum_str, CL_MISSED_str,strlen(CL_MISSED_str)) == 0)
		return CL_MISSED;
    
	if(strncmp(enum_str, CL_RECEIVED_str,strlen(CL_RECEIVED_str)) == 0)
		return CL_RECEIVED;

	if(strncmp(enum_str, CL_DIALED_str,strlen(CL_DIALED_str)) == 0)
		return CL_DIALED;
    
	printf("Invalid clstatus enum value %s", enum_str);
	
	return CL_NON;
}



