
export PRX=/home/$USER
export HOST_PATH=/opt/fn3/rootfs

export PKG_CONFIG_PATH=$PKG_CONFIG_PATH:$HOST_PATH$PRX/lib/pkgconfig

./configure \
	--prefix=$PRX \
  --host=arm-linux



