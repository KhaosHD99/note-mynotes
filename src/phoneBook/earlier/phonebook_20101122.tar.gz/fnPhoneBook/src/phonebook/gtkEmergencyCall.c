#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>

#include "phonebookapi.h"
#include "MessageStack.h"
#include "windowstack.h"
#include "LogMsg.hpp"

#define _(STRING) g_convert(STRING, -1, "UTF-8", "GB2312", NULL, NULL, NULL)
#define _to_asc(STRING) g_convert(STRING, -1, "GB2312", "UTF-8", NULL, NULL, NULL)

GtkBuilder *builder;
GtkListStore *store;
GtkTreeView *treeview;

enum 
{
	COMMON_PHONE_INDEX_COL,
    COMMON_PHONE_PHONENUM_COL,
    COMMON_PHONE_DESC_COL
};

void on_button_commonphone_dial_clicked(GtkWidget *window, gpointer user_data)
{
	showDebug("dial event\n");
}

void on_button_commonphone_cancel_clicked(GtkWidget *window, gpointer user_data)
{	
    GtkWindowInfo pwindow_info;
	
	get_window_out_stack(&pwindow_info);
	gtk_widget_destroy(GTK_WIDGET(pwindow_info.window));
}
#if 1
/********************************************************************************
                                                      comonphone treeview
********************************************************************************/
GtkListStore* create_commonphone_store(void)
{
	GtkListStore *store;
	store = gtk_list_store_new(3, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING);
	
	return store;
}

GtkTreeModel* fill_commonphone_store(GtkListStore *store)
{
    #if 1
    int i;
	
    for(i = 0; i < get_commonphone_count(); i++)
	{  
	   Commonphone commonphone;
	   GtkTreeIter iter;
	   memset(&commonphone, 0, sizeof(Commonphone));
       
	   if(!get_commonphone_by_index(&commonphone, i))
	   		showDebug("commonphone: %s\n", commonphone.phonenum);
	   else
			showDebug("Fail\n");
	   
	   gtk_list_store_append(store, &iter);
	   gtk_list_store_set(store, &iter,
			              COMMON_PHONE_INDEX_COL, i,
			              COMMON_PHONE_PHONENUM_COL, _(commonphone.phonenum) == NULL ? 
			                                         commonphone.phonenum : _(commonphone.phonenum),
						  COMMON_PHONE_DESC_COL, commonphone.desc,
	   					  -1);
	}
    #endif
	
	return GTK_TREE_MODEL (store);
}
#endif

/********************************************************************************
                                          set commonphone phonenum to column
********************************************************************************/
void set_commonphone_phonenum(GtkTreeViewColumn *tree_column,
									    GtkCellRenderer   *cell,
									    GtkTreeModel      *model,
									    GtkTreeIter       *iter,
									    gpointer           data)
{
    #if 1
	int index;
	char *phonenum;
	char *desc;
		
	gtk_tree_model_get(model, iter,
	                   COMMON_PHONE_PHONENUM_COL, &phonenum,
					   -1);
	
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", _(phonenum),
                 NULL);
	
	g_free(phonenum);
    #endif
}

/********************************************************************************
                                          set commonphone description to column
********************************************************************************/
void set_commonphone_desc(GtkTreeViewColumn *tree_column,
									      GtkCellRenderer   *cell,
									      GtkTreeModel      *model,
									      GtkTreeIter       *iter,
									      gpointer           data)
{
	int index;
	char *phonenum;
	char *desc;
		
	gtk_tree_model_get(model, iter,
					   COMMON_PHONE_DESC_COL, &desc,
					   -1);
	
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", _(desc),
                 NULL);
	
	g_free(desc);
}

/********************************************************************************
                                          show_commonphone_call_window
********************************************************************************/
int show_commonphone_window()
{
	GtkWidget *window;
	GtkTreeViewColumn *column_phonenum;
	GtkTreeViewColumn *column_desc;
	GtkCellRenderer *cell_renderer;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_commonphone"));
	
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	put_window_into_stack(window);
	
    #if 1
	//add  model to tree view
	store = create_commonphone_store();
	
	treeview = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_commonphone");
	gtk_tree_view_set_model(treeview, fill_commonphone_store(store));
	
	//column  
	column_phonenum = gtk_tree_view_column_new();
	column_desc = gtk_tree_view_column_new();
    
	// phonenum cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_phonenum,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_phonenum, cell_renderer,
		                              	    set_commonphone_phonenum, 
		                              	    NULL, NULL);

	// desc cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_desc,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_desc, cell_renderer,
		                              	    set_commonphone_desc, 
		                              	    NULL, NULL);
	
	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
					            column_phonenum);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
					            column_desc);
	#endif
    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();
	
	return 0;
}

