#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

#include "phonebookapi.h"
#include "MessageStack.h"
#include "windowstack.h"
#include "LogMsg.hpp"

#define _(STRING) g_convert(STRING, -1, "UTF-8", "GB2312", NULL, NULL, NULL)
#define _to_asc(STRING) g_convert(STRING, -1, "GB2312", "UTF-8", NULL, NULL, NULL)

GtkListStore *store;
GtkListStore *phonenum_store;
GtkListStore *combo_group_store;
GtkListStore *combo_phonenum_store;
GtkListStore *combo_email_store;

GtkTreeIter current_phonenum_iter;
GtkTreeIter current_email_iter;

GtkTreeView *contact_treeview;
GtkTreeView *phonenum_treeview;
GtkComboBox *combo_group;
GtkComboBox *combo_phonenum_index;
GtkComboBox *combo_email_index;

GtkEntry *entry_familyname;
GtkEntry *entry_givenname;
GtkEntry *entry_phonenum;
GtkEntry *entry_email;
GtkEntry *entry_im;
GtkEntry *entry_voip;
GtkEntry *entry_address;

enum 
{
	CONTACT_INDEX_COL,
    FAMILY_NAME_COL,
    GIVEN_NAME_COL,
    GROUP_COL = 0,
    PHONENUM_INDEX_COL = 0,
    PHONENUM_COL,
    EMAIL_INDEX_COL = 0,
    EMAIL_COL
};

typedef struct stModeInfo
{
	ContactDetailMode mode;
	int index;
}ModeInfo;

/********************************************************************************
                                                      contact treeview
********************************************************************************/
GtkListStore* create_contact_store(void)
{
	GtkListStore *store;
	store = gtk_list_store_new(3, G_TYPE_INT, G_TYPE_STRING, G_TYPE_STRING);
	
	return store;
}

GtkTreeModel* fill_contact_store(GtkListStore *store)
{
    #if 1
    int i;
	
    for(i = 0; i < get_contact_count(); i++)
	{
	   Contact contact;
	   GtkTreeIter iter;
	   memset(&contact, 0, sizeof(Contact));
       get_contact_by_index(&contact, i);
	      
	   gtk_list_store_append(store, &iter);
	   gtk_list_store_set(store, &iter,
			              CONTACT_INDEX_COL, i,
			              FAMILY_NAME_COL, _(contact.name.szfamily_name) == NULL ? 
			                                 contact.name.szfamily_name : _(contact.name.szfamily_name),
			              GIVEN_NAME_COL, _(contact.name.szgiven_name),
			              -1);
	}
    #endif
	
	return GTK_TREE_MODEL (store);
}

/********************************************************************************
                                                      phonenum treeview
********************************************************************************/
GtkListStore* create_phonenum_store(void)
{
	GtkListStore *store;
	store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING);
	
	return store;
}

GtkTreeModel* fill_phonenum_store(GtkListStore *store, int index)
{	
    
    int i;
	Contact contact;
	
	get_contact_by_index(&contact, index);
	showDebug("phonum count: %d, index col: %d, phonenum col: %d\n", contact.phone_count
											     				   , CONTACT_INDEX_COL
											  	 				   , PHONENUM_COL);
	#if 1
    for(i = 0; i < contact.phone_count; i++)
    {
       GtkTreeIter iter;
	   gtk_list_store_append(store, &iter);
	   gtk_list_store_set(store, &iter,
	     	              CONTACT_INDEX_COL, i,
			              PHONENUM_COL, _(contact.phones[i].szphone) == NULL ? 
	    	                              contact.phones[i].szphone : _(contact.phones[i].szphone),
			              -1);
	}
    #endif
	
	return GTK_TREE_MODEL (store);
}

void set_index(GtkTreeViewColumn *tree_column,
				      GtkCellRenderer   *cell,
				      GtkTreeModel      *model,
				      GtkTreeIter       *iter,
				      gpointer           data)
{
	int index;
	char index_str[16];
		
	gtk_tree_model_get(model, iter,
	                   CONTACT_INDEX_COL, &index,
	                   -1);
   
	sprintf(index_str, "%i", index + 1);
	
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", _(index_str),
                 NULL);
}

void set_name (GtkTreeViewColumn *tree_column,
				      GtkCellRenderer   *cell,
				      GtkTreeModel      *model,
				      GtkTreeIter       *iter,
				      gpointer           data)
{
    #if 1
	char *given_name;
	char *family_name;
	char strCombine[64];
	
	gtk_tree_model_get(model, iter,
	                 FAMILY_NAME_COL, &family_name,
	                 GIVEN_NAME_COL, &given_name,
	                 -1);
	
	sprintf(strCombine, "%s%s", family_name, given_name);
	
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", strCombine,
                 NULL);	
	
	g_free(family_name);
	g_free(given_name);
    #endif
}

void set_phonenum(GtkTreeViewColumn *tree_column,
				      GtkCellRenderer   *cell,
				      GtkTreeModel      *model,
				      GtkTreeIter       *iter,
				      gpointer           data)
{
    #if 1
	char *phonenum;
	
	gtk_tree_model_get(model, iter,
	                   PHONENUM_COL, &phonenum,
	                   -1);
		
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", phonenum,
                 NULL);
	
	g_free(phonenum);
    #endif
}

/********************************************************************************
                                                               event
********************************************************************************/
void on_button_contact_dial_clicked(GtkWidget *gtklist, gpointer user_data)
{	
	int index;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;
	
	if(!get_contact_count())
    {
        show_message_window(_(get_value_from_key(DISPLAY_NO_CONTACT)));
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(contact_treeview));
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window(_(get_value_from_key(DISPLAY_NO_SELECT)));
		return;
	}
	
	gtk_tree_model_get(model, &iter,
	                   CONTACT_INDEX_COL, &index,
	                   -1);
 	
	GtkBuilder *builder;
	GtkWidget *window;
	GtkTreeViewColumn *column_phonenum;
	GtkCellRenderer *cell_renderer;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_select_phonenum"));
	
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	put_window_into_stack(window);
	
	//add  model to tree view
	phonenum_store = create_phonenum_store();
	phonenum_treeview = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_phonenum");
	gtk_tree_view_set_model(phonenum_treeview, fill_phonenum_store(phonenum_store, index));
	
	#if 1
	//column  
	//column_index = gtk_tree_view_column_new();
	column_phonenum = gtk_tree_view_column_new();
    gtk_tree_view_column_set_title(column_phonenum, _(DISPLAY_CONTACT));
    
	//name cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_phonenum,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_phonenum, cell_renderer,
		                              	    set_phonenum, NULL, NULL);
	
	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(phonenum_treeview),
					            column_phonenum);
	#endif
    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();
}

void on_button_contact_add_clicked(GtkWidget *gtklist, gpointer user_data)
{
	show_contact_detail_window(ADD, NULL);
}

void on_button_contact_edit_clicked(GtkWidget *gtklist, gpointer user_data)
{
    GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(phonenum_treeview));
    if(!gtk_tree_selection_get_selected(selection, &model, &iter))
    {
		show_message_window(_(get_value_from_key(DISPLAY_NO_SELECT)));
		return;
	}
	
	show_contact_detail_window(EDIT, NULL);
}

void on_button_contact_delete_clicked(GtkWidget *gtklist, gpointer user_data)
{   
	int index;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreeIter iter;

    if(!get_contact_count())
    {
        show_message_window(_(get_value_from_key(DISPLAY_NO_CONTACT)));
		return;
    }
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(contact_treeview));
	if(!gtk_tree_selection_get_selected(selection, &model, &iter))
	{
		show_message_window(_(get_value_from_key(DISPLAY_NO_SELECT)));
		return;
	}
	
    if(!(show_confirm_window(_(get_value_from_key(DISPLAY_DELETE_CONFIRM))) ==	GTK_RESPONSE_OK))
   		return;
	
    #if 1
	if (gtk_tree_selection_get_selected(selection, &model, &iter))
	{
	    gtk_tree_model_get(model, &iter,
	                       CONTACT_INDEX_COL, &index,
	                       -1);
		
		//delete contact by index
		delete_contact_by_index(index);
    }
    #endif
	
	//sync contact list
    sync_contact_list();
}

void on_treeview_contactlist_row_activated(GtkWidget *gtklist, gpointer user_data)
{
	on_button_contact_edit_clicked(gtklist, user_data);
}

void on_button_contact_close_clicked(GtkWidget *gtklist, gpointer user_data)
{
    GtkWindowInfo pwindow_info;
	
    get_window_out_stack(&pwindow_info);
	gtk_widget_destroy(GTK_WIDGET(pwindow_info.window));
}

/********************************************************************************
                                                     phonenum selector
********************************************************************************/
on_button_select_phonenum_focus_in_event(GtkWidget *window, gpointer user_data)
{
	showDebug("event foucus in\n");
	GdkColor color;
	//gdk_color_parse(DEF_BUTTON_ACTION_COLOR, &color );
	gdk_color_parse("#FFFFFF", &color);
	gtk_widget_modify_bg(window, GTK_STATE_NORMAL, &color );
}

on_button_select_phonenum_cancel_focus_out_event(GtkWidget *window, gpointer user_data)
{
	GdkColor  color;
	//gdk_color_parse( DEF_BUTTON_NORMAL_COLOR, &color );
	//gtk_widget_modify_bg( button_save_account, GTK_STATE_NORMAL, &color );
}

on_button_select_phonenum_cancel_clicked(GtkWidget *window, gpointer user_data)
{
	GtkWindowInfo pwindow_info;
	
    get_window_out_stack(&pwindow_info);
	gtk_widget_destroy(GTK_WIDGET(pwindow_info.window));
}

/********************************************************************************
                                                       contact detail
********************************************************************************/
void on_button_contact_detail_cancel_clicked(GtkWidget *window, gpointer user_data)
{
	GtkWindowInfo pwindow_info;
	
	get_window_out_stack(&pwindow_info);	
	gtk_widget_destroy(GTK_WIDGET(pwindow_info.window));
	
	gtk_list_store_clear (combo_group_store);
	gtk_list_store_clear (combo_phonenum_store);
	gtk_list_store_clear (combo_email_store);
}

void on_button_contact_detail_save_clicked(GtkWidget *savebutton, gpointer user_data)
{
    if(validate_input())
		return;
	
    ModeInfo *mode_info = (ModeInfo *)user_data;
	const gchar *group_name;
    Contact contact;
    GtkEntry *entry;
	const gchar *tmpStr;
	const gchar *phonenum;
	const gchar *email;
	int i;
    
	memset(&contact, 0, sizeof(Contact));
	
	//family name
    tmpStr = gtk_entry_get_text(entry_familyname);
	strcpy(contact.name.szfamily_name, _to_asc(tmpStr));
	
	//given name
	tmpStr = gtk_entry_get_text(entry_givenname);
	strcpy(contact.name.szgiven_name, _to_asc(tmpStr));
    
    //group
	GtkTreeIter iter;
	
	gtk_combo_box_get_active_iter(combo_group, &iter);
	gtk_tree_model_get(gtk_combo_box_get_model(combo_group), &iter,
					   GROUP_COL, &group_name,
					   -1);
	
	if(!strcmp(group_name, _(DISPLAY_GROUPTYPE_FAMILY)))
		contact.type = GT_FAMILY;
	else if(!strcmp(group_name, _(DISPLAY_GROUPTYPE_COLLEAGUES)))
		contact.type = GT_COLLEAGUES;
	else if(!strcmp(group_name, _(DISPLAY_GROUPTYPE_FRIENDS)))
		contact.type = GT_FRIENDS;
	else if(!strcmp(group_name, _(DISPLAY_GROUPTYPE_RELATIVES)))
		contact.type = GT_RELATIVES;
	else if(!strcmp(group_name, _(DISPLAY_GROUPTYPE_OTHER)))
		contact.type = GT_OTHER;
    else
		contact.type = GT_NONE;
	g_free((gpointer)group_name);
	
    //phone
	//set entry text to store 
	phonenum = gtk_entry_get_text(entry_phonenum);
	gtk_list_store_set (combo_phonenum_store, &current_phonenum_iter,
				        PHONENUM_COL, phonenum,
				        -1);
	
	//save
	if(gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	{   
	    for(i = 0; i < MAX_PHONE_COUNT; i++)
		{
			gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
						       PHONENUM_COL, &phonenum,
						       -1);
			
	        if(phonenum)
	        {
				strcpy(contact.phones[i].szphone, phonenum);	
				g_free((gpointer)phonenum);
			}
			
			contact.phones[i].type = PT_HOME;
			
		    if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_phonenum_store), &iter))
		    {
				break;
		    }
		}
		
		contact.phone_count = get_phonenum_count();
	}
	
    //email
	//set entry text to store 
	email = gtk_entry_get_text(entry_email);
	gtk_list_store_set (combo_email_store, &current_email_iter,
				        EMAIL_COL, email,
				        -1);
	
	//save
	if(gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_email_store), &iter))
	{   
	    for(i = 0; i < MAX_EMAIL_COUNT; i++)
		{
			gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
						       EMAIL_COL, &email,
						       -1);
			
	        if(email)
	        {
				strcpy(contact.emails[i].szemail, email);
				g_free((gpointer)email);
			}
			contact.emails[i].type = EMT_HOME;
			
		    if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_email_store), &iter))
			{
				break;
		    }
		}
		
		contact.email_count = get_email_count();
	} 
	
	//voip
	tmpStr = gtk_entry_get_text(entry_voip);
	strcpy(contact.szvoip, tmpStr);
    
	//im
	tmpStr = gtk_entry_get_text(entry_im);
	strcpy(contact.szim,tmpStr);
    
	//address
    tmpStr = gtk_entry_get_text(entry_address);
	strcpy(contact.szaddress, tmpStr);

	#if 1
	if(mode_info->mode == ADD)
	{
		if(add_contact(&contact))
		{
			show_message_window(_(get_value_from_key(DISPLAY_SAVE_FAIL)));
			goto end;
		}
	}
	else if(mode_info->mode == EDIT)
	{
		if(update_contact_by_index(&contact, mode_info->index))
		{
			show_message_window(_(get_value_from_key(DISPLAY_SAVE_FAIL)));
			goto end;
		}
	}
	
    //sync contact list
	if(sync_contact_list())
    	show_message_window(_(get_value_from_key(DISPLAY_SAVE_SUCCESSFULLY)));
	else
		show_message_window(_(get_value_from_key(DISPLAY_SAVE_FAIL)));

end:
	//close window
	on_button_contact_detail_cancel_clicked(NULL, NULL);
	#endif
}

void on_button_contact_detail_reset_clicked(GtkWidget *window, gpointer user_data)
{	
    if(!(show_confirm_window(_(DISPLAY_RESET_CONFIRM)) ==	GTK_RESPONSE_OK))
   		return;
	
	//family name
    gtk_entry_set_text(entry_familyname, "");
    
	//given name
	gtk_entry_set_text(entry_givenname, "");
	
    //phone num
	gtk_entry_set_text(entry_phonenum, "");
	
	//email
	gtk_entry_set_text(entry_email, "");
	
	//voip
	gtk_entry_set_text(entry_voip, "");
	
	//im
	gtk_entry_set_text(entry_im, "");
	
	//address
    gtk_entry_set_text(entry_address, "");

	#if 0
	gtk_list_store_clear (phonenum_store);
	gtk_list_store_clear (email_store);
	gtk_combo_box_set_model (combo_phonenum_index, GTK_TREE_MODEL(phonenum_store));
	gtk_combo_box_set_model (combo_email_index, GTK_TREE_MODEL(email_store));
	
	gtk_combo_box_set_active (GTK_COMBO_BOX (combo_email_index), 0);
	gtk_combo_box_set_active (GTK_COMBO_BOX (combo_phonenum_index), 0);
	
	#endif
}

//combo event
void on_combobox_contact_detail_phonenum_index_changed(GtkWidget *window, gpointer user_data)
{
    #if 1
	int index;
	const gchar *phonenum;
	int phonenum_index;
	GtkTreeIter iter;
	int i;
	
	if(!combo_phonenum_store)
   	{
	    showDebug("phonenum store is null\n");
    	return;
	}
	
    //save phonenum
	phonenum = gtk_entry_get_text(entry_phonenum);
	gtk_list_store_set (combo_phonenum_store, &current_phonenum_iter,
				        PHONENUM_COL, phonenum,
				        -1);
	
	//change text
	if(!gtk_combo_box_get_active_iter (combo_phonenum_index, &iter))
	{
		showError("get active phonenum iter fail\n");
		return;
	}
    
    gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
				       PHONENUM_COL, &phonenum,
				       PHONENUM_INDEX_COL, &phonenum_index,
		    	       -1);
	
	if(!phonenum)
	{
		showDebug("change: phonenum is null\n");
		gtk_entry_set_text(entry_phonenum, "");
	}
	else
	{
		showDebug("phonenum is not null\n");
		gtk_entry_set_text(entry_phonenum, phonenum);
		showDebug("phonenum: %s\n", phonenum);
		showDebug("phonenum_index: %d\n", phonenum_index);
	}
	
	gtk_combo_box_get_active_iter (combo_phonenum_index, &current_phonenum_iter);
	#endif
}

void on_combobox_contact_detail_email_index_changed(GtkWidget *window, gpointer user_data)
{
    #if 1
	int index;
	int email_index;
	const gchar *email;
	GtkTreeIter iter;
	int i;
	
	if(!combo_email_store)
   	{
	    showDebug("email store is null\n");
    	return;
	}

    //save phonenum 
	email = gtk_entry_get_text(entry_email);
	gtk_list_store_set (combo_email_store, &current_email_iter,
				        EMAIL_COL, email,
				        -1);
	
	//change text
	if(!gtk_combo_box_get_active_iter (combo_email_index, &iter))
	{
	    showDebug("get active email iter fail\n");
    	return;
	}
    gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
				       EMAIL_COL, &email,
				       EMAIL_INDEX_COL, &email_index,
				       -1);
	
	if(!email)
	{
		showDebug("change: email is null\n");
		gtk_entry_set_text(entry_email, "");
	}
	else
	{
		showDebug("phonenum is not null\n");
		gtk_entry_set_text(entry_email, email);
		showDebug("email: %s\n", email);
		showDebug("email_index: %d\n", email_index);
	}
	//
	gtk_combo_box_get_active_iter (combo_email_index, &current_email_iter);
	#endif
}

void on_combobox_contact_detail_phonenum_index_move_active(GtkWidget *window, gpointer user_data)
{
	showDebug("phone move active evnet\n");
}

void on_combobox_contact_detail_email_index_move_active(GtkWidget *window, gpointer user_data)
{
    showDebug("email move active evnet\n");
}

void on_combobox_contact_detail_phonenum_index_popdown(GtkWidget *window, gpointer user_data)
{
	showDebug("phone popdown evnet\n");
}

void on_combobox_contact_detail_phonenum_index_popup(GtkWidget *window, gpointer user_data)
{
	showDebug("phone popup evnet\n");
}

void on_combobox_contact_detail_email_index_popdown(GtkWidget *window, gpointer user_data)
{
	showDebug("email popdown evnet\n");
}

void on_combobox_contact_detail_email_index_popup(GtkWidget *window, gpointer user_data)
{
	showDebug("email popup evnet\n");
}

//combo button
void on_button_contact_detail_addPhonenum_clicked(GtkWidget *window, gpointer user_data)
{
    int i;
	int index;
	const gchar *phonenum;
	GtkTreeIter iter;
	
    //phonenum
    phonenum = gtk_entry_get_text(entry_phonenum);
	
	if(strlen(phonenum) == 0)
    {
		show_message_window(_(get_value_from_key(DISPLAY_CAN_NOT_EMPTY)));
		return;
	}

	if(get_phonenum_index_count() == MAX_PHONE_COUNT)
	{
	    show_message_window(_(get_value_from_key(DISPLAY_EXCEED_LIMIT)));
		return;
	}
	
	if(!gtk_combo_box_get_active_iter (combo_phonenum_index, &iter))
	{
        printf("get active phonenum iter fail\n");
		return;
	}
	
	if(combo_phonenum_store == NULL)
		return;
	
	//save 
	gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
				       PHONENUM_INDEX_COL, &index,
				       -1);
	
    add_phonenum_to_store(phonenum , index);
    #if 1
	
	//check 
	if(get_phonenum_count() != get_phonenum_index_count())
	{
		show_message_window(_(get_value_from_key(DISPLAY_UNFINISHED_INPUT)));
		return;
	}
	
	//add index
	add_phonenum_index_to_store();
    gtk_combo_box_set_model (combo_phonenum_index, GTK_TREE_MODEL(combo_phonenum_store));
	gtk_combo_box_set_active (combo_phonenum_index, get_phonenum_index_count() - 1);
	#endif
}

void on_button_contact_detail_addEmail_clicked(GtkWidget *window, gpointer user_data)
{
    #if 1
	int i;
	int index;
	const gchar *email;
	GtkTreeIter iter;
	
    //phonenum
    email = gtk_entry_get_text(entry_email);
	
	if(strlen(email) == 0)
    {
		show_message_window(_(get_value_from_key(DISPLAY_CAN_NOT_EMPTY)));
		return;
	}
	
	if(get_email_index_count() == MAX_EMAIL_COUNT)
	{
	    show_message_window(_(get_value_from_key(DISPLAY_EXCEED_LIMIT)));
		return;
	}

	if(!gtk_combo_box_get_active_iter (combo_email_index, &iter))
	{
        showDebug("get active email iter fail\n");
		return;
	}
	
	if(combo_email_store == NULL)
		return;
	
	//save 
	gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
				       EMAIL_INDEX_COL, &index,
				       -1);
	
    add_email_to_store(email , index);
    #if 1
	
	//check 
	if(get_email_count() != get_email_index_count())
	{
		show_message_window(_(get_value_from_key(DISPLAY_UNFINISHED_INPUT)));
		return;
	}
	
	//add index
	add_email_index_to_store();
    gtk_combo_box_set_model (combo_email_index, GTK_TREE_MODEL(combo_email_store));
	gtk_combo_box_set_active (combo_email_index, get_email_index_count() - 1);
    #endif
	#endif
}

/********************************************************************************
                                                       group combo
********************************************************************************/
GtkTreeModel* fill_group_store()
{
    #if 1
    int i;
	GtkTreeIter iter;
	char label[5][32] = { DISPLAY_GROUPTYPE_FAMILY,
 		                  DISPLAY_GROUPTYPE_RELATIVES,
 		                  DISPLAY_GROUPTYPE_COLLEAGUES,
		                  DISPLAY_GROUPTYPE_FRIENDS,
		                  DISPLAY_GROUPTYPE_OTHER};
	
    if(combo_group_store == NULL)
    	combo_group_store = gtk_list_store_new(1, G_TYPE_STRING);
    
	for(i = 0; i < 5; i++)
	{
		gtk_list_store_append (combo_group_store, &iter);
		gtk_list_store_set (combo_group_store, &iter,
					        GROUP_COL, _(label[i]),
					        -1);
	}
	#endif
	
	return GTK_TREE_MODEL (combo_group_store);
}

/********************************************************************************
                                                    phonenum combo
********************************************************************************/
//phonenum store
int get_phonenum_count()
{
	char *phonenum;
	GtkTreeIter iter;
	int i;
	
	if(combo_phonenum_store == NULL)
    	return 0;
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &iter))
		return 0;

	
	for(i = 0; i < MAX_PHONE_COUNT; i++)
	{   
		gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
					       PHONENUM_COL, &phonenum,
					       -1);
		
	    if(!phonenum)
	    	return i;
	    
		if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	    	return i + 1;
	}
	
	return MAX_PHONE_COUNT;
}

int get_phonenum_index_count()
{
	char *phonenum;
	GtkTreeIter iter;
	int i;
	
	if(combo_phonenum_store == NULL)
	{
		showDebug(" phonenum store is null\n");	
    	return 0;
	}
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	{
	    //showDebug("get first phonenum iter fail\n");
		return 0;
	}
	
	for(i = 0; i < MAX_PHONE_COUNT; i++)
	{   
		gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
					       PHONENUM_COL, &phonenum,
					       -1);
		
	    if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	    {
	        showDebug("phone index count: %d\n", i + 1);
			return i + 1;
	    }
	}
	
	return MAX_PHONE_COUNT;
}

int add_phonenum_to_store(char *phonenum, int display_index_para)
{	
    #if 1
    int i;
	int display_index;
	GtkTreeIter iter;
	
	if(combo_phonenum_store == NULL)
	    combo_phonenum_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING);
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	{
	    showDebug("get first phonenum iter fail\n");
		return -1;
	}
	
	for(i = 0; i < MAX_PHONE_COUNT; i++)
	{   
		gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
					       PHONENUM_INDEX_COL, &display_index,
					       -1);
		
		if(display_index == display_index_para)
			gtk_list_store_set (combo_phonenum_store, &iter,
		             			//  PHONENUM_INDEX_COL, phonenum_count,
				                PHONENUM_COL, phonenum,
				                -1);
		
		if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_phonenum_store), &iter))
			return -1;;
	}
   	
	#endif
	
	return 0;
}

int add_phonenum_index_to_store()
{	
    #if 1
    int i;
	GtkTreeIter iter;
	
	if(combo_phonenum_store == NULL)
	    combo_phonenum_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING);

    if(get_phonenum_index_count() != get_phonenum_count())
    {
		showWarning("index count != phonenum count\n");
		return -1;
	}
	
    //phonenum_count = get_phonenum_count();
    gtk_list_store_append (combo_phonenum_store, &iter);
	gtk_list_store_set (combo_phonenum_store, &iter,
		                PHONENUM_INDEX_COL, get_phonenum_count() + 1,
				        -1);
	#endif
	
	return 0;
}

char *get_phonenum_by_index(int index)
{
	char *phonenum;
	GtkTreeIter iter;
	int i;
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	{
	    showError("get first iter error\n");
		return NULL;
	}
	for(i = 0; i < MAX_PHONE_COUNT; i++)
	{   
		gtk_tree_model_get(GTK_TREE_MODEL(combo_phonenum_store), &iter,
					       PHONENUM_COL, &phonenum,
					       -1);
		
		if(i == index)
			return phonenum;

		g_free(phonenum);
		
	    if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_phonenum_store), &iter))
	    {
	        showDebug("phonum count: %d\n", i + 1);
			return NULL;
	    }
	}
}

/********************************************************************************
                                                       email combo
********************************************************************************/
//phonenum store
int get_email_count()
{
	char *email;
	GtkTreeIter iter;
	int i;

	if(combo_email_store == NULL)
	{
	    showDebug("email store is null\n");
		return 0;
	}
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_email_store), &iter))
	{   
	    //showDebug("get first email iter fail\n");
		return 0;
	} 
	
	for(i = 0; i < MAX_EMAIL_COUNT; i++)
	{	
		gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
						   EMAIL_COL, &email,
						   -1);
		
		if(!email)
			return i;

		g_free(email);
		
		if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_email_store), &iter))
			return i + 1;
	}
	
	return MAX_EMAIL_COUNT;
}

int get_email_index_count()
{
	char *email;
	GtkTreeIter iter;
	int i;

	if(combo_email_store == NULL)
	{
	    showDebug("email store is null\n");
		return 0;
	}
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_email_store), &iter))
	{   
	    //showDebug("get first email iter fail\n");
		return 0;
	} 

	for(i = 0; i < MAX_EMAIL_COUNT; i++)
	{	
		gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
						   EMAIL_COL, &email,
						   -1);

		g_free(email);
		if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_email_store), &iter))
		{
			//printf("phone index count: %d\n", i + 1);
			
			return i + 1;
		}
	}
	
	return MAX_EMAIL_COUNT;
}

int add_email_to_store(char *email, int index_para)
{
#if 1
	int i;
	int index;
	GtkTreeIter iter;
	
	if(combo_email_store == NULL)
	    combo_email_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING);
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_email_store), &iter))
	{   
	    showDebug("get first email iter fail\n");
		return -1;
	} 
	
	for(i = 0; i < MAX_EMAIL_COUNT; i++)
	{	
		gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
						   EMAIL_INDEX_COL, &index,
						   -1);
	
		if(index == index_para)
			gtk_list_store_set (combo_email_store, &iter,
								EMAIL_COL, email,
								-1);
		
		if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_email_store), &iter))
			return -1;
	}
	
#endif
	
	return 0;
}

int add_email_index_to_store()
{
#if 1
	int i;
	GtkTreeIter iter;
	
	if(combo_email_store == NULL)
	    combo_email_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING);

    if(get_email_index_count() != get_email_count())
    {
		showDebug("index count != email count\n");
		return -1;
	}
	
	gtk_list_store_append (combo_email_store, &iter);
	gtk_list_store_set (combo_email_store, &iter,
						EMAIL_INDEX_COL, get_email_count() + 1,
						-1);
#endif
	
	return 0;
}

char *get_email_by_index(int index)
{
	char *email;
	GtkTreeIter iter;
	int i;
	
	if(!gtk_tree_model_get_iter_first(GTK_TREE_MODEL(combo_email_store), &iter))
	{   
	    showDebug("get first email iter fail\n");
		return NULL;
	} 
	
	for(i = 0; i < MAX_EMAIL_COUNT; i++)
	{	
		gtk_tree_model_get(GTK_TREE_MODEL(combo_email_store), &iter,
						   EMAIL_COL, &email,
						   -1);
		
		if(i == index)
			return email;
		
		if(!gtk_tree_model_iter_next(GTK_TREE_MODEL(combo_email_store), &iter))
		{
		    g_free(email);
			return NULL;
		}
	}
}


void* release_resource(void)
{
	
}

void selection_changed(GtkTreeSelection *selection)
{
	
}


int validate_input()
{
	if(strlen(gtk_entry_get_text(entry_familyname)) == 0)
    {
		show_message_window(_(get_value_from_key(DISPLAY_CAN_NOT_EMPTY)));
		return -1;
	}

	if(strlen(gtk_entry_get_text(entry_givenname)) == 0)
    {
		show_message_window(_(get_value_from_key(DISPLAY_CAN_NOT_EMPTY)));
		return -1;
	}

	if(strlen(gtk_entry_get_text(entry_phonenum)) == 0)
    {
		show_message_window(_(get_value_from_key(DISPLAY_CAN_NOT_EMPTY)));
		return -1;
	}

	Contact contact;
    const gchar* family_name;
	const gchar* given_name;
    const char full_name[64];
	
    //family name
    family_name = gtk_entry_get_text(entry_familyname);
	
	//given name
	given_name = gtk_entry_get_text(entry_givenname);

	sprintf(full_name, "%s%s", family_name, given_name);
	if(!get_contact_by_name(&contact, full_name))
	{
		show_message_window(_(get_value_from_key(DISPLAY_NAME_EXISTED)));
		return -1;
	}
	
	return 0;
}

int sync_contact_list()
{
    gtk_list_store_clear(store);
	gtk_tree_view_set_model(contact_treeview, fill_contact_store(store));
}

int show_contact_detail_window(ContactDetailMode mode_val, gpointer *pdata)
{	
	GtkBuilder *builder;
	GtkWidget *window;
	Contact contact;
	GtkEntry *entry;
	GtkWidget *button_save;
	int index;
	GtkTreeModel *model;
	GtkTreeIter iter;
	GtkCellRenderer *renderer;
	GtkTreeSelection *selection;
    ModeInfo *mode_info = (ModeInfo *)malloc(sizeof(ModeInfo));
	int i;
    
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file(builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_contact_detail"));
    gtk_window_move(GTK_WINDOW(window), 200, 0);
    
	put_window_into_stack(window);
    
	button_save = GTK_WIDGET(gtk_builder_get_object(builder, "button_contact_detail_save"));
	
	#if 1
    //edit mode
    if(mode_val == ADD)
    {    
    	//family name
		entry_familyname = (GtkEntry *)gtk_builder_get_object(builder, "entry_familyname");
	    
		//given name
	    entry_givenname = (GtkEntry *)gtk_builder_get_object(builder, "entry_givenname");
		
		//phone num
		entry_phonenum = (GtkEntry *)gtk_builder_get_object(builder, "entry_phonenum");
		
        if(pdata != NULL)
	    	gtk_entry_set_text(entry_phonenum, (const gchar *)pdata);
	    
		//email
		entry_email = (GtkEntry *)gtk_builder_get_object(builder, "entry_email");
		
		//voip
		entry_voip = (GtkEntry *)gtk_builder_get_object(builder, "entry_voip");
		
		//im
		entry_im = (GtkEntry *)gtk_builder_get_object(builder, "entry_im");
		
		//address
		entry_address = (GtkEntry *)gtk_builder_get_object(builder, "entry_address");
	 	
        //group combo
		combo_group = (GtkComboBox *)gtk_builder_get_object(builder, "combobox_concact_detail_group");
		
		gtk_combo_box_set_model (combo_group, fill_group_store(combo_group_store));
        
		renderer = gtk_cell_renderer_text_new ();
		gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_group), renderer, TRUE);
		gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_group), renderer,
										"text", GROUP_COL,
										NULL);
		
		gtk_combo_box_set_active (GTK_COMBO_BOX (combo_group), 0);
		
		
		//phone num index combo
 		combo_phonenum_index = (GtkComboBox *)gtk_builder_get_object(builder, "combobox_contact_detail_phonenum_index");
		
	    add_phonenum_index_to_store();
        
		gtk_combo_box_set_model (combo_phonenum_index, GTK_TREE_MODEL(combo_phonenum_store));
        
		renderer = gtk_cell_renderer_text_new ();
		gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_phonenum_index), renderer, TRUE);
		gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_phonenum_index), renderer,
										"text", PHONENUM_INDEX_COL,
										NULL);
		
		gtk_combo_box_set_active (GTK_COMBO_BOX (combo_phonenum_index), 0);
        gtk_combo_box_get_active_iter (combo_phonenum_index, &current_phonenum_iter);
		
		
		//email index combo
		combo_email_index = (GtkComboBox *)gtk_builder_get_object(builder, "combobox_contact_detail_email_index");
		
	    add_email_index_to_store();
        
		gtk_combo_box_set_model (combo_email_index, GTK_TREE_MODEL(combo_email_store));
        
		renderer = gtk_cell_renderer_text_new ();
		gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_email_index), renderer, TRUE);
		gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_email_index), renderer,
										"text", EMAIL_INDEX_COL,
										NULL);
        		
		gtk_combo_box_set_active (GTK_COMBO_BOX (combo_email_index), 0);
		gtk_combo_box_get_active_iter (combo_email_index, &current_email_iter);
    }
	else if(mode_val == EDIT)
	{
	    #if 1
	    memset(&contact, 0, sizeof(Contact));

		selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(contact_treeview));
		if(gtk_tree_selection_get_selected(selection, &model, &iter))
		{
		    gtk_tree_model_get(model, &iter,
		                       CONTACT_INDEX_COL, &index,
		                       -1);
			
	        get_contact_by_index(&contact, index);
	    }
		
		//family name
		entry_familyname = (GtkEntry *)gtk_builder_get_object(builder, "entry_familyname");
	    gtk_entry_set_text(entry_familyname, _(contact.name.szfamily_name));
        
		//given name
	    entry_givenname = (GtkEntry *)gtk_builder_get_object(builder, "entry_givenname");
		gtk_entry_set_text(entry_givenname, _(contact.name.szgiven_name));

        //phone num
		entry_phonenum = (GtkEntry *)gtk_builder_get_object(builder, "entry_phonenum");

		//email
		entry_email = (GtkEntry *)gtk_builder_get_object(builder, "entry_email");
	    
		//voip
		entry_voip = (GtkEntry *)gtk_builder_get_object(builder, "entry_voip");
		gtk_entry_set_text(entry_voip, contact.szvoip);
		
		//im
		entry_im = (GtkEntry *)gtk_builder_get_object(builder, "entry_im");
		gtk_entry_set_text(entry_im, contact.szim);
		
		//address
		entry_address = (GtkEntry *)gtk_builder_get_object(builder, "entry_address");
	    gtk_entry_set_text(entry_address, contact.szaddress);


		//group combo
		combo_group = (GtkComboBox *)gtk_builder_get_object(builder, "combobox_concact_detail_group");
		
		gtk_combo_box_set_model (combo_group, fill_group_store(combo_group_store));
        
		renderer = gtk_cell_renderer_text_new ();
		gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_group), renderer, TRUE);
		gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_group), renderer,
										"text", GROUP_COL,
										NULL);
		
        if(contact.type == GT_FAMILY)
			gtk_combo_box_set_active (GTK_COMBO_BOX (combo_group), 0);
		else if(contact.type == GT_RELATIVES)
			gtk_combo_box_set_active (GTK_COMBO_BOX (combo_group), 1);
		else if(contact.type == GT_COLLEAGUES)
			gtk_combo_box_set_active (GTK_COMBO_BOX (combo_group), 2);
		else if(contact.type == GT_FRIENDS)
			gtk_combo_box_set_active (GTK_COMBO_BOX (combo_group), 3);
		else if(contact.type == GT_OTHER)
			gtk_combo_box_set_active (GTK_COMBO_BOX (combo_group), 4);

		//phone num index combo
 		combo_phonenum_index = (GtkComboBox *)gtk_builder_get_object(builder, "combobox_contact_detail_phonenum_index");
		
	    add_phonenum_index_to_store();
        
		gtk_combo_box_set_model (combo_phonenum_index, GTK_TREE_MODEL(combo_phonenum_store));
        
		renderer = gtk_cell_renderer_text_new ();
		gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_phonenum_index), renderer, TRUE);
		gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_phonenum_index), renderer,
										"text", PHONENUM_INDEX_COL,
										NULL);
		
		for(i = 0; i < contact.phone_count; i++)
		{
			add_phonenum_index_to_store();
            add_phonenum_to_store(contact.phones[i].szphone, i + 1);
		}

		showDebug("phone count: %d\n", contact.phone_count);
		//gtk_combo_box_set_active (GTK_COMBO_BOX (combo_phonenum_index), 1);
		gtk_combo_box_set_model (combo_phonenum_index, GTK_TREE_MODEL(combo_phonenum_store));
        gtk_combo_box_get_active_iter (combo_phonenum_index, &current_phonenum_iter);
		
		//email index combo
		combo_email_index = (GtkComboBox *)gtk_builder_get_object(builder, "combobox_contact_detail_email_index");
		
	    add_email_index_to_store();
        
		gtk_combo_box_set_model (combo_email_index, GTK_TREE_MODEL(combo_email_store));
        
		renderer = gtk_cell_renderer_text_new ();
		gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_email_index), renderer, TRUE);
		gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_email_index), renderer,
										"text", EMAIL_INDEX_COL,
										NULL);
		
        for(i = 0; i < contact.email_count; i++)
		{
			add_email_index_to_store();
            add_email_to_store(contact.emails[i].szemail, i + 1);
		}

		showDebug("email count: %d\n", contact.email_count);
		//gtk_combo_box_set_active (GTK_COMBO_BOX (combo_email_index), 1);
		gtk_combo_box_set_model (combo_email_index, GTK_TREE_MODEL(combo_email_store));
		gtk_combo_box_get_active_iter (combo_email_index, &current_email_iter);
		
		#endif
	}
	
	//event
	if(mode_val == ADD)
	{
	    mode_info->index = -1;
        mode_info->mode = ADD;
		
		g_signal_connect(G_OBJECT (button_save), "clicked",
                 		 G_CALLBACK (on_button_contact_detail_save_clicked),
		                 mode_info);
	}
	else if(mode_val == EDIT)
	{
    	mode_info->index = index;
		mode_info->mode = EDIT;
		
		g_signal_connect(G_OBJECT (button_save), "clicked",
                  		 G_CALLBACK (on_button_contact_detail_save_clicked),
						 mode_info);
	}
	
	gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	#endif
	//show
	show_top_window();
		
	return 0;
}

int show_contact_window()
{
    GtkBuilder *builder;
	GtkWidget *window;
	GtkTreeViewColumn *column_index;
	GtkTreeViewColumn *column_name;
	GtkCellRenderer *cell_renderer;
	GtkTreeSelection *selection;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_contact"));
	
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	put_window_into_stack(window);

	//add  model to tree view
	store = create_contact_store();
	
	contact_treeview = (GtkTreeView *)gtk_builder_get_object(builder, ("treeview_contactlist"));
	gtk_tree_view_set_model(contact_treeview, fill_contact_store(store));
	
	//column  
	column_index = gtk_tree_view_column_new();
	column_name = gtk_tree_view_column_new();
    gtk_tree_view_column_set_title(column_name, _(DISPLAY_CONTACT));
    
	//index cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_index,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_index, cell_renderer,
		                              	    set_index, NULL, NULL);
	
	//name cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_name,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_name, cell_renderer,
		                              	    set_name, NULL, NULL);

	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(contact_treeview),
					            column_index);
	gtk_tree_view_append_column(GTK_TREE_VIEW(contact_treeview),
					            column_name);

    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();
	
	return 0;
}

