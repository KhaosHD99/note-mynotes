#ifndef COMMON_PHONE_DEF
#define COMMON_PHONE_DEF

#include "lpconfig.h"
#include <pthread.h>
#include "phonebookinfo.h"

class CCommonphoneManager
{		
	private:
		LpConfig *commonphone_lpconfig;
		pthread_mutex_t mutex;
		static CCommonphoneManager *commonphone_instance;
		Commonphone **commonphone_buf;
		int buf_count;
		
	private:
		CCommonphoneManager();
		~CCommonphoneManager();
		void init();
		void uninit();
		Commonphone* get_section_from_config_file(int index);
		
        //mutex
		int init_mutex();
		void lock_mutex();
		void unlock_mutex();
	public:
		static CCommonphoneManager *get_instance();
			
		int load_commonphone_from_file();
		int get_commonphone_count();
		int get_commonphone_by_index(Commonphone *commonphone, int index);
	    //const char *get_value_from_key(const char *key);
};
#endif

