#ifndef CONFIG_DEF
#define CONFIG_DEF

#include "lpconfig.h"
#include <pthread.h>
#include "phonebookinfo.h"

class CConfigManager
{
	private:
		LpConfig *config_lpconfig;
		pthread_mutex_t mutex;
		static CConfigManager *config_instance;
		
	private:
		CConfigManager();
		~CConfigManager();
		void init();
		void uninit();

	public:
		static CConfigManager *get_instance();
		
	    const char *get_value_from_key(const char *key);
};
#endif
