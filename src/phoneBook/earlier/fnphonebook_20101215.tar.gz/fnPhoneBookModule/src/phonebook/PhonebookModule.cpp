#include "PhonebookModule.h"
#include "CCST.hpp"

/********************************************************************************
                                      					get instance
********************************************************************************/
PhonebookModule* PhonebookModule::adverModule_instance = NULL;
PhonebookModule* PhonebookModule::get_instance(VialSystem *vialSys)
{	
	if(vialSys == NULL)
	{	
		showWarning("vialSys null, creat prompter module failed!\r\n");
		return NULL;	
	}	
	
	if(!adverModule_instance)
			adverModule_instance = new PhonebookModule(vialSys);
		
	return adverModule_instance;
}

/**************************************************************
**PrompterModule
**(�绰״̬)��ʾģ��
**
**************************************************************/
PhonebookModule::PhonebookModule(VialSystem *vialSys) : AbstractModule(vialSys)
{
	this->vialSys = vialSys;
}

/**************************************************************
**run
**����runѭ��
**
**************************************************************/
void PhonebookModule::run()
{
	vialSys->run();
}

/**************************************************************
**localInit
**ģ���ڲ���ʼ��
**�ú�����init()����
**************************************************************/
bool PhonebookModule::localInit()
{
	showInfo("%s localInit\n", __CLASS__);
	memset(&PhoneCode, 0, sizeof(PhoneCode));
	
	return true;
}

/**************************************************************
**onExit
**����״̬�ı���Ϣ
**�ڲ����д���״̬
**************************************************************/
bool PhonebookModule::onExit()
{
	showInfo("%s onExit\n", __CLASS__);
	return false;
}

bool PhonebookModule::post_vial(Vial *vial, NodeID dstID)
{
	vialSys->postVial(vial, dstID);
	memset(&PhoneCode, 0, sizeof(PhoneCode));
}

/**************************************************************
1.	����  			[ON_HOOK, NON_PHONE] 				: StateChangeVial
2.	ժ��  			[OFF_HOOK, V_PHONE] 				: StateChangeVial
3.	��������		[OFF_HOOK, V_PHONE, ����] 	: StateDailVial
4.	����״̬		[RRINGING�� V_PHONE]				: StateChangeVial
5.	����״̬		[NOVIDEO_CONN�� V_PHONE]		: StateChangeVial

6. �������			[RINGING, V_PHONE, ����]		: CallerIDVial 
7. �һ�					[ON_HOOK, NON_PHONE]				: StateChangeVial
8. ��ͨ..  			[VIDEO_CONN, NON_PHONE]			: StateChangeVial
**************************************************************/
bool PhonebookModule::OnReceive(Vial *inputVial)
{	
	/*Vial *vial;
	
	vial = VialFactory_Phonebook::createVialByCopy(inputVial);
	if (vial == NULL)
	{
		showWarning("Vial is NULL\n");
		delete vial;
		return false;
	}*/
	
	#if 1
	switch (inputVial->vialType)
	{
		case GETVT(StateChangeVial):
			return on_vial_state_change((StateChangeVial *)inputVial);
		case GETVT(DialNotifyVial):
			return on_vial_dial_notify((DialNotifyVial *)inputVial);
		case GETVT(CallerPhoneCodeVial):
			return on_vial_caller_phonecode((CallerPhoneCodeVial *)inputVial);
		
		default:
			printf("Can not distiguish vial\n");
			return false;
	}
	#endif
	
	return false;
}

bool PhonebookModule::on_vial_state_change(StateChangeVial *vial)
{	
	if(!vial)
	{
		printf("StateChangeVial is NULL\n");	
	}
	
	printf("curState: %s, oldState: %s\n", STATE_INFO[vial->curState.st],
										   STATE_INFO[vial->oldState.st]);
	
	if(vial->curState.st == CCST::ON_HOOK && 
	   vial->oldState.st == CCST::DIALING)
	{	
		printf("Clear Dial Num Buf\n");
		memset(&PhoneCode, 0, sizeof(PhoneCode));
		
		showInfo("%s, PhoneCode: %s, CodeLen: %d\n", __FUNCTION__, 
													 PhoneCode.cPhoneCode,
													 PhoneCode.nCodelen);
	}	
	
	return true;
}

bool PhonebookModule::on_vial_dial_notify(DialNotifyVial *vial)
{		
	printf("Get DialNotifyVial, code: %c\n", vial->code);
	
	Contact contact;
	char full_name[64];
	memset(&contact, 0, sizeof(Contact));
	
	PhoneCode.cPhoneCode[PhoneCode.nCodelen] = vial->code;
	
	if(PhoneCode.nCodelen >= (VIAL_PHONECODE_LEN - 1))
	{
		showWarning("phoneCode too long [%d:%d%s]\n", PhoneCode.nCodelen, VIAL_PHONECODE_LEN-1, PhoneCode.cPhoneCode);
		return true;
	}

	showInfo("CodeLen: %d\n", PhoneCode.nCodelen);
	
	PhoneCode.nCodelen++;
	PhoneCode.cPhoneCode[PhoneCode.nCodelen]= '\0';	
	
	showInfo("%s, phoneCode: %d -> %s, CodeLen: %d\n", __FUNCTION__, 
													   vial->code-'0', 
													   PhoneCode.cPhoneCode,
													   PhoneCode.nCodelen);
	
	if(!get_contact_by_phone(&contact, PhoneCode.cPhoneCode))
	{	
		sprintf(full_name, "%s%s", contact.name.szfamily_name, contact.name.szgiven_name);
		printf("name: %s\n", full_name);
		
		ContactPrompterVial contact_prompter_vial;
		strcpy(contact_prompter_vial.szContactName, full_name);
		strcpy(contact_prompter_vial.szPhoneNum, PhoneCode.cPhoneCode);
		
		post_vial(&contact_prompter_vial, FN_PROMPTER_MODULE_ID);
	}	
	else
		printf("Get Nothing\n");
						
	return true;	
}

bool PhonebookModule::on_vial_caller_phonecode(CallerPhoneCodeVial *vial)
{
	printf("Get CallerPhoneCodeVial, phonecode: %s\n", vial->cPhoneCode);

	#if 0
	if(vial)
	{
		showWarning("%s::%s\n", __CLASS__, __FUNCTION__);
		PhoneCode.nCallType = 0;
		strncpy(PhoneCode.cPhoneCode, vial->cPhoneCode, VIAL_PHONECODE_LEN-1);
		PhoneCode.nCodelen = vial->nLen;
		PhoneCode.cPhoneCode[PhoneCode.nCodelen]= '\0';	
	}
	else
		showWarning("%s::%s, vial null\n", __CLASS__, __FUNCTION__);
	#endif

	return true;
}

int PhonebookModule::get_contact_info_by_phonenum(Contact *contact, const char *phonenum)
{
	printf("%s\n", __FUNCTION__);
	char full_name[64];
	
	//memset(&contact, 0, sizeof(Contact));
	if(!get_contact_by_phone(contact, phonenum))
	{
		sprintf(full_name, "%s%s", contact->name.szfamily_name, contact->name.szgiven_name);
		printf("Get Contact: %s\n", full_name);
	}
	else
	{
		printf("Can not get contact\n");
		//sprintf(phonenum, "%s", vial->phonenum);
	}
}

/**************************************************************
						onVialStateChang
**************************************************************/
#if 0
bool PhonebookModule::on_vial_state_change(StateChangeVial *vial)
{
    #if 0
	if(vial == NULL)
	{	
		printf("Vial is Null\n");
		return false;
	}
	else
	{
	    #if 1
		switch(vial->curState.st)
		{		
			case CCST::ON_HOOK:	
				if(vial->oldState.st == CCST::ON_HOOK)
				{
					showDebug("Invalid State : PP_ON_HOOK\n");
					return -1;
				}
				break;
			case CCST::DIALING:
				if(vial->oldState.st == CCST::DIALING||
				   vial->oldState.st == CCST::RINGING||
				   vial->oldState.st == CCST::NOVIDEO_CONN||
				   vial->oldState.st == CCST::VIDEO_CONN)
				{
					showDebug("Invalid State : PP_OFF_HOOK\n");
					return -1;
				}
				break;
			case CCST::RINGING:
				if(vial->oldState.st == CCST::RINGING ||
				   vial->oldState.st == CCST::DIALING ||
				   vial->oldState.st == CCST::NOVIDEO_CONN ||
				   vial->oldState.st == CCST::VIDEO_CONN)
				{
					showDebug("Invalid State : PP_RINGING\n");
					return -1;
				}
				break;
			case CCST::NOVIDEO_CONN:
				if( vial->oldState.st == CCST::NOVIDEO_CONN ||
					vial->oldState.st == CCST::ON_HOOK ||
					vial->oldState.st == CCST::VIDEO_CONN)
				{
					showDebug("Invalid State : PP_CONNECT\n");
					return -1;
				}
				break;
			case CCST::VIDEO_CONN:
				if( vial->oldState.st == CCST::VIDEO_CONN||
					vial->oldState.st == CCST::ON_HOOK ||
					vial->oldState.st == CCST::NOVIDEO_CONN)
				{
					showDebug("Invalid State : PP_CONNECT\n");
					return -1;
				}
				break;
				
			default:
				return false;
		}
	    #endif
	}
	#endif
}
#endif

/************************************************************************************
									onOnHook 
*************************************************************************************/
bool PhonebookModule::on_on_hook(StateChangeVial *vial)
{	
    #if 0
	showDebug("%s, stateVal: %d\n", __FUNCTION__, vial->curState);
	AdverManager *adverManager = AdverManager::get_instance();
	
	pthread_mutex_lock(&(adverManager->mutex));
	adverManager->phoneState = CCST::ON_HOOK;
	pthread_mutex_unlock(&(adverManager->mutex));
	
	sem_post(&(adverManager->timeSem));	
	return true; 
	#endif
}

/**************************************************************
							on_dialing
**************************************************************/
bool PhonebookModule::on_dialing(StateChangeVial *vial)
{
    #if 0
	showDebug("%s, stateVal: %d\n", __FUNCTION__, vial->curState);
	AdverManager *adverManager = AdverManager::get_instance();

	pthread_mutex_lock(&(adverManager->mutex));
	adverManager->phoneState = CCST::DIALING;
	pthread_mutex_unlock(&(adverManager->mutex));
	
	sem_post(&(adverManager->timeSem));	
	return true; 
	#endif
}

/**********************************************************************************************
						               	onRinging
***********************************************************************************************/
bool PhonebookModule::on_ringing(StateChangeVial *vial)
{
    #if 0
	showDebug("%s, stateVal: %d\n", __FUNCTION__, vial->curState);

	AdverManager *adverManager = AdverManager::get_instance();
	pthread_mutex_lock(&(adverManager->mutex));
	adverManager->phoneState = CCST::RINGING;
	pthread_mutex_unlock(&(adverManager->mutex));
	
	sem_post(&(adverManager->timeSem));	
	return true; 
	#endif
}

/************************************************************************************************
					                               	onNoVideoConn
*************************************************************************************************/
bool PhonebookModule::on_novideoconn(StateChangeVial *vial)
{	
    #if 0
	showDebug("%s, stateVal: %d\n", __FUNCTION__, vial->curState);
	AdverManager *adverManager = AdverManager::get_instance();

	pthread_mutex_lock(&(adverManager->mutex));
	adverManager->phoneState = CCST::NOVIDEO_CONN;
	pthread_mutex_unlock(&(adverManager->mutex));
	
	sem_post(&(adverManager->timeSem)); 
	return true; 
	#endif
}

