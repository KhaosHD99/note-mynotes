set -x
aclocal
libtoolize -c -f
autoheader
autoconf
automake --foreign --add-missing --copy
