#include "contact.hpp"
#include "calllog.hpp"
#include "string.h"

/**************************************************************************************************/
/**************************************** contact *************************************************/
/**************************************************************************************************/

extern "C" int get_contact_by_index(Contact *contact,	int index)
{
		CContactManager *manager = CContactManager::get_instance();
    manager->get_contact_by_index(contact, index);
		
    return 0;
}		
	 
extern "C" int get_contact_by_name(Contact *contact,	const char *szname)
{
		CContactManager *manager = CContactManager::get_instance();
    manager->get_contact_by_name(contact, szname);
		
    return 0;
}

extern "C" int get_contact_by_letter(Contact *contact, const char *szletter) 
{
		CContactManager *manager = CContactManager::get_instance();
    manager->get_contact_by_letter(contact, szletter);
		
    return 0;
}

extern "C" int get_contact_by_phone(Contact *contact,	const char *szphone) 
{
		CContactManager *manager = CContactManager::get_instance();
    manager->get_contact_by_phone(contact, szphone);
		
    return 0;
}			 									

extern "C" int add_contact(Contact* contact)
{
    CContactManager *manager = CContactManager::get_instance();
    manager->add_contact(contact);
		
    return 0;
}

extern "C" int add_contact_by_index(Contact *contact, int index)
{
		CContactManager *manager = CContactManager::get_instance();
    manager->add_contact_by_index(contact, index);
		
    return 0;
}			 	
extern "C" int update_contact_by_index(Contact *contact, int index)
{
  	CContactManager *manager = CContactManager::get_instance();
    manager->update_contact_by_index(contact, index);
		
    return 0;
}
			 	
extern "C" int delete_contact_by_index(int index)
{
		CContactManager *manager = CContactManager::get_instance();
    manager->delete_contact_by_index(index);
		
    return 0;
}
extern "C" int delete_contact_all()
{
		CContactManager *manager = CContactManager::get_instance();
    manager->delete_contact_all();
		
    return 0;
}

/**************************************************************************************************/
/**************************************** calllog *************************************************/
/**************************************************************************************************/

extern "C" int get_calllog_count()
{
		CCalllogManager *manager = CCalllogManager::get_instance();
    manager->get_calllog_count();
		
    return 0;
}
extern "C" int get_calllog_count_by_type(CLSTATUS status)
{
	  CCalllogManager *manager = CCalllogManager::get_instance();
    manager->get_calllog_count_by_type(status);
		
    return 0;
}

extern "C" int get_calllog_by_index(CallLog *calllog, int index, CLSTATUS status)
{
	  CCalllogManager *manager = CCalllogManager::get_instance();
    manager->get_calllog_by_index(calllog, index, status);
		
    return 0;
}

extern "C" int add_calllog(CLSTATUS status, CallLog *calllog)
{
	  CCalllogManager *manager = CCalllogManager::get_instance();
    manager->add_calllog(status, calllog);
		
    return 0;
}

extern "C" int delete_calllog_by_index(int index, CLSTATUS status)
{
	  CCalllogManager *manager = CCalllogManager::get_instance();
    manager->delete_calllog_by_index(index, status);
		
    return 0;
}

extern "C" int delete_calllog_by_status(CLSTATUS status)
{
	  CCalllogManager *manager = CCalllogManager::get_instance();
    manager->delete_calllog_by_status(status);
		
    return 0;
}
