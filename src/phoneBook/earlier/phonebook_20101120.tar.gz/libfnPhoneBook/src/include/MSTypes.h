#ifndef MQTYPES_DEF_H
#define MQTYPES_DEF_H

typedef int ERR_NUMBER;
typedef unsigned int uint;
typedef unsigned char uint_8;

#endif


