#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>
#include "phonebookapi.h"
#include "MessageStack.h"
#include "windowstack.h"
#define _(STRING) g_convert(STRING, -1, "UTF-8", "GB2312", NULL, NULL, NULL)
#define _to_asc(STRING) g_convert(STRING, -1, "GB2312", "UTF-8", NULL, NULL, NULL)

GtkBuilder *builder;

void on_button_blacklist_cancel_clicked(GtkWidget *window, gpointer user_data)
{
    GtkWindowInfo pwindow_info;
	
	get_window_out_stack(&pwindow_info);		
	gtk_widget_destroy(GTK_WIDGET(pwindow_info.window));
}

int show_blacklist_window()
{
	GtkWidget *window;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_blacklist"));
	
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	put_window_into_stack(window);
	
    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));

	show_top_window();
	
	return 0;
}

