#ifndef CONTACT_DEF
#define CONTACT_DEF

#include "lpconfig.h"
#include <pthread.h>
#include "phonebookinfo.h"

class CContactManager
{
		private:
				LpConfig *contact_lpconfig;
			 	int buf_count;
			 	pthread_mutex_t mutex;
			 	Contact **contact_buf;
			 	static CContactManager *contact_instance;
			
	  private:
				CContactManager();
				~CContactManager();
			 	void init();
			  void uninit();
			  
			  //inner function
				Contact* get_section_from_config_file(int index);
				int write_contact_item(Contact *item, int index);
				int sync_contact_config();
			  
			  //mutex
				int init_mutex();
				void lock_mutex();
				void unlock_mutex();
	 
		public:
			 	static CContactManager *get_instance();
			 	
				//CURD
				int load_contact_from_file();
				int get_contact_count();
			 	int get_contact_by_index(Contact *contact,	int index);					 
			 	int get_contact_by_name(Contact *contact,	const char *szname);
			 	int get_contact_by_letter(Contact *contact, const char *szletter);		 
			 	int get_contact_by_phone(Contact *contact,	const char *szphone);		 
			 									
			  int add_contact(Contact *contact);
			 	int add_contact_by_index(Contact *contact, int index);
			 	
			 	int update_contact_by_index(Contact *contact, int index);	
			 	
			 	int delete_contact_by_index(int index);
			 	int delete_contact_all();
		
				//validate
		    int validate();
				
				//sort
			 	void sort_by_name();													 						
			 	void sort_by_letter();
		
				//enum
				const char* __grouptype_enum_to_str(int enum_val);
				const char* __phonetype_enum_to_str(int enum_val);
				const char* __emailtype_enum_to_str(int enum_val);
		
				GroupType __grouptype_str_to_enum(const char *enum_str);
				PhoneType __phonetype_str_to_enum(const char *enum_str);
				EMailType __emailtype_str_to_enum(const char *enum_str);
};
#endif