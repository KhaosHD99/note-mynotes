#ifdef _cplusplus 
extern "C" 
{ 
#endif 


int test(int,int);


#ifdef _cplusplus 
} 
#endif
