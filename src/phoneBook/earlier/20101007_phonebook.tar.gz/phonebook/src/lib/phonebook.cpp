#include "contact.hpp" 
#include "string.h"
#ifndef _cplusplus 
#define _cplusplus 
#include "phonebook.h" 
//#include "iostream"
#endif 


int test(int x, int y)
{
    CContactManager *manager = CContactManager::get_instance();	
    
    Contact *section = new Contact;
		memset(section, 0, sizeof(Contact));
	
		strcpy(section->name.szfamily_name,"徐");
		strcpy(section->name.szgiven_name,"镇杰");
	
		section->phones[0].type = PT_HOME;
		strcpy(section->phones[0].szphone, "31325201");
		section->phones[1].type = PT_MOBILE;
		strcpy(section->phones[1].szphone, "13539982758");
		section->phones[2].type = PT_WORK;
		strcpy(section->phones[2].szphone, "12345678");
	
		section->emails[0].type = EMT_WORK;
		strcpy(section->emails[0].szemail, "xujiekoo@qq.com");
	  section->emails[1].type = EMT_HOME;
		strcpy(section->emails[1].szemail, "163.com");
	    
		strcpy(section->szvoip,"172.17");
		strcpy(section->szim,"466795229");
		strcpy(section->szaddress,"yuexu");
	
	  manager->add_contact(section);
		manager->add_contact(section);
		manager->add_contact(section);
		
		//printf("hello\n");
		
    return x + y;
}
