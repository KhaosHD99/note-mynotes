#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "calllog.hpp"
#include "lpconfig.h"
#include "iostream"
using namespace std;

CCalllogManager::CCalllogManager()     
{
    init();
}

void CCalllogManager::init()
{
	calllog_lpconfig = lp_config_new(CLOG_PATHNAME);

	init_log(&calllog_missed);
	init_log(&calllog_received);
	init_log(&calllog_dialed);
}

void CCalllogManager::init_log(CallLog_Info *calllog_info)
{
	calllog_info->count = 0;
	calllog_info->calllog_buf = new CallLog*[MAX_CALLLOG_COUNT];

	for(int i = 0; i < MAX_CALLLOG_COUNT; i++)
	{
		calllog_info->calllog_buf[i] = NULL;
	}	
}

void CCalllogManager::uninit()
{
	uninit_log(&calllog_missed);
	uninit_log(&calllog_received);
	uninit_log(&calllog_dialed);
	
	//destory
	lp_config_destroy(calllog_lpconfig);
}

void CCalllogManager::uninit_log(CallLog_Info *calllog_info)
{
	for(int i = 0; i < calllog_info->count;	i++)
	{
		if(calllog_info->calllog_buf[i])
			delete calllog_info->calllog_buf[i];
		calllog_info->calllog_buf[i] = NULL;
	}
	delete calllog_info->calllog_buf;
	calllog_info->calllog_buf = NULL;
}

CCalllogManager* CCalllogManager::calllog_instance =  NULL;
CCalllogManager* CCalllogManager::get_instance()
{
	calllog_instance = new CCalllogManager;
	return calllog_instance;
}

void CCalllogManager::test()
{
	gchar section_index[50];
	CallLog *calllog;
	int index = 1;
	 	
	sprintf(section_index, "%s%i", CLOG_CALLLOG_INDEX, index);
	cout << section_index << endl;
}

CallLog* CCalllogManager::get_section_from_config_file(int index)
{
	gint calllogindex = -1, 
		 statusIndex = -1, 
		 duration = -1;
	const gchar *tmp = NULL;
	gchar *tmpcpy;
	gchar section_index[50];
	CallLog *calllog;
	 	
	sprintf(section_index, "%s%i", CLOG_CALLLOG_INDEX, index);
	
	//check status
	if (!lp_config_has_section(calllog_lpconfig, section_index))
		return NULL;
	
	
	calllog = g_new0(CallLog,1);
	memset(calllog , 0, sizeof(CallLog));

	tmp = lp_config_get_string(calllog_lpconfig, section_index, CLOG_STATUS, NULL);

	if(tmp != NULL && __clstatus_str_to_enum(tmp) != CL_NON)
		calllog->status = __clstatus_str_to_enum(tmp);

	//missed, received, dailed
	if(calllog->status == CL_NON)           
	{
		free(calllog);
		return NULL;
	}
	else if(calllog->status == CL_MISSED)
	{
	    //status_index, remote
		statusIndex = lp_config_get_int(calllog_lpconfig, section_index, CLOG_MISSED_INDEX, NULL);
		if(statusIndex != -1)
		{
			calllog->status_index = statusIndex;
			statusIndex = -1;
		}
		
		tmp = lp_config_get_string(calllog_lpconfig, section_index, CLOG_REMOTE_FROM, NULL);
		if(tmp != NULL)
			strcpy(calllog->szremote, tmp);
	}
	else if(calllog->status == CL_RECEIVED)
	{
	    //status_index, remote
		statusIndex = lp_config_get_int(calllog_lpconfig, section_index, CLOG_RECEIVED_INDEX, NULL);
		if(statusIndex != -1)
		{
			calllog->status_index = statusIndex;
			statusIndex = -1;
		}
		
		tmp = lp_config_get_string(calllog_lpconfig, section_index, CLOG_REMOTE_FROM, NULL);
		if(tmp != NULL)
			strcpy(calllog->szremote, tmp);
	}
	else if(calllog->status == CL_DIALED)
	{
	    //status_index, remote
		statusIndex = lp_config_get_int(calllog_lpconfig, section_index, CLOG_DIALED_INDEX, NULL);
		if(statusIndex != -1) 
		{
			calllog->status_index = statusIndex;
			statusIndex = -1;
		}
		
		tmp = lp_config_get_string(calllog_lpconfig,section_index, CLOG_REMOTE_TO, NULL);
		if(tmp != NULL)
			strcpy(calllog->szremote, tmp);
	}	

	//date
	tmp = lp_config_get_string(calllog_lpconfig, section_index, CLOG_START_DATE, NULL);
    tmpcpy = (char*)malloc(strlen(tmp)); 
	strcpy(tmpcpy, tmp);
	
    char *p_date, *p_time;	
	p_date = strtok(tmpcpy, " ");
	p_time = strtok(NULL, "");
	
	if(p_date) 
	{
		p_date = strtok(p_date, "-");
		strcpy(calllog->date.year, p_date);
		
		p_date = strtok(NULL, "-");
		strcpy(calllog->date.month, p_date);
		
		p_date = strtok(NULL, "-");
		strcpy(calllog->date.day, p_date);
	}	
	
	if(p_time) 
	{
		p_time = strtok(p_time, ":");
		strcpy(calllog->date.hour, p_time);
		
		p_time = strtok(NULL, ":");
		strcpy(calllog->date.minute, p_time);
		
	    p_time = strtok(NULL, ":");
		strcpy(calllog->date.second, p_time);
		//printf("calllog->date.second: %s\n", calllog->date.second);	
	}

	//duration
	duration = lp_config_get_int(calllog_lpconfig, section_index, CLOG_DURATION, NULL);
	if(duration > 0)
		calllog->date.duration = duration;
	
	return calllog;
}

int CCalllogManager::read_calllog()
{
	CallLog *calllog = new CallLog;	
	
	if(calllog_lpconfig == NULL)
	{
		g_error("_LpConfig = (null)");
		return NULL;
	}

	calllog_missed.count = 0;
    calllog_received.count = 0;
    calllog_dialed.count = 0;
	
	for (int i=0; (calllog = get_section_from_config_file(i)) != NULL; i++)
	{
		if(calllog->status == CL_MISSED)
		{
			calllog_missed.status = CL_MISSED;
			calllog_missed.calllog_buf[calllog_missed.count] = calllog;
			calllog_missed.count++;
		}
		
		if(calllog->status == CL_RECEIVED)
		{
			calllog_received.status = CL_RECEIVED;
			calllog_received.calllog_buf[calllog_received.count] = calllog;
			calllog_received.count++;
		}
		
		if(calllog->status == CL_DIALED)
		{
			calllog_dialed.status = CL_DIALED;
			calllog_dialed.calllog_buf[calllog_dialed.count] = calllog;
			calllog_dialed.count++;
		}
    }
}

int CCalllogManager::write_calllog_item(CallLog *item, int index, int status_index)
{
	gchar section_index[50];
	char str[10]; 	

    sprintf(section_index, "%s%i", CLOG_CALLLOG_INDEX, index);

	//status, status_index, szremote
	if(item->status == CL_MISSED)
	{
		lp_config_set_string(calllog_lpconfig, section_index, CLOG_STATUS, __clstatus_enum_to_str(item->status));
		lp_config_set_int(calllog_lpconfig, section_index, CLOG_MISSED_INDEX, status_index);
		lp_config_set_string(calllog_lpconfig, section_index, CLOG_REMOTE_FROM, item->szremote);
	}
	else if(item->status == CL_RECEIVED)
	{
		lp_config_set_string(calllog_lpconfig, section_index, CLOG_STATUS, __clstatus_enum_to_str(item->status));
		lp_config_set_int(calllog_lpconfig, section_index, CLOG_RECEIVED_INDEX, status_index);
		lp_config_set_string(calllog_lpconfig, section_index, CLOG_REMOTE_FROM, item->szremote);
	}
	else if(item->status == CL_DIALED)
	{
		lp_config_set_string(calllog_lpconfig, section_index, CLOG_STATUS, __clstatus_enum_to_str(item->status));
		lp_config_set_int(calllog_lpconfig, section_index, CLOG_DIALED_INDEX, status_index);
		lp_config_set_string(calllog_lpconfig, section_index, CLOG_REMOTE_TO, item->szremote);
	}

	//time
	char datetime[64] = "";

	sprintf(datetime, "%s-%s-%s %s:%s:%s", item->date.year, item->date.month,
		                                   item->date.day, item->date.hour, 
		                                   item->date.minute, item->date.second);
 
	lp_config_set_string(calllog_lpconfig, section_index, CLOG_START_DATE, datetime);

	//duration
    lp_config_set_int(calllog_lpconfig, section_index, CLOG_DURATION, item->date.duration);

	return 0;
}

int CCalllogManager::sync_calllog_config()
{ 
    
    int writeindex = 0;
	char section[30];

	if(calllog_lpconfig == NULL)
	{
		g_error("calllog_lpconfig = (null)");
		return -1;
	}
	
    update_buf_count();
	
    //clear
	for(int i = 0; i < MAX_CALLLOG_COUNT; i++)
	{
	    sprintf(section, "%s%i", CLOG_CALLLOG_INDEX, i);
	    if(lp_config_has_section(calllog_lpconfig, section))
	     	lp_config_clean_section(calllog_lpconfig, section);
		
	}
	
	for(int i = 0; i < calllog_missed.count; i++)
		write_calllog_item(calllog_missed.calllog_buf[i], i, i);
	
	for(int i = 0; i < calllog_received.count; i++)
		write_calllog_item(calllog_received.calllog_buf[i], 
                           i + calllog_missed.count, i);
		
	for(int i = 0; i < calllog_dialed.count; i++)
		write_calllog_item(calllog_dialed.calllog_buf[i], 
		                   i + calllog_missed.count + calllog_received.count, i);
	
	//sync
	return lp_config_sync(calllog_lpconfig);
}

//CRUD
int CCalllogManager::get_calllog_count()
{	
	read_calllog();
	
    return calllog_missed.count + calllog_received.count + calllog_dialed.count;
}

int CCalllogManager::get_calllog_buf_count()
{	
    update_buf_count();
    return calllog_missed.count + calllog_received.count + calllog_dialed.count;
}

int CCalllogManager::get_calllog_count_by_type(CLSTATUS status)
{
    read_calllog();
	if(status == CL_MISSED)
		return calllog_missed.count;
	
	if(status == CL_RECEIVED)
		return calllog_received.count;
	
	if(status == CL_DIALED)
		return calllog_dialed.count;
	
	return 0;
}

int CCalllogManager::get_calllog_by_index(CLSTATUS status, int index, CallLog **calllog)
{
	return 0;
}

int CCalllogManager::add_calllog(CLSTATUS status, CallLog *calllog)
{
	int len;
	int i = 0; 
	
	len = get_calllog_count();
	
	if(status == CL_MISSED)
	{
	    while(1)
	    {
	        if(calllog_missed.calllog_buf[i] == NULL)
	        {
	            calllog_missed.calllog_buf[i] = new CallLog;
	            calllog_missed.calllog_buf[i]->status = status;

                //datetime
				strcpy(calllog_missed.calllog_buf[i]->date.year, calllog->date.year);
				strcpy(calllog_missed.calllog_buf[i]->date.month, calllog->date.month);
				strcpy(calllog_missed.calllog_buf[i]->date.day, calllog->date.day);
				strcpy(calllog_missed.calllog_buf[i]->date.hour, calllog->date.hour);
				strcpy(calllog_missed.calllog_buf[i]->date.minute, calllog->date.minute);
				strcpy(calllog_missed.calllog_buf[i]->date.second, calllog->date.second);
				
				strcpy(calllog_missed.calllog_buf[i]->szremote, calllog->szremote);
				break;
	        }
			i++;
		}
	}
	
	if(status == CL_RECEIVED)
	{
		while(1)
		{
	        if(calllog_received.calllog_buf[i] == NULL)
	        {
	            calllog_received.calllog_buf[i] = new CallLog;
	            calllog_received.calllog_buf[i]->status = status;

				//datetime
				strcpy(calllog_received.calllog_buf[i]->date.year, calllog->date.year);
				strcpy(calllog_received.calllog_buf[i]->date.month, calllog->date.month);
				strcpy(calllog_received.calllog_buf[i]->date.day, calllog->date.day);
				strcpy(calllog_received.calllog_buf[i]->date.hour, calllog->date.hour);
				strcpy(calllog_received.calllog_buf[i]->date.minute, calllog->date.minute);
				strcpy(calllog_received.calllog_buf[i]->date.second, calllog->date.second);
							strcpy(calllog_received.calllog_buf[i]->szremote, calllog->szremote);
				break;
	        }
			i++;
		}
	}
	
	if(status == CL_DIALED)
	{
	    while(1)
		{
	        if(calllog_dialed.calllog_buf[i] == NULL)
	        {
	            calllog_dialed.calllog_buf[i] = new CallLog;
	            calllog_dialed.calllog_buf[i]->status = status;

				//datetime
				strcpy(calllog_dialed.calllog_buf[i]->date.year, calllog->date.year);
				strcpy(calllog_dialed.calllog_buf[i]->date.month, calllog->date.month);
				strcpy(calllog_dialed.calllog_buf[i]->date.day, calllog->date.day);
				strcpy(calllog_dialed.calllog_buf[i]->date.hour, calllog->date.hour);
				strcpy(calllog_dialed.calllog_buf[i]->date.minute, calllog->date.minute);
				strcpy(calllog_dialed.calllog_buf[i]->date.second, calllog->date.second);
			    
				strcpy(calllog_dialed.calllog_buf[i]->szremote, calllog->szremote);
				break;
	        }
			i++;
		}
	}
	
	//sync
    sync_calllog_config();
}

int CCalllogManager::delete_calllog_by_index(CLSTATUS status, int index)
{
	int len;
	
	len = get_calllog_count();
	if(len == 0)
		return -1;

	if(status == CL_MISSED)
	{
	    if(index >= calllog_missed.count)
			return -1;
	    while(1)
	    {
	    	if(index + 1 == len)
	    	{
	    	    delete(calllog_missed.calllog_buf[index]);
				calllog_missed.calllog_buf[index] = NULL;
		        break;
			}    
			calllog_missed.calllog_buf[index] = calllog_missed.calllog_buf[index + 1];
	        index++;
	    }
	}

	if(status == CL_RECEIVED)
	{
	    if(index >= calllog_received.count)
			return -1;
	    while(1)
	    {
	    	if(index + 1 == len)
	    	{
	    	    delete(calllog_received.calllog_buf[index]);
				calllog_received.calllog_buf[index] = NULL;
		        break;
			}    
			calllog_received.calllog_buf[index] = calllog_received.calllog_buf[index + 1];
	        index++;
	    }
	}
	
	if(status == CL_DIALED)
	{
	    if(index >= calllog_dialed.count)
			return -1;
	    while(1)
	    {
	    	if(index + 1 == len)
	    	{   
	    	    delete(calllog_dialed.calllog_buf[index]);
				calllog_dialed.calllog_buf[index] = NULL;
		        break;
			}    
			calllog_dialed.calllog_buf[index] = calllog_dialed.calllog_buf[index + 1];
	        index++;
	    }
	}
	
	//sync
	sync_calllog_config();
}

int CCalllogManager::delete_calllog_by_status(CLSTATUS status)
{
	int len;
	
	len = get_calllog_count();
	if(len == 0)
		return -1;

	if(status == CL_MISSED)
	{
	    if(calllog_missed.count == 0)
			return -1;
	    for(int i = 0; i < calllog_missed.count; i++)
	    {
	    	delete(calllog_missed.calllog_buf[i]);
			calllog_missed.calllog_buf[i] = NULL;
	    }
	}

	if(status == CL_RECEIVED)
	{
	    if(calllog_received.count == 0)
			return -1;
	    for(int i = 0; i < calllog_received.count; i++)
	    {
	    	delete(calllog_received.calllog_buf[i]);
			calllog_received.calllog_buf[i] = NULL;
	    }
	}
	
	if(status == CL_DIALED)
	{
	    if(calllog_dialed.count == 0)
			return -1;
	    for(int i = 0; i < calllog_dialed.count; i++)
	    {
	    	delete(calllog_dialed.calllog_buf[i]);
			calllog_dialed.calllog_buf[i] = NULL;
	    }
	}
	
	//sync
	sync_calllog_config();
}

//sort
void CCalllogManager::sort_by_date()
{

}

//help
int CCalllogManager::update_buf_count()
{
	int i = 0;
	calllog_missed.count = 0;
	calllog_received.count = 0;
	calllog_dialed.count = 0;

    while(calllog_missed.calllog_buf[i++] != NULL)
   		calllog_missed.count++;
		i = 0;
	
	while(calllog_received.calllog_buf[i++] != NULL)
    	calllog_received.count++;
		i = 0;
		
	while(calllog_dialed.calllog_buf[i++] != NULL)
	    calllog_dialed.count++;

	return 0;
}


//enum
const gchar* CCalllogManager::__clstatus_enum_to_str(int enum_val)
{
	switch(enum_val)
	{
		case CL_NON:
			return CL_NON_str;
			break;
		case CL_MISSED:
			return CL_MISSED_str;
			break;
		case CL_RECEIVED:
			return CL_RECEIVED_str;
			break;
		case CL_DIALED:
			return CL_DIALED_str;
			break;
	}
	g_warning("Invalid clstatus enum value.");
	return "NULL";
}

CLSTATUS CCalllogManager::__clstatus_str_to_enum(const char *enum_str)
{	

	if(strncmp(enum_str, CL_MISSED_str,strlen(CL_MISSED_str)) == 0)
		return CL_MISSED;

	if(strncmp(enum_str, CL_RECEIVED_str,strlen(CL_RECEIVED_str)) == 0)
		return CL_RECEIVED;

	if(strncmp(enum_str, CL_DIALED_str,strlen(CL_DIALED_str)) == 0)
		return CL_DIALED;

	g_warning("Invalid clstatus enum value %s", enum_str);
	return CL_NON;
}
