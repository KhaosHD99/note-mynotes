#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include "lpconfig.h"
#include "calllog.hpp"


int main()
{
	//CCalllogManager *log = CCalllogManager::get_instance();
	//CCalllogManager *manager = CCalllogManager::get_instance();
	//manager->test();
	
	//���������ļ�
	//manager->load_calllog_from_file();
	
	//int itemcounts = manager->get_calllogitem_count();      //��ʾ�����ļ�������
	//printf("get_calllogitem_counts : %d \n\n", itemcounts);

	/*CallLog *section = new CallLog;	
	memset(section, 0, sizeof(CallLog));

	//section->index = 8;
	//section->status = CL_DIALED;
	//section->status_index = 6;

	char *buf[] = {"123456789","2010","09","10","12","30","55"};
	
	snprintf(section->szremote,sizeof(section->szremote)-1,buf[0]);

	snprintf(section->date.year,sizeof(section->date.year),buf[1]);
	snprintf(section->date.month,sizeof(section->date.month),buf[2]);
	snprintf(section->date.day,sizeof(section->date.day),buf[3]);
	snprintf(section->date.hour,sizeof(section->date.hour),buf[4]);
	snprintf(section->date.minute,sizeof(section->date.minute),buf[5]);
	snprintf(section->date.second,sizeof(section->date.second),buf[6]);
	
	section->date.duration = 13;

	printf("star write section into config: \n");
	printf("section->status         :%d \n",section->status);
	printf("section->status_index   :%d \n",section->status_index);
	printf("section->szremote       :%s \n",section->szremote);

	printf("section->date.year      :%s \n",section->date.year);
	printf("section->date.month     :%s \n",section->date.month);
	printf("section->date.day       :%s \n",section->date.day);
	printf("section->date.hour      :%s \n",section->date.hour);
	printf("section->date.minute    :%s \n",section->date.minute);
	printf("section->date.second    :%s \n",section->date.second);

	printf("section->date.duration  :%d \n\n",section->date.duration);

	/*for(int i=0;i<3;i++)
	{
		section->status = CL_MISSED;
		manager->add_calllog(section->status,section);
	}
	for(int i=0;i<3;i++)
	{
		section->status = CL_RECEIVED;
		manager->add_calllog(section->status,section);
	}//*/
	/*for(int i=0;i<5;i++)
	{
		section->status = CL_DIALED;
		manager->add_calllog(section->status,section);
	}//*/

	//manager->delete_calllog_by_index(CL_DIALED, 2);
	
	return 0;
}

