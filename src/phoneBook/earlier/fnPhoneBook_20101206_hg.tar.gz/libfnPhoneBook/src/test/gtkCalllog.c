#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include "phonebookapi.h"
#include "MessageStack.h"

extern GtkWidget *rootWindow;
extern GtkWidget *contactWindow;
extern GtkWidget *calllogWindow;
extern GtkBuilder *builder;


void on_button_calllog_close_clicked(GtkWidget *gtklist, gpointer user_data)
{
	gtk_widget_hide(calllogWindow);
}

/*typedef struct _ContactItemDetail ContactItemDetail;
struct _ContactItemDetail
{
  	GtkWidget* family_name;
  	GtkWidget* given_name;
  	GtkWidget* group;
  	GtkWidget* phone;
	GtkWidget* image;
};

void on_button_menu_clicked(GtkWidget *gtklist, gpointer user_data)
{
    printf("event");
	gtk_widget_hide(contactWindow);
	//gtk_widget_destroy(contactWindow);
	//contactWindow = NULL;
}

static GtkTreeModel* create_model(void)
{
		GtkListStore *store;
		GSList *ids;
		GSList *tmp_list;
        int i;
		
		store = gtk_list_store_new(3, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_INT);
		
		for(i = 0; i < get_contact_count(); i++)
		{
	        Contact contact; 
			GtkTreeIter iter;
	        get_contact_by_index(&contact, i);
			
		    gtk_list_store_append (store, &iter);
		    gtk_list_store_set (store, &iter, 
				                0, contact.name.szgiven_name,
				                1, contact.name.szfamily_name,
				                2, i,
				                -1);
		     
		    //free(&contact);
			#if 0
		   
			#endif
		}
		
		return GTK_TREE_MODEL (store);
}

static void selection_changed(GtkTreeSelection *selection)
{
	  #if 1
	  GtkTreeView *treeview;
	  ContactItemDetail* display;
	  GtkTreeModel *model;
	  GtkTreeIter iter;
	  Contact contact;
	  
	  treeview = gtk_tree_selection_get_tree_view(selection);
	  display = g_object_get_data(G_OBJECT(treeview), "ContactDetail");
	
	  if (gtk_tree_selection_get_selected(selection, &model, &iter))
	  {
	      int i = 0;
	      gint index;
		  GdkPixbuf *image;
		  char phoneInfo[128];

	      gtk_tree_model_get(model, &iter,
	                         2, &index,
	                         -1);

		  //get contact
		  get_contact_by_index(&contact, index);
          
		  gtk_label_set_text (GTK_LABEL(display->given_name), contact.name.szgiven_name);
	      gtk_label_set_text (GTK_LABEL(display->family_name), contact.name.szfamily_name);
	      gtk_label_set_text (GTK_LABEL(display->group), NULL);

		  //phone
		  //while(contact.phones[i].szphone[0] != '\0')
		//  {
		//  		strcat(phoneInfo, contact.phones[i].szphone);
		//		i++;
		//  }
		//  gtk_label_set_text (GTK_LABEL(display->phone), phoneInfo);

		  //image
	      image = gdk_pixbuf_new_from_file(ZHENJIE_PATH	, NULL);
	      gtk_image_set_from_pixbuf (GTK_IMAGE(display->image), image);
          
		  //release
	  }
	  else
	  {
		   
	  }
	  #endif
}

static void set_text (GtkTreeViewColumn *tree_column,
								     GtkCellRenderer   *cell,
								     GtkTreeModel      *model,
								     GtkTreeIter       *iter,
								     gpointer           data)
{
	  gchar *given_name;
	  gchar *family_name;
	  gchar strCombine[64];
	  
	  
	  gtk_tree_model_get(model, iter,
	                     0, &given_name,
	                     1, &family_name,
	                     -1);

	  sprintf(strCombine, "%s%s", family_name, given_name);
	  
	  g_object_set(GTK_CELL_RENDERER(cell),
	               "text", strCombine,
	               NULL);

	  //g_free();
}*/

int show_missed_calllog_window()
{
	  if(!calllogWindow)
	  {
        GtkWidget *window;
	    
	    //window
        window = GTK_WIDGET(gtk_builder_get_object(builder, "window_calllog"));
		calllogWindow = window;
		gtk_window_move(GTK_WINDOW(calllogWindow), 200, 0);
	
        gtk_builder_connect_signals(builder, NULL);
		gtk_widget_show_all(calllogWindow);
	  }
	  else if (!GTK_WIDGET_VISIBLE (calllogWindow))
	  {
	     printf("not NULL\n");
	 	 gtk_widget_show_all(calllogWindow);
	  }
      
      return 0;
}

int show_received_calllog_window()
{
	  if(!calllogWindow)
	  {
        GtkWidget *window;
	    
	    //window
        window = GTK_WIDGET(gtk_builder_get_object(builder, "window_calllog"));
		calllogWindow = window;
		gtk_window_move(GTK_WINDOW(calllogWindow), 200, 0);
	
        gtk_builder_connect_signals(builder, NULL);
		gtk_widget_show_all(calllogWindow);
	  }
	  else if (!GTK_WIDGET_VISIBLE (calllogWindow))
	  {
	     printf("not NULL\n");
	 	 gtk_widget_show_all(calllogWindow);
	  }
      
      return 0;
}

int show_dialed_calllog_window()
{
	  if(!calllogWindow)
	  {
        GtkWidget *window;
	    
	    //window
        window = GTK_WIDGET(gtk_builder_get_object(builder, "window_calllog"));
		calllogWindow = window;
		gtk_window_move(GTK_WINDOW(calllogWindow), 200, 0);
	
        gtk_builder_connect_signals(builder, NULL);
		gtk_widget_show_all(calllogWindow);
	  }
	  else if (!GTK_WIDGET_VISIBLE (calllogWindow))
	  {
	     printf("not NULL\n");
	 	 gtk_widget_show_all(calllogWindow);
	  }
      
      return 0;
}

