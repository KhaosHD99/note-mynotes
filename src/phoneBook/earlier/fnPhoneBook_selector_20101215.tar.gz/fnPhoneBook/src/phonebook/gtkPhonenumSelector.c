#include <stdio.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>

#include "phonebookapi.h"
//#include "MessageStack.h"
#include "windowstack.h"
#include "LogMsg.hpp"

#define _(STRING) g_convert(STRING, -1, "UTF-8", "GB2312", NULL, NULL, NULL)
#define _to_asc(STRING) g_convert(STRING, -1, "GB2312", "UTF-8", NULL, NULL, NULL)

GtkListStore *phonenum_selector_store;
GtkTreeView *phonenum_selector_treeview;

enum 
{
	SELECTOR_INDEX_COL,
    SELECTOR_PHONENUM_COL,
};

GtkListStore* create_contact_phonenum_selector_store(void)
{
	GtkListStore *store;
	store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_STRING);
	
	return store;
}

GtkTreeModel* fill_contact_phonenum_selector_store(GtkListStore *store, int index)
{	
    
    int i;
	Contact contact;
	
	get_contact_by_index(&contact, index);
	//showDebug("phonum count: %d, index col: %d, phonenum col: %d\n", contact.phone_count
	//										     				   , CONTACT_INDEX_COL
	//										  	 				   , PHONENUM_COL);
	
	#if 1
    for(i = 0; i < contact.phone_count; i++)
    {
       GtkTreeIter iter;
	   gtk_list_store_append(store, &iter);
	   gtk_list_store_set(store, &iter,
	     	              SELECTOR_INDEX_COL, i,
			              SELECTOR_PHONENUM_COL, _(contact.phones[i].szphone) == NULL ? 
	    	                              contact.phones[i].szphone : _(contact.phones[i].szphone),
			              -1);
	}
    #endif
	
	return GTK_TREE_MODEL (store);
}

void set_selector_phonenum(GtkTreeViewColumn *tree_column,
				      GtkCellRenderer   *cell,
				      GtkTreeModel      *model,
				      GtkTreeIter       *iter,
				      gpointer           data)
{
    #if 1
	char *phonenum;
	
	gtk_tree_model_get(model, iter,
	                   SELECTOR_PHONENUM_COL, &phonenum,
	                   -1);
		
	g_object_set(GTK_CELL_RENDERER(cell),
                 "text", phonenum,
                 NULL);
	
	g_free(phonenum);
    #endif
}


int show_phonenum_selector_window(int index)
{
	GtkBuilder *builder;
	GtkWidget *window;
	GtkTreeViewColumn *column_phonenum;
	GtkCellRenderer *cell_renderer;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_select_phonenum"));
	gtk_window_set_title(window, "window_select_phonenum");
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	put_window_into_stack(window);
	
	//add  model to tree view	
	phonenum_selector_store = create_contact_phonenum_selector_store();
	phonenum_selector_treeview = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_phonenum");
	gtk_tree_view_set_model(phonenum_selector_treeview, 
							fill_contact_phonenum_selector_store(phonenum_selector_store, index));
	
	
	#if 1
	column_phonenum = gtk_tree_view_column_new();
    gtk_tree_view_column_set_title(column_phonenum, _(DISPLAY_CONTACT));
    
	//name cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_phonenum,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_phonenum, cell_renderer,
		                              	    set_selector_phonenum, NULL, NULL);
	
	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(phonenum_selector_treeview),
					            column_phonenum);
	#endif
    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();
	

	#if 0
	GtkBuilder *builder;
    GtkWidget *window;
	GtkTreeViewColumn *column_phonenum;
	GtkCellRenderer *cell_renderer;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_quickdial"));
	
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	
	put_window_into_stack(window);
	
    #if 1
	//add  model to tree view
	quickdial_store = create_quickdial_store();
	
	treeview_quickdial_main = (GtkTreeView *)gtk_builder_get_object(builder, "treeview_quickdial");
	gtk_tree_view_set_model(treeview_quickdial_main, fill_quickdial_store(quickdial_store));
	
	//column  
	column_phonenum = gtk_tree_view_column_new();
    
	// phonenum cell renderer
	cell_renderer = gtk_cell_renderer_text_new();
	gtk_tree_view_column_pack_start(column_phonenum,
			       	                cell_renderer,
			       					TRUE);
	
	gtk_tree_view_column_set_cell_data_func(column_phonenum, cell_renderer,
		                              	    set_quickdial_phonenum, 
		                              	    NULL, NULL);
		
	//bingding column to tree view
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview_quickdial_main),
					            column_phonenum);
	#endif
    gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	
	show_top_window();
	#endif
	
	return 0;
}

