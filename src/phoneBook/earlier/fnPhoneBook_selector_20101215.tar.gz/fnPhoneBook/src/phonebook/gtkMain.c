#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <locale.h>
#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>

#include "phonebookapi.h"
#include "windowstack.h"
#include "MessageStack.h"
#include "LogMsg.hpp"

#define _(STRING) g_convert(STRING, -1, "UTF-8", "GB18030", NULL, NULL, NULL)

GtkWidget  *eventbox_contact;
GtkWidget  *eventbox_calllog;
GtkWidget  *eventbox_blacklist;
GtkWidget  *eventbox_quickdial;
GtkWidget  *eventbox_emergencydial;
GtkWidget  *image_contact;
GtkWidget  *image_calllog;
GtkWidget  *image_blacklist;
GtkWidget  *image_quickdial;
GtkWidget  *image_emergencydial;

void on_eventbox_contact_button_press_event(GtkWidget *widget, gpointer user_data)
{
	gtk_button_set_focus_on_click((GtkButton *)widget, TRUE);
	show_contact_window();
}

void on_eventbox_calllog_button_press_event(GtkWidget *widget, gpointer user_data)
{
	gtk_button_set_focus_on_click((GtkButton *)widget, TRUE);
	show_calllog_window();
}

void on_eventbox_blacklist_button_press_event(GtkWidget *widget, gpointer user_data)
{
	gtk_button_set_focus_on_click((GtkButton *)widget, TRUE);
	show_blacklist_window();
}

void on_eventbox_quickdial_button_press_event(GtkWidget *widget, gpointer user_data)
{
	gtk_button_set_focus_on_click((GtkButton *)widget, TRUE);
 	show_quick_dial_window();
}

void on_eventbox_commonphonedial_button_press_event(GtkWidget *widget, gpointer user_data)
{
	gtk_button_set_focus_on_click((GtkButton *)widget, TRUE);
	showDebug("common event\n");
	show_commonphone_window();
}

//dialog
void show_message_window(char *msg)
{	
	GtkBuilder *builder;
	GtkMessageDialog *dialog;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	dialog = (GtkMessageDialog *)gtk_builder_get_object(builder, "dialog_message");
	
	gtk_message_dialog_format_secondary_text(dialog, msg);
	
	gtk_dialog_run (GTK_DIALOG (dialog));
	gtk_widget_destroy(GTK_WIDGET(dialog));
}

int show_confirm_window(char *msg)
{	
	GtkBuilder *builder;
	GtkMessageDialog *dialog;
	int rtn;
	
	//window
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL);
	dialog = (GtkMessageDialog *)gtk_builder_get_object(builder, "dialog_confirm");
	
	gtk_message_dialog_format_secondary_text(dialog, msg);
	
	rtn = gtk_dialog_run (GTK_DIALOG (dialog));
	gtk_widget_destroy(GTK_WIDGET(dialog));
	
	return rtn;
}

/************ !Start ʹ��eventbox����Button�ڲŴ������� ****************************************************
            �� �������ۺϴ������������������������¼��������µļ�ֵ���û�����
*******************************************************************************************************************/
void on_key_press_event(GtkWidget *widget, GdkEventKey *event, const char *user_data)
{
	switch(event->keyval) 
	{
	    case GDK_Up:
			g_print("Up\n");
			break;
	    case GDK_Left:
	        g_print("Left\n");
	        break;
	    case GDK_Right:
	        g_print("Right\n");
	        break;
	    case GDK_Down:
			g_print("Down\n");
			break;
		case GDK_Tab:
			g_print("Tab\n");
			break;
		case GDK_KP_Enter:
			if( strcmp(user_data, "contact") == 0 )
				on_eventbox_contact_button_press_event(NULL, NULL);
			if( strcmp(user_data, "calllog") == 0 )
				on_eventbox_calllog_button_press_event(NULL, NULL);
			if( strcmp(user_data, "blacklist") == 0 )
				on_eventbox_blacklist_button_press_event(NULL, NULL);
			if( strcmp(user_data, "quickdial") == 0 )
				on_eventbox_quickdial_button_press_event(NULL, NULL);
			if( strcmp(user_data, "commonphonedial") == 0 )
				on_eventbox_commonphonedial_button_press_event(NULL, NULL);
			g_print("Enter\n");
			break;
		case GDK_Return:
			if( strcmp(user_data, "contact") == 0 )
				on_eventbox_contact_button_press_event(NULL, NULL);
			if( strcmp(user_data, "calllog") == 0 )
				on_eventbox_calllog_button_press_event(NULL, NULL);
			if( strcmp(user_data, "blacklist") == 0 )
				on_eventbox_blacklist_button_press_event(NULL, NULL);
			if( strcmp(user_data, "quickdial") == 0 )
				on_eventbox_quickdial_button_press_event(NULL, NULL);
			if( strcmp(user_data, "commonphonedial") == 0 )
				on_eventbox_commonphonedial_button_press_event(NULL, NULL);
			g_print("Return\n");
			break;
		default:		
			printf("default  \n");
			break;
    }
}

//contact
void on_eventbox_contact_focus_in_event( GtkWidget *widget, gpointer data)
{
    #if 1
    char img_path[128];
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_MENU_ITEM_FOCUSED);
	
	gtk_image_set_from_file( (GtkImage*)image_contact, img_path);
	showDebug("on_eventbox_contact_focus_in_event  \n");
	#endif
}
void on_eventbox_contact_focus_out_event( GtkWidget *widget, gpointer data)
{
    #if 1
	char img_path[128];
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_MENU_ITEM);

	gtk_image_set_from_file( (GtkImage*)image_contact, img_path);
	showDebug("on_eventbox_contact_focus_out_event  \n");
	#endif
}
void on_eventbox_contact_key_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
	on_key_press_event(widget, event, "contact");
}

//calllog
void on_eventbox_calllog_focus_in_event( GtkWidget *widget, gpointer data)
{
	char img_path[128];
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_MENU_ITEM_FOCUSED);

	gtk_image_set_from_file( (GtkImage*)image_calllog, img_path);
	showDebug("on_eventbox_calllog_focus_in_event  \n");
}
void on_eventbox_calllog_focus_out_event( GtkWidget *widget, gpointer data)
{
	char img_path[128];
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_MENU_ITEM);

	gtk_image_set_from_file( (GtkImage*)image_calllog, img_path);
	showDebug("on_eventbox_calllog_focus_out_event  \n");
}
void on_eventbox_calllog_key_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
	on_key_press_event(widget, event, "calllog");
}

//blacklist
void on_eventbox_blacklist_focus_in_event( GtkWidget *widget, gpointer data)
{
    char img_path[128];
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_MENU_ITEM_FOCUSED);
	gtk_image_set_from_file( (GtkImage*)image_blacklist, img_path);
	showDebug("on_eventbox_blacklist_focus_in_event  \n");
}
void on_eventbox_blacklist_focus_out_event( GtkWidget *widget, gpointer data)
{
    char img_path[128];
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_MENU_ITEM);
	gtk_image_set_from_file( (GtkImage*)image_blacklist, img_path);
	showDebug("on_eventbox_blacklist_focus_out_event  \n");
}
void on_eventbox_blacklist_key_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
	on_key_press_event(widget, event, "blacklist");
}

//quickdial
void on_eventbox_quickdial_focus_in_event( GtkWidget *widget, gpointer data)
{
    char img_path[128];
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_MENU_ITEM_FOCUSED);
	gtk_image_set_from_file( (GtkImage*)image_quickdial, img_path);
	showDebug("on_eventbox_quickdial_focus_in_event  \n");
}
void on_eventbox_quickdial_focus_out_event( GtkWidget *widget, gpointer data)
{
    char img_path[128];
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_MENU_ITEM);
	gtk_image_set_from_file( (GtkImage*)image_quickdial, img_path);
	showDebug("on_eventbox_quickdial_focus_out_event  \n");
}
void on_eventbox_quickdial_key_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
	on_key_press_event(widget, event, "quickdial");
}

//emergencydial
void on_eventbox_emergencydial_focus_in_event( GtkWidget *widget, gpointer data)
{
    char img_path[128];
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_MENU_ITEM_FOCUSED);
	
	gtk_image_set_from_file( (GtkImage*)image_emergencydial, img_path);
	showDebug("on_eventbox_emergencydial_focus_in_event  \n");
}
void on_eventbox_emergencydial_focus_out_event( GtkWidget *widget, gpointer data)
{
    char img_path[128];
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_MENU_ITEM);
	
	gtk_image_set_from_file( (GtkImage*)image_emergencydial, img_path);
	showDebug("on_eventbox_emergencydial_focus_out_event  \n");
}
void on_eventbox_emergencydial_key_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
	on_key_press_event(widget, event, "commonphonedial");
}
/************ !End ʹ��eventbox����Button�ڲŴ������� ****************************************************/
int main(int argc, char *argv[])
{		
	gtk_rc_parse(".gtkrc-2.0"); 
	gtk_init(&argc, &argv);
	setlocale(LC_ALL, "C");

	
	
	GtkBuilder *builder;
	GtkWidget *window;
    char img_path[128];
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_MENU_ITEM);
	
	builder = gtk_builder_new();
	
	if(!gtk_builder_add_from_file (builder, GLADE_FILE_PATH, NULL))
	{	
		showError("can not find glade file\n");
		return -1;
	}
	
	creat_window_stack();
	
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window_main"));
	gtk_window_set_title(window, "window_main");
	gtk_window_move(GTK_WINDOW(window), 200, 0);

	GtkWidget *main_image; 
	main_image = GTK_WIDGET(gtk_builder_get_object(builder, "image_main_bg"));

	char main_bg_img_path[128];
	sprintf(main_bg_img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_BG);

	printf(" main_bg_img_path : %s \n", main_bg_img_path);
	if(main_image == NULL)
	{
		showDebug("main_image is NULL\n");
		return (FALSE);
	}
	else
		gtk_image_set_from_file(main_image, main_bg_img_path); 
	
	eventbox_contact = GTK_WIDGET(gtk_builder_get_object(builder, "eventbox_contact"));
	eventbox_calllog = GTK_WIDGET(gtk_builder_get_object(builder, "eventbox_calllog"));
	eventbox_blacklist = GTK_WIDGET(gtk_builder_get_object(builder, "eventbox_blacklist"));
	eventbox_quickdial = GTK_WIDGET(gtk_builder_get_object(builder, "eventbox_quickdial"));
	eventbox_emergencydial = GTK_WIDGET(gtk_builder_get_object(builder, "eventbox_emergencydial"));

	image_contact = GTK_WIDGET(gtk_builder_get_object(builder, "image_contact"));
	image_calllog = GTK_WIDGET(gtk_builder_get_object(builder, "image_calllog"));
	image_blacklist = GTK_WIDGET(gtk_builder_get_object(builder, "image_blacklist"));
	image_quickdial = GTK_WIDGET(gtk_builder_get_object(builder, "image_quickdial"));
	image_emergencydial = GTK_WIDGET(gtk_builder_get_object(builder, "image_emergencydial"));
	
	//image
    gtk_image_set_from_file((GtkImage*)image_contact, img_path);
	gtk_image_set_from_file((GtkImage*)image_calllog, img_path);
	gtk_image_set_from_file((GtkImage*)image_blacklist, img_path);
	gtk_image_set_from_file((GtkImage*)image_quickdial, img_path);
	gtk_image_set_from_file((GtkImage*)image_emergencydial, img_path);
	
	put_window_into_stack(window);
	gtk_builder_connect_signals(builder, NULL);
	g_object_unref(G_OBJECT (builder));
	show_top_window();
	
	//Blacklist blacklist;
	
	//strcpy(blacklist.contact_name, "bl");
    //add_blacklist(&blacklist);
	//Quickdial quickdial;	
	//strcpy(quickdial.contact_name, "ddddelon");
	//showDebug("size: %d\n", sizeof(quickdial)); 
	phone_incoming("1353988");
	/*if(get_value_from_key(DISPLAY_CAN_NOT_EMPTY) == NULL)
	{
		showDebug("NULL\n");	
	}
	else
	{
		showDebug("Not NULL\n");
	}*/

	/*int i;
	Commonphone commonphone;

	for(i = 0; i < 5; i++)
	{
		if(!get_commonphone_by_index(&commonphone, i))
			showDebug("commonphone: %s\n", commonphone.phonenum);
		else
			showDebug("Fail\n");
	}*/

	//showDebug("Count: %d\n", get_commonphone_count());
	//showDebug("quickdial count: %d\n", get_quickdial_count()); 

    //Quickdial quickdial;

	//strcpy(quickdial.phonenum, "1353998");
	//add_quickdial(&quickdial);
	
	//delete_quickdial_by_index(0);
	
	gtk_main();
	
	return 0;
}

