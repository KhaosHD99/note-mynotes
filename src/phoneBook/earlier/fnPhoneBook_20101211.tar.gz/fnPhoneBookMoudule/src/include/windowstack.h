#ifndef WINDOW_STACK_DEF
#define WINDOW_STACK_DEF

#include "MessageStack.h"

typedef struct GtkWindowInfo
{
	GtkWindow* window;
	char window_name[64];
}GtkWindowInfo;

#if 1
extern int creat_window_stack();
		
//put window into stack with block
extern int put_window_into_stack(GtkWidget *window);
		
//get top window with block
extern int get_window_out_stack(GtkWindowInfo *pwindow_info);
		
//read top window without block
extern int read_top_window_stack(GtkWindowInfo *pwindow_info);
		
//show top window
extern int show_top_window();
#endif

#endif

