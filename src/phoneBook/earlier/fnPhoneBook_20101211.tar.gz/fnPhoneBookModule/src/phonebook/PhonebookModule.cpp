#include "PhonebookModule.h"
//#include "PrompterGui.h"
#include "CCST.hpp"
//#include "Advertisement.hpp"

/* Test */
/*
bool MyClass::OnReceive(Vial *vial)
{	
	printf("No Require CC Get Vial\n");
	#if 0
	switch (vial->vialType)
	{
		case GETVT(StateChangeVial):		
			return on_vial_state_change((StateChangeVial *)vial);
			
		//case GETVT(DialNotifyVial):
		//	return onVialDialNotify((DialNotifyVial *)vial);				//3
		//case GETVT(CallerPhoneCodeVial):
		//	return onVialCallerPhoneCode((CallerPhoneCodeVial *)vial);
	}
	#endif
	
	return false;
}*/
/* End Test */


/********************************************************************************
                                      					get instance
********************************************************************************/
PhonebookModule* PhonebookModule::adverModule_instance = NULL;
PhonebookModule* PhonebookModule::get_instance(VialSystem *vialSys)
{	
	if(vialSys == NULL)
	{	
		showWarning("vialSys null, creat prompter module failed!\r\n");
		return NULL;	
	}	
	
	if(!adverModule_instance)
			adverModule_instance = new PhonebookModule(vialSys);
		
	return adverModule_instance;
}	
	
/**************************************************************
**PrompterModule
**(�绰״̬)��ʾģ��
**
**************************************************************/
PhonebookModule::PhonebookModule(VialSystem *vialSys) : AbstractModule(vialSys)
{
	this->vialSys = vialSys;
}

/**************************************************************
**run
**����runѭ��
**
**************************************************************/
void PhonebookModule::run()
{
	vialSys->run();
}

/**************************************************************
**localInit
**ģ���ڲ���ʼ��
**�ú�����init()����
**************************************************************/
bool PhonebookModule::localInit()
{
	showInfo("%s localInit\n", __CLASS__);
	return true;
}

/**************************************************************
**onExit
**����״̬�ı���Ϣ
**�ڲ����д���״̬
**************************************************************/
bool PhonebookModule::onExit()
{
	showInfo("%s onExit\n", __CLASS__);
	return false;
}

bool PhonebookModule::post_vial(Vial *vial, NodeID dstID)
{
	vialSys->postVial(vial, dstID);
}

/**************************************************************
1.	����  			[ON_HOOK, NON_PHONE] 				: StateChangeVial
2.	ժ��  			[OFF_HOOK, V_PHONE] 				: StateChangeVial
3.	��������		[OFF_HOOK, V_PHONE, ����] 	: StateDailVial
4.	����״̬		[RRINGING�� V_PHONE]				: StateChangeVial
5.	����״̬		[NOVIDEO_CONN�� V_PHONE]		: StateChangeVial

6. �������			[RINGING, V_PHONE, ����]		: CallerIDVial 
7. �һ�					[ON_HOOK, NON_PHONE]				: StateChangeVial
8. ��ͨ..  			[VIDEO_CONN, NON_PHONE]			: StateChangeVial
**************************************************************/
bool PhonebookModule::OnReceive(Vial *vial)
{	
	if (AbstractModule::OnReceive(vial))
	{
		showInfo("%s onReceive , return true\n", __CLASS__);
		return true;
	}
	
	#if 1
	switch (vial->vialType)
	{
		case GETVT(StateChangeVial):		
			return on_vial_state_change((StateChangeVial *)vial);
		default:
			showWarning("Can not distiguish vial\n");
			return false;
	}
	#endif
	
	return false;
}

/**************************************************************
						onVialStateChang
**************************************************************/
#if 1
bool PhonebookModule::on_vial_state_change(StateChangeVial *vial)
{
    #if 0
	if(vial == NULL)
	{	
		printf("Vial is Null\n");
		return false;
	}
	else
	{
	    #if 1
		switch(vial->curState.st)
		{		
			case CCST::ON_HOOK:	
				if(vial->oldState.st == CCST::ON_HOOK)
				{
					showDebug("Invalid State : PP_ON_HOOK\n");
					return -1;
				}
				break;
			case CCST::DIALING:
				if(vial->oldState.st == CCST::DIALING||
				   vial->oldState.st == CCST::RINGING||
				   vial->oldState.st == CCST::NOVIDEO_CONN||
				   vial->oldState.st == CCST::VIDEO_CONN)
				{
					showDebug("Invalid State : PP_OFF_HOOK\n");
					return -1;
				}
				break;
			case CCST::RINGING:
				if(vial->oldState.st == CCST::RINGING ||
				   vial->oldState.st == CCST::DIALING ||
				   vial->oldState.st == CCST::NOVIDEO_CONN ||
				   vial->oldState.st == CCST::VIDEO_CONN)
				{
					showDebug("Invalid State : PP_RINGING\n");
					return -1;
				}
				break;
			case CCST::NOVIDEO_CONN:
				if( vial->oldState.st == CCST::NOVIDEO_CONN ||
					vial->oldState.st == CCST::ON_HOOK ||
					vial->oldState.st == CCST::VIDEO_CONN)
				{
					showDebug("Invalid State : PP_CONNECT\n");
					return -1;
				}
				break;
			case CCST::VIDEO_CONN:
				if( vial->oldState.st == CCST::VIDEO_CONN||
					vial->oldState.st == CCST::ON_HOOK ||
					vial->oldState.st == CCST::NOVIDEO_CONN)
				{
					showDebug("Invalid State : PP_CONNECT\n");
					return -1;
				}
				break;
				
			default:
				return false;
		}
	    #endif
	}
	#endif
}
#endif

/************************************************************************************
									onOnHook 
*************************************************************************************/
bool PhonebookModule::on_on_hook(StateChangeVial *vial)
{	
    #if 0
	showDebug("%s, stateVal: %d\n", __FUNCTION__, vial->curState);
	AdverManager *adverManager = AdverManager::get_instance();
	
	pthread_mutex_lock(&(adverManager->mutex));
	adverManager->phoneState = CCST::ON_HOOK;
	pthread_mutex_unlock(&(adverManager->mutex));
	
	sem_post(&(adverManager->timeSem));	
	return true; 
	#endif
}

/**************************************************************
							on_dialing
**************************************************************/
bool PhonebookModule::on_dialing(StateChangeVial *vial)
{
    #if 0
	showDebug("%s, stateVal: %d\n", __FUNCTION__, vial->curState);
	AdverManager *adverManager = AdverManager::get_instance();

	pthread_mutex_lock(&(adverManager->mutex));
	adverManager->phoneState = CCST::DIALING;
	pthread_mutex_unlock(&(adverManager->mutex));
	
	sem_post(&(adverManager->timeSem));	
	return true; 
	#endif
}

/**********************************************************************************************
						               	onRinging
***********************************************************************************************/
bool PhonebookModule::on_ringing(StateChangeVial *vial)
{
    #if 0
	showDebug("%s, stateVal: %d\n", __FUNCTION__, vial->curState);

	AdverManager *adverManager = AdverManager::get_instance();
	pthread_mutex_lock(&(adverManager->mutex));
	adverManager->phoneState = CCST::RINGING;
	pthread_mutex_unlock(&(adverManager->mutex));
	
	sem_post(&(adverManager->timeSem));	
	return true; 
	#endif
}

/************************************************************************************************
					                               	onNoVideoConn
*************************************************************************************************/
bool PhonebookModule::on_novideoconn(StateChangeVial *vial)
{	
    #if 0
	showDebug("%s, stateVal: %d\n", __FUNCTION__, vial->curState);
	AdverManager *adverManager = AdverManager::get_instance();

	pthread_mutex_lock(&(adverManager->mutex));
	adverManager->phoneState = CCST::NOVIDEO_CONN;
	pthread_mutex_unlock(&(adverManager->mutex));
	
	sem_post(&(adverManager->timeSem)); 
	return true; 
	#endif
}

/************************************************************************************************
                                                                         onVideoConn
************************************************************************************************/
bool PhonebookModule::on_videoconn(StateChangeVial *vial)
{	
	showDebug("%s, stateVal: %d\n", __FUNCTION__, vial->curState);
	AdverManager *adverManager = AdverManager::get_instance();

	pthread_mutex_lock(&(adverManager->mutex));
	adverManager->phoneState = CCST::VIDEO_CONN;
	pthread_mutex_unlock(&(adverManager->mutex));
	
	sem_post(&(adverManager->timeSem));	
	return true; 
}







#if 0

#endif



/**************************************************************
**onVialStateDail
**������Ϣ
**���ҽ�����һ״̬ΪOFF_HOOKʱ�����յ�������Ϣ
**************************************************************/
#if 0
bool AdverModule::onVialDialNotify(DialNotifyVial *vial)
{
	if(vial)
	{
		PhoneCode.cPhoneCode[PhoneCode.nCodelen] = vial->code;
		if(PhoneCode.nCodelen >= (VIAL_PHONECODE_LEN-1))
		{
			showWarning("phoneCode too long [%d:%d%s]\n", PhoneCode.nCodelen, VIAL_PHONECODE_LEN-1, PhoneCode.cPhoneCode);
			return true;
		}
		PhoneCode.nCodelen++;
		PhoneCode.cPhoneCode[PhoneCode.nCodelen]= '\0';	
		showWarning("%s::%s, phoneCode : %d -> %s\n", __CLASS__, __FUNCTION__, vial->code-'0', PhoneCode.cPhoneCode);
		
        #if 0
		StatePrompterInfo stateinfo;
		memset(&stateinfo, 0, sizeof(stateinfo));
		
		stateinfo.state = PP_OFF_HOOK;
		strncpy(stateinfo.message, PhoneCode.cPhoneCode, PhoneCode.nCodelen);
		stateinfo.message[PhoneCode.nCodelen]= '\0';
		showInfo("update_prompter_info : %d, %s\r\n", stateinfo.state, stateinfo.message);
		update_prompter_info(&stateinfo);
		#endif
		
	}
	else
		showWarning("%s::%s, vial null\n", __CLASS__, __FUNCTION__);
	
	return true;	
}
#endif

/**************************************************************
**onVialCallerID
**���������Ϣ
**���ҽ�����һ״̬ΪRINGRINGʱ�����յ����������Ϣ
**************************************************************/
#if 0
bool AdverModule::onVialCallerPhoneCode(CallerPhoneCodeVial *vial)
{
	if(vial)
	{
		showWarning("%s::%s\n", __CLASS__, __FUNCTION__);
		PhoneCode.nCallType = 0;
		//strncpy(PhoneCode.cPhoneCode, vial->cPhoneCode, vial->nLen);
		strncpy(PhoneCode.cPhoneCode, vial->cPhoneCode, VIAL_PHONECODE_LEN-1);
		PhoneCode.nCodelen = vial->nLen;
		PhoneCode.cPhoneCode[PhoneCode.nCodelen]= '\0';	

        #if 0
		StatePrompterInfo stateinfo;
		memset(&stateinfo, 0, sizeof(stateinfo));

		stateinfo.state = PP_RINGING;
		strncpy(stateinfo.message, vial->cPhoneCode, vial->nLen);
		stateinfo.message[vial->nLen]= '\0';
		showInfo("update_prompter_info : %d, %s\r\n", stateinfo.state, stateinfo.message);
		update_prompter_info(&stateinfo);
		#endif

		showWarning("%s::%s, phoneCode : %s\n", __CLASS__, __FUNCTION__, PhoneCode.cPhoneCode);

		
	}
	else
		showWarning("%s::%s, vial null\n", __CLASS__, __FUNCTION__);
	
	return true;
}
#endif

