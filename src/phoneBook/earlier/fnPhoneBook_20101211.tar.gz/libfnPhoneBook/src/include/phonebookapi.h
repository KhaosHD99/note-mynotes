#ifndef PHONEBOOKAPI_DEF
#define PHONEBOOKAPI_DEF

#include "phonebookinfo.h"

#ifdef __cplusplus 
extern "C" 
{ 
#endif 

	//contact
	int get_contact_count();
	int get_contact_by_index(Contact *contact,	int index); 
	int get_contact_by_name(Contact *contact,	const char *szname);
	int get_contact_by_letter(Contact *contact, const char *szletter);		 
	int get_contact_by_phone(Contact *contact,	const char *szphone);		 
	 									
	int add_contact(Contact *contact);
	int add_contact_by_index(Contact *contact, int index);
	 	
	int update_contact_by_index(Contact *contact, int index);	
	 	
	int delete_contact_by_index(int index);
	int delete_contact_all();
	
	//calllog
	int get_calllog_count();
	int get_calllog_count_by_type(CLSTATUS status);	 
	int get_calllog_by_index(CallLog *calllog, int index, CLSTATUS status); 
    
	int add_calllog(CallLog *calllog);

	int update_calllog_by_index(CallLog *calllog, int index, CLSTATUS status);
    
	int delete_calllog_by_index(int index, CLSTATUS status);
	int delete_calllog_by_status(CLSTATUS status);
    
	int phone_incoming(char *phone_num);
	int phone_dial(char *phone_num);

    //quickdial
	int get_quickdial_count();
	int get_quickdial_by_index(Quickdial* quickdial, int index);
	
	int add_quickdial(Quickdial *quickdial);
	
	int delete_quickdial_by_index(int index);
	
	//blacklist
	int get_blacklist_count();
	int get_blacklist_by_index(Blacklist *blacklist, int index);
	
	int add_blacklist(Blacklist *blacklist);
	
	int delete_blacklist_by_index(int index);
	
    //commonphone
    int get_commonphone_count();
	int get_commonphone_by_index(Commonphone *commonphone, int index);
	
	//config
	const char *get_value_from_key(const char *key);

#ifdef _cplusplus 
} 
#endif

#endif
