#include <string.h>
#include <stdio.h>

#include "TVManager.h"

#ifdef __cplusplus
extern "C" 
{
#endif

/**************************************************************************************************/
/**************************************** GtkManager ***************************************************/
/**************************************************************************************************/
int init_gtk_manager(GdkScreen *screen)
{
	GtkManager *manager = GtkManager::get_instance();
  	return manager->init_gtk_manager(screen);
}

GtkWidget* create_gtk_window(int width, int height)
{	
	GtkManager *manager = GtkManager::get_instance();
  	return manager->create_gtk_window(width, height);
}	
	
GtkWidget* create_gtk_fixed(int width, int height)
{	
	GtkManager *manager = GtkManager::get_instance();
  	return manager->create_gtk_fixed(width, height);
}

GtkWidget* create_gtk_image(char *img_path, int width, int height)
{
	GtkManager *manager = GtkManager::get_instance();
  	return manager->create_gtk_image(img_path, width, height);
}

int get_screen_width()
{
	GtkManager *manager = GtkManager::get_instance();
  	return manager->get_screen_width();
}

int get_screen_height()
{
	GtkManager *manager = GtkManager::get_instance();
  	return manager->get_screen_height();
}

/* Layout */
int get_widget_layout_info_by_name(LayoutInfo *layout_info, char *widget_name)
{
	GtkManager *manager = GtkManager::get_instance();
	return manager->get_widget_layout_info_by_name(layout_info, widget_name);
}

/* Play List */
int get_top_playinfo(Playinfo *playinfo)
{	
	GtkManager *manager = GtkManager::get_instance();
	return manager->get_top_playinfo(playinfo);
}
	
int get_child_playinfo_by_name(Playinfo *playinfo, char *name)
{		
	GtkManager *manager = GtkManager::get_instance();
	return manager->get_child_playinfo_by_name(playinfo, name);
}
	
#ifdef __cplusplus
}
#endif

