#include "TVManager.h"

GtkManager::GtkManager()
{
	init();
}

GtkManager::~GtkManager()
{
	uninit();
}

void GtkManager::init()
{	
	gdk_screen = NULL;
}

void GtkManager::uninit()
{	
	
}

/* ************************************************************************************************
				                           			       Single Instance
**************************************************************************************************/
GtkManager* GtkManager::instance = NULL;
GtkManager* GtkManager::get_instance()
{
	if(!instance)
		instance = new GtkManager;
	
	return instance;
}

int GtkManager::init_gtk_manager(GdkScreen *screen)
{	
	if(!screen)
		return -1;
	
	gdk_screen = screen;
	showInfo("------------------ Screen width: %d, Height: %d ------------------\n", gdk_screen_get_width(gdk_screen), 
			 							     										 gdk_screen_get_height(gdk_screen));
	return 0;
}	


GtkWidget* GtkManager::create_gtk_window(int width, int height)
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}	
	
	GtkWidget* window;
	
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(GTK_WIDGET(window), 
								width, 
								height);
	
	return window;
}
GtkWidget* GtkManager::create_gtk_fixed(int width, int height)
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}
	
	GtkWidget* fixed;
	
	fixed = gtk_fixed_new();
	gtk_widget_set_size_request(GTK_WIDGET(fixed), 
								width, 
								height);

	return fixed;
}
/*
GtkWidget* GtkManager::create_gtk_table(int column_count, int row_count)
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}
	
	GtkWidget *table;
		
	table = gtk_table_new(column_count, row_count, FALSE);
	gtk_widget_set_size_request(GTK_WIDGET(table), 
								gdk_screen_get_width(gdk_screen) / 10 * 9, 
								gdk_screen_get_height(gdk_screen) / 10 * 9);
	
	return table;
}*/

GtkWidget* GtkManager::create_gtk_image(char *img_path, int width, int height)
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}
	
	GtkWidget *image;
	GdkPixbuf *pixbuf;
	
	image =  gtk_image_new_from_file(img_path);
	pixbuf = gdk_pixbuf_scale_simple(gtk_image_get_pixbuf(GTK_IMAGE(image)),
									 width, 
									 height,
									 GDK_INTERP_NEAREST);
	gtk_widget_destroy(image);
	
	image = gtk_image_new_from_pixbuf(pixbuf);
	//gdk_widget_destroy(pixbuf);
	
	return image;
}	

int GtkManager::get_screen_width()
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}

	return gdk_screen_get_width(gdk_screen);
}

int GtkManager::get_screen_height()
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}

	return gdk_screen_get_height(gdk_screen);
}

int GtkManager::get_widget_layout_info_by_name(LayoutInfo *layout_info, char *widget_name)
{	
	if(!layout_info)
		return -1;
	
	int i = 0;
	xmlNodePtr element = NULL;
	xmlNodePtr root_element = NULL;
	xmlChar *name = NULL;
	xmlChar *x_xmlchar = NULL;
	xmlChar *y_xmlchar = NULL;
	xmlChar *width_xmlchar = NULL;
	xmlChar *height_xmlchar = NULL;
	
	root_element = xml_read_root_node((char *)TV_SCHEME_FILE_PATH);
	if(!root_element)
	{
		showWarning("%s: Read Root Element Fail\r\n", __FUNCTION__);
		goto ERR;
	}
	
	element = xml_read_child_node(root_element);
	if(!element)
	{	
		showWarning("%s: Read Element Fail\r\n", __FUNCTION__);
		goto ERR;
	}
	
	#if 1
    i = 0;
	while(element)
	{	
		name = xml_read_attribute_value(element, BAD_CAST "name");
		if(!name)
			goto ERR;
		
		if(0 == strcmp(widget_name, (char *)name))
		{	
			x_xmlchar = xml_read_attribute_value(element, BAD_CAST "x");
			y_xmlchar = xml_read_attribute_value(element, BAD_CAST "y");
			width_xmlchar = xml_read_attribute_value(element, BAD_CAST "width");
			height_xmlchar = xml_read_attribute_value(element, BAD_CAST "height");
			
			if(x_xmlchar)
				sscanf((const char *)x_xmlchar, "%d", &layout_info->x);
			if(y_xmlchar)
				sscanf((const char *)y_xmlchar, "%d", &layout_info->y);
			if(width_xmlchar)
				sscanf((const char *)width_xmlchar, "%d", &layout_info->width);
			if(height_xmlchar)
				sscanf((const char *)height_xmlchar, "%d", &layout_info->height);

			//showInfo("---- Widget: %s LayoutInfo x: %d, y: %d, width: %d, height: %d ----\n", name,
			//																				  layout_info->x,
			//																			      layout_info->y,
			//																			      layout_info->width,
	        //																			      layout_info->height);
			goto SUC;
		}
		
		element = xml_read_brother_node(element);
	}	
	#endif
	
ERR:	
	free_xml_parser();
	return -1;
	
SUC:
	free_xml_parser();
	return 0;
}

int GtkManager::get_top_playinfo(Playinfo *playinfo)
{	
	#if 1
	xmlNodePtr element = NULL;
	xmlNodePtr root_element = NULL;
	xmlChar *name = NULL;
	int i = 0;
	
	root_element = xml_read_root_node((char *)TV_PLAYLIST_FILE_PATH);
	if(!root_element)
	{
		showWarning("%s: Read Root Element Fail\r\n", __FUNCTION__);
		goto ERR;
	}
	
	element = xml_read_child_node(root_element);
	if(!element)
	{	
		showWarning("%s: Read Element Fail\r\n", __FUNCTION__);
		goto ERR;
	}
	#endif
	
	while(element)
	{	
		name = xml_read_attribute_value(element, BAD_CAST "name");
		if(!name)
			goto ERR;
			
		strcpy(playinfo->name[i], (const char *)name);
		playinfo->count++;
		//showInfo("------- Name: %s -----------\n", name);
		element = xml_read_brother_node(element);
		i++;
	}
	
	SUC:
	free_xml_parser();
	return 0;
	
	ERR:	
	free_xml_parser();
	return -1;
}	

int GtkManager::get_child_playinfo_by_name(Playinfo *playinfo, char *name)
{	
#if 1
	xmlNodePtr element = NULL;
	xmlNodePtr root_element = NULL;
	xmlChar *channel_name = NULL;
	
	root_element = xml_read_root_node((char *)TV_PLAYLIST_FILE_PATH);
	if(!root_element)
	{				
		showWarning("%s: Read Root Element Fail\r\n", __FUNCTION__);
		goto ERR;
	}		
		
	element = xml_read_child_node(root_element);
	if(!element)
	{			
		showWarning("%s: Read Element Fail\r\n", __FUNCTION__);
		goto ERR;
	}
#endif
	
	test_recurse(element, playinfo, name);
	//showError("----------- get_channel_by_list_name Error-------------\n");
	
	SUC:
	free_xml_parser();
	return 0;
	
	ERR:	
	free_xml_parser();
	return -1;
}

int GtkManager::test_recurse(xmlNodePtr node, Playinfo *playinfo, char *name)
{	
	xmlNodePtr child;
	xmlChar *channel_name = NULL;
		
	while(node)
	{	
		channel_name = xml_read_attribute_value(node, BAD_CAST "name");
		if(!channel_name)														
			showWarning("------------ Get Name Error -------------\n");
		
		if(0 == strcmp(name, (const char *)channel_name))
		{
			child = xml_read_child_node(node);
			if(!child)
				showError("---------------- Get Channel Fail --------------------\n");

			int i = 0;
			while(child)
			{
				channel_name = xml_read_attribute_value(child, BAD_CAST "name");
				if(channel_name)
				{		
					strcpy(playinfo->name[i], (const char *)channel_name);
					playinfo->count++;
				}	
								
				child = xml_read_brother_node(child);
				i++;	
			}	
			return 0;
		}	
		
		child = xml_read_child_node(node);
		if(child)	
			test_recurse(child, playinfo, name);
		
		node = xml_read_brother_node(node);
	}	
	
	return 0;
	
	#if 0
	xmlNodePtr child;
	xmlChar *title = NULL;
		
	while(node)
	{	
		title = xml_read_attribute_value(node, BAD_CAST "name");
		if(title)
			showInfo("---------- Play Type: %s, Name: %s, XMLType: %d -------------\n", node->name,
							     														 title,
																						 node->type);
		else		
			showWarning("------------ Get Title Error -------------\n");
		child = xml_read_child_node(node);
		if(child)
			test_recurse(child);
		
		//showInfo("------- Title Name: %s -----------\n", name);
		node = xml_read_brother_node(node);
	}	
	
	SUC:
	free_xml_parser();
	return 0;
	
	ERR:	
	free_xml_parser();
	return -1;
	#endif
}

