#include <stdlib.h>
#include <string.h>
#include <gdk/gdkkeysyms.h>
#include <gtk/gtk.h>

#include "TVManagerInterface.h"
#include "televisionskin.h"
#include "windowstack.h"
#include "LogMsg.hpp"
	
GtkWidget *eventbox_media_service;
GtkWidget *eventbox_video_phone;
GtkWidget *eventbox_phonebook;
GtkWidget *eventbox_web;
GtkWidget *eventbox_setting;

GtkWidget *image_media_service;
GtkWidget *image_video_phone;
GtkWidget *image_phonebook;
GtkWidget *image_web;
GtkWidget *image_setting;

GdkBitmap *bitmap_media_service;
GdkBitmap *bitmap_video_phone;
GdkBitmap *bitmap_phonebook;
GdkBitmap *bitmap_web;
GdkBitmap *bitmap_setting;

//Layout
LayoutInfo layout_window;
LayoutInfo layout_eventbox;
LayoutInfo layout_image;
	
void button_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{		
	if(0 == strcmp(user_data, "media_service"))
		showInfo("Click %s\n", "media_service");
	else if(0 == strcmp(user_data, "video_phone"))
		showInfo("Click %s\n", "video_phone");
	else if(0 == strcmp(user_data, "web"))
		showInfo("Click %s\n", "web");
	else if(0 == strcmp(user_data, "phonebook"))
		showInfo("Click %s\n", "phonebook");
	else if(0 == strcmp(user_data, "setting"))
		showInfo("Click %s\n", "setting");
	else
		showInfo("%s: Can not Disguish Button\n", __FUNCTION__);
}

/* Cursor Hold/Leave */
void enter_notify_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
	showDebug("Get in %s \n", __FUNCTION__);
}

void leave_notify_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
	showDebug("Get in %s \n", __FUNCTION__);
}

/* Focus In/Focus Out */
void focus_in_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{	
	char img_path[128];
	GtkWidget *image_tmp;
	
	if(0 == strcmp(user_data, "media_service"))
	{	
		showInfo("Focus in %s\n", "media_service");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_MEDIA_SERVICE_FOCUSED);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_media_service, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}	
	else if(0 == strcmp(user_data, "video_phone"))		
	{	
		showInfo("Focus in %s\n", "video_phone");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_VIDEO_PHONE_FOCUSED);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_video_phone, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}		
	else if(0 == strcmp(user_data, "web"))
	{	
		showInfo("Focus in %s\n", "web");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_WEB_FOCUSED);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_web, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}	
	else if(0 == strcmp(user_data, "phonebook"))	
	{	
		showInfo("Focus in %s\n", "phonebook");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_PHONEBOOK_FOCUSED);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_phonebook, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}	
	else if(0 == strcmp(user_data, "setting"))	
	{	
		showInfo("Focus in %s\n", "setting");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_SETTING_FOCUSED);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_setting, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}
	else
	{	
		showInfo("%s: Can not Disguish User Data: %s\n", __FUNCTION__, user_data);
		return;
	}	
	
	gtk_widget_destroy(image_tmp);
}	
	
void focus_out_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{	
	char img_path[128];
	GtkWidget *image_tmp;
	
	if(0 == strcmp(user_data, "media_service"))
	{
		showInfo("Focus out %s\n", "media_service");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_MEDIA_SERVICE);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_media_service, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}		
	else if(0 == strcmp(user_data, "video_phone"))		
	{
		showInfo("Focus out %s\n", "video_phone");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_VIDEO_PHONE);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_video_phone, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}			
	else if(0 == strcmp(user_data, "web"))
	{
		showInfo("Focus out %s\n", "web");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_WEB);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_web, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}	
	else if(0 == strcmp(user_data, "phonebook"))	
	{		
		showInfo("Focus out %s\n", "phonebook");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_PHONEBOOK);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_phonebook, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}
	else if(0 == strcmp(user_data, "setting"))	
	{	
		showInfo("Focus out %s\n", "setting");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_SETTING);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_setting, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}			
	else
	{	
		showInfo("%s: Can not Disguish User Data: %s\n", __FUNCTION__, user_data);
		return;
	}
	
	gtk_widget_destroy(image_tmp);
}

int show_main_window()
{	
	#if 1
	GtkWidget* window;	
	GtkWidget* fixed;
		
	GdkPixbuf *pixbuf;
	GdkPixmap *pixmap;
	GdkBitmap *bitmap;
	GtkWidget *bg_image;
	char img_path[128];
		
	/* ---------------------------------- Create Main Window ------------------------------------*/
	window	= create_gtk_window(layout_window.width, layout_window.height);
	if(!window)
	{	
		showError("window is NULL\n");
		return -1;
	}	
	gtk_window_move(GTK_WINDOW(window), layout_window.x, layout_window.y);
	gtk_window_set_decorated(GTK_WINDOW(window), FALSE);
	gtk_widget_set_app_paintable(window, TRUE);
	
	//Create Main Window Back Groud Image
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BG);
	bg_image = create_gtk_image(img_path, layout_window.width, layout_window.height);
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(bg_image)), &pixmap, &bitmap, 128);
	gtk_widget_shape_combine_mask(window, bitmap, 0, 0);
	
	/* ------------------------------- Create Fixed ----------------------------------*/
	fixed = create_gtk_fixed(layout_window.width, layout_window.height);
	gtk_container_add(GTK_CONTAINER(window), fixed);
	gtk_widget_show(fixed);
	
	/* ------------------------------- Create EvenBox --------------------------------*/
	int increment_x_eventbox = layout_eventbox.x * 3;
	int increment_y_eventbox = layout_eventbox.y * 2;
	
	showInfo("------- increment_x_eventbox: %d, increment_y_eventbox: %d\n", increment_x_eventbox,
																			 increment_y_eventbox);
							
	//Media Service
	eventbox_media_service = gtk_event_box_new();
	gtk_widget_set_can_focus(eventbox_media_service, TRUE);
	gtk_container_add(GTK_CONTAINER(fixed), eventbox_media_service);
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_media_service, layout_eventbox.x, layout_eventbox.y);
	gtk_widget_show (eventbox_media_service);						
	
	//Video Phone
	eventbox_video_phone = gtk_event_box_new();
	gtk_widget_set_can_focus(eventbox_video_phone, TRUE);
	gtk_container_add(GTK_CONTAINER(fixed), eventbox_video_phone);
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_video_phone, layout_eventbox.x + increment_x_eventbox, layout_eventbox.y);
	gtk_widget_show (eventbox_video_phone);
		
	//Phonebook
	eventbox_phonebook = gtk_event_box_new();
	gtk_widget_set_can_focus(eventbox_phonebook, TRUE);
	gtk_container_add(GTK_CONTAINER(fixed), eventbox_phonebook);
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_phonebook, layout_eventbox.x + increment_x_eventbox * 2, layout_eventbox.y);
	gtk_widget_show (eventbox_phonebook);
			
	//Web	
	eventbox_web = gtk_event_box_new();
	gtk_widget_set_can_focus(eventbox_web, TRUE);
	gtk_container_add(GTK_CONTAINER(fixed), eventbox_web);
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_web, layout_eventbox.x + increment_x_eventbox * 3, layout_eventbox.y);
	gtk_widget_show (eventbox_web);
	
	//Setting
	eventbox_setting = gtk_event_box_new();
	gtk_widget_set_can_focus(eventbox_setting, TRUE);
	gtk_container_add(GTK_CONTAINER(fixed), eventbox_setting);
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_setting, layout_eventbox.x, layout_eventbox.y + increment_y_eventbox);
	gtk_widget_show (eventbox_setting);
	
	/* ----------------------------------- Create Image ----------------------------------------*/
	//Media Service
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_MEDIA_SERVICE);
	image_media_service = create_gtk_image(img_path, layout_image.width, layout_image.height);
	gtk_container_add(GTK_CONTAINER(eventbox_media_service), image_media_service);
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_media_service)), 
									  NULL,
									  &bitmap_media_service,
									  128);
	gtk_widget_shape_combine_mask(eventbox_media_service, bitmap_media_service, 0, 0);
	gtk_widget_show (image_media_service);
	
	//Video Phone
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_VIDEO_PHONE);
	image_video_phone =  create_gtk_image(img_path, layout_image.width, layout_image.height);
	gtk_container_add(GTK_CONTAINER(eventbox_video_phone), image_video_phone);
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_video_phone)),
									  NULL,
									  &bitmap_video_phone,
									  128);
	gtk_widget_shape_combine_mask(eventbox_video_phone, bitmap_video_phone, 0, 0);
	gtk_widget_show (image_video_phone);
	
	//PhoneBook
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_PHONEBOOK);
	image_phonebook =  create_gtk_image(img_path, layout_image.width, layout_image.height);
	gtk_container_add(GTK_CONTAINER(eventbox_phonebook), image_phonebook);
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_phonebook)), 
									  NULL,
									  &bitmap_phonebook, 
									  128);
	gtk_widget_shape_combine_mask(eventbox_phonebook, bitmap_phonebook, 0, 0);
	gtk_widget_show (image_phonebook);
	
	//Web
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_WEB);
	image_web =  create_gtk_image(img_path, layout_image.width, layout_image.height);
	gtk_container_add(GTK_CONTAINER(eventbox_web), image_web);
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_web)), 
									  NULL,
									  &bitmap_web, 
									  128);
	gtk_widget_shape_combine_mask(eventbox_web, bitmap_web, 0, 0);
	gtk_widget_show (image_web);

	//Setting
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_MAIN_WINDOW_BUTTON_SETTING);
	image_setting = create_gtk_image(img_path, layout_image.width, layout_image.height);
	gtk_container_add(GTK_CONTAINER(eventbox_setting), image_setting);
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_setting)), 
									  NULL,
									  &bitmap_setting, 
									  128);
	gtk_widget_shape_combine_mask(eventbox_setting, bitmap_setting, 0, 0);
	gtk_widget_show (image_setting);
	
	/*-------------------------------  Event --------------------------------*/
	//Media Service
	g_signal_connect(G_OBJECT(eventbox_media_service), "button_press_event",
					 G_CALLBACK(button_press_event), "media_service");
	g_signal_connect(G_OBJECT(eventbox_media_service), "enter_notify_event",
					 G_CALLBACK(focus_in_event), "media_service");
	g_signal_connect(G_OBJECT(eventbox_media_service), "leave_notify_event",
					 G_CALLBACK(focus_out_event), "media_service");
	g_signal_connect(G_OBJECT(eventbox_media_service), "focus_in_event",
					 G_CALLBACK(focus_in_event), "media_service");
	g_signal_connect(G_OBJECT(eventbox_media_service), "focus_out_event",
					 G_CALLBACK(focus_out_event), "media_service");
	
	//Video Phone
	g_signal_connect(G_OBJECT(eventbox_video_phone), "button_press_event",
					 G_CALLBACK(button_press_event), "video_phone");
	g_signal_connect(G_OBJECT(eventbox_video_phone), "enter_notify_event",
					 G_CALLBACK(focus_in_event), "video_phone");
	g_signal_connect(G_OBJECT(eventbox_video_phone), "leave_notify_event",
					 G_CALLBACK(focus_out_event), "video_phone");
	g_signal_connect(G_OBJECT(eventbox_video_phone), "focus_in_event",
					 G_CALLBACK(focus_in_event), "video_phone");
	g_signal_connect(G_OBJECT(eventbox_video_phone), "focus_out_event",
					 G_CALLBACK(focus_out_event), "video_phone");
	
	//Web
	g_signal_connect(G_OBJECT(eventbox_web), "button_press_event",
					 G_CALLBACK(button_press_event), "web");
	g_signal_connect(G_OBJECT(eventbox_web), "enter_notify_event",
					 G_CALLBACK(focus_in_event), "web");
	g_signal_connect(G_OBJECT(eventbox_web), "leave_notify_event",
					 G_CALLBACK(focus_out_event), "web");
	g_signal_connect(G_OBJECT(eventbox_web), "focus_in_event",
					 G_CALLBACK(focus_in_event), "web");
	g_signal_connect(G_OBJECT(eventbox_web), "focus_out_event",
					 G_CALLBACK(focus_out_event), "web");
	
	//Phonebook
	g_signal_connect(G_OBJECT(eventbox_phonebook), "button_press_event",
					 G_CALLBACK(button_press_event), "phonebook");
	g_signal_connect(G_OBJECT(eventbox_phonebook), "enter_notify_event",
					 G_CALLBACK(focus_in_event), "phonebook");
	g_signal_connect(G_OBJECT(eventbox_phonebook), "leave_notify_event",
					 G_CALLBACK(focus_out_event), "phonebook");
	g_signal_connect(G_OBJECT(eventbox_phonebook), "focus_in_event",
					 G_CALLBACK(focus_in_event), "phonebook");
	g_signal_connect(G_OBJECT(eventbox_phonebook), "focus_out_event",
					 G_CALLBACK(focus_out_event), "phonebook");
	
	//Setting
	g_signal_connect(G_OBJECT(eventbox_setting), "button_press_event",
					 G_CALLBACK(button_press_event), "setting");
	g_signal_connect(G_OBJECT(eventbox_setting), "enter_notify_event",
					 G_CALLBACK(focus_in_event), "setting");
	g_signal_connect(G_OBJECT(eventbox_setting), "leave_notify_event",
					 G_CALLBACK(focus_out_event), "setting");
	g_signal_connect(G_OBJECT(eventbox_setting), "focus_in_event",
					 G_CALLBACK(focus_in_event), "setting");
	g_signal_connect(G_OBJECT(eventbox_setting), "focus_out_event",
					 G_CALLBACK(focus_out_event), "setting");
	
	/* ---------------- Realize and Set Cursor ----------------*/
	gtk_widget_realize (eventbox_media_service);
	gtk_widget_realize (eventbox_video_phone);
	gtk_widget_realize (eventbox_web);
	gtk_widget_realize (eventbox_phonebook);
	gtk_widget_realize (eventbox_setting);
	gdk_window_set_cursor (eventbox_media_service->window, gdk_cursor_new (GDK_HAND1));
	gdk_window_set_cursor (eventbox_video_phone->window, gdk_cursor_new (GDK_HAND1));
	gdk_window_set_cursor (eventbox_web->window, gdk_cursor_new (GDK_HAND1));
	gdk_window_set_cursor (eventbox_phonebook->window, gdk_cursor_new (GDK_HAND1));
	gdk_window_set_cursor (eventbox_setting->window, gdk_cursor_new (GDK_HAND1));
	
	/*------------------ Set Irregular Window --------------------*/
	gdk_window_set_back_pixmap(window->window, pixmap, FALSE);
	
	gtk_widget_show(window);
	
	return 0;
	#endif
}

int set_layout_info()
{	
	/*--------------------------------- Set Layout Info ---------------------------------*/
	//Window
	memset(&layout_window, 0 , sizeof(LayoutInfo));
	if(get_widget_layout_info_by_name(&layout_window, "window"))
	{			
		showError("------------------ Get Widget LayoutInfo Fail-----------------------\n");
		return -1;
	}
	
	layout_window.x = layout_window.x * get_screen_width() / BASE_SCREEN_WIDTH;
	layout_window.y = layout_window.y * get_screen_height() / BASE_SCREEN_HEIGHT;
	layout_window.width = layout_window.width * get_screen_width() / BASE_SCREEN_WIDTH;
	layout_window.height = layout_window.height * get_screen_height() / BASE_SCREEN_HEIGHT;
	
	showInfo("---- Window LayoutInfo x: %d, y: %d, width: %d, height: %d ----\n", layout_window.x,
																			      layout_window.y,
																			      layout_window.width,
																			      layout_window.height);
	
	//EventBox
	memset(&layout_eventbox, 0 ,sizeof(LayoutInfo));
	if(get_widget_layout_info_by_name(&layout_eventbox,"eventbox_main_menu"))
	{			
		showError("------------------ Get Widget LayoutInfo Fail-----------------------\n");
		return -1;
	}		
	layout_eventbox.x = layout_eventbox.x * get_screen_width() / BASE_SCREEN_WIDTH;
	layout_eventbox.y = layout_eventbox.y * get_screen_height() / BASE_SCREEN_HEIGHT;

	showInfo("---- EventBox LayoutInfo x: %d, y: %d, width: %d, height: %d ----\n", layout_eventbox.x,
																			        layout_eventbox.y,
																			        layout_eventbox.width,
																			        layout_eventbox.height);
		
	//Image
	memset(&layout_image, 0 ,sizeof(LayoutInfo));
	if(get_widget_layout_info_by_name(&layout_image,"image_main_menu"))
	{			
		showError("------------------ Get Widget LayoutInfo Fail-----------------------\n");
		return -1;
	}		
	layout_image.width = layout_image.width * get_screen_width() / BASE_SCREEN_WIDTH;
	layout_image.height = layout_image.height * get_screen_height() / BASE_SCREEN_HEIGHT;
	showInfo("---- Image LayoutInfo x: %d, y: %d, width: %d, height: %d ----\n", layout_image.x,
																		         layout_image.y,
																		         layout_image.width,
																		         layout_image.height);
}

gint main(int argc, char *argv[])
{	
#if 1 //My Prj
	gtk_init(&argc,&argv);
	
	/*--------------------------------- Get X Screen ----------------------------------*/
	GdkDisplay *gdk_display = gdk_display_get_default();
	GdkScreen *gdk_screen = gdk_display_get_default_screen(gdk_display);
	
	init_gtk_manager(gdk_screen);
	set_layout_info();
	
	if(show_main_window())
		showError("------------------ Create Main Window Fail --------------------\n");
	
	#if 0//Test
	Playinfo playinfo;
	memset(&playinfo, 0, sizeof(Playinfo));
	
	get_top_playinfo(&playinfo);
	int i;					
	showInfo("----------------- Playinfo Count: %d, Type: %d ---------------------\n", playinfo.count,
																					   playinfo.type);	   
	for(i = 0; i < playinfo.count; i++)
	{	
		showInfo("----------------- Playinfo %d: %s ---------------------\n", i,
																			  playinfo.name[i]);
	}
	
	memset(&playinfo, 0, sizeof(Playinfo));
	get_child_playinfo_by_name(&playinfo, "newest");
	i = 0;
	showInfo("----------------- Playinfo Count: %d, Type: %d ---------------------\n", playinfo.count,
																					   playinfo.type);
	for(i = 0; i < playinfo.count; i++)
	{
		showInfo("----------------- Playinfo %d: %s ---------------------\n", i,
																			  playinfo.name[i]);
	}
	#endif
	
	gtk_main();
	
#endif
	
	return 0;
}	
	
