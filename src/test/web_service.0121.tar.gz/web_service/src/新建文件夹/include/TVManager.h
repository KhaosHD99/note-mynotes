#ifndef GTK_MANAGER_DEF
#define GTK_MANAGER_DEF

#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>

#include "LogMsg.hpp"
#include "XMLInterface.h"
#include "TVManagerInfo.h"

#define TV_SCHEME_FILE_PATH             "../share/data/appfile/television/tv-layout.xml"
#define TV_PLAYLIST_FILE_PATH             "../share/data/appfile/television/tv-play.xml"

class GtkManager
{
	public:	
    	static GtkManager *instance;
		GdkScreen *gdk_screen; 
	
	private:
		GtkManager();
		~GtkManager();
		void init();	
		void uninit();
		int test_recurse(xmlNodePtr node, Playinfo *playinfo, char *name);
		
	public:
		static GtkManager *get_instance();
		
		int init_gtk_manager(GdkScreen *screen);
		GtkWidget* create_gtk_window(int width, int height);
		GtkWidget* create_gtk_fixed(int width, int height);
		GtkWidget* create_gtk_image(char *img_path, int width, int height);

		/* X Screen */
		int get_screen_width();
		int get_screen_height();

		/* Layout */
		int get_widget_layout_info_by_name(LayoutInfo *layout_info, char *widget_name); 

		/* Play List */	
		int get_top_playinfo(Playinfo *playinfo);
		int get_child_playinfo_by_name(Playinfo *playinfo, char *name);
};

#endif

