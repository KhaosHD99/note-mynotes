#ifndef GTK_MANAGER_INFO_DEF
#define GTK_MANAGER_INFO_DEF

#define MAX_PLAYLIST_COUNT     10
#define MAX_CHANNEL_COUNT      100

enum
{
	LIST,
	CHANNEL
};
	
typedef struct _LayoutInfo
{	
	int x;
	int y;
	int width;
	int height;
}LayoutInfo;

#if 1
typedef struct _Playinfo
{	
	int count;
	char name[MAX_PLAYLIST_COUNT][128];
	int type;
}Playinfo;
#else
typedef struct _Playinfo
{		
	PlayList playList;
}Playinfo;	

typedef struct _PlayChannel
{
	//int channel_id;
	char name[256];
	char url[256];
}PlayChannel;

typedef struct _PlayList
{	
	//int list_id;
	struct _PlayList *pPlayList;
	PlayChannel *pPlayChannel;
}PlayList;
#endif

/*
typedef struct _ChannelList
{	
	int count;
	char channel[MAX_CHANNEL_COUNT][128];
	int type;		
}ChannelList;
*/

#endif

