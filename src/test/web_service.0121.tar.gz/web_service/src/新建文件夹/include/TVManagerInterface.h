#ifndef GTK_MANAGER_INTERFACE_DEF
#define GTK_MANAGER_INTERFACE_DEF

#include "TVManagerInfo.h"
	
#ifdef __cplusplus
extern"C"
{	
#endif
	int init_gtk_manager(GdkScreen *screen);
	/* Return NULL if Create Fail */
	GtkWidget* create_gtk_window(int width, int height);
	
	/* Return NULL if Create Fail */
	GtkWidget* create_gtk_fixed(int width, int height);
	
	/* Return NULL if Create Fail */
	GtkWidget* create_gtk_image(char *img_path, int width, int height);
	
	/* X Screen */
	int get_screen_width();
	int get_screen_height();
	
	/* Layout */
	int get_widget_layout_info_by_name(LayoutInfo *layout_info, char *name);
	
	/* Play List */
	int get_top_playinfo(Playinfo *playinfo);
	int get_child_playinfo_by_name(Playinfo *playinfo, char *name);

#ifdef __cplusplus
}
#endif
	
#endif
