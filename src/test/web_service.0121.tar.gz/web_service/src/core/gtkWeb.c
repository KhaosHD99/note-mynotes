#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>

#include "LogMsg.hpp"
#include "televisionskin.h"


gboolean set_background_pixmap(const gchar *filename, GtkWidget *widget, int width, int height);

static GtkWidget *curr_page_label = NULL;
static GtkWidget *curr_page_info = NULL;
static GtkWidget *menu_eventbox[MAX_MENU_EVENTBOX];
static GtkWidget *menu_label[MAX_MENU_EVENTBOX];
static GtkWidget *detail_eventbox[MAX_DETAIL_EVENTBOX];
static GtkWidget *detail_label[MAX_DETAIL_EVENTBOX];
static GtkWidget *button_eventbox[MAX_BUTTON_EVENTBOX];
static GtkWidget *curr_media_menu = NULL;


static char img_path[MAX_IMAGE_FILE_PATH];



static gboolean on_media_menu_enter_notify_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}
	gtk_widget_grab_focus(widget);

	if(!gtk_widget_has_focus(widget))
		showWarning("widget without focus ! (%s) \n", gtk_widget_get_name(widget));
			
	return TRUE;
}	

static gboolean on_media_menu_focus_out_event(GtkWidget *widget, gpointer user_data);
static gboolean on_media_menu_focus_in_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}
	on_media_menu_focus_out_event(curr_media_menu, NULL);
	curr_media_menu = widget;
	
	char img_path_focused[MAX_IMAGE_FILE_PATH];
	snprintf(img_path_focused, sizeof(img_path_focused)-1, "%s%s", IMAGE_FILE_PATH, IMG_MEDIA_MENU_ACTIVE);
	set_background_pixmap(img_path_focused, widget, 0, 0);

	return TRUE;
}	

static gboolean on_media_menu_focus_out_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}

	//GList *child_list = gtk_container_get_children((GtkContainer*)widget);
	//printf("gtk_widget_get_name : %s \n", gtk_widget_get_name(child_list[0].data));
	
	snprintf(img_path, sizeof(img_path)-1, "%s%s", IMAGE_FILE_PATH, IMG_MEDIA_MENU_NORMAL);
	//gtk_image_set_from_file((GtkImage*)child_list[0].data, img_path);
	set_background_pixmap(img_path, widget, 0, 0);

	return TRUE;
}
	
static gboolean on_media_menu_key_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}
	
	switch(event->keyval) 
	{
		case GDK_Left:
			showDebug("GDK_Left : %d \n", GDK_Left);
			break;
			
		case GDK_Right:
			showDebug("GDK_Right : %d \n", GDK_Right);			
			gtk_widget_grab_focus(detail_eventbox[0]);
			return TRUE;
			//break;
			
		case GDK_Up:
			showDebug("GDK_Up : %d \n", GDK_Up);
			break;
			
		case GDK_Down:
			showDebug("GDK_Down : %d \n", GDK_Down);
			break;
			
		case GDK_Tab:
			showDebug("GDK_Tab : %d \n", GDK_Tab);
			break;
		
		case GDK_KP_Enter:
			showDebug("GDK_KP_Enter : %d \n", GDK_KP_Enter);			
			break;
			
		case GDK_Return:
			showDebug("GDK_Return : %d \n", GDK_Return);
			break;

		case GDK_Escape:
			showDebug("GDK_Escape : %d \n", GDK_Escape);
			break;
			
		default:		
			showDebug("default  \n");
			break;
    }

	return FALSE;	
}

static gboolean on_media_menu_click_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}

	return TRUE;
}

static gboolean on_media_detail_enter_notify_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}
	gtk_widget_grab_focus(widget);

	if(!gtk_widget_has_focus(widget))
		showWarning("widget without focus ! (%s) \n", gtk_widget_get_name(widget));
			
	return TRUE;
}	

static gboolean on_media_detail_focus_in_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}
	
	char img_path_focused[MAX_IMAGE_FILE_PATH];
	snprintf(img_path_focused, sizeof(img_path_focused)-1, "%s%s", IMAGE_FILE_PATH, IMG_MEDIA_DETAIL_ACTIVE);
	set_background_pixmap(img_path_focused, widget, 0, 0);

	if(detail_eventbox[0] == widget)
	{
		if(curr_media_menu)
		{
			snprintf(img_path_focused, sizeof(img_path_focused)-1, "%s%s", IMAGE_FILE_PATH, IMG_MEDIA_MENU_ACTIVE);		
			set_background_pixmap(img_path_focused, curr_media_menu, 0, 0);
		}
	}
	
	return FALSE;
}	

static gboolean on_media_detail_focus_out_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}
	
	snprintf(img_path, sizeof(img_path)-1, "%s%s", IMAGE_FILE_PATH, IMG_MEDIA_DETAIL_NORMAL);
	set_background_pixmap(img_path, widget, 0, 0);

	return TRUE;
}

static gboolean on_media_detail_key_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}

	switch(event->keyval) 
	{
		case GDK_Left:
			showDebug("GDK_Left : %d \n", GDK_Left);
			if(detail_eventbox[0] == widget)
			{
				gtk_widget_grab_focus(curr_media_menu);
				return TRUE;
			}
			if(detail_eventbox[4] == widget)
			{
				gtk_widget_grab_focus(detail_eventbox[3]);
				return TRUE;
			}
			if(detail_eventbox[8] == widget)
			{
				gtk_widget_grab_focus(detail_eventbox[7]);
				return TRUE;
			}
			break;
			
		case GDK_Right:
			showDebug("GDK_Right : %d \n", GDK_Right);			
			if(detail_eventbox[3] == widget)
			{
				gtk_widget_grab_focus(detail_eventbox[4]);
				return TRUE;
			}
			if(detail_eventbox[7] == widget)
			{
				gtk_widget_grab_focus(detail_eventbox[8]);
				return TRUE;
			}
			if(detail_eventbox[11] == widget)
			{
				gtk_widget_grab_focus(detail_eventbox[0]);
				return TRUE;
			}
			break;
			
		case GDK_Up:
			showDebug("GDK_Up : %d \n", GDK_Up);
			if(detail_eventbox[0] == widget)
			{
				gtk_widget_grab_focus(detail_eventbox[11]);
			}
			if(detail_eventbox[1] == widget)
			{
				gtk_widget_grab_focus(detail_eventbox[0]);
			}
			if(detail_eventbox[2] == widget)
			{
				gtk_widget_grab_focus(detail_eventbox[1]);
			}
			if(detail_eventbox[3] == widget)
			{
				gtk_widget_grab_focus(detail_eventbox[2]);
			}
			break;
			
		case GDK_Down:
			showDebug("GDK_Down : %d \n", GDK_Down);
			if(detail_eventbox[8] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[9]);
				return TRUE;
			}
			if(detail_eventbox[9] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[10]);
				return TRUE;
			}
			if(detail_eventbox[10] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[11]);
				return TRUE;
			}
			if(detail_eventbox[11] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[0]);
				return TRUE;
			}
			break;
			
		case GDK_Tab:
			showDebug("GDK_Tab : %d \n", GDK_Tab);
			break;
		
		case GDK_KP_Enter:
			showDebug("GDK_KP_Enter : %d \n", GDK_KP_Enter);			
			break;
			
		case GDK_Return:
			showDebug("GDK_Return : %d \n", GDK_Return);
			break;

		case GDK_Escape:
			showDebug("GDK_Escape : %d \n", GDK_Escape);
			break;
			
		default:		
			showDebug("default  \n");
			break;
    }

	return FALSE;	
}

static gboolean on_media_detail_click_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}

	return TRUE;
}

static gboolean on_button_enter_notify_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}
	gtk_widget_grab_focus(widget);

	if(!gtk_widget_has_focus(widget))
		showWarning("widget without focus ! (%s) \n", gtk_widget_get_name(widget));
			
	return TRUE;
}	

static gboolean on_button_focus_in_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}
	
	char img_path_focused[MAX_IMAGE_FILE_PATH];
	snprintf(img_path_focused, sizeof(img_path_focused)-1, "%s%s", IMAGE_FILE_PATH, IMG_MEDIA_BUTTON_ACTIVE);
	set_background_pixmap(img_path_focused, widget, 0, 0);

	return FALSE;
}	

static gboolean on_button_focus_out_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}
	
	snprintf(img_path, sizeof(img_path)-1, "%s%s", IMAGE_FILE_PATH, IMG_MEDIA_BUTTON_NORMAL);
	set_background_pixmap(img_path, widget, 0, 0);

	return TRUE;
}

static gboolean on_button_key_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}

	switch(event->keyval) 
	{
		case GDK_Left:
			showDebug("GDK_Left : %d \n", GDK_Left);
			if(button_eventbox[0] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[4]);
				return TRUE;
			}
			break;
			
		case GDK_Right:
			showDebug("GDK_Right : %d \n", GDK_Right);
			if(button_eventbox[4] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[0]);
				return TRUE;
			}
			break;
			
		case GDK_Up:
			showDebug("GDK_Up : %d \n", GDK_Up);
			if(button_eventbox[0] == widget)
			{
				gtk_widget_grab_focus(detail_eventbox[11]);
				return TRUE;
			}
			if(button_eventbox[1] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[0]);
				return TRUE;
			}
			if(button_eventbox[2] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[1]);
				return TRUE;
			}
			if(button_eventbox[3] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[2]);
				return TRUE;
			}
			if(button_eventbox[4] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[3]);
				return TRUE;
			}
			break;
			
		case GDK_Down:
			showDebug("GDK_Down : %d \n", GDK_Down);
			if(button_eventbox[0] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[1]);
				return TRUE;
			}
			if(button_eventbox[1] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[2]);
				return TRUE;
			}
			if(button_eventbox[2] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[3]);
				return TRUE;
			}
			if(button_eventbox[3] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[4]);
				return TRUE;
			}
			if(button_eventbox[4] == widget)
			{
				gtk_widget_grab_focus(button_eventbox[0]);
				return TRUE;
			}
			break;
			
		case GDK_Tab:
			showDebug("GDK_Tab : %d \n", GDK_Tab);
			break;
		
		case GDK_KP_Enter:
			showDebug("GDK_KP_Enter : %d \n", GDK_KP_Enter);			
			break;
			
		case GDK_Return:
			showDebug("GDK_Return : %d \n", GDK_Return);
			break;

		case GDK_Escape:
			showDebug("GDK_Escape : %d \n", GDK_Escape);
			break;
			
		default:		
			showDebug("default  \n");
			break;
    }

	return FALSE;	
}


static gboolean on_button_click_event(GtkWidget *widget, gpointer user_data)
{	
	showDebug("Get in %s (%s) \n", __FUNCTION__, gtk_widget_get_name(widget));
	if(!widget)
	{	
		showWarning("widget is null ! (%s) \n", gtk_widget_get_name(widget));
		return FALSE;
	}	
		
	return TRUE;
}			
	
int show_web_service_window(int X, int Y, int width, int height)
{	
	GtkWidget *media_window = NULL;
	GtkWidget *media_fixed = NULL;	
	GtkTable  *menu_table = NULL;
	GtkTable  *detail_table = NULL;
	
	int i = 0;

	for(i=0; i<MAX_MENU_EVENTBOX; i++)
		menu_eventbox[i] = NULL;	
	for(i=0; i<MAX_MENU_EVENTBOX; i++)
		menu_label[i] = NULL;
	for(i=0; i<MAX_DETAIL_EVENTBOX; i++)
		detail_eventbox[i] = NULL;
	for(i=0; i<MAX_DETAIL_EVENTBOX; i++)
		detail_label[i] = NULL;
	for(i=0; i<MAX_BUTTON_EVENTBOX; i++)
		button_eventbox[i] = NULL;
	
	/* Get X Screen */
	int screen_width, screen_height, position_x, position_y;
	if(width>0 && height>0 && X>=0 && Y>=0)
	{
		screen_width = width;
		screen_height = height;
		position_x = X;
		position_y = Y;
	}
	else
	{
		return -1;
	}
	showDebug("Screen width: %d, height: %d, position_x: %d, position_y: %d\n", screen_width, screen_height, position_x, position_y);

	/* ------------------------------- Create media Window -------------------------------*/
	media_window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	if(!media_window)
	{
		showWarning("gtk_window_new() failed !\n");
		return -1;
	}
	else
	{		
		gtk_widget_set_size_request(GTK_WIDGET(media_window), screen_width, screen_height);
		gtk_window_move(GTK_WINDOW(media_window), position_x, position_y);
		gtk_window_set_decorated(GTK_WINDOW(media_window), FALSE);	   
		gtk_widget_set_app_paintable(media_window, TRUE);
		gtk_widget_realize(media_window);

		/* Create media Window Back Groud Image */
		snprintf(img_path, sizeof(img_path)-1, "%s%s", IMAGE_FILE_PATH, IMG_MEDIA_WINDOW_BG);

		GdkPixbuf *pixbuf = NULL;
		GdkPixmap *pixmap = NULL;
		GdkBitmap *bitmap = NULL;
		GtkWidget *gtk_image = NULL;

		gtk_image =  gtk_image_new_from_file(img_path);
		if(!gtk_image)
		{
			showWarning("gtk_image_new_from_file() failed !\n");
			return -1;
		}
		pixbuf = gdk_pixbuf_scale_simple(gtk_image_get_pixbuf(GTK_IMAGE(gtk_image)),
										 screen_width, 
										 screen_height,
										 GDK_INTERP_NEAREST);
		
		gdk_pixbuf_render_pixmap_and_mask(pixbuf, &pixmap, &bitmap, 128);		
		gtk_widget_shape_combine_mask(media_window, bitmap, 0, 0);
		gdk_window_set_back_pixmap(media_window->window, pixmap, FALSE);	
		
		gdk_pixbuf_unref(pixbuf);
		gdk_pixmap_unref(pixmap);
		gdk_pixmap_unref(bitmap);
	}

	/*------------------------------- Create Fixed -------------------------------*/
	media_fixed = gtk_fixed_new();
	if(!media_fixed)
	{
		showWarning("gtk_fixed_new() failed !\n");
		return -1;
	}
	gtk_widget_set_size_request(GTK_WIDGET(media_fixed), screen_width, screen_height);
	gtk_container_add(GTK_CONTAINER(media_window), media_fixed);
	gtk_widget_realize(media_fixed);


	/*------------------------------- Create curr_page_label -------------------------------*/
	curr_page_label = gtk_label_new("21/32");
	if(!curr_page_label)
	{
		showWarning("gtk_label_new() failed !\n");
		return -1;
	}
		
	gtk_widget_set_size_request(GTK_WIDGET(curr_page_label), 
								(int)(screen_width/10 * 1), 
								(int)(screen_height/10 * 0.5));	
	gtk_fixed_put(GTK_FIXED(media_fixed), curr_page_label, 
										(int)(screen_width/10 * 8.5), 
										(int)(screen_height/10 * 0.8));
			
	/*------------------------------- Create menu_table -------------------------------*/
	menu_table = gtk_table_new((guint)MAX_MENU_EVENTBOX, (guint)1, TRUE);				//ͳһ��С
	if(!menu_table)
	{
		showWarning("gtk_table_new() failed !\n");
		return -1;
	}
	gtk_table_set_row_spacings((GtkTable*)menu_table, screen_height/10 * 0.1);			//�о�
	//gtk_table_set_col_spacings((GtkTable*)menu_table, screen_width/10 * 0.2);					//�о�
	gtk_widget_set_size_request(GTK_WIDGET(menu_table), 
								(int)(screen_width/10 * 2.2), 
								(int)(screen_height/10 * 8));	
	gtk_fixed_put(GTK_FIXED(media_fixed), GTK_WIDGET(menu_table), 
										(int)(screen_width/10 * 0.3), 
										(int)(screen_height/10 * 0.8));	
	gtk_widget_realize(GTK_WIDGET(menu_table));
	
	snprintf(img_path, sizeof(img_path)-1, "%s%s", IMAGE_FILE_PATH, IMG_MEDIA_MENU_NORMAL);
	
	for(i=0; i<10; i++)
	{	
		/* Add eventbox to menu_table*/
		menu_eventbox[i] = gtk_event_box_new();
		if(!menu_eventbox[i])
		{
			showWarning("gtk_event_box_new() failed : %d !\n", i);
			return -1;
		}
		gtk_widget_set_can_focus(menu_eventbox[i], TRUE);
		char widget_name[32];
		snprintf(widget_name, sizeof(widget_name)-1, "%s%d", "menu_eventbox_", i);
		gtk_widget_set_name(menu_eventbox[i], widget_name);

		/* Add label to menu_eventbox[i] */
		menu_label[i] =  gtk_label_new("电视直播");
		if(!menu_label[i])
		{
			showWarning("gtk_image_new_from_file() failed : %d !\n", i);
			return -1;
		}
		gtk_container_add(GTK_CONTAINER(menu_eventbox[i]), menu_label[i]);

		/* Add menu_eventbox[i] to menu_table */
		gtk_table_attach_defaults((GtkTable*)menu_table, menu_eventbox[i],
								  0, 1,
								  i, i+1);
		set_background_pixmap(img_path, menu_eventbox[i], (int)(screen_width/10 * 2.2), (int)((screen_height/10 * 7.1)/10));
		
		/* Event */		
		g_signal_connect(G_OBJECT(menu_eventbox[i]), "enter-notify-event", G_CALLBACK(on_media_menu_enter_notify_event), NULL);		
		g_signal_connect(G_OBJECT(menu_eventbox[i]), "focus-in-event", G_CALLBACK(on_media_menu_focus_in_event), NULL);
		g_signal_connect(G_OBJECT(menu_eventbox[i]), "focus-out-event", G_CALLBACK(on_media_menu_focus_out_event), NULL);
		g_signal_connect(G_OBJECT(menu_eventbox[i]), "key-press-event", G_CALLBACK(on_media_menu_key_press_event), NULL);		
		g_signal_connect(G_OBJECT(menu_eventbox[i]), "button-press-event", G_CALLBACK(on_media_menu_click_event), NULL);	
		
		gdk_window_set_cursor(menu_eventbox[i]->window, gdk_cursor_new(GDK_HAND2));
	}		
	curr_media_menu = menu_eventbox[0];

	/*------------------------------- Create detail_table -------------------------------*/
	detail_table = gtk_table_new(3, 4, TRUE);
	if(!detail_table)
	{
		showWarning("gtk_table_new() failed !\n");
		return -1;
	}
	gtk_table_set_row_spacings((GtkTable*)detail_table, (int)(screen_height/10 * 0.2));	
	gtk_table_set_col_spacings((GtkTable*)detail_table, (int)(screen_width/10 * 0.2));	
	gtk_widget_set_size_request(GTK_WIDGET(detail_table), 
								screen_width/10 * 6.5, 
								screen_height/10 * 7);
	gtk_fixed_put(GTK_FIXED(media_fixed), GTK_WIDGET(detail_table), 
										(int)(screen_width/10 * 3), 
										(int)(screen_height/10 * 1.5));

	snprintf(img_path, sizeof(img_path)-1, "%s%s", IMAGE_FILE_PATH, IMG_MEDIA_DETAIL_NORMAL);
	int col = 0, row = 0;
	for(i=0; i<MAX_DETAIL_EVENTBOX; i++)
	{
		/* Create eventbox */
		detail_eventbox[i] = gtk_event_box_new();
		if(!detail_eventbox[i])
		{
			showWarning("gtk_event_box_new() failed : %d !\n", i);
			return -1;
		}
		gtk_widget_set_can_focus(detail_eventbox[i], TRUE);
		char widget_name[32];
		snprintf(widget_name, sizeof(widget_name)-1, "%s%d", "detail_eventbox_", i);
		gtk_widget_set_name(detail_eventbox[i], widget_name);
		
		/* Add eventbox to detail_table*/
		gtk_table_attach_defaults((GtkTable*)detail_table, detail_eventbox[i],
								  col, col+1,
								  row, row+1);
		col++;
		if(col == 4)
		{
			col = 0;
			row++;
		}
		set_background_pixmap(img_path, detail_eventbox[i], (int)((screen_width/10 * 5.9)/4), (int)((screen_height/10 * 6.6)/3));
		
		detail_label[i] = gtk_label_new("珠江经济广播电台");
		if(!detail_label[i])
		{
			showWarning("gtk_label_new() failed : %d !\n", i);
			return -1;
		}

		GtkWidget *halign = gtk_alignment_new(0.5, 1, 0, 0);
		if(!halign)
		{
			showWarning("gtk_alignment_new() failed : %d !\n", i);
			return -1;
		}
		gtk_container_add(GTK_CONTAINER(halign), detail_label[i]);
		gtk_container_add(GTK_CONTAINER(detail_eventbox[i]), halign);
	
		/* Event */
		g_signal_connect(G_OBJECT(detail_eventbox[i]), "enter-notify-event", G_CALLBACK(on_media_detail_enter_notify_event), NULL);		
		g_signal_connect(G_OBJECT(detail_eventbox[i]), "focus-in-event", G_CALLBACK(on_media_detail_focus_in_event), NULL);
		g_signal_connect(G_OBJECT(detail_eventbox[i]), "focus-out-event", G_CALLBACK(on_media_detail_focus_out_event), NULL);
		g_signal_connect(G_OBJECT(detail_eventbox[i]), "key-press-event", G_CALLBACK(on_media_detail_key_press_event), NULL);
		g_signal_connect(G_OBJECT(detail_eventbox[i]), "button-press-event", G_CALLBACK(on_media_detail_click_event), NULL);
		
		gdk_window_set_cursor(detail_eventbox[i]->window, gdk_cursor_new(GDK_HAND2));
	}

	/*------------------------------- Create curr_page_info -------------------------------*/
	curr_page_info = gtk_label_new("On Demand");
	if(!curr_page_info)
	{
		showWarning("gtk_label_new() failed !\n");
		return -1;
	}
	gtk_widget_set_size_request(GTK_WIDGET(curr_page_info), 
								(int)(screen_width/10 * 1.5), 
								(int)(screen_height/10 * 0.5));	
	gtk_fixed_put(GTK_FIXED(media_fixed), curr_page_info, 
										(int)(screen_width/10 * 1), 
										(int)(screen_height/10 * 9.2));

	snprintf(img_path, sizeof(img_path)-1, "%s%s", IMAGE_FILE_PATH, IMG_MEDIA_BUTTON_NORMAL);
	/*------------------------------- Create button -------------------------------*/
	for(i=0; i<MAX_BUTTON_EVENTBOX; i++)
	{		
		/* Create eventbox */
		button_eventbox[i] = gtk_event_box_new();
		if(!button_eventbox[i])
		{
			showWarning("gtk_event_box_new() failed : %d !\n", i);
			return -1;
		}
		gtk_widget_set_can_focus(button_eventbox[i], TRUE);
		char widget_name[32];
		snprintf(widget_name, sizeof(widget_name)-1, "%s%d", "button_eventbox_", i);
		gtk_widget_set_name(button_eventbox[i], widget_name);
		
		/* Add label to button_eventbox[i] */
		GtkWidget *label_button = NULL;
		const char *button_name[10] = {"首页", "上页", "下页", "末页", "返回>"};
		label_button =  gtk_label_new(button_name[i]);
		if(!label_button)
		{
			showWarning("gtk_image_new_from_file() failed : %d !\n", i);
			return -1;
		}
		gtk_container_add(GTK_CONTAINER(button_eventbox[i]), label_button);
		
		gtk_widget_set_size_request(GTK_WIDGET(button_eventbox[i]), 
									(int)(screen_width/10 * 0.8), 
									(int)(screen_height/10 * 0.6));	
		
		if(i == 4)
		{
			gtk_fixed_put(GTK_FIXED(media_fixed), button_eventbox[i], 
												(int)(screen_width/10 * (4+i)), 
												(int)(screen_height/10 * 9.2));
		}
		else
		{
			gtk_fixed_put(GTK_FIXED(media_fixed), button_eventbox[i], 
												(int)(screen_width/10 * (3+i)), 
												(int)(screen_height/10 * 9.2));
		}
		set_background_pixmap(img_path, button_eventbox[i], (int)(screen_width/10 * 0.8), (int)(screen_height/10 * 0.6));
		
		/* Event */
		g_signal_connect(G_OBJECT(button_eventbox[i]), "enter-notify-event", G_CALLBACK(on_button_enter_notify_event), NULL);		
		g_signal_connect(G_OBJECT(button_eventbox[i]), "focus-in-event", G_CALLBACK(on_button_focus_in_event), NULL);
		g_signal_connect(G_OBJECT(button_eventbox[i]), "focus-out-event", G_CALLBACK(on_button_focus_out_event), NULL);
		g_signal_connect(G_OBJECT(button_eventbox[i]), "key-press-event", G_CALLBACK(on_button_key_press_event), NULL);
		g_signal_connect(G_OBJECT(button_eventbox[i]), "button-press-event", G_CALLBACK(on_button_click_event), NULL);		
		
		gdk_window_set_cursor(button_eventbox[i]->window, gdk_cursor_new(GDK_HAND2));
	}

	gtk_widget_show_all(media_window);

	return (TRUE);
}


/*******************************************************************************
*  ��������: �ı�ؼ��ı���ͼƬ
*  filename:ͼƬ�ļ���·��
*  widget:  Ҫ�ı䱳���Ŀؼ�
*  �ú������ܸı����пؼ��ı�����ֻ�ܶԲ��ֿؼ�������
********************************************************************************/
gboolean set_background_pixmap(const gchar *filename, GtkWidget *widget, int width, int height)
{
	GdkPixbuf *pbuf, *bg;
	GdkPixmap *pixmap;
	GdkBitmap *bitmap = NULL;
	gint img_width, img_height;

	if(GTK_WIDGET_NO_WINDOW(widget))
	{
		showWarning("the widget has not window !\n");   
		return FALSE; 
	}

	if(!GTK_WIDGET_REALIZED(widget))
	{
		gtk_widget_realize(widget);
	}

	if(!filename)
	{
		gdk_window_set_back_pixmap(widget->window, NULL, FALSE);
		showWarning("filename NULL ! \n");  
		return FALSE;
	}

	pbuf = gdk_pixbuf_new_from_file(filename,NULL);
	if(!pbuf)
	{
		showWarning("gdk_pixbuf_new_from_file failed ! \n");  
		return FALSE;
	}
	img_width = gdk_pixbuf_get_width(pbuf);
	img_height = gdk_pixbuf_get_height(pbuf);
	//showDebug("img_width : %d, ------- img_height : %d \n", img_width, img_height);
	
	gint drawable_width, drawable_height;
	if(width<=0 || height<=0)
	{
		gdk_drawable_get_size(widget->window, &drawable_width, &drawable_height);
		//showDebug("drawable_width : %d, ------- drawable_height : %d \n", drawable_width, drawable_height);	
	}
	else
	{
		drawable_width = width+2;
		drawable_height = height+2;
		//showDebug("width : %d, ------- height : %d \n", width, height);	
	}
	
	double scale_x, scale_y;
	if(img_width>0 && img_height>0)
	{
		scale_x = (double)drawable_width/img_width;
		scale_y = (double)drawable_height/img_height;
	}
	else
	{
		scale_x = 1.0;
		scale_y = 1.0;
	}	
	//showDebug("scale_x : %f, ------- scale_y : %f \n", scale_x, scale_y);	
	
	bg = gdk_pixbuf_new(GDK_COLORSPACE_RGB, 
						TRUE,
	       				gdk_pixbuf_get_bits_per_sample(pbuf), 
	       				drawable_width, 
	       				drawable_height);
	gdk_pixbuf_fill(bg, 0);
	gdk_pixbuf_composite(pbuf, bg, 0, 0, drawable_width, drawable_height, 0, 0, scale_x, scale_y, GDK_INTERP_BILINEAR, 0xFF);
	pixmap = gdk_pixmap_new(widget->window, drawable_width, drawable_height, -1);
	gdk_draw_pixbuf(pixmap, NULL, bg, 0, 0, 0, 0, -1, -1, GDK_RGB_DITHER_NORMAL, 1, 1);
	
	gdk_draw_drawable(widget->window, 
					  widget->style->fg_gc[GTK_WIDGET_STATE(widget)],
					  pixmap,
					  0, 0,
					  0, 0,
					  drawable_width, drawable_height);

	gtk_widget_set_app_paintable(widget, TRUE);
	gdk_pixbuf_render_pixmap_and_mask(bg, &pixmap, &bitmap, 128);
	gtk_widget_shape_combine_mask(widget, bitmap, 0, 0);
	gdk_window_set_back_pixmap(widget->window, pixmap, FALSE);
	gtk_widget_queue_draw(widget);

	gdk_pixbuf_unref(pbuf);
	gdk_pixbuf_unref(bg);
	gdk_pixmap_unref(pixmap);
	gdk_bitmap_unref(bitmap);
	
	gtk_widget_show(widget);
	
	return TRUE;
}




