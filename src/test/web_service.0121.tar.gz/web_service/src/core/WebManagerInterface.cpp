#include "WebManager.h"

/* ************************************************************************************************
				                           			       Inner Function
**************************************************************************************************/
WebManager::WebManager()
{
	init();
}

WebManager::~WebManager()
{
	uninit();
}

void WebManager::init()
{	
	gdk_screen = NULL;
}

void WebManager::uninit()
{	
	
}

WebManager* WebManager::instance = NULL;
WebManager* WebManager::get_instance()
{
	if(!instance)
		instance = new WebManager;
	
	return instance;
}

int WebManager::init_web_manager(GdkScreen *screen)
{	
	if(!screen)
		return -1;
	
	gdk_screen = screen;
	showInfo("------------------ Screen width: %d, Height: %d ------------------\n", gdk_screen_get_width(gdk_screen), 
			 							     										 gdk_screen_get_height(gdk_screen));
	return 0;
}
	
int WebManager::recurse_playlist(xmlNodePtr node, PlayNode *p)
{	
	#if 1
	xmlNodePtr child;
	PlayNode *p_child;
	PlayNode *p_tmp;
	xmlChar *name = NULL;
	xmlChar *image_normal = NULL;
	xmlChar *image_active = NULL;
	xmlChar *url = NULL;
	
	while(node)
	{	
		child = xml_read_child_node(node);
		if(child) /* List */
		{
			name = xml_read_attribute_value(node, BAD_CAST "name");
			image_normal = xml_read_attribute_value(node, BAD_CAST "image_normal");
			image_active = xml_read_attribute_value(node, BAD_CAST "image_active");
			//showInfo("----------------  Got Child --------------------\n");
			//Current Node
			p->child = new PlayNode;
			p->list_info = new ListInfo;
			memset(p->list_info, 0, sizeof(ListInfo));
			p->channel_info = NULL;
			p->type = LIST;
				
			if(name)
				strcpy(p->list_info->name, (char *)name);
			if(image_normal)
				strcpy(p->list_info->image_normal, (char *)image_normal);
			if(image_active)
				strcpy(p->list_info->image_active, (char *)image_active);
				
			//Child Node
			p_child = p->child;
			p_child->parent = p;
			p_child->pre = NULL;
			
			recurse_playlist(child, p_child);
		}		
		else /* Channel */ 
		{	
			//showInfo("---------------- No Child to Get --------------------\n");
			name = xml_read_attribute_value(node, BAD_CAST "name");
			image_normal = xml_read_attribute_value(node, BAD_CAST "image_normal");
			image_active = xml_read_attribute_value(node, BAD_CAST "image_active");
			url = xml_read_attribute_value(node, BAD_CAST "url");
			
			p->child = NULL;
			p->list_info = NULL;
			p->channel_info = new ChannelInfo;
			memset(p->channel_info, 0, sizeof(ChannelInfo));
			p->type = CHANNEL;
				
			if(name)
				strcpy(p->channel_info->name, (char *)name);
			if(image_normal)	
				strcpy(p->channel_info->image_normal, (char *)image_normal);
			if(image_active)	
				strcpy(p->channel_info->image_active, (char *)image_active);
			if(url)
				strcpy(p->channel_info->url, (char *)url);
		}
		
		node = xml_read_brother_node(node);
		if(node)
		{	
			p->next = new PlayNode;
			p_tmp = p;
			
			p = p->next;
			p->pre = p_tmp;
			p->parent = p_tmp->parent;
			recurse_playlist(node, p);
		}
	}	
	
	p->next = NULL;
	#endif
	
	return 0;
}

/* ************************************************************************************************
				                           			       API
**************************************************************************************************/
GtkWidget* WebManager::create_gtk_window(int width, int height)
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}	
	
	GtkWidget* window;
	
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(GTK_WIDGET(window), 
								width, 
								height);
	
	return window;
}
GtkWidget* WebManager::create_gtk_fixed(int width, int height)
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}
	
	GtkWidget* fixed;
	
	fixed = gtk_fixed_new();
	gtk_widget_set_size_request(GTK_WIDGET(fixed), 
								width, 
								height);

	return fixed;
}

GtkWidget* WebManager::create_gtk_image(char *img_path, int width, int height)
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}
	
	GtkWidget *image;
	GdkPixbuf *pixbuf;
	
	image =  gtk_image_new_from_file(img_path);
	pixbuf = gdk_pixbuf_scale_simple(gtk_image_get_pixbuf(GTK_IMAGE(image)),
									 width, 
									 height,
									 GDK_INTERP_NEAREST);
	gtk_widget_destroy(image);
	
	image = gtk_image_new_from_pixbuf(pixbuf);
	//gdk_widget_destroy(pixbuf);
	
	return image;
}	

int WebManager::get_screen_width()
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}

	return gdk_screen_get_width(gdk_screen);
}

int WebManager::get_screen_height()
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}

	return gdk_screen_get_height(gdk_screen);
}

int WebManager::get_widget_layout_info_by_name(LayoutInfo *layout_info, char *widget_name)
{	
	if(!layout_info)
		return -1;
	
	int i = 0;
	xmlNodePtr element = NULL;
	xmlNodePtr root_element = NULL;
	xmlChar *name = NULL;
	xmlChar *x_xmlchar = NULL;
	xmlChar *y_xmlchar = NULL;
	xmlChar *width_xmlchar = NULL;
	xmlChar *height_xmlchar = NULL;
	
	root_element = xml_read_root_node(TV_SCHEME_FILE_PATH);
	if(!root_element)
	{
		showWarning("%s: Read Root Element Fail\r\n", __FUNCTION__);
		goto ERR;
	}
	
	element = xml_read_child_node(root_element);
	if(!element)
	{	
		showWarning("%s: Read Element Fail\r\n", __FUNCTION__);
		goto ERR;
	}
	
	#if 1
    i = 0;
	while(element)
	{	
		name = xml_read_attribute_value(element, BAD_CAST "name");
		if(!name)
			goto ERR;
		
		if(0 == strcmp(widget_name, (char *)name))
		{	
			x_xmlchar = xml_read_attribute_value(element, BAD_CAST "x");
			y_xmlchar = xml_read_attribute_value(element, BAD_CAST "y");
			width_xmlchar = xml_read_attribute_value(element, BAD_CAST "width");
			height_xmlchar = xml_read_attribute_value(element, BAD_CAST "height");
			
			if(x_xmlchar)
				sscanf((const char *)x_xmlchar, "%d", &layout_info->x);
			if(y_xmlchar)
				sscanf((const char *)y_xmlchar, "%d", &layout_info->y);
			if(width_xmlchar)
				sscanf((const char *)width_xmlchar, "%d", &layout_info->width);
			if(height_xmlchar)
				sscanf((const char *)height_xmlchar, "%d", &layout_info->height);

			//showInfo("---- Widget: %s LayoutInfo x: %d, y: %d, width: %d, height: %d ----\n", name,
			//																				  layout_info->x,
			//																			      layout_info->y,
			//																			      layout_info->width,
	        //																			      layout_info->height);
			goto SUC;
		}
		
		element = xml_read_brother_node(element);
	}	
	#endif
	
ERR:	
	free_xml_parser();
	return -1;
	
SUC:
	free_xml_parser();
	return 0;
}

PlayNode *WebManager::get_playlist_root_node()
{
#if 1
		xmlNodePtr element = NULL;
		xmlNodePtr root_element = NULL;
		PlayNode *playnode;
		PlayNode *p;
		
		root_element = xml_read_root_node(TV_PLAYLIST_FILE_PATH);
		if(!root_element)
		{	
			showWarning("%s: Read Root Element Fail\r\n", __FUNCTION__);
			goto ERR;
		}		
			
		element = xml_read_child_node(root_element);
		if(!element)
		{			
			showWarning("%s: Read Element Fail\r\n", __FUNCTION__);
			goto ERR;
		}
		
		/* Init Root PlayNode */
		playnode = new PlayNode;
		playnode->parent = NULL;
		playnode->pre = NULL;
		p = playnode;
		
		/* Get All Element */
		recurse_playlist(root_element, p);
		
		SUC:
		free_xml_parser();
		return playnode;
		
		ERR:
		free_xml_parser();
		return NULL;
#endif
	
}


