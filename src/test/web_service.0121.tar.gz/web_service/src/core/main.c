#if 1
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h>

#include "WebManagerInterface.h"
#include "webskin.h"
#include "LogMsg.hpp"

GtkWidget* fixed;

GtkWidget *eventbox_browser;
GtkWidget *eventbox_email;

GtkWidget *image_browser;
GtkWidget *image_email;

//Layout
LayoutInfo layout_window;
LayoutInfo layout_eventbox;
LayoutInfo layout_image;

int destroy_widget(GtkWidget *widget, gpointer user_data)
{		
	showDebug("---------------- Get in %s, Widget: %s ------------------\n", 
			  __FUNCTION__, 
			  gtk_widget_get_name(widget));
		
	gtk_widget_destroy(widget);
}

void button_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{			
	if(0 == strcmp(user_data, "browser"))
	{	
		fill_browser();
	}
	else if(0 == strcmp(user_data, "email"))
		showInfo("Click %s\n", "video_phone");
	else
		showInfo("%s: Can not Disguish Button\n", __FUNCTION__);
}	

/* Cursor Hold/Leave */
void enter_notify_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
	showDebug("Get in %s \n", __FUNCTION__);
}

void leave_notify_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{
	showDebug("Get in %s \n", __FUNCTION__);
}

/* Focus In/Focus Out */
void focus_in_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{	
	#if 1
	char img_path[128];
	GtkWidget *image_tmp;
	
	if(0 == strcmp(user_data, "browser"))
	{		
		showInfo("Focus in %s\n", "browser");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WEB_SERVICE_BROWSER_BUTTON_ACTIVE);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_browser, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}	
	else if(0 == strcmp(user_data, "email"))		
	{	
		showInfo("Focus in %s\n", "email");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WEB_SERVICE_EMAIL_BUTTON_ACTIVE);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_email, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}
	else
	{	
		showInfo("%s: Can not Disguish User Data: %s\n", __FUNCTION__, user_data);
		return;
	}		
		
	gtk_widget_destroy(image_tmp);
	#endif
}	
	
void focus_out_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{	
	#if 1
	char img_path[128];
	GtkWidget *image_tmp;
	
	if(0 == strcmp(user_data, "browser"))
	{			
		showInfo("Focus out %s\n", "browser");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WEB_SERVICE_BROWSER_BUTTON_NORMAL);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_browser, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}
	else if(0 == strcmp(user_data, "email"))		
	{	
		showInfo("Focus out %s\n", "email");
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WEB_SERVICE_EMAIL_BUTTON_NORMAL);
		image_tmp = create_gtk_image(img_path, layout_image.width, layout_image.height);
		gtk_image_set_from_pixbuf((GtkImage*)image_email, gtk_image_get_pixbuf(GTK_IMAGE(image_tmp)));
	}	
	else
	{	
		showInfo("%s: Can not Disguish User Data: %s\n", __FUNCTION__, user_data);
		return;
	}	
	
	gtk_widget_destroy(image_tmp);
	#endif
}

int fill_main_menu()
{	
	char img_path[128];
	
	gtk_container_forall(GTK_CONTAINER(fixed), destroy_widget, NULL);
		
	/* ------------------------------- Create EvenBox --------------------------------*/
	int increment_x_eventbox = layout_eventbox.x * 4;
	int increment_y_eventbox = layout_eventbox.y;
	showInfo("------- increment_x_eventbox: %d, increment_y_eventbox: %d\n", increment_x_eventbox,
																			 increment_y_eventbox);
	//Media Service
	eventbox_browser = gtk_event_box_new();
	gtk_widget_set_can_focus(eventbox_browser, TRUE);
	gtk_container_add(GTK_CONTAINER(fixed), eventbox_browser);
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_browser, layout_eventbox.x, layout_eventbox.y);
	gtk_widget_show (eventbox_browser);	
	
	//Video Phone
	eventbox_email = gtk_event_box_new();
	gtk_widget_set_can_focus(eventbox_email, TRUE);
	gtk_container_add(GTK_CONTAINER(fixed), eventbox_email);
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_email, layout_eventbox.x, layout_eventbox.y + increment_y_eventbox);
	gtk_widget_show (eventbox_email);
	
	/* ----------------------------------- Create Image ----------------------------------------*/
	//Web
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WEB_SERVICE_BROWSER_BUTTON_NORMAL);
	image_browser = create_gtk_image(img_path, layout_image.width, layout_image.height);
	gtk_container_add(GTK_CONTAINER(eventbox_browser), image_browser);
	gtk_widget_show (image_browser);
	
	//Email
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WEB_SERVICE_EMAIL_BUTTON_NORMAL);
	image_email =  create_gtk_image(img_path, layout_image.width, layout_image.height);
	gtk_container_add(GTK_CONTAINER(eventbox_email), image_email);
	gtk_widget_show (image_email);
	
#if 1/*-------------------------------	Event --------------------------------*/
	//Borwser
	g_signal_connect(G_OBJECT(eventbox_browser), "button_press_event",
					 G_CALLBACK(button_press_event), "browser");
	g_signal_connect(G_OBJECT(eventbox_browser), "enter_notify_event",
					 G_CALLBACK(focus_in_event), "browser");
	g_signal_connect(G_OBJECT(eventbox_browser), "leave_notify_event",
					 G_CALLBACK(focus_out_event), "browser");
	g_signal_connect(G_OBJECT(eventbox_browser), "focus_in_event",
					 G_CALLBACK(focus_in_event), "browser");
	g_signal_connect(G_OBJECT(eventbox_browser), "focus_out_event",
					 G_CALLBACK(focus_out_event), "browser");
	
	//Email
	g_signal_connect(G_OBJECT(eventbox_email), "button_press_event",
					 G_CALLBACK(button_press_event), "email");
	g_signal_connect(G_OBJECT(eventbox_email), "enter_notify_event",
					 G_CALLBACK(focus_in_event), "email");
	g_signal_connect(G_OBJECT(eventbox_email), "leave_notify_event",
					 G_CALLBACK(focus_out_event), "email");
	g_signal_connect(G_OBJECT(eventbox_email), "focus_in_event",
					 G_CALLBACK(focus_in_event), "email");
	g_signal_connect(G_OBJECT(eventbox_email), "focus_out_event",
					 G_CALLBACK(focus_out_event), "email");
#endif
	
	//Set Cursor Style
	if(eventbox_browser->window)
		gdk_window_set_cursor (eventbox_browser->window, gdk_cursor_new (GDK_HAND1));
	if(eventbox_email->window)
		gdk_window_set_cursor (eventbox_email->window, gdk_cursor_new (GDK_HAND1));
}
	
int fill_browser()
{				
	gtk_container_forall(GTK_CONTAINER(fixed), destroy_widget, NULL);
		
	GtkWidget *browser_vbox = show_browser(layout_window.width * 6 / 7, layout_window.height * 6 / 7);
	gtk_container_add(GTK_CONTAINER(fixed), browser_vbox);
	gtk_fixed_move(fixed, browser_vbox, layout_window.width / 10, layout_window.height / 10);
}		
	
int show_main_window()
{		
	GtkWidget* window;
	GdkPixbuf *pixbuf;
	GdkPixmap *pixmap;
	GdkBitmap *bitmap;
	GtkWidget *bg_image;
	char img_path[128];
	
	/* ---------------------------------- Create Main Window ------------------------------------*/
	window	= create_gtk_window(layout_window.width, layout_window.height);
	if(!window)
	{							
		showError("window is NULL\n");
		return -1;
	}					
	gtk_window_move(GTK_WINDOW(window), layout_window.x, layout_window.y);
	gtk_window_set_decorated(GTK_WINDOW(window), FALSE);
	gtk_widget_set_app_paintable(window, TRUE);
	
	//Create Main Window Back Groud Image
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WEB_SERVICE_MAIN_BG);
	bg_image = create_gtk_image(img_path, layout_window.width, layout_window.height);
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(bg_image)), &pixmap, &bitmap, 128);
	gtk_widget_shape_combine_mask(window, bitmap, 0, 0);
		
	/* ------------------------------- Create Fixed ----------------------------------*/
	fixed = create_gtk_fixed(layout_window.width, layout_window.height);
	gtk_container_add(GTK_CONTAINER(window), fixed);
	gtk_widget_show(fixed);
	
	fill_main_menu();
		
	/* ---------------- Realize and Set Cursor ----------------*/
	gtk_widget_realize (eventbox_browser);
	gtk_widget_realize (eventbox_email);
	gdk_window_set_cursor (eventbox_browser->window, gdk_cursor_new (GDK_HAND1));
	gdk_window_set_cursor (eventbox_email->window, gdk_cursor_new (GDK_HAND1));
		
	/*------------------ Set Irregular Window --------------------*/
	gdk_window_set_back_pixmap(window->window, pixmap, FALSE);
			
	gtk_widget_show(window);
	
	return 0;
}
	
int set_layout_info()
{
	/*--------------------------------- Set Layout Info ---------------------------------*/
	//Window
	memset(&layout_window, 0 , sizeof(LayoutInfo));
	layout_window.x = get_screen_width() / 10;
	layout_window.y = get_screen_height() / 10;
	layout_window.width = get_screen_width() * 8 / 10;
	layout_window.height = get_screen_height() * 8 / 10;
	
	showInfo("---- Window LayoutInfo x: %d, y: %d, width: %d, height: %d ----\n", layout_window.x,
																			      layout_window.y,
																			      layout_window.width,
																			      layout_window.height);
																					
	//EventBox
	memset(&layout_eventbox, 0 ,sizeof(LayoutInfo));
	layout_eventbox.x = get_screen_width() / 4;
	layout_eventbox.y = get_screen_height() / 7;
	
	showInfo("---- EventBox LayoutInfo x: %d, y: %d, width: %d, height: %d ----\n", layout_eventbox.x,
																			        layout_eventbox.y,
																			        layout_eventbox.width,
																			        layout_eventbox.height);
	//Image
	memset(&layout_image, 0 ,sizeof(LayoutInfo));	
	layout_image.width = get_screen_width() / 3;
	layout_image.height = get_screen_height() / 9;
	showInfo("---- Image LayoutInfo x: %d, y: %d, width: %d, height: %d ----\n", layout_image.x,
																		         layout_image.y,
																		         layout_image.width,
																		         layout_image.height);
}
	
gint main(int argc, char *argv[])
{
	gtk_init(&argc,&argv);
#if 1 //My Prj
	/*--------------------------------- Get X Screen ----------------------------------*/
	GdkDisplay *gdk_display = gdk_display_get_default();
	GdkScreen *gdk_screen = gdk_display_get_default_screen(gdk_display);
	
	init_web_manager(gdk_screen);
	set_layout_info();
	
	if(show_main_window())
		showError("------------------ Create Main Window Fail --------------------\n");
#endif		
	gtk_main();

	return 0;
}	
#endif
	
