#if 1
#include <gtk/gtk.h>
#include <X11/keysym.h>
#include <webkit/webkit.h> 
#include <gdk/gdkkeysyms.h>
//#include <gdk/gdkx.h>

#include "LogMsg.hpp"

GtkWidget* scrolled_window;
GtkWidget* toolbar;

static GtkWidget* main_window;
static GtkWidget* uri_entry;
static GtkStatusbar* main_statusbar;
static WebKitWebView* web_view;
static gchar* main_title;
static gint load_progress;
static guint status_context_id; 
static GtkWidget* videoDraw;

static WebKitWebBackForwardList* bf_list_main;
GtkToolItem* button_back;
GtkToolItem* button_forward;
GtkToolItem* button_stop;
GtkToolItem* button_refresh;
GtkToolItem* button_quit;
		
//extern int destroy_widget(GtkWidget *widget, gpointer user_data);
extern GtkWidget* fixed;
extern fill_widget();

		
static gboolean
show_web_view_cb (WebKitWebView* web_view_1)
{		
    GtkWidget* window = gtk_widget_get_toplevel(GTK_WIDGET(web_view));
	
    showInfo("on [%s] new web_view_cb[%s]\r\n", __FUNCTION__, webkit_web_view_get_uri(web_view));
    gtk_widget_show(window);
    return TRUE;
}
	
static WebKitWebView*
create_web_view_cb (WebKitWebView* web_view, WebKitWebFrame* web_frame)
{
	showInfo("on [%s] \r\n", __FUNCTION__);
	const gchar* uri = webkit_web_frame_get_uri(web_frame);
		
	showInfo("uri : [webview:%s] [webframe:%s]\r\n", webkit_web_view_get_uri(web_view), uri);
	return WEBKIT_WEB_VIEW(web_view);
}

static void
activate_uri_entry_cb (GtkWidget* entry, gpointer data)
{
	showInfo("on [%s] \r\n", __FUNCTION__);
    const gchar* uri = gtk_entry_get_text (GTK_ENTRY (entry));
    g_assert (uri);
    webkit_web_view_open (web_view, uri);
} 

#if 1
static void
update_title (GtkWindow* window)
{
    GString* string = g_string_new (main_title);
    g_string_append (string, " - WebKit Launcher");
		
    if (load_progress < 100)
        g_string_append_printf (string, " (%d%%)", load_progress);
    gchar* title = g_string_free (string, FALSE);
    gtk_window_set_title (window, title);
    gtk_widget_set_name (main_window, "fnBrowser");
    g_free (title);
}
#endif

static void
link_hover_cb (WebKitWebView* page, const gchar* title, const gchar* link, gpointer data)
{
		showInfo("on [%s] \r\n", __FUNCTION__);
    /* underflow is allowed */
    gtk_statusbar_pop (main_statusbar, status_context_id);
    if (link)
        gtk_statusbar_push (main_statusbar, status_context_id, link);
} 

static void
title_change_cb (WebKitWebView* web_view, WebKitWebFrame* web_frame, const gchar* title, gpointer data)
{
		showInfo("on [%s] \r\n", __FUNCTION__);
    if (main_title)
        g_free (main_title);
    main_title = g_strdup (title);
    update_title (GTK_WINDOW (main_window));
    gtk_widget_set_name (main_window, "fnBrowser");
} 

static void
progress_change_cb (WebKitWebView* page, gint progress, gpointer data)
{		
	showInfo("on [%s] \r\n", __FUNCTION__);
    load_progress = progress;
    update_title (GTK_WINDOW (main_window));
    gtk_widget_set_name (main_window, "fnBrowser");
}

static void
load_commit_cb (WebKitWebView* page, WebKitWebFrame* frame, gpointer data)
{	
    const gchar* uri = webkit_web_frame_get_uri(frame);
	
    /* Disable Or Enable Back/Forward Button*/
    WebKitWebHistoryItem* history_item_back = webkit_web_back_forward_list_get_back_item(bf_list_main);
    WebKitWebHistoryItem* history_item_forward = webkit_web_back_forward_list_get_forward_item(bf_list_main); 
    if(!history_item_back)
    {	
        showInfo("[%s] back item is NULL\n", __FUNCTION__);
		if(gtk_widget_is_sensitive(GTK_WIDGET(button_back)))
        	gtk_widget_set_sensitive (GTK_WIDGET(button_back), false);
    }	
    else
    {	
        showInfo("[%s] back item is not NULL\n", __FUNCTION__);
		if(!gtk_widget_is_sensitive(GTK_WIDGET(button_back)))
        	gtk_widget_set_sensitive (GTK_WIDGET(button_back), true);
    }	
   	
    if(!history_item_forward)
    {	
        showInfo("[%s] forward item is NULL\n", __FUNCTION__);
		if(gtk_widget_is_sensitive(GTK_WIDGET(button_forward)))
        	gtk_widget_set_sensitive (GTK_WIDGET(button_forward), false);
    }	
    else
    {	
        showInfo("[%s] forward item is not NULL\n", __FUNCTION__);
		if(!gtk_widget_is_sensitive(GTK_WIDGET(button_forward)))
        	gtk_widget_set_sensitive (GTK_WIDGET(button_forward), true);
    }	
		
	/* Enable Stop Button*/
    if(!gtk_widget_is_sensitive(GTK_WIDGET(button_stop)))
		gtk_widget_set_sensitive (GTK_WIDGET(button_stop), true);
	
    /* Disable Refresh Button*/
	if(gtk_widget_is_sensitive(GTK_WIDGET(button_refresh)))
		gtk_widget_set_sensitive (GTK_WIDGET(button_refresh), false);
			 	
	showInfo("on [%s] uri : [%s] -> [%s]\r\n", __FUNCTION__, 
			 webkit_web_view_get_uri(web_view), uri);
}
	
static void load_finished_cb(WebKitWebView* web_view)
{
    showInfo("on [%s]\n", __FUNCTION__);

	/*Disable Enable Stop Button*/
    if(gtk_widget_is_sensitive(GTK_WIDGET(button_stop)))
		gtk_widget_set_sensitive (GTK_WIDGET(button_stop), false);

	/* Enable Refresh Button*/
	if(!gtk_widget_is_sensitive(GTK_WIDGET(button_refresh)))
		gtk_widget_set_sensitive (GTK_WIDGET(button_refresh), true);
}

static void
destroy_cb (GtkWidget* widget, gpointer data)
{		
    gtk_main_quit ();
}	 	


static void
go_back_cb (GtkWidget* widget, gpointer data)
{
    showInfo("on [%s] \r\n", __FUNCTION__);
	WebKitWebHistoryItem* history_item = webkit_web_back_forward_list_get_back_item(bf_list_main);
    if(!history_item)    
    {
        showInfo("[%s] back item is NULL\n", __FUNCTION__);
        return;
    }
    else
        showInfo("[%s] back item not NULL\n", __FUNCTION__);        

    if(!webkit_web_view_can_go_back(web_view))
    {
        showInfo("[%s] can not go back\n", __FUNCTION__);
        return;
    }
	
    webkit_web_view_go_back (web_view);
} 

static void
go_forward_cb (GtkWidget* widget, gpointer data)
{
	showInfo("on [%s] \r\n", __FUNCTION__);

	WebKitWebHistoryItem* history_item = webkit_web_back_forward_list_get_forward_item(bf_list_main);
	if(!history_item)
    {
        showInfo("[%s] forward item is NULL\n", __FUNCTION__);
        return;
    }
    else
        showInfo("[%s] forward item not NULL\n", __FUNCTION__);

	if(!webkit_web_view_can_go_forward(web_view))    
    {
        showInfo("[%s] can not go forward\n", __FUNCTION__);
        return;
    }
	
    webkit_web_view_go_forward (web_view);
}

static void
go_stop_cb (GtkWidget* widget, gpointer data)
{
		showInfo("on [%s] \r\n", __FUNCTION__);
    webkit_web_view_stop_loading(web_view);
}

static void
go_reflash_cb (GtkWidget* widget, gpointer data)
{
		showInfo("on [%s] \r\n", __FUNCTION__);
    webkit_web_view_reload(web_view);
} 

static void
go_quit_cb (GtkWidget* widget, gpointer data)
{
	showInfo("on [%s] \r\n", __FUNCTION__);
	//gtk_container_forall(GTK_CONTAINER(fixed), destroy_widget, NULL);
  	fill_main_menu();
}

static GtkWidget* create_browser ()
{	
    //GtkWidget* scrolled_window = gtk_scrolled_window_new (NULL, NULL);
    //gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC); 
	
    web_view = WEBKIT_WEB_VIEW (webkit_web_view_new ());
    //gtk_container_add (GTK_CONTAINER (scrolled_window), GTK_WIDGET (web_view)); 
	
    g_signal_connect (G_OBJECT (web_view), "create-web-view", G_CALLBACK (create_web_view_cb), NULL);
    //g_signal_connect (G_OBJECT (web_view), "title-changed", G_CALLBACK (title_change_cb), web_view);
    //g_signal_connect (G_OBJECT (web_view), "load-progress-changed", G_CALLBACK (progress_change_cb), web_view);
    g_signal_connect (G_OBJECT (web_view), "load-committed", G_CALLBACK (load_commit_cb), web_view);
	g_signal_connect (G_OBJECT (web_view), "load-finished", G_CALLBACK (load_finished_cb), NULL);
    g_signal_connect (G_OBJECT (web_view), "hovering-over-link", G_CALLBACK (link_hover_cb), web_view); 
    g_signal_connect (G_OBJECT (web_view), "web-view-ready", G_CALLBACK (show_web_view_cb), web_view);
	
    // return scrolled_window;
   	return web_view;
}

static void
go_home_cb (GtkWidget* widget, gpointer data)
{	
    showInfo("on [%s] \r\n", __FUNCTION__);
	//WebKitWebFrame *frame = webkit_web_view_get_focused_frame(web_view);
	//showInfo("------------------- webkit_web_frame_get_uri: %s ---------------------\n", webkit_web_frame_get_uri(frame));
	//webkit_web_view_move_cursor(web_view, GTK_MOVEMENT_WORDS, 1);
	//webkit_web_view_select_all(web_view);
    //const char home_uri[] = "http://www.phonmedia.com/phonmedia";
    // webkit_web_view_open (web_view, home_uri);
   // GdkEvent *event = gdk_event_new(GDK_KEY_PRESS);
	//GdkEventKey *event_key = (GdkEventKey *)event;
	//int x;
	//event->type = GDK_KEY_PRESS;
	//event_key ->keyval = GDK_Up;

	//GdkDisplay *gdk_display = gdk_display_get_default();
	//GdkScreen *gdk_screen = gdk_display_get_default_screen(gdk_display);
	//gdk_display_put_event(gdk_display, event_key);

	//gdk_event_put(event_key);
	//gdk_event_send_client_message(event);
	//x = ((GdkEventButton*)event)->x;
	//showInfo("X: %d\n", x);
	
	guint keyval = GDK_Up;
	
   GdkKeymapKey* keys;
   gint n_keys;
   //gdk_keymap_get_entries_for_keyval(gdk_keymap_get_default(),
	//								 keyval,
	//								 &keys,
	//								 &n_keys);
// Note: GdkEvent is an union
   GdkEvent* event = gdk_event_new(GDK_KEY_PRESS);
   ((GdkEventKey*)event)->window = fixed->window;
   ((GdkEventKey*)event)->send_event = TRUE;
   ((GdkEventKey*)event)->time = GDK_CURRENT_TIME;
   ((GdkEventKey*)event)->state = GDK_KEY_PRESS_MASK;
   ((GdkEventKey*)event)->keyval = keyval;
	
    gdk_event_put(event);
} 


static GtkWidget*
create_statusbar ()
{	
    main_statusbar = GTK_STATUSBAR (gtk_statusbar_new ());
    status_context_id = gtk_statusbar_get_context_id (main_statusbar, "Link Hover"); 
	
    return (GtkWidget*)main_statusbar;
}	
	
static GtkWidget* create_toolbar ()
{
    GtkWidget* toolbar = gtk_toolbar_new (); 
	
   // gtk_toolbar_set_orientation (GTK_TOOLBAR (toolbar), GTK_ORIENTATION_HORIZONTAL);
   // gtk_toolbar_set_style (GTK_TOOLBAR (toolbar), GTK_TOOLBAR_BOTH_HORIZ); 

    GtkToolItem* item;
	
    //GTK_STOCK_HOME 
    item = gtk_tool_button_new_from_stock (GTK_STOCK_HOME);
    g_signal_connect (G_OBJECT (item), "clicked", G_CALLBACK (go_home_cb), NULL);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), item, -1); 

    /* the back button */
    button_back = gtk_tool_button_new_from_stock (GTK_STOCK_GO_BACK);
    g_signal_connect (G_OBJECT (button_back), "clicked", G_CALLBACK (go_back_cb), NULL);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), button_back, -1); 

    /* The forward button */
    button_forward = gtk_tool_button_new_from_stock (GTK_STOCK_GO_FORWARD);
    g_signal_connect (G_OBJECT (button_forward), "clicked", G_CALLBACK (go_forward_cb), NULL);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), button_forward, -1);

    /* The stop button */
    button_stop = gtk_tool_button_new_from_stock (GTK_STOCK_STOP);
    g_signal_connect (G_OBJECT (button_stop), "clicked", G_CALLBACK (go_stop_cb), NULL);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), button_stop, -1);
	
    /* The redo button */
    button_refresh = gtk_tool_button_new_from_stock (GTK_STOCK_REFRESH);
    g_signal_connect (G_OBJECT (button_refresh), "clicked", G_CALLBACK (go_reflash_cb), NULL);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), button_refresh, -1); 

	/* The Quit button */
    button_quit = gtk_tool_button_new_from_stock (GTK_STOCK_QUIT);
    g_signal_connect (G_OBJECT (button_quit), "clicked", G_CALLBACK (go_quit_cb), NULL);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), button_quit, -1); 
	
	//GTK_STOCK_QUIT
    /*item = gtk_tool_item_new ();
    	gtk_tool_item_set_expand (item, TRUE);
    	gtk_container_add (GTK_CONTAINER (item), create_statusbar());
    	gtk_toolbar_insert (GTK_TOOLBAR (toolbar), item, -1);
	*/
	
    return toolbar;
} 
	
static GtkWidget*
create_window ()
{
    GtkWidget* window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	
    gtk_window_set_default_size (GTK_WINDOW (window), 600, 450);
    gtk_window_move( GTK_WINDOW(window), 200, 0);
	
    gtk_widget_set_name (window, "fnBrowser");
    g_signal_connect (G_OBJECT (window), "destroy", G_CALLBACK (destroy_cb), NULL); 

    return window;
} 

static gboolean  keystroke_cb (GtkWidget* widget, GdkEventKey* event, gpointer user_data)
{
	showInfo("on key : %d\r\n", event->keyval);
	
	if(event->keyval == XK_Tab)
	{
	   showInfo("on tab key\r\n");
	   
	   GtkWidget *widget = gtk_window_get_focus(GTK_WINDOW(main_window));
	   showInfo("on focus widget : %s, %08X\r\n", gtk_widget_get_name(widget), widget);
           if(widget != NULL)
           {
		widget = gtk_container_get_focus_child(GTK_CONTAINER(widget));
		if(widget)
		 showInfo("on focus : %s\r\n", gtk_widget_get_name(widget));
           	
	   }
	   else
             showInfo("on focus null\r\n");
	}

        if(event->keyval == XK_Escape)
        {
        	return TRUE;
        }	
        showInfo("on key : %d\r\n", event->keyval);
        return FALSE;
}		

static gboolean button_release_event_handle(GtkWidget *widget, GdkEventButton *event, gpointer data)
{	
	showInfo("Get in %s\r\n", __FUNCTION__);
 	return FALSE;
}




void key_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{	
	#if 1
	guint keyval = GDK_Tab;
	GdkKeymapKey* keys;
		    gint n_keys;

	GdkEvent* gdk_event = gdk_event_new(GDK_KEY_PRESS);
	
	
	switch(event->keyval) 
	{	
	    case GDK_Up:		
			g_print("Up\n");
			((GdkEventKey*)gdk_event)->window = fixed->window;
		    ((GdkEventKey*)gdk_event)->send_event = TRUE;
		    ((GdkEventKey*)gdk_event)->time = GDK_CURRENT_TIME;
		    ((GdkEventKey*)gdk_event)->state = GDK_KEY_PRESS_MASK;
		    ((GdkEventKey*)gdk_event)->keyval = GDK_3270_BackTab;
			gdk_event_put(gdk_event);
			//GDK_KP_Tab
			break;
			
	    case GDK_Left:
	        g_print("Left\n");
			((GdkEventKey*)gdk_event)->window = fixed->window;
		    ((GdkEventKey*)gdk_event)->send_event = TRUE;
		    ((GdkEventKey*)gdk_event)->time = GDK_CURRENT_TIME;
		    ((GdkEventKey*)gdk_event)->state = GDK_KEY_PRESS_MASK;
		    ((GdkEventKey*)gdk_event)->keyval = GDK_3270_BackTab;
			gdk_event_put(gdk_event);
			break;
			
	    case GDK_Right:
	        g_print("Right\n");
			((GdkEventKey*)gdk_event)->window = fixed->window;
		    ((GdkEventKey*)gdk_event)->send_event = TRUE;
		    ((GdkEventKey*)gdk_event)->time = GDK_CURRENT_TIME;
		    ((GdkEventKey*)gdk_event)->state = GDK_KEY_PRESS_MASK;
		    ((GdkEventKey*)gdk_event)->keyval = keyval;
			gdk_event_put(gdk_event);
	        break;
			
	    case GDK_Down:
			g_print("Down\n");
			((GdkEventKey*)gdk_event)->window = fixed->window;
		    ((GdkEventKey*)gdk_event)->send_event = TRUE;
		    ((GdkEventKey*)gdk_event)->time = GDK_CURRENT_TIME;
		    ((GdkEventKey*)gdk_event)->state = GDK_KEY_PRESS_MASK;
		    ((GdkEventKey*)gdk_event)->keyval = keyval;
			gdk_event_put(gdk_event);
			break;
			
		case GDK_Tab:
			g_print("Tab\n");
			break;
			
		case GDK_KP_Enter:
			g_print("Enter\n");
			break;

		case GDK_Return:
			g_print("Return\n");
			break;
			
		case GDK_Escape:
			g_print("GDK_Escape\n");
			break;
			
		default:		
			printf("default\n");
			break;
		}
	#endif
}

GtkWidget* show_browser (int width, int height)
{ 
	#if 1
	GtkWidget *vbox = gtk_vbox_new (FALSE, 0);
	gtk_widget_set_size_request(vbox, width, height);
	
	scrolled_window = create_browser();
	/*gtk_container_add(GTK_CONTAINER(fixed), scrolled_window);
	gtk_widget_set_size_request(scrolled_window, width, height * 5 / 6);
	gtk_fixed_move(fixed, scrolled_window, 0, 0);*/
	gtk_widget_set_size_request(scrolled_window, width, height * 5 / 6);
	gtk_box_pack_start (GTK_BOX (vbox), create_browser(), TRUE, TRUE, 0);
	
	toolbar = create_toolbar();
	/*gtk_container_add(GTK_CONTAINER(fixed), toolbar);
	gtk_widget_set_size_request(toolbar, width, height / 6);
	gtk_fixed_move(fixed, toolbar, 0, height * 5 / 6);
	*/
	gtk_widget_set_size_request(toolbar, width, height / 6);
    gtk_box_pack_start (GTK_BOX (vbox), create_toolbar (), FALSE, FALSE, 0);
    //gtk_container_add (GTK_CONTAINER (main_window), fixed); 
	gtk_widget_show_all(vbox);
	
    gchar* uri = (gchar*)"http://www.baidu.com";
    webkit_web_view_open (web_view, uri);
	
	g_signal_connect(G_OBJECT(web_view), "key_release_event",
					 G_CALLBACK(key_press_event), NULL);
	//g_signal_connect(G_OBJECT(web_view), "key_press_event",
	//				 G_CALLBACK(key_press_event), NULL);
		
	/* History List*/
    //bf_list_main = webkit_web_back_forward_list_new_with_web_view(web_view);
    //gtk_widget_grab_focus (GTK_WIDGET (web_view));
    //gtk_widget_show_all (main_window);
	
    //gtk_widget_add_events(main_window, GDK_KEY_RELEASE_MASK);
    
    //g_signal_connect (G_OBJECT (main_window), "key_release_event", G_CALLBACK (keystroke_cb), NULL); 
	
    return vbox;
	#endif
}
#endif




