#include <string.h>
#include <stdio.h>

#include "WebManager.h"

#ifdef __cplusplus
extern "C" 
{
#endif

/**************************************************************************************************/
/**************************************** GtkManager ***************************************************/
/**************************************************************************************************/
int init_web_manager(GdkScreen *screen)
{
	WebManager *manager = WebManager::get_instance();
  	return manager->init_web_manager(screen);
}

GtkWidget* create_gtk_window(int width, int height)
{	
	WebManager *manager = WebManager::get_instance();
  	return manager->create_gtk_window(width, height);
}	
	
GtkWidget* create_gtk_fixed(int width, int height)
{	
	WebManager *manager = WebManager::get_instance();
  	return manager->create_gtk_fixed(width, height);
}

GtkWidget* create_gtk_image(char *img_path, int width, int height)
{
	WebManager *manager = WebManager::get_instance();
  	return manager->create_gtk_image(img_path, width, height);
}

int get_screen_width()
{
	WebManager *manager = WebManager::get_instance();
  	return manager->get_screen_width();
}

int get_screen_height()
{
	WebManager *manager = WebManager::get_instance();
  	return manager->get_screen_height();
}

/* Layout */
int get_widget_layout_info_by_name(LayoutInfo *layout_info, char *widget_name)
{
	WebManager *manager = WebManager::get_instance();
	return manager->get_widget_layout_info_by_name(layout_info, widget_name);
}

/* Play List */
PlayNode *get_playlist_root_node()
{
	WebManager *manager = WebManager::get_instance();
	return manager->get_playlist_root_node();
}

	
#ifdef __cplusplus
}
#endif

