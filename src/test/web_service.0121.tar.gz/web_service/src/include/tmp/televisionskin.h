#ifndef PHONEBOOKSKIN_DEF
#define PHONEBOOKSKIN_DEF

#define BASE_SCREEN_WIDTH 			     1280
#define BASE_SCREEN_HEIGHT 			     738

#define IMAGE_FILE_PATH             "../share/data/appfile/television/image/"
	
//Image										
#define IMG_MAIN_WINDOW_BG								 	"pb_main_window_bg.png"

#define IMG_MAIN_WINDOW_BUTTON_MEDIA_SERVICE             	"media_service.png"
#define IMG_MAIN_WINDOW_BUTTON_VIDEO_PHONE    				"video_phone.png"
#define IMG_MAIN_WINDOW_BUTTON_PHONEBOOK   					"addressbook.png"
#define IMG_MAIN_WINDOW_BUTTON_WEB	    					"web.png"
#define IMG_MAIN_WINDOW_BUTTON_SETTING    					"setting.png"
	
#define IMG_MAIN_WINDOW_BUTTON_MEDIA_SERVICE_FOCUSED        "media_service_focused.png"
#define IMG_MAIN_WINDOW_BUTTON_VIDEO_PHONE_FOCUSED    		"video_phone_focused.png"
#define IMG_MAIN_WINDOW_BUTTON_PHONEBOOK_FOCUSED   			"addressbook_focused.png"
#define IMG_MAIN_WINDOW_BUTTON_WEB_FOCUSED	    			"web_focused.png"
#define IMG_MAIN_WINDOW_BUTTON_SETTING_FOCUSED    			"setting_focused.png"

//button color
#define MAIN_WINDOW_TITLE                 "window_main"

#define DIALOG_SIZE_WIDTH                 280
#define DIALOG_SIZE_HEIGHT                120	
#define DIALOG_POS_X                      350
#define DIALOG_POS_Y                      200
	
#define PROGRESS_BAR_SIZE_WIDTH                 150
#define PROGRESS_BAR_SIZE_HEIGHT                25
#define PROGRESS_BAR_POS_X                      350
#define PROGRESS_BAR_POS_Y                      230

#define DISPLAY_ADD_NEW_ITEM      "添加新项"

enum
{
    CONTACT_BUF,
    CALLLOG_BUF,
    BLACKLIST_BUF,
    QUICKDIAL_BUF,
    COMMONPHONE_BUF
};

#endif
