#ifndef WEBSKIN_DEF
#define WEBSKIN_DEF

#define IMAGE_FILE_PATH             "../share/data/appfile/television/image/"

#define BASE_SCREEN_WIDTH 			     1280
#define BASE_SCREEN_HEIGHT 			     738
	
	
//Image										
#define IMG_WEB_SERVICE_MAIN_BG			"web_service_main_bg.png"
	
#define IMG_WEB_SERVICE_BROWSER_BUTTON_NORMAL	"web_service_browser_button_normal.png"
#define IMG_WEB_SERVICE_BROWSER_BUTTON_ACTIVE	"web_service_browser_button_active.png"

#define IMG_WEB_SERVICE_EMAIL_BUTTON_NORMAL		"web_service_email_button_normal.png"
#define IMG_WEB_SERVICE_EMAIL_BUTTON_ACTIVE		"web_service_email_button_active.png"

enum
{	
	MEDIA_SERVICE=0,
	VIDEO_PHONE,
	ADDRESS_BOOK,
	WEB,
	SETTING
};	

#endif
