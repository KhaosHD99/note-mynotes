#ifndef GTK_MANAGER_DEF
#define GTK_MANAGER_DEF

#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>

#include "LogMsg.hpp"
#include "XMLInterface.h"
#include "WebManagerInfo.h"

#define TV_SCHEME_FILE_PATH             "../share/data/appfile/television/tv-layout.xml"
#define TV_PLAYLIST_FILE_PATH             "../share/data/appfile/television/tv-play.xml"

class WebManager
{
	public:	
    	static WebManager *instance;
		GdkScreen *gdk_screen; 
	
	private:
		WebManager();
		~WebManager();
		void init();	
		void uninit();
		int recurse_playlist(xmlNodePtr node, PlayNode *p);
		
	public:
		static WebManager *get_instance();
		
		int init_web_manager(GdkScreen *screen);
		GtkWidget* create_gtk_window(int width, int height);
		GtkWidget* create_gtk_fixed(int width, int height);
		GtkWidget* create_gtk_image(char *img_path, int width, int height);

		/* X Screen */
		int get_screen_width();
		int get_screen_height();

		/* Layout */
		int get_widget_layout_info_by_name(LayoutInfo *layout_info, char *widget_name); 
		
		/* Play List */	
		PlayNode *get_playlist_root_node();
};

#endif

