#ifndef XML_PARSER_DEF
#define XML_PARSER_DEF

#include <libxml/parser.h>
#include "LogMsg.hpp"

class CXMLParser  
{
	private:
		xmlDocPtr doc;	
		xmlNodePtr root_node;
		static CXMLParser *instance;
		CXMLParser();
		
	public:
		~CXMLParser();
		static CXMLParser *get_instance();
		int load_file(char *szFileName);
		xmlNodePtr read_root_node(char *szFileName);
		xmlNodePtr read_child_node(xmlNodePtr pNode);
		xmlNodePtr read_brother_node(xmlNodePtr pNode);
		xmlChar *read_attribute_value(xmlNodePtr pNode, xmlChar *cAttrName);
};
#endif

