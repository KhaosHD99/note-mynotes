#ifndef GTK_MANAGER_INFO_DEF
#define GTK_MANAGER_INFO_DEF
	
#define MAX_PLAYLIST_COUNT     10
#define MAX_CHANNEL_COUNT      100
	
enum
{
	LIST,
	CHANNEL
};
	
typedef struct _LayoutInfo
{	
	int x;
	int y;
	int width;
	int height;
}LayoutInfo;

#if 1
typedef struct _ChannelInfo
{
	int id;
	char name[256];
	char url[256];
	char image_normal[256];
	char image_active[256];
}ChannelInfo;

typedef struct _ListInfo
{	
	int id;
	char name[256];
	char image_normal[256];
	char image_active[256];
}ListInfo;

typedef struct _PlayNode
{		
	struct _PlayNode *pre;
	struct _PlayNode *next;
	struct _PlayNode *parent;
	struct _PlayNode *child;
		
	int type;
	ListInfo *list_info;
	ChannelInfo *channel_info;
}PlayNode;
#endif

#endif

