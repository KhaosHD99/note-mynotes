export PRX="$HOME/opt/x86-usr"

export PKG_CONFIG_PATH=$PKG_CONFIG_PATH:$PRX/lib/pkgconfig



./configure \
	--prefix=$PRX

