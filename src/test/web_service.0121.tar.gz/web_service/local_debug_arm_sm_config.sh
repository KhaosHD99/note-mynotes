export PRX="/usr/Fn/debug/xuzhenjie"
export PKG_CONFIG_PATH=/usr/Fn/debug/lib/pkgconfig:$PRX/lib/pkgconfig

./configure \
	--prefix=$PRX

