#include <stdlib.h> 
#include <stdio.h>
#include <gtk/gtk.h>
#include <string.h>
#include <gconf/gconf-client.h>
#include<glib.h>

#define SET_KEY "/test_apps/test"
	
GMainLoop *loop;
	
#if 1
static void
callback_func(GConfEngine* gConfClient, guint cnxn_id,
                GConfEntry* entry, gpointer user_data) 
{	
	printf("-------------------- Get in %s --------------------\n", __FUNCTION__);
	#if 0
    gchar* strvalue = NULL; 
			
    if(0 == strcmp(entry->key, SET_KEY) ) 
    {			
        strvalue = strdup(gconf_value_get_string(entry->value)); 
        printf("the gconf changed: %s\n", strvalue);                        //��ӡ�����º��value.
    }			 
    else 
    {	
        printf("the gconf don't changed.\n"); 
    }		 
    g_main_loop_quit(loop); 
	#endif				
	
    return; 
}	

static void
callback_func_client(GConfClient* gConfClient, guint cnxn_id,
                GConfEntry* entry, gpointer user_data) 
{	
	printf("-------------------- Get in %s --------------------\n", __FUNCTION__);
	#if 0
    gchar* strvalue = NULL; 
			
    if(0 == strcmp(entry->key, SET_KEY) ) 
    {			
        strvalue = strdup(gconf_value_get_string(entry->value)); 
        printf("the gconf changed: %s\n", strvalue);                        //��ӡ�����º��value.
    }			 
    else 
    {	
        printf("the gconf don't changed.\n"); 
    }		 
    g_main_loop_quit(loop); 
	#endif				
	
    return; 
}	

		
static gboolean
time_callback_func(gpointer arg) 
{
	printf("Get in %s\n", __FUNCTION__);
    g_main_loop_quit(loop); 
	
	return true;
}
#endif

GConfEngine* engine;
GConfClient* client;

#if 1
static void
entry_activated_callback()
{	
  printf("Get in %s\n", __FUNCTION__);
  //GConfClient* client;
  //gchar* str;
  
  //client = GCONF_CLIENT(user_data);
  
  //str = gtk_editable_get_chars(GTK_EDITABLE(entry), 0, -1);

  static int flag = 0;

  if(flag % 2)
  	 gconf_client_set_string(client, "/test_apps",
                          "test", NULL);
  else
   	 gconf_client_set_string(client, "/test_apps",
                          "test2", NULL);

  flag++;
	
  // printf("String: %s\n", 
   //		   gconf_client_get_string (client, "/test_apps/test",
  //                 NULL));
  
  //g_free(str);
}
#endif

int main (int argc, char* argv[])
{
	#if 1
	GtkWidget* window;
	GtkWidget* entry;
	char address[260] = {0};
	GError* error = NULL; 
	
	gtk_init(&argc, &argv);
	gconf_init(argc, argv, NULL);
	
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	entry = gtk_entry_new();
	
	gtk_container_add(GTK_CONTAINER(window), entry);  
	
	//client = gconf_client_get_default();

	sprintf(address, "xml:readwrite:%s", "/home/elon/tmp/.gconf"); 
	printf("Address: %s\n", address);

	engine = gconf_engine_get_for_address (address, &error);          
    if(!engine) 
    {		
    	g_error("%s\n", error->message); 
    }		
	else
	{							
		printf("Create Engine Suc\n");
	}	
		
    client = gconf_client_get_for_engine (engine);
	if(!client) 
	{			
		printf("Create GConfClient Fail\n");
	}	
	else
	{
		printf("Create GConfClient Suc\n");
	}	
	
	/*
	gboolean ret = gconf_client_set_string(client,  
                                           SET_KEY,
                                           "broncho", 
                                           NULL);                  //����key������ֵ
    
    if(ret) 
    {	
    	//Get Key Value
        char* str = gconf_client_get_string(client,  
                                            SET_KEY, 
                                            NULL);
        if(str != NULL) 
        {				 
            printf("the str = %s \n",str); 
        }	
    }	
	else
	{	
		printf("gconf_client_set_string Return Fail\n");
	}	*/
	
	//gconf_client_add_dir(client,
	//	                 "/extra/test/directory",
	//	                 GCONF_CLIENT_PRELOAD_NONE,
	//	                 NULL);

	
	//gconf_engine_notify_add (engine, "/test_apps/test",
	//						 callback_func, NULL, NULL);
	gconf_client_add_dir(client, 
    					 "/test_apps",  
                         GCONF_CLIENT_PRELOAD_NONE, 
                         NULL);
	
	gconf_client_notify_add(client, "/test_apps",
                           callback_func_client, NULL, NULL, NULL);
		
	g_signal_connect (G_OBJECT (entry), "activate",
			          entry_activated_callback,
			          client);
		
	/* If key isn't writable, then set insensitive */
	gtk_widget_set_sensitive (entry,
			                  gconf_client_key_is_writable (client,"/extra/test/directory/key", NULL));
	gtk_widget_show_all(window);
	
	gtk_main();
	#endif
	
	#if 0
	char address[260] = {0};
    GError* error = NULL; 
    g_type_init(); 
	
    if(g_thread_supported() == 0) 
    { 
        g_thread_init(NULL); 
    } 
				
    loop = g_main_loop_new(NULL, FALSE); 
    if(loop == NULL) 
    {			
        g_error("Faile to create mainloop.\n"); 
    }	
	
	//snprintf(address, 
	//	     sizeof(address),   
    //         "%.gconf", 
    //         g_get_home_dir());
	
	sprintf(address, "xml:readwrite:%s", "/home/elon/tmp/.gconf"); 
	printf("Address: %s\n", address);
	
	//Init the Engine
    GConfEngine* engine = gconf_engine_get_for_address (address, &error);          
    if(!engine) 
    {		
    	g_error("%s\n", error->message); 
    }		
	else
	{							
		printf("Create Engine Suc\n");
	}	
		
    GConfClient*  gConfClient = gconf_client_get_for_engine (engine);
	if(!gConfClient) 
	{			
		printf("Create GConfClient Fail\n");
	}	
	else
	{
		printf("Create GConfClient Suc\n");
	}	
	
	gboolean ret = gconf_client_set_string(gConfClient,  
                                           SET_KEY,
                                           "broncho", 
                                           NULL);                  //����key������ֵ
    
    if(ret) 
    {	
    	//Get Key Value
        char* str = gconf_client_get_string(gConfClient,  
                                            SET_KEY, 
                                            NULL);
        if(str != NULL) 
        {				 
            printf("the str = %s \n",str); 
        }	
    }	
	else
	{	
		printf("gconf_client_set_string Return Fail\n");
	}	

	gconf_client_notify_add(gConfClient, SET_KEY ,  
                            callback_func, NULL, NULL,
                            NULL);  
	#if 0
    gchar* dir = strdup(SET_KEY); 
    gchar* p = strrchr(dir, '/'); 
    if(p != NULL)
		*p = '\0'; 
	
	//Set Monitor Path
    gconf_client_add_dir(gConfClient, 
    					 dir,  
                         GCONF_CLIENT_PRELOAD_NONE, 
                         NULL);
    g_free(dir);
	
	//Register Key Notify
    gconf_client_notify_add(gConfClient, SET_KEY ,  
                            callback_func, NULL, NULL,
                            NULL);                                               
                             
	//Set Time
    g_timeout_add(1000, 
    			  time_callback_func, 
    			  NULL);
	
    g_main_loop_run(loop);
	
	//Clean
    g_main_loop_unref(loop); 
    g_object_unref(gConfClient); 
	#endif
	#endif
	
    return 0;
}

