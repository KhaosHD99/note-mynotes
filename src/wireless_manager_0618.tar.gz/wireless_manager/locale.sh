xgettext -k_ -o locale.po src/core/*.c src/core/*.cpp

#msgfmt -o locale.mo locale.po
