#ifndef GTK_MANAGER_DEF
#define GTK_MANAGER_DEF
				
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <assert.h>
	
#include "LogMsg.hpp"
#include "XMLInterface.h"
#include "WirelessManagerInfo.h"
#include "skin.h"

#define LOCALIZATION_SCHEME_FILE 	"/usr/Fn/release/share/data/appfile/wireless_manager/localization.xml"

const char LANGUAGE_INFO[2][128] = 			
{	
	"cn",
	"en"
};	

typedef struct _StackNode
{					
	int data;
	struct _StackNode *next;        
}StackNode;
	
typedef struct _LinkStack
{			
	StackNode *top;
}LinkStack;

class WirelessManager
{	
	public:
    	static WirelessManager *instance;
		GdkScreen *gdk_screen; 
		char *locale;
		LinkStack *page_stack;
		
	private:
		WirelessManager();
		~WirelessManager();
		void init();	
		void uninit();
		
	public:
		static WirelessManager *get_instance();
		int init_wireless_manager(GdkScreen *screen);	
		GtkWidget* create_gtk_window(int width, int height);			
		GtkWidget* create_gtk_fixed(int width, int height);			
		GdkPixbuf* create_gtk_pixbuf(char *img_path, int width, int height, char *markup, int size);
		
		/* X Screen */
		int get_screen_width();
		int get_screen_height();
		
		/* Page Stack */
		int push_window(int window);			
		int pop_window();
		int peek_window();
		void show_stack();
		
		const char *window_page_enum_to_str(int enum_val);
};

#endif

