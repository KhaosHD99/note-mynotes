#ifndef GTK_MANAGER_INFO_DEF
#define GTK_MANAGER_INFO_DEF

#define MAX_PLAYLIST_COUNT     10
#define MAX_CHANNEL_COUNT      100

enum
{			
	cn,
	en,
};

typedef struct _LayoutInfo
{	
	int x;
	int y;
	int width;
	int height;
}LayoutInfo;

#endif

