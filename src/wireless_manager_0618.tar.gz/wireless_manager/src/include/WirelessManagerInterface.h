#ifndef GTK_MANAGER_INTERFACE_DEF
#define GTK_MANAGER_INTERFACE_DEF
	
#include "WirelessManagerInfo.h"
	
#ifdef __cplusplus
extern"C"
{	
#endif
	int init_wireless_manager(GdkScreen *screen);
	/* Return NULL if Create Fail */
	GtkWidget* create_gtk_window(int width, int height);
	
	/* Return NULL if Create Fail */
	GtkWidget* create_gtk_fixed(int width, int height);
	
	/* Return NULL if Create Fail */
	GdkPixbuf* create_gtk_pixbuf(char *img_path, int width, int height, char *markup, int size);
		
	/* X Screen */
	int get_screen_width();
	int get_screen_height();
	
	/* Page Stack */	
	int push_window(int window);		
	int pop_window();
	int peek_window();
	void show_stack();						
												
#ifdef __cplusplus
}	
#endif
	
#endif
