#ifndef PHONEBOOKSKIN_DEF
#define PHONEBOOKSKIN_DEF
		
#define MAX_PHONE_COUNT			10
#define MAX_DEV_NAME_LEN		32
#define DISPLAY_ADD_NEW_ITEM      	"添加新项"
										
#define RESOURCE_FILE_BASE_PATH         "/usr/Fn/release/share/data/appfile/wireless_manager/"
#define SET_NETWORK_FILE           		"set_network.sh"
#define SET_AUTH_FILE           		"set_network.sh"	

#define LOCALE_PACKAGE 				"locale"
#define LOCALEDIR 					"/usr/Fn/release/share/data/appfile/wireless_manager/locale"
									
#define IMAGE_FILE_PATH             "/usr/Fn/release/share/data/appfile/wireless_manager/image/"

#define BASE_SCREEN_WIDTH 			     1280
#define BASE_SCREEN_HEIGHT 			     738
	
#define DIALOG_SIZE_WIDTH                 280
#define DIALOG_SIZE_HEIGHT                120
		
#define PROGRESS_BAR_SIZE_WIDTH                 150
#define PROGRESS_BAR_SIZE_HEIGHT                25
		
//Image
#define IMG_WIRELESS_MANAGER_MAIN_BG				"wireless_manager_main_bg.png"
#define IMG_WIRELESS_MANAGER_MAIN_BG2				"wireless_manager_main_bg2.png"
										
#define IMG_WIRELESS_MANAGER_BUTTON_NORMAL	    	"wireless_manager_button_normal.png"
#define IMG_WIRELESS_MANAGER_BUTTON_ACTIVE	    	"wireless_manager_button_active.png"
				
//UI Text
#define TEXT_CONTACT					"TEXT_CONTACT"
#define TEXT_CALLLOG					"TEXT_CALLLOG"
#define TEXT_CANCEL						"TEXT_CANCEL"
#define TEXT_DIAL						"TEXT_DIAL"
#define TEXT_EDIT						"TEXT_EDIT"
#define TEXT_ADD						"TEXT_ADD"
#define TEXT_ADDTO_CONTACT				"TEXT_ADDTO_CONTACT"
#define TEXT_DELETE						"TEXT_DELETE"
#define TEXT_CONFIRM					"TEXT_CONFIRM"
#define TEXT_SAVE						"TEXT_SAVE"

#define TEXT_FAMILY_NAME				"TEXT_FAMILY_NAME"
#define TEXT_GIVEN_NAME					"TEXT_GIVEN_NAME"
#define TEXT_NAME						"TEXT_NAME"
#define TEXT_PHONENUM					"TEXT_PHONENUM"
#define TEXT_EMAIL						"TEXT_EMAIL"
#define TEXT_REMOTE						"TEXT_REMOTE"
#define TEXT_DATETIME					"TEXT_DATETIME"
#define	TEXT_DURATION					"TEXT_DURATION"
#define	TEXT_CALLLOG_TYPE				"TEXT_CALLLOG_TYPE"

#define	TEXT_REFRESH					"TEXT_REFRESH"
#define	TEXT_REFRESH_SCAN					"TEXT_REFRESH_SCAN"
#define	TEXT_DEVICE						"TEXT_DEVICE"	
#define	TEXT_CONNECT					"TEXT_CONNECT"	
#define	TEXT_DISCONNECT					"TEXT_DISCONNECT"		
#define	TEXT_SETTING					"TEXT_SETTING"
#define	TEXT_SCAN						"TEXT_SCAN"
#define	TEXT_QUIT						"TEXT_QUIT"				
#define	TEXT_STATUS						"TEXT_STATUS"

#define	TEXT_ESSID						"TEXT_ESSID"
#define	TEXT_AUTH_MODE					"TEXT_AUTH_MODE"
#define	TEXT_ENCRYPTION_TYPE			"TEXT_ENCRYPTION_TYPE"
#define	TEXT_KEY						"TEXT_KEY"
#define	TEXT_KEY_INDEX					"TEXT_KEY_INDEX"				

#define	TEXT_IP_ADDRESS					"TEXT_IP_ADDRESS"
#define	TEXT_SUBNET_MASK				"TEXT_SUBNET_MASK"
#define	TEXT_DEFAULT_GATEWAY			"TEXT_DEFAULT_GATEWAY"
#define	TEXT_PRIMARY_DNS				"TEXT_PRIMARY_DNS"
#define	TEXT_SLAVE_DNS					"TEXT_SLAVE_DNS"
#define	TEXT_AUTO_GET_IP				"TEXT_AUTO_GET_IP"
#define	TEXT_USE_SPEC_IP				"TEXT_USE_SPEC_IP"
#define	TEXT_AUTO_GET_DNS				"TEXT_AUTO_GET_DNS"
#define	TEXT_USE_SPEC_DNS				"TEXT_USE_SPEC_DNS"

//Prompt Msg
#define MSG_DELETE_CONTACT_CONFIRM				"MSG_DELETE_CONTACT_CONFIRM"
#define MSG_DELETE_PHONENUM_CONFIRM				"MSG_DELETE_PHONENUM_CONFIRM"
#define MSG_DELETE_CALLLOG_CONFIRM				"MSG_DELETE_CALLLOG_CONFIRM"
#define MSG_NO_SELECTION						"MSG_NO_SELECTION"
#define MSG_DIAL_FAIL							"MSG_DIAL_FAIL"
#define MSG_INVALID_NUMBER						"MSG_INVALID_NUMBER"
#define MSG_CANNOT_EMPTY						"MSG_CANNOT_EMPTY"

#define MSG_SAVE_SUC							"MSG_SAVE_SUC"
#define MSG_SAVE_FAILED							"MSG_SAVE_FAILED"
#define MSG_UPDATE_SUC							"MSG_UPDATE_SUC"
#define MSG_UPDATE_FAILED						"MSG_UPDATE_FAILED"
#define MSG_DELETE_SUC							"MSG_DELETE_SUC"
#define MSG_DELETE_FAILED						"MSG_DELETE_FAILED"
	
#define SCAN_INTERVAL							10000
	
enum
{				
	MEDIA_SERVICE=0,
	VIDEO_PHONE,
	ADDRESS_BOOK,
	WEB,
	SETTING
};			
		
enum
{		
	NOTE_BOOK_PAGE_SCAN = 0,	
	NOTE_BOOK_PAGE_DEVICE,		
};	
	
enum AUTH_MODE 
{
	AUTH_MODE_OPEN = 0,	
	AUTH_MODE_SHARE,
	AUTH_MODE_WPA_PSK,
	AUTH_MODE_WPA2_PSK
};

enum ENCRYPTION_TYPE
{		
	ENCRYPTION_TYPE_NOT_USE = 0,
	ENCRYPTION_TYPE_WEP,
	ENCRYPTION_TYPE_TKIP,
	ENCRYPTION_TYPE_AES_CCMP
};	

enum
{	
	WINDOW_PAGE_MAIN = 0,
	WINDOW_PAGE_AP,
	WINDOW_PAGE_CONFIG
	
};	

enum			
{	
	PROMPT_TYPE_NONE,
	PROMPT_TYPE_CONNECT
};

enum			
{	
	SCAN_STORE_COLUMN_INDEX = 0,
	SCAN_STORE_COLUMN_ESSID,
	SCAN_STORE_COLUMN_STATUS_ICON,
	SCAN_STORE_COLUMN_ENCRY,
	SCAN_STORE_COLUMN_ADDRESS
};

enum			
{	
	DEVICE_STORE_COLUMN_INDEX = 0,
	DEVICE_STORE_COLUMN_INTERFACE
};

int single_instance_check(const char *filename);

void show_message_window(char *msg);
int show_confirm_window(char *msg);

const char* auth_mode_enum_to_str(int enum_val);
const char* encryption_type_enum_to_str(int enum_val);

#endif
