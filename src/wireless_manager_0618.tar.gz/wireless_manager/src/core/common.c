#include <gtk/gtk.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <ifaddrs.h>			
#include <netinet/in.h>
#include "skin.h"					
#include "LogMsg.hpp"				
#include "WirelessManagerInterface.h"

#define LOCKMODE (S_IRUSR | S_IWUSR | S_IRGRP | S_IROTH)

static GtkWidget *prompt_bar;
static int timer;

int get_iface_address(char *iface, char *addr_str, int len)
{			
	if(len < INET6_ADDRSTRLEN 
	   || NULL == iface 
	   || 0 == strcmp(iface, "") 
	   || NULL == addr_str)
	{	
		showInfo("*** Arg Invalid");
		return -1;
	}	
	struct ifaddrs *iflist, *ifaddr;
	
	if (getifaddrs(&iflist) < 0) 
	{		
		perror("********** getifaddrs");
		return 1;
	}	
	
	for (ifaddr = iflist; ifaddr; ifaddr = ifaddr->ifa_next)
	{	
		int af = ifaddr->ifa_addr->sa_family;
		const void *addr;
		
		switch (af) 
		{
			case AF_INET:
				addr = &((struct sockaddr_in *)ifaddr->ifa_addr)->sin_addr;
				break;
				
			case AF_INET6:
				printf("--------- AF_INET6 --------\n");
				addr = &((struct sockaddr_in6 *)ifaddr->ifa_addr)->sin6_addr;
				break;
				
			default:
				addr = NULL;
		}
		
		if (addr) 
		{	
			if(0 == strcmp(ifaddr->ifa_name, iface))
			{		
				if (inet_ntop(af, addr, addr_str, len) == NULL) 
				{	
					perror("inet_ntop");
					continue;
				}	
				showInfo("Get interface %s address %s\n", ifaddr->ifa_name, addr_str);
				goto SUC;
			}
		}
	}

SUC:
	freeifaddrs(iflist);
	return 0;
}

int get_iface_netmask(char *iface, char *netmask_str, int len)
{		
	if(len < INET6_ADDRSTRLEN 
	   || NULL == iface 
	   || 0 == strcmp(iface, "") 
	   || NULL == netmask_str)
	{		
		showInfo("*** netmask_str lengtn is too short");
		return -1;
	}	
    struct ifaddrs *iflist, *ifaddr;
	 
	if (getifaddrs(&iflist) < 0) 
	{				
		showWarning("********** getifaddrs Err");
		return -1;
	}
	
	for (ifaddr = iflist; ifaddr; ifaddr = ifaddr->ifa_next)
	{	
		int af = ifaddr->ifa_addr->sa_family;
		const void *netmask;
		
		switch (af) 
		{
			case AF_INET:
				netmask = &((struct sockaddr_in *)ifaddr->ifa_netmask)->sin_addr;
				break;
				
			case AF_INET6:
				printf("--------- AF_INET6 --------\n");
				netmask = &((struct sockaddr_in6 *)ifaddr->ifa_netmask)->sin6_addr;
				break;
				
			default:
				netmask = NULL;
		}
		
		if (netmask) 
		{	
			if(0 == strcmp(ifaddr->ifa_name, iface))
			{		
				if (inet_ntop(af, netmask, netmask_str, len) == NULL) 
				{	
					perror("inet_ntop");
					continue;
				}
				showInfo("Get interface %s netmask %s\n", ifaddr->ifa_name, netmask_str);
				goto SUC;
			}
		}
	}
	
SUC:
	freeifaddrs(iflist);
	return 0;
}

int lockfile(int fd)
{	
    struct flock fl;
	
    fl.l_type = F_WRLCK;
    fl.l_start = 0;
    fl.l_whence = SEEK_SET;
    fl.l_len = 0;
	
    return(fcntl(fd, F_SETLK, &fl));
}

int single_instance_check(const char *filename)
{	
	int fd;
	char buf[16];
	
	fd = open(filename, O_RDWR | O_CREAT, LOCKMODE);
	if (fd < 0)
	{	
		printf("can't open %s\n", filename);
		return -1;
	}
	if (lockfile(fd) == -1) 
	{	
        if (errno == EACCES || errno == EAGAIN) 
		{		
            printf("file: %s already locked\n", filename);
            close(fd);
            return -1;
        }
	}
	
	ftruncate(fd, 0);
	sprintf(buf, "%ld", (long)getpid());
	write(fd, buf, strlen(buf) + 1);
	
	return 0;
}	

static void destroy_widget(GtkWidget *widget, gpointer user_data)
{		
	if(GTK_IS_WIDGET(widget))
	{		
		showInfo("Get in %s, Destroy Widget: %s\n", 
			 	  __FUNCTION__, 
			  	  gtk_widget_get_name(widget));
		
		gtk_widget_destroy(widget);
	}			
}	

gboolean prompt_bar_timer(gpointer data)
{		
	showInfo("on %s\n", __FUNCTION__);
	gtk_widget_hide(prompt_bar);
	
	return FALSE;
}		

int show_prompt_bar(gdouble val, char *msg, int type)
{	
	//showInfo("Get in %s, val: %f\n", __FUNCTION__, val);
	if(type == PROMPT_TYPE_NONE)
		return -1;
	
	if(type != PROMPT_TYPE_CONNECT)
	{	
		showWarning("**** Unknow Prompt Type\n");
		return -1;
	}
	
	char msg_info[128] = {0};
	
	if(GTK_IS_WIDGET(prompt_bar))
	{	
		if(msg)
		{	
			gtk_progress_bar_set_text (GTK_PROGRESS_BAR (prompt_bar), msg);
		}	
		else
		{	
			if(PROMPT_TYPE_CONNECT== type)
				snprintf(msg_info, sizeof(msg_info), "%s%d", "Connecting: ", (int)(val * 100));
			else
				snprintf(msg_info, sizeof(msg_info), "%d", (int)(val * 100));
			
			gtk_progress_bar_set_text (GTK_PROGRESS_BAR (prompt_bar), msg_info);
		}
		if(0 <= val)
			gtk_progress_bar_set_fraction (GTK_PROGRESS_BAR (prompt_bar), val);
		
		//Timer
		if(-1 != timer)
			gtk_timeout_remove(timer);
		
		timer = gtk_timeout_add (2000, prompt_bar_timer, NULL);
		gtk_widget_show(prompt_bar);
	}
	
	return 0;
}

//dialog
void show_message_window(char *msg)
{	
	if(NULL == msg)
	{	
		showWarning("*** Invalid Arg");
		return;
	}	
	GtkWidget *dialog;
	GtkWidget *label;
	
	dialog = gtk_dialog_new();			
	gtk_window_set_decorated(GTK_WINDOW(dialog), FALSE);
	gtk_window_set_title(GTK_WINDOW(dialog), "dialog_message");
	gtk_widget_set_size_request(dialog, DIALOG_SIZE_WIDTH, DIALOG_SIZE_HEIGHT);
	gtk_window_move(GTK_WINDOW(dialog), get_screen_width() / 2 - DIALOG_SIZE_WIDTH / 2,
										get_screen_height() / 2 - DIALOG_SIZE_HEIGHT / 2);
	g_signal_connect(G_OBJECT(dialog), "focus-out-event",	
					 G_CALLBACK(gtk_widget_destroy), NULL);
	//Button								
	gtk_dialog_add_button(GTK_DIALOG(dialog),
						  GTK_STOCK_OK,
						  GTK_RESPONSE_OK);

	//Label
	GtkWidget *box = ((GtkBin *)dialog)->child;
		
	label = gtk_label_new(msg);
	gtk_container_add(GTK_CONTAINER(box), label);
	gtk_widget_show(label);
	
	//Show
	gtk_dialog_run (GTK_DIALOG (dialog));
	
	//Destroy
	destroy_widget(dialog, NULL);
}
	
int show_confirm_window(char *msg)
{	
	if(NULL == msg)
	{
		showWarning("*** Invalid Arg");
		return -1;
	}
	GtkWidget *dialog;
	GtkWidget *label;
	int rtn;
			
	dialog = gtk_dialog_new();								
	gtk_window_set_decorated(GTK_WINDOW(dialog), FALSE);			
	gtk_window_set_title(GTK_WINDOW(dialog), "dialog_confirm");
	gtk_widget_set_size_request(dialog, DIALOG_SIZE_WIDTH, DIALOG_SIZE_HEIGHT);
	gtk_window_move(GTK_WINDOW(dialog), get_screen_width() / 2 - DIALOG_SIZE_WIDTH / 2,
										get_screen_height() / 2 - DIALOG_SIZE_HEIGHT / 2);
	g_signal_connect(G_OBJECT(dialog), "focus-out-event",			
					 G_CALLBACK(gtk_widget_destroy), NULL);				
	//Button													
	gtk_dialog_add_button(GTK_DIALOG(dialog),				
						  GTK_STOCK_OK,			
						  GTK_RESPONSE_OK);			
											
	gtk_dialog_add_button(GTK_DIALOG(dialog),
						  GTK_STOCK_CANCEL,
						  GTK_RESPONSE_CANCEL);
	
	//Label
	GtkWidget *box = ((GtkBin *)dialog)->child;
		
	label = gtk_label_new(msg);
	gtk_container_add(GTK_CONTAINER(box), label);
	gtk_widget_show(label);
	
	//Show
	rtn = gtk_dialog_run (GTK_DIALOG (dialog));
	
	//Destroy
	destroy_widget(dialog, NULL);
	return rtn;
}

const char* auth_mode_enum_to_str(int enum_val)
{				
	switch(enum_val)
	{		
	    case AUTH_MODE_OPEN:
			return "Open";
		
		case AUTH_MODE_SHARE:
			return "Share";
		
		case AUTH_MODE_WPA_PSK:
			return "WPA-PSK";
			
		case AUTH_MODE_WPA2_PSK:
			return "WPA2-PSK";
		
		default:
			showWarning("******* %s: Invalid enum value ***********\n", __FUNCTION__);		
	}	
		
	return NULL;
}

const char* encryption_type_enum_to_str(int enum_val)
{		
	switch(enum_val)
	{		
		case ENCRYPTION_TYPE_NOT_USE:
			return "Not Use";
			
	    case ENCRYPTION_TYPE_WEP:
			return "WEP";
			
		case ENCRYPTION_TYPE_TKIP:
			return "TKIP";
			
		case ENCRYPTION_TYPE_AES_CCMP:
			return "AES-CCMP";
		
		default:
			showWarning("******* %s: Invalid enum value ***********\n", __FUNCTION__);		
	}		
	
	return NULL;
}

