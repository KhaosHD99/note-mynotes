#include "WirelessManager.h"

/* ************************************************************************************************
				                           			       Inner Function
**************************************************************************************************/
WirelessManager::WirelessManager()
{
	init();
}
	
WirelessManager::~WirelessManager()
{
	uninit();
}

void WirelessManager::init()
{		
	gdk_screen = NULL;
	page_stack = new LinkStack;
	page_stack->top = NULL;
}

void WirelessManager::uninit()
{	
	
}

WirelessManager* WirelessManager::instance = NULL;
WirelessManager* WirelessManager::get_instance()
{
	if(!instance)
		instance = new WirelessManager;
	
	return instance;
}
	
int WirelessManager::init_wireless_manager(GdkScreen *screen)
{		
	if(!screen)
		return -1;
	
	gdk_screen = screen;
	showInfo("------------------ Screen width: %d, Height: %d ------------------\n", gdk_screen_get_width(gdk_screen), 
			 							     										 gdk_screen_get_height(gdk_screen));
	return 0;
}

/* ************************************************************************************************
				                           			       API
**************************************************************************************************/
GtkWidget* WirelessManager::create_gtk_window(int width, int height)
{		
	if(!gdk_screen)
	{			
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}	
			
	GtkWidget* window;
	
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_size_request(GTK_WIDGET(window), 
								width,
								height);
		
	return window;
}	
GtkWidget* WirelessManager::create_gtk_fixed(int width, int height)
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}
	
	GtkWidget* fixed;
	
	fixed = gtk_fixed_new();
	gtk_widget_set_size_request(GTK_WIDGET(fixed), 
								width, 
								height);

	return fixed;
}	
	
GdkPixbuf* WirelessManager::create_gtk_pixbuf(char *img_path, int width, int height, char *markup, int size)
{	
	if(width < 0 || height < 0 || size < 0)
		return NULL;
	
	cairo_surface_t *surface; 
	cairo_t 		*cr;
	GdkPixbuf		*pixbuf;
	GdkPixbuf		*scaled_pixbuf;
	PangoLayout 	*layout;
	gint			 i_width,
					 i_height,
					 l_width, 
					 l_height, 
					 dx,
					 dy, 
					 s_stride, 
					 p_stride, 
					 i, 
					 j; 
	guchar			*s_data, 
					*p_data;
	PangoFontDescription *desc;
	char desc_str[64] = {0};
	
	surface = cairo_image_surface_create_from_png(img_path);
	i_width  = cairo_image_surface_get_width(surface); 
	i_height = cairo_image_surface_get_height(surface); 
	cr = cairo_create(surface); 
	
	layout = pango_cairo_create_layout(cr);
	if(markup)
		pango_layout_set_markup(layout, markup, strlen(markup));
	else
		pango_layout_set_markup(layout, "", 0); 
	
	snprintf(desc_str, sizeof(desc_str), "%s%d", "Sans ", size);
	desc = pango_font_description_from_string(desc_str);
	pango_layout_set_font_description(layout, desc); 
	pango_font_description_free(desc); 

	
	/* Center text */ 
	pango_layout_get_size(layout, &l_width, &l_height); 
	l_width  /= PANGO_SCALE; 
	l_height /= PANGO_SCALE; 

	dx = (i_width - l_width) * .5;
	dy = (i_height - l_height) * .5;
	
	cairo_move_to(cr, dx, dy); 
	pango_cairo_show_layout(cr, layout); 
	cairo_fill(cr);

	if(G_IS_OBJECT(layout))
		g_object_unref(layout);
	cairo_destroy(cr);
	
	/* Convert cairo surface to pixbuf */	
	pixbuf = gdk_pixbuf_new(GDK_COLORSPACE_RGB, TRUE, 8, i_width, i_height);
	s_stride = cairo_image_surface_get_stride(surface);
	p_stride = gdk_pixbuf_get_rowstride(pixbuf);			
	showInfo("gdk_pixbuf_get_rowstride: %d\n", p_stride);	
	s_data = cairo_image_surface_get_data(surface);
	p_data = gdk_pixbuf_get_pixels(pixbuf);
		
	for( i = 0; i < i_height; i++ )
	{		
		for( j = 0; j < i_width; j++ ) 
		{
			gint	s_index = i * s_stride + j * 4, 
					p_index = i * p_stride + j * 4;
			gdouble alpha;
			
			alpha = s_data[s_index + 3] ? 
					(gdouble)s_data[s_index + 3] / 0xff : 1.0; 
					
			p_data[p_index	  ] = s_data[s_index + 2] / alpha; 
			p_data[p_index + 1] = s_data[s_index + 1] / alpha; 
			p_data[p_index + 2] = s_data[s_index	] / alpha; 
			p_data[p_index + 3] = s_data[s_index + 3]; 
		}		
	}	
	cairo_surface_destroy(surface);
	
	scaled_pixbuf = gdk_pixbuf_scale_simple(pixbuf,
											 width,
											 height,
											 GDK_INTERP_NEAREST);
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	return scaled_pixbuf;
}
	
int WirelessManager::get_screen_width()
{	
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}

	return gdk_screen_get_width(gdk_screen);
}

int WirelessManager::get_screen_height()
{
	if(!gdk_screen)
	{	
		showError("%s: -------------- GtkManager is Not Init -----------------\n", __FUNCTION__);
		return NULL;
	}
	
	return gdk_screen_get_height(gdk_screen);
}	

/* ************************************************************************************************
				                           			     Stack
**************************************************************************************************/
int WirelessManager::push_window(int window)
{		
	StackNode *p = new StackNode;
	
	if(!p)	
	{			
		showError("Page Stack NULL\n");
		return -1;
	}	
	else
		p->data = window;
	showInfo("Push %s\n", window_page_enum_to_str(window));
	p->next = page_stack->top;
	page_stack->top = p;
	
	//show_stack();
	return 0;
}		

int WirelessManager::pop_window()
{	
	StackNode *p = page_stack->top;
	int window;
			
	if(!p)
	{	
		showError("Page Stack NULL\n");
		return -1;
	}
	else
	{
		window = p->data;
		showInfo("Pop %s\n", window_page_enum_to_str(window));	
		page_stack->top = p->next;	
		free(p);
		//show_stack();			
		return window;
	}		
}
	
int WirelessManager::peek_window()
{	
	StackNode *p = page_stack->top;
	int window;
	
	if(NULL == p)
	{	
		showInfo("Page Stack NULL\n");
		return -1;
	}
	
	window = p->data;
	showInfo("Peek %s\n", window_page_enum_to_str(window));
	//show_stack();
	return window;
}

void WirelessManager::show_stack()
{		
	StackNode *p = page_stack->top;
	if(NULL == p)
	{	
		showInfo("*** Not Any Window Page ***\n");
		return;
	}	
	else
	{	
		showInfo("--------- Window Page Stack --------: \n");;   
		while(p)	
		{	
			showInfo("%s\n", window_page_enum_to_str(p->data));
			p = p->next;        
		}	
		showInfo("------------------------------------\n");;   
	}	
}		

const char *WirelessManager::window_page_enum_to_str(int enum_val)
{				
	switch(enum_val)
	{				
		case WINDOW_PAGE_MAIN:
			return "WINDOW_PAGE_MAIN";
		
		case WINDOW_PAGE_AP:
			return "WINDOW_PAGE_AP";
			
		case WINDOW_PAGE_CONFIG:
			return "WINDOW_PAGE_CONFIG";
			
		default:
			showWarning("******* %s: Invalid Enum Value: %d ***********\n", __FUNCTION__, enum_val);		
	}
		
	return NULL;
}

