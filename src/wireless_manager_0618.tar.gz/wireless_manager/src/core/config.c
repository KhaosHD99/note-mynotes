#include <gtk/gtk.h>
#include <X11/keysym.h>	
#include <gdk/gdkkeysyms.h>
#include <locale.h>
#include <glib/gi18n.h>
#include "skin.h"				
#include "LogMsg.hpp" 
#include "AppConfigApi.h"
#include "WirelessManagerInterface.h"
			
extern int skfd;			/* generic raw socket desc*/
extern GtkTreeStore *store_device;
extern GtkTreeStore *store_scan;
extern GtkTreeIter current_device_combo_iter;
	
//Label		
static GtkWidget* label_ip;	
static GtkWidget* label_mask;				
static GtkWidget* label_gateway;			

static GtkWidget* label_primary_dns;		
static GtkWidget* label_slave_dns;			

//Entry		
static GtkWidget* entry_ip;
static GtkWidget* entry_mask;
static GtkWidget* entry_gateway;
	
static GtkWidget* entry_primary_dns;
static GtkWidget* entry_slave_dns;

//Radio
static GtkWidget *radio_auto_get_ip;
static GtkWidget *radio_use_spec_ip;
static GtkWidget *radio_auto_get_dns;
static GtkWidget *radio_use_spec_dns;

//Table
static GtkWidget *table_ip;
static GtkWidget *table_dns; 

//Event Box									
static GtkWidget *eventbox_confirm;	
static GtkWidget *eventbox_cancel;	
	
//Image
static GtkImage *image_confirm;
static GtkImage *image_cancel;

//Bitmap		
static GdkBitmap *bitmap_confirm;
static GdkBitmap *bitmap_cancel;
	
void fill_main_ui();	
void show_message_window(char *msg);
int show_confirm_window(char *msg);

static void destroy_widget(GtkWidget *widget, gpointer user_data)
{	
	if(GTK_IS_WIDGET(widget))
	{		
		showInfo("Get in %s, Destroy Widget: %s\n", 
			 	  __FUNCTION__, 
			  	  gtk_widget_get_name(widget));

		if(widget == eventbox_confirm)
			eventbox_confirm = NULL;
		else if(widget == eventbox_cancel)
			eventbox_cancel = NULL;
		
		gtk_widget_destroy(widget);
	}			
}

static gboolean focus_in_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{		
	if(!gtk_widget_is_focus(widget))		
		gtk_widget_grab_focus(widget);
	
	char img_path[256];
	GdkPixbuf *pixbuf = NULL;
							
	if(0 == strcmp(user_data, "config_confirm"))
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_ACTIVE);
		pixbuf = create_gtk_pixbuf(img_path,
									 get_screen_width() / 9,		
								     get_screen_width() * 2 / 45,
									 _("Confirm"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_confirm, pixbuf);
	}
	else if(0 == strcmp(user_data, "config_cancel"))
	{
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_ACTIVE);
		pixbuf = create_gtk_pixbuf(img_path,
									 get_screen_width() / 9, 			
								     get_screen_width() * 2 / 45,		
									 _("Cancel"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_cancel, pixbuf);
	}	
	else
	{	
		showInfo("%s: Can not Disguish User Data\n", __FUNCTION__);
	}
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	return TRUE;
}		

static gboolean focus_out_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{	
	char img_path[256];		
	GdkPixbuf *pixbuf = NULL;	
				
	if(0 == strcmp(user_data, "config_confirm"))
	{
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
		pixbuf = create_gtk_pixbuf(img_path,
									 get_screen_width() / 9, 			
								     get_screen_width() * 2 / 45,	
									 _("Confirm"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_confirm, pixbuf);
	}
	else if(0 == strcmp(user_data, "config_cancel"))
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
		pixbuf = create_gtk_pixbuf(img_path,
									 get_screen_width() / 9,
								     get_screen_width() * 2 / 45,		
									 _("Cancel"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_cancel, pixbuf);
	}		
	else
	{			
		showInfo("%s: Can not Disguish User Data\n", __FUNCTION__);
	}
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	return TRUE;
}

int validate_input()
{
	if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(radio_use_spec_ip)))
	{	
		const gchar *ip_str = gtk_entry_get_text(GTK_ENTRY(entry_ip));
		if(0 == strlen(ip_str))
		{	
			showInfo("------------ ip_str Len 0\n");
			show_message_window(_("Can not Empty"));
			return -1;
		}	
	}
	
	return 0;
}
	
void config_confirm()
{	
	if(0 != validate_input())
		return;
	
	char cmd_set_ip[128] = {0};
	char cmd_set_netmask[128] = {0};
	char cmd_set_gw[128] = {0};
	FILE * pFile = NULL;
	const gchar *ip_str = NULL;
	const gchar *netmask_str = NULL;
	const gchar *gw_str = NULL;
	gchar *iface = NULL;

	/****************  Set Spec Network Setting *****************/
	if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(radio_use_spec_ip)))
	{	
		pFile = fopen (RESOURCE_FILE_BASE_PATH SET_NETWORK_FILE, "w+");
		if(NULL == pFile)
		{	
			printf("****** Open File Err\n");
			return -1;
		}	
			
		/* Get Current Interface */
		if(!gtk_tree_store_iter_is_valid(store_device, &current_device_combo_iter))
		{		
			showError("****** current_device_combo_iter Invalid\n");	
			return -1;
		}
		
		gtk_tree_model_get(GTK_TREE_MODEL(store_device), &current_device_combo_iter,
	                   	   1, &iface,
	                   	   -1);
		
		/*Get Input IP */
		ip_str = gtk_entry_get_text(GTK_ENTRY(entry_ip));
		
		/* Get Input Netmask */
		netmask_str = gtk_entry_get_text(GTK_ENTRY(entry_mask));
		
		/* Get Input Gateway */
		gw_str = gtk_entry_get_text(GTK_ENTRY(entry_gateway));
		
		
		/* Generate Shell */
		//IP
		if(ip_str && iface
		   && 0 != strlen(ip_str))
		{	
			snprintf(cmd_set_ip, sizeof(cmd_set_ip), "ifconfig %s up %s\n", iface, ip_str);
			fwrite (cmd_set_ip, 1 , strlen(cmd_set_ip),pFile);
		}
		//Netmask
		if(netmask_str && iface
		   && 0 != strlen(netmask_str))
		{	
			snprintf(cmd_set_netmask, sizeof(cmd_set_netmask), "ifconfig %s netmask %s\n", iface, netmask_str);
			fwrite (cmd_set_netmask, 1 , strlen(cmd_set_netmask),pFile);
		}
		//Gateway
		if(gw_str && iface
		   && 0 != strlen(gw_str))	
		{	
			snprintf(cmd_set_gw, sizeof(cmd_set_gw), "route add default gw %s %s\n", gw_str, iface);
			fwrite (cmd_set_gw, 1 , strlen(cmd_set_gw),pFile);
		}	
		fclose (pFile);
		
		//Execute Shell
		if(system("sh "RESOURCE_FILE_BASE_PATH SET_NETWORK_FILE))
		{	
			showInfo("*** Set NetWork Err, Interface: %s, IP: %s\n", iface, ip_str);	
			show_message_window(_("Set NetWork Err"));
			goto ERR;
		}
		else
		{
			showInfo("Set NetWork Suc, Interface: %s, IP: %s\n", iface, ip_str);
			show_message_window(_("Set NetWork Suc"));
		}
		if(iface)
			g_free(iface);
	}	
	
	/****************  DHCP *****************/
	
	
	pop_window();
	fill_main_ui();
	return;
		
ERR:
	if(iface)
		g_free(iface);
	return;
}	
	
void config_cancel()
{	
	pop_window();
	fill_main_ui();
}

static gboolean key_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{		
	switch(event->keyval) 
	{		
		case GDK_KP_Enter:
			g_print("GDK_KP_Enter\n");
			if(widget == eventbox_confirm)
			{
				config_confirm();
				return TRUE;
			}
			else if(widget == eventbox_cancel)
			{		
				config_cancel();
				return TRUE;
			}
			break;
			
		case GDK_Return:
			g_print("GDK_Return\n");
			if(widget == eventbox_confirm)
			{
				config_confirm();
				return TRUE;
			}
			else if(widget == eventbox_cancel)
			{		
				config_cancel();
				return TRUE;
			}	
			break;
			
		case GDK_Escape:						
			showInfo("GDK_Escape\n");
			break;
			
		default:
			showInfo("Default\n");				
	}
	
	return FALSE;
}		
	
static gboolean button_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{		
	if(widget == eventbox_confirm)
	{
		config_confirm();
		return TRUE;
	}
	else if(widget == eventbox_cancel)
	{		
		config_cancel();
		return TRUE;
	}
	
	return FALSE;
}
	
static void ip_setting_radio_toggled(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{		
	showInfo("Get in %s\n", __FUNCTION__);
	if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(radio_auto_get_ip)))
	{		
		gtk_widget_set_sensitive(table_ip, FALSE);
		gtk_entry_set_text(GTK_ENTRY(entry_ip), "");
		gtk_entry_set_text(GTK_ENTRY(entry_mask), "");
		gtk_entry_set_text(GTK_ENTRY(entry_gateway), "");
	}	
		
	if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(radio_use_spec_ip)))
	{	
		gtk_widget_set_sensitive(table_ip, TRUE);
	}
	
	return ;
}
	
static void dns_setting_radio_toggled(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{		
	showInfo("Get in %s\n", __FUNCTION__);	
	if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(radio_auto_get_dns)))
	{				
		gtk_widget_set_sensitive(table_dns, FALSE);
		gtk_entry_set_text(GTK_ENTRY(entry_primary_dns), "");
		gtk_entry_set_text(GTK_ENTRY(entry_slave_dns), "");
	}
		
	if(gtk_toggle_button_get_active (GTK_TOGGLE_BUTTON(radio_use_spec_dns)))
	{	
		gtk_widget_set_sensitive(table_dns, TRUE);
	}

	return ;
}	
	
void fill_config_ui(GtkWidget* fixed, int width, int height, int x, int y)
{				
	char img_path[128];	
	GdkPixbuf *pixbuf = NULL;
	char addr_str[64] = {0};	
	char netmask_str[64] = {0};
	gchar *dev = NULL;	
	GtkWidget *table_main, *frame_ip, *frame_dns;
	
	gtk_container_forall(GTK_CONTAINER(fixed), destroy_widget, NULL);
	if(peek_window() == -1 || peek_window() != WINDOW_PAGE_CONFIG)			
		push_window(WINDOW_PAGE_CONFIG);
	
	//Get Dev
	if(!gtk_tree_store_iter_is_valid(store_device, &current_device_combo_iter))
	{			
		showError("****** current_device_combo_iter Invalid\n");	
		return;
	}
	gtk_tree_model_get(GTK_TREE_MODEL(store_device), &current_device_combo_iter,
                   	   1, &dev,
                   	   -1);
	if(NULL == dev)
		showWarning("*** Dev NULL\n");
		
	/* Main Table*/
	table_main = gtk_table_new(1,
		 		  			   3,
						  	   FALSE);
	gtk_table_set_row_spacings (GTK_TABLE(table_main), 3);
	gtk_table_set_col_spacings (GTK_TABLE(table_main), 8);
	gtk_container_add (GTK_CONTAINER (fixed), table_main);
	gtk_fixed_move(GTK_FIXED(fixed), table_main, width / 20, height * 3 / 20);
	gtk_widget_show(table_main);
	
	/* -------------------------- IP Setting ----------------------*/
	/************  Auto Get IP Radio ************/	
	radio_auto_get_ip = gtk_radio_button_new_with_label (NULL, _("Auto Get IP"));	
	g_signal_connect(G_OBJECT(radio_auto_get_ip), "toggled",
					 G_CALLBACK(ip_setting_radio_toggled), NULL);
	gtk_table_attach_defaults(GTK_TABLE(table_main), radio_auto_get_ip, 0, 1, 0, 1);		
	gtk_widget_show(radio_auto_get_ip);	
		
	/************ Specific IP Frame  ***********/
	frame_ip = gtk_frame_new(NULL);
	gtk_frame_set_shadow_type (GTK_FRAME(frame_ip), GTK_SHADOW_ETCHED_IN);/* GTK_SHADOW_NONE, GTK_SHADOW_IN, GTK_SHADOW_OUT, GTK_SHADOW_ETCHED_IN, GTK_SHADOW_ETCHED_OUT */
	gtk_table_attach_defaults(GTK_TABLE(table_main), frame_ip, 0, 1, 1, 2);	
	gtk_widget_show(frame_ip);
	
	radio_use_spec_ip = gtk_radio_button_new_with_label_from_widget (GTK_RADIO_BUTTON (radio_auto_get_ip),
	                                 			                     _("Use Spec IP"));
	g_signal_connect(G_OBJECT(radio_use_spec_ip), "toggled",	
					 G_CALLBACK(ip_setting_radio_toggled), NULL);			
	gtk_frame_set_label_widget(GTK_FRAME(frame_ip), radio_use_spec_ip);	
	gtk_widget_show(radio_use_spec_ip);					
		
	/* Setting detail */
	table_ip = gtk_table_new(4,
			  			     4,	
						  	 FALSE);
	gtk_table_set_row_spacings (GTK_TABLE(table_ip), 10);
	gtk_table_set_col_spacings (GTK_TABLE(table_ip), 10);
	gtk_widget_set_sensitive(table_ip, FALSE);
	gtk_container_add (GTK_CONTAINER (frame_ip), table_ip);
	gtk_widget_show(table_ip);
	
	//IP	
	label_ip = gtk_label_new(_("IP"));	
	gtk_table_attach_defaults(GTK_TABLE(table_ip), label_ip, 1, 2, 0, 1);
	gtk_widget_show(label_ip);	
					
	entry_ip = gtk_entry_new();
	gtk_table_attach_defaults(GTK_TABLE(table_ip), entry_ip, 2, 3, 0, 1);
	gtk_widget_show(entry_ip);
	
	//mask
	label_mask = gtk_label_new(_("Mask"));
	gtk_table_attach_defaults(GTK_TABLE(table_ip), label_mask, 1, 2, 1, 2);
	gtk_widget_show(label_mask);
	
	entry_mask = gtk_entry_new();
	gtk_table_attach_defaults(GTK_TABLE(table_ip), entry_mask, 2, 3, 1, 2);
	gtk_widget_show(entry_mask);
	
	//gateway
	label_gateway = gtk_label_new(_("Gateway"));
	gtk_table_attach_defaults(GTK_TABLE(table_ip), label_gateway, 1, 2, 2, 3);
	gtk_widget_show(label_gateway);
						
	entry_gateway = gtk_entry_new();
	gtk_table_attach_defaults(GTK_TABLE(table_ip), entry_gateway, 2, 3, 2, 3);
	gtk_widget_show(entry_gateway);
		
	/* ----------------------- DNS Setting -----------------------*/
	/************ Auto Get DNS Radio ************/
	radio_auto_get_dns = gtk_radio_button_new_with_label (NULL, _("Auto Get DNS"));
	g_signal_connect(G_OBJECT(radio_auto_get_dns), "toggled",	
					 G_CALLBACK(dns_setting_radio_toggled), NULL);	
	gtk_table_attach_defaults(GTK_TABLE(table_main), radio_auto_get_dns, 2, 3, 0, 1);
	gtk_widget_show(radio_auto_get_dns);
				
	/************ Specific DNS Frame ************/
	frame_dns = gtk_frame_new(NULL);	
	gtk_frame_set_shadow_type (GTK_FRAME(frame_dns), GTK_SHADOW_ETCHED_IN);/* GTK_SHADOW_NONE, GTK_SHADOW_IN, GTK_SHADOW_OUT, GTK_SHADOW_ETCHED_IN, GTK_SHADOW_ETCHED_OUT */				
	gtk_table_attach_defaults(GTK_TABLE(table_main), frame_dns, 2, 3, 1, 2);	
	gtk_widget_show(frame_dns);	
	
	radio_use_spec_dns = gtk_radio_button_new_with_label_from_widget (GTK_RADIO_BUTTON (radio_auto_get_dns),
	                                 			                     _("Use Spec DNS"));
	g_signal_connect(G_OBJECT(radio_use_spec_dns), "toggled",	
					 G_CALLBACK(dns_setting_radio_toggled), NULL);		
	gtk_frame_set_label_widget(GTK_FRAME(frame_dns), radio_use_spec_dns);
	gtk_widget_show(radio_use_spec_dns);
			
	/* Setting detail */
	table_dns = gtk_table_new(4,
			  			 	  4,
						      FALSE);
	gtk_table_set_row_spacings (GTK_TABLE(table_dns), 10);
	gtk_table_set_col_spacings (GTK_TABLE(table_dns), 10);
	gtk_widget_set_sensitive(table_dns, FALSE);
	gtk_container_add (GTK_CONTAINER (frame_dns), table_dns);
	gtk_widget_show(table_dns);	
	
	//Primary DNS
	label_primary_dns = gtk_label_new(_("Primary DNS"));	
	gtk_table_attach_defaults(GTK_TABLE(table_dns), label_primary_dns, 1, 2, 0, 1);
	gtk_widget_show(label_primary_dns);	
	
	entry_primary_dns = gtk_entry_new();
	gtk_table_attach_defaults(GTK_TABLE(table_dns), entry_primary_dns, 2, 3, 0, 1);
	gtk_widget_show(entry_primary_dns);		
	
	//Slave DNS
	label_slave_dns = gtk_label_new(_("Slave DNS"));
	gtk_table_attach_defaults(GTK_TABLE(table_dns), label_slave_dns, 1, 2, 1, 2);
	gtk_widget_show(label_slave_dns);
	
	entry_slave_dns = gtk_entry_new();		
	gtk_table_attach_defaults(GTK_TABLE(table_dns), entry_slave_dns, 2, 3, 1, 2);
	gtk_widget_show(entry_slave_dns);
	
	/* ------------------------------- Create EventBox ----------------------------------*/
	//config_confirm	
	eventbox_confirm = gtk_event_box_new();
	gtk_widget_set_can_focus(eventbox_confirm, TRUE);	
	gtk_container_add(GTK_CONTAINER(fixed), eventbox_confirm);	
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_confirm, width * 5 / 9,	
													   height * 17 / 20);	
	
	g_signal_connect(G_OBJECT(eventbox_confirm), "key_press_event",
					 G_CALLBACK(key_press_event), "config_confirm");
	g_signal_connect(G_OBJECT(eventbox_confirm), "button_press_event",	
					 G_CALLBACK(button_press_event), "config_confirm");
	g_signal_connect(G_OBJECT(eventbox_confirm), "enter_notify_event",			
					 G_CALLBACK(focus_in_event), "config_confirm");		
	g_signal_connect(G_OBJECT(eventbox_confirm), "leave_notify_event",
					 G_CALLBACK(focus_out_event), "config_confirm");	
	g_signal_connect(G_OBJECT(eventbox_confirm), "focus_in_event",
					 G_CALLBACK(focus_in_event), "config_confirm");
	g_signal_connect(G_OBJECT(eventbox_confirm), "focus_out_event",
					 G_CALLBACK(focus_out_event), "config_confirm");
	gtk_widget_show (eventbox_confirm);	
		
	//config_cancel
	eventbox_cancel = gtk_event_box_new();
	gtk_widget_set_can_focus(eventbox_cancel, TRUE);
	gtk_container_add(GTK_CONTAINER(fixed), eventbox_cancel);
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_cancel, width * 7 / 9,			 
													  height * 17 / 20);
		
	g_signal_connect(G_OBJECT(eventbox_cancel), "key_press_event",
					 G_CALLBACK(key_press_event), "config_cancel");		
	g_signal_connect(G_OBJECT(eventbox_cancel), "button_press_event",
					 G_CALLBACK(button_press_event), "config_cancel");		
	g_signal_connect(G_OBJECT(eventbox_cancel), "enter_notify_event",	
					 G_CALLBACK(focus_in_event), "config_cancel");	
	g_signal_connect(G_OBJECT(eventbox_cancel), "leave_notify_event",
					 G_CALLBACK(focus_out_event), "config_cancel");	
	g_signal_connect(G_OBJECT(eventbox_cancel), "focus_in_event",
					 G_CALLBACK(focus_in_event), "config_cancel");
	g_signal_connect(G_OBJECT(eventbox_cancel), "focus_out_event",
					 G_CALLBACK(focus_out_event), "config_cancel");
	gtk_widget_show (eventbox_cancel);
	
	/* ------------------------------- Create Image ----------------------------------*/
	//config_confirm
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
	pixbuf =  create_gtk_pixbuf(img_path,
									  get_screen_width() / 9, 
									  get_screen_width() / 22,
									  _("Confirm"), 14);
	image_confirm = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_confirm)), 
									  NULL,				
									  &bitmap_confirm,				
									  128);				
	gtk_widget_shape_combine_mask(eventbox_confirm, bitmap_confirm, 0, 0);
	gtk_container_add(GTK_CONTAINER(eventbox_confirm), GTK_WIDGET(image_confirm));
	gtk_widget_show (GTK_WIDGET(image_confirm));
	
	//config_cancel
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
	pixbuf =  create_gtk_pixbuf(img_path, 
									 get_screen_width() / 9,	
									 get_screen_width() / 22,	 		
									 _("Cancel"), 14);
	image_cancel = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_cancel)), 
									  NULL,
									  &bitmap_cancel,	
									  128);
	gtk_widget_shape_combine_mask(eventbox_cancel, bitmap_cancel, 0, 0);
	gtk_container_add(GTK_CONTAINER(eventbox_cancel), GTK_WIDGET(image_cancel));
	gtk_widget_show (GTK_WIDGET(image_cancel));
	
	/* ------------------------------- Set Data ----------------------------------*/
	if(dev && 0 == get_iface_address(dev, addr_str, sizeof(addr_str)))	
	{	
		gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON(radio_use_spec_ip), TRUE);
		gtk_entry_set_text(GTK_ENTRY(entry_ip), addr_str);
		if(0 == get_iface_netmask(dev, netmask_str, sizeof(netmask_str)))
		{	
			gtk_entry_set_text(GTK_ENTRY(entry_mask), netmask_str);
		}
	}

	LOCALAPPCONFIG config;
	if(0 == read_configs(&config, sizeof(config)))
	{
		showInfo("------------------ Gw: %s, DNS: %s\n", config.szLocalGatewayIp, 
														 config.szDnsServer);
		
		gtk_toggle_button_set_active (GTK_TOGGLE_BUTTON(radio_use_spec_dns), TRUE);
		gtk_entry_set_text(GTK_ENTRY(entry_primary_dns), config.szDnsServer);
	}
	else
		showWarning("*** Read Config Error\n");
}

