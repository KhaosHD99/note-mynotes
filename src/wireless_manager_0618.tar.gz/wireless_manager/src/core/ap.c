#include <gtk/gtk.h>
#include <X11/keysym.h>	
#include <gdk/gdkkeysyms.h>
#include <locale.h>
#include <glib/gi18n.h>
#include "skin.h"				
#include "LogMsg.hpp" 
#include "iwlib.h"
#include "WirelessManagerInterface.h"

extern int skfd;			/* generic raw socket desc*/
extern GtkTreeStore *store_device;
extern GtkTreeStore *store_scan;
extern GtkTreeIter current_device_combo_iter;

//Label	
static GtkWidget* label_essid = NULL;				
static GtkWidget* label_auth_mode = NULL;
static GtkWidget* label_encryption_type = NULL;	
static GtkWidget* label_key = NULL;				
static GtkWidget* label_key_index = NULL;			

//Entry	
static GtkWidget* entry_essid = NULL;
static GtkWidget* entry_key = NULL;

//ComboBox
static GtkWidget *combo_auth_mode = NULL;			
static GtkWidget *combo_encryption_type = NULL;
static GtkWidget *combo_key_index = NULL;
					
//ComboBox Store
static GtkListStore *combo_auth_mode_store = NULL;			
static GtkListStore *combo_encryption_type_store = NULL;	
static GtkListStore *combo_key_index_store = NULL;			
	
//Event Box									
static GtkWidget *eventbox_confirm = NULL;	
static GtkWidget *eventbox_cancel = NULL;	

//Image
static GtkImage *image_confirm = NULL;
static GtkImage *image_cancel = NULL;

//Bitmap		
static GdkBitmap *bitmap_confirm = NULL;
static GdkBitmap *bitmap_cancel = NULL;

void fill_main_ui();
void show_message_window(char *msg);
int show_confirm_window(char *msg);
int set_essid(int skfd, char *ifname,	char *essid);
//void destroy_main_page_widget(GtkWidget *widget, gpointer user_data);

static void destroy_widget(GtkWidget *widget, gpointer user_data)
{	
	if(GTK_IS_WIDGET(widget))
	{		
		showInfo("Get in %s, Destroy Widget: %s\n", 
			 	  __FUNCTION__, 
			  	  gtk_widget_get_name(widget));

		if(widget == eventbox_confirm)
			eventbox_confirm = NULL;
		else if(widget == eventbox_cancel)
			eventbox_cancel = NULL;
			
		gtk_widget_destroy(widget);
	}			
}

static int add_auth_mode_to_store(int mode)
{	
	GtkTreeIter iter;
	
	if(!GTK_IS_LIST_STORE(combo_auth_mode_store))
	    combo_auth_mode_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_INT);
	
   	gtk_list_store_append (combo_auth_mode_store, &iter);
	gtk_list_store_set (combo_auth_mode_store, &iter,
		                1, mode,
				        -1);
	
	return 0;
}	

static int add_encryption_type_to_store(int type)
{	
	GtkTreeIter iter;
	
	if(!GTK_IS_LIST_STORE(combo_encryption_type_store))
	    combo_encryption_type_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_INT);
		
   	gtk_list_store_append (combo_encryption_type_store, &iter);
	gtk_list_store_set (combo_encryption_type_store, &iter,
		                1, type,
				        -1);
	
	return 0;
}		

static int add_key_index_to_store(int index)
{					
	GtkTreeIter iter;
	
	if(!GTK_IS_LIST_STORE(combo_key_index_store))
	    combo_key_index_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_INT);
				
   	gtk_list_store_append (combo_key_index_store, &iter);	
	gtk_list_store_set (combo_key_index_store, &iter,	
		                1, index,
				        -1);
							
	return 0;
}	

static gboolean focus_in_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{	
	if(!gtk_widget_is_focus(widget))		
		gtk_widget_grab_focus(widget);
	
	char img_path[256];	
	GdkPixbuf *pixbuf = NULL;	
	
	if(0 == strcmp(user_data, "ap_confirm"))
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_ACTIVE);
		pixbuf = create_gtk_pixbuf(img_path,		
									 get_screen_width() / 9,		
								     get_screen_width() * 2 / 45,
									 _("Confirm"), 14);
		gtk_image_set_from_pixbuf((GtkImage *)image_confirm, pixbuf);
	}
	else if(0 == strcmp(user_data, "ap_cancel"))
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_ACTIVE);
		pixbuf = create_gtk_pixbuf(img_path,	
									 get_screen_width() / 9, 			
								     get_screen_width() * 2 / 45,		
									 _("Cancel"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_cancel, pixbuf);
	}	
	else
	{	
		showInfo("%s: Can not Disguish User Data\n", __FUNCTION__);
	}	
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);

	return TRUE;
}		

static gboolean focus_out_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{	
	char img_path[256];		
	GdkPixbuf *pixbuf = NULL;	
	
	if(0 == strcmp(user_data, "ap_confirm"))
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
		pixbuf = create_gtk_pixbuf(img_path, 
									 get_screen_width() / 9, 			
								     get_screen_width() * 2 / 45,	
									 _("Confirm"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_confirm, pixbuf);
	}
	else if(0 == strcmp(user_data, "ap_cancel"))
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
		pixbuf = create_gtk_pixbuf(img_path,
									 get_screen_width() / 9, 			
								     get_screen_width() * 2 / 45,		
									 _("Cancel"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_cancel, pixbuf);
	}		
	else
	{	
		showInfo("%s: Can not Disguish User Data\n", __FUNCTION__);
	}
	if(G_IS_OBJECT(pixbuf))	
		g_object_unref(pixbuf);

	return TRUE;
}
	
void ap_confirm()
{	
	gchar *dev = NULL;
	char cmd_network[128];
	
	if(!gtk_tree_store_iter_is_valid(store_device, &current_device_combo_iter))
	{		
		showError("****** current_device_combo_iter Invalid\n");	
		return;
	}
	
	gtk_tree_model_get(GTK_TREE_MODEL(store_device), &current_device_combo_iter,
                   	   1, &dev,
                   	   -1);
	
	/* Set Essid */
	if(0 != set_essid(skfd, dev, (char *)gtk_entry_get_text(GTK_ENTRY(entry_essid))))
	{	
		showError("*********** Set Essid Error\n");
		goto END;
	}	
	
	/* Execute The Set Network Shell */
	snprintf(cmd_network, sizeof(cmd_network), "sh %s%s", RESOURCE_FILE_BASE_PATH, 
														  SET_NETWORK_FILE);
	if(system(cmd_network))
	{	
		printf("****** Set Network Err\n");	
		show_message_window(_("Connect Error"));
		goto END;
	}	
	
	/* Execute The Set Auth Shell */
	
	
		
	pop_window();
	if(GTK_IS_LIST_STORE(combo_auth_mode_store))	
		gtk_list_store_clear(combo_auth_mode_store);	
	if(GTK_IS_LIST_STORE(combo_key_index_store))		
		gtk_list_store_clear(combo_key_index_store);
	fill_main_ui();
	
END: 
	if(dev)
		g_free(dev);
}	

void ap_cancel()
{		
	pop_window();
	if(GTK_IS_LIST_STORE(combo_auth_mode_store))
		gtk_list_store_clear(combo_auth_mode_store);	
	if(GTK_IS_LIST_STORE(combo_key_index_store))
		gtk_list_store_clear(combo_key_index_store);
	fill_main_ui();
}			

static gboolean key_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{	
	switch(event->keyval) 
	{	
		case GDK_KP_Enter:
			g_print("GDK_KP_Enter\n");
			if(widget == eventbox_confirm)
			{	
				ap_confirm();
				return TRUE;
			}
			else if(widget == eventbox_cancel)
			{	
				ap_cancel();
				return TRUE;
			}
			break;
			
		case GDK_Return:
			g_print("GDK_Return\n");
			if(widget == eventbox_confirm)
			{		
				ap_confirm();
				return TRUE;
			}	
			else if(widget == eventbox_cancel)
			{	
				ap_cancel();
				return TRUE;
			}
			break;
			
		default:
			showInfo("Default\n");			
	}
	
	return FALSE;
}		

static gboolean button_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{	
	if(widget == eventbox_confirm)
	{	
		ap_confirm();
		return TRUE;
	}	
	else if(widget == eventbox_cancel)
	{	
		ap_cancel();
		return TRUE;
	}
	
	return FALSE;
}	

static void set_auth_mode (GtkCellLayout   *cell_layout,
					           GtkCellRenderer *cell,
					           GtkTreeModel    *model,
					           GtkTreeIter     *iter,
					           gpointer         data)
{		
	int auth_mode;
		
	gtk_tree_model_get(model, iter,	
	                   1, &auth_mode,	
	                   -1);	
	g_object_set(GTK_CELL_RENDERER(cell),
   	    		 "text", auth_mode_enum_to_str(auth_mode),
	 			 NULL);	
}	

static void set_encryption_type (GtkCellLayout   *cell_layout,
					           		GtkCellRenderer *cell,
					           		GtkTreeModel    *model,
					           		GtkTreeIter     *iter,
					           		gpointer         data)
{				
	int encryption_type;
	
	gtk_tree_model_get(model, iter,	
	                   1, &encryption_type,	
	                   -1);	
	g_object_set(GTK_CELL_RENDERER(cell),	
   	    		 "text", encryption_type_enum_to_str(encryption_type),
	 			 NULL);	
}	
	
static void set_key_index(GtkCellLayout   *cell_layout,
					         GtkCellRenderer *cell,	
					         GtkTreeModel    *model,	
					         GtkTreeIter     *iter,	
					         gpointer         data)
{				
	int key_index;	
	char key_index_str[4];
		
	gtk_tree_model_get(model, iter,	
	                   1, &key_index,	
	                   -1);
	sprintf(key_index_str, "%d", key_index + 1);
	g_object_set(GTK_CELL_RENDERER(cell),
   	    		 "text", key_index_str,	
	 			 NULL);					
}	

void combo_auth_mode_change(GtkComboBox *widget,
                                     gpointer user_data)
{	
	GtkTreeIter iter;
	int auth_mode;
	
	if(gtk_combo_box_get_active_iter(GTK_COMBO_BOX(combo_auth_mode), &iter))
	{	
		gtk_tree_model_get(GTK_TREE_MODEL(combo_auth_mode_store), &iter,
                   		   1, &auth_mode,
                   		   -1);
		
		switch(auth_mode)
		{	
			case AUTH_MODE_OPEN:	
				if(GTK_IS_LIST_STORE(combo_encryption_type_store))
					gtk_list_store_clear(combo_encryption_type_store);
				add_encryption_type_to_store(ENCRYPTION_TYPE_NOT_USE);
				add_encryption_type_to_store(ENCRYPTION_TYPE_WEP);
				gtk_combo_box_set_active (GTK_COMBO_BOX (combo_encryption_type), 0);
				break;	
			
			case AUTH_MODE_SHARE:
				if(GTK_IS_LIST_STORE(combo_encryption_type_store))
					gtk_list_store_clear(combo_encryption_type_store);
				add_encryption_type_to_store(ENCRYPTION_TYPE_NOT_USE);
				add_encryption_type_to_store(ENCRYPTION_TYPE_WEP);
				gtk_combo_box_set_active (GTK_COMBO_BOX (combo_encryption_type), 0);
				break;
				
			case AUTH_MODE_WPA_PSK:
				if(GTK_IS_LIST_STORE(combo_encryption_type_store))
					gtk_list_store_clear(combo_encryption_type_store);
				add_encryption_type_to_store(ENCRYPTION_TYPE_TKIP);
				add_encryption_type_to_store(ENCRYPTION_TYPE_AES_CCMP);
				gtk_combo_box_set_active (GTK_COMBO_BOX (combo_encryption_type), 0);
				break;
				
			case AUTH_MODE_WPA2_PSK:	
				if(GTK_IS_LIST_STORE(combo_encryption_type_store))
					gtk_list_store_clear(combo_encryption_type_store);	
				add_encryption_type_to_store(ENCRYPTION_TYPE_TKIP);
				add_encryption_type_to_store(ENCRYPTION_TYPE_AES_CCMP);
				gtk_combo_box_set_active (GTK_COMBO_BOX (combo_encryption_type), 0);
				break;
				
			default:
				showWarning("*** Invalid Auth Mode ***\n");
		}
		
	}	
	else
	{			
		showWarning("**** Get Active Iter Fail\n");
	}
}                                                        

void 
fill_ap_ui(GtkWidget* fixed,
		   GtkTreeModel *model,
		   GtkTreeIter *iter,
		   int width,
		   int height, 
		   int x, 
		   int y)
{		
	showInfo("on %s\n", __FUNCTION__);
	char img_path[128] = {0};
	GdkPixbuf *pixbuf = NULL;
	GtkWidget *frame;
	GtkWidget *table;
	GtkCellRenderer *renderer;
	gchar *essid = NULL;
	
	gtk_container_forall(GTK_CONTAINER(fixed), destroy_widget, NULL);
	//gtk_container_forall(GTK_CONTAINER(fixed), destroy_main_page_widget, NULL);
	
	if(peek_window() == -1 || peek_window() != WINDOW_PAGE_AP)			
		push_window(WINDOW_PAGE_AP);
	
	gtk_tree_model_get(model, iter,
				   	   SCAN_STORE_COLUMN_ESSID, &essid,
                       -1);			
	showInfo("---------- Selected Essid: %s -------------\n", essid);	
	
	/*********************** Frame **************************/
	frame = gtk_frame_new("Config Wireless");
	gtk_frame_set_shadow_type (GTK_FRAME(frame), GTK_SHADOW_ETCHED_IN);/* GTK_SHADOW_NONE, GTK_SHADOW_IN, GTK_SHADOW_OUT, GTK_SHADOW_ETCHED_IN, GTK_SHADOW_ETCHED_OUT */
	gtk_container_add(GTK_CONTAINER(fixed), frame);
	gtk_fixed_move(GTK_FIXED(fixed), frame, width / 13, height / 15);
	gtk_widget_show(frame);
	
	/************************  Table ************************/			
	table = gtk_table_new(7,			//Row
			  			  4,			
						  FALSE);
	gtk_table_set_row_spacings (GTK_TABLE(table), 10);
	gtk_table_set_col_spacings (GTK_TABLE(table), 10);
	gtk_container_add (GTK_CONTAINER (frame), table);
	gtk_widget_show(table);
	
	/********** essid  Label/Entry **********/
	label_essid = gtk_label_new("essid");
	gtk_table_attach_defaults(GTK_TABLE(table), label_essid, 1,		//Left 
												  2, 
												  1, 		//top
												  2);
	gtk_widget_show(label_essid);
		
	entry_essid = gtk_entry_new();
	gtk_entry_set_text(GTK_ENTRY(entry_essid), (const gchar *)essid);
	gtk_widget_set_sensitive(entry_essid, FALSE);
	gtk_widget_set_size_request(GTK_WIDGET(entry_essid), 150, 27);
	gtk_table_attach_defaults(GTK_TABLE(table), entry_essid, 2,		//Left 
												  3, 
												  1, 		//top
												  2);
	gtk_widget_show(entry_essid);
	
	/********** Auth Mode Label/Combo **********/
	label_auth_mode = gtk_label_new(_("Authenticate Mode"));
	gtk_table_attach_defaults(GTK_TABLE(table), label_auth_mode, 1,		//Left 
													  2, 
													  2, 		//top
													  3);
	gtk_widget_show(label_auth_mode);
	
	add_auth_mode_to_store(AUTH_MODE_OPEN);
	add_auth_mode_to_store(AUTH_MODE_SHARE);
	add_auth_mode_to_store(AUTH_MODE_WPA_PSK);
	add_auth_mode_to_store(AUTH_MODE_WPA2_PSK);
	combo_auth_mode = gtk_combo_box_new_with_model(GTK_TREE_MODEL(combo_auth_mode_store));
	renderer = gtk_cell_renderer_text_new ();	
    gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_auth_mode), renderer, TRUE);
    gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_auth_mode), renderer,
				    				"text", 1,		
				    				NULL);			
	
    gtk_cell_layout_set_cell_data_func (GTK_CELL_LAYOUT (combo_auth_mode),
										renderer,
										set_auth_mode,	
										NULL, NULL);
	gtk_widget_set_size_request(combo_auth_mode, 150, 27);
	gtk_table_attach_defaults(GTK_TABLE(table), combo_auth_mode, 2,		//Left 
																  3,
																  2, 		//top
																  3);
	g_signal_connect(GTK_OBJECT(combo_auth_mode), "changed",
					 G_CALLBACK(combo_auth_mode_change), NULL);
	gtk_widget_show(combo_auth_mode);
				
	/********** Encryption Type Label/Combo **********/
	label_encryption_type = gtk_label_new(_("Encryption Type"));
	gtk_table_attach_defaults(GTK_TABLE(table), label_encryption_type, 1,		//Left 
														    2, 
														    3, 		//top
														    4);
	gtk_widget_show(label_encryption_type);	
		
	//add_encryption_type_to_store(ENCRYPTION_TYPE_WEP);	
	//add_encryption_type_to_store(ENCRYPTION_TYPE_TKIP);	
	//add_encryption_type_to_store(ENCRYPTION_TYPE_AES_CCMP);			
	combo_encryption_type_store = gtk_list_store_new(2, G_TYPE_INT, G_TYPE_INT);
	combo_encryption_type = gtk_combo_box_new_with_model(GTK_TREE_MODEL(combo_encryption_type_store));
	renderer = gtk_cell_renderer_text_new ();
    gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_encryption_type), renderer, TRUE);
    gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_encryption_type), renderer,
				    				"text", 1,		
				    				NULL);			
	
    gtk_cell_layout_set_cell_data_func (GTK_CELL_LAYOUT (combo_encryption_type),
										renderer,
										set_encryption_type,	
										NULL, NULL);
	//gtk_combo_box_set_active (GTK_COMBO_BOX (combo_encryption_type), 0);
	gtk_widget_set_size_request(GTK_WIDGET(combo_encryption_type), 150, 27);
	gtk_table_attach_defaults(GTK_TABLE(table), combo_encryption_type, 2,		//Left 
														    3, 
														    3, 		//top
														    4);
	gtk_widget_show(combo_encryption_type);
	
	/********** Secret Key Label/Entry **********/
	label_key = gtk_label_new(_("Key"));	
	gtk_table_attach_defaults(GTK_TABLE(table), label_key, 1,		//Left 
											 	 2, 
												  4, 		//top
												  5);
	gtk_widget_show(label_key);
					
	entry_key = gtk_entry_new();
	gtk_widget_set_size_request(GTK_WIDGET(entry_key), 150, 27);
	gtk_table_attach_defaults(GTK_TABLE(table), entry_key, 2,		//Left 
												  3, 
												  4, 		//top
												  5);
	gtk_widget_show(entry_key);
		
	/********** Key Index Label/Combo **********/
	label_key_index = gtk_label_new("Index");
	gtk_table_attach_defaults(GTK_TABLE(table), label_key_index, 1,		//Left 
													  2, 
													  5, 		//top
													  6);
	gtk_widget_show(label_key_index);				
	
	add_key_index_to_store(0);	
	add_key_index_to_store(1);	
	add_key_index_to_store(2);	
	add_key_index_to_store(3);	
	add_key_index_to_store(4);
	combo_key_index = gtk_combo_box_new_with_model(GTK_TREE_MODEL(combo_key_index_store));
	renderer = gtk_cell_renderer_text_new ();	
    gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_key_index), renderer, TRUE);
    gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_key_index), renderer,
				    				"text", 1,	
				    				NULL);			
			
    gtk_cell_layout_set_cell_data_func (GTK_CELL_LAYOUT (combo_key_index),
										renderer,
										set_key_index,		
										NULL, NULL);		
	gtk_combo_box_set_active (GTK_COMBO_BOX (combo_key_index), 0);	
	gtk_widget_set_size_request(GTK_WIDGET(combo_key_index), 150, 27);	
	gtk_table_attach_defaults(GTK_TABLE(table), combo_key_index, 2,		//Left 
													  3, 
													  5, 		//top
													  6);
	gtk_widget_show(combo_key_index);

	//Set Combo 		
	gtk_combo_box_set_active (GTK_COMBO_BOX (combo_auth_mode), 0);
	
	/* ------------------------------- Create EventBox ----------------------------------*/
	//ap_confirm	
	eventbox_confirm = gtk_event_box_new();
	gtk_widget_set_can_focus(eventbox_confirm, TRUE);	
	gtk_container_add(GTK_CONTAINER(fixed), eventbox_confirm);	
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_confirm, 
									 width * 5 / 9,
									 height * 17 / 20);
	
	g_signal_connect(G_OBJECT(eventbox_confirm), "key_press_event",
					 G_CALLBACK(key_press_event), NULL);
	g_signal_connect(G_OBJECT(eventbox_confirm), "button_press_event",	
					 G_CALLBACK(button_press_event), NULL);	
	g_signal_connect(G_OBJECT(eventbox_confirm), "enter_notify_event",			
					 G_CALLBACK(focus_in_event), "ap_confirm");		
	g_signal_connect(G_OBJECT(eventbox_confirm), "leave_notify_event",
					 G_CALLBACK(focus_out_event), "ap_confirm");	
	g_signal_connect(G_OBJECT(eventbox_confirm), "focus_in_event",
					 G_CALLBACK(focus_in_event), "ap_confirm");
	g_signal_connect(G_OBJECT(eventbox_confirm), "focus_out_event",
					 G_CALLBACK(focus_out_event), "ap_confirm");
	gtk_widget_show (eventbox_confirm);	
		
	//ap_cancel	
	eventbox_cancel = gtk_event_box_new();
	gtk_widget_set_can_focus(eventbox_cancel, TRUE);	
	gtk_container_add(GTK_CONTAINER(fixed), eventbox_cancel);
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_cancel,
									  width * 7 / 9,
									  height * 17 / 20);		
																	
	g_signal_connect(G_OBJECT(eventbox_cancel), "key_press_event",
					 G_CALLBACK(key_press_event), "ap_cancel");		
	g_signal_connect(G_OBJECT(eventbox_cancel), "button_press_event",
					 G_CALLBACK(button_press_event), "ap_cancel");		
	g_signal_connect(G_OBJECT(eventbox_cancel), "enter_notify_event",	
					 G_CALLBACK(focus_in_event), "ap_cancel");	
	g_signal_connect(G_OBJECT(eventbox_cancel), "leave_notify_event",
					 G_CALLBACK(focus_out_event), "ap_cancel");	
	g_signal_connect(G_OBJECT(eventbox_cancel), "focus_in_event",
					 G_CALLBACK(focus_in_event), "ap_cancel");
	g_signal_connect(G_OBJECT(eventbox_cancel), "focus_out_event",
					 G_CALLBACK(focus_out_event), "ap_cancel");
	gtk_widget_show (eventbox_cancel);
		
	/* ------------------------------- Create Image ----------------------------------*/
	//Confirm
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
	pixbuf =  create_gtk_pixbuf(img_path, 	
									  get_screen_width() / 9, 
									  get_screen_width() / 22,
									  _("Confirm"), 14);
	image_confirm = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_confirm)), 
									  NULL,				
									  &bitmap_confirm,				
									  128);				
	gtk_widget_shape_combine_mask(eventbox_confirm, bitmap_confirm, 0, 0);
	gtk_container_add(GTK_CONTAINER(eventbox_confirm), GTK_WIDGET(image_confirm));
	gtk_widget_show (GTK_WIDGET(image_confirm));
	
	//Cancel	
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
	pixbuf =  create_gtk_pixbuf(img_path, 
									 get_screen_width() / 9,	
									 get_screen_width() / 22,	 		
									 _("Cancel"), 14);
	image_cancel = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
	if(G_IS_OBJECT(pixbuf))	
		g_object_unref(pixbuf);
	
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_cancel)), 
									  NULL,
									  &bitmap_cancel,	
									  128);				
	gtk_widget_shape_combine_mask(eventbox_cancel, bitmap_cancel, 0, 0);
	gtk_container_add(GTK_CONTAINER(eventbox_cancel), GTK_WIDGET(image_cancel));
	gtk_widget_show (GTK_WIDGET(image_cancel));
	
	/* ------------------------------- Grab Focus ----------------------------------*/
	if(gtk_widget_is_sensitive(entry_essid))
		gtk_widget_grab_focus(entry_essid);	
	else
		gtk_widget_grab_focus(combo_auth_mode);
}	
	
