#include <gtk/gtk.h>
#include <gdk/gdkkeysyms.h>
#include <locale.h>
#include <glib/gi18n.h>
#include "fnGtkApplicationDef.h"	
#include "WirelessManagerInterface.h"
#include "skin.h"	
#include "LogMsg.hpp"		
#include "AppConfigApi.h"		
#include "iwlib.h"		
	
#define LOCKFILE_PREFIX "/var/run/"

int skfd;			/* generic raw socket desc*/
static GtkWidget* window;
static GtkWidget* fixed;
static GdkPixmap *bg_pixmap;

static GtkWidget *treeview_scan;

GtkTreeStore *store_device;
GtkTreeStore *store_scan;
	
static GtkWidget *combo_device;

//Label
static GtkWidget* label_scan;
static GtkWidget* label_device;

//EventBox
static GtkWidget *eventbox_scan;
static GtkWidget *eventbox_device;
static GtkWidget *eventbox_setting;
static GtkWidget *eventbox_connect;
static GtkWidget *eventbox_disconnect;
static GtkWidget *eventbox_quit;	

//Image	
static GtkImage *bg_image;
static GtkImage *image_scan;
static GtkImage *image_device;
static GtkImage *image_setting;
static GtkImage *image_connect;
static GtkImage *image_disconnect;
static GtkImage *image_quit;
	
//Bitmap	
static GdkBitmap *bg_bitmap;			
static GdkBitmap *bitmap_scan;		
static GdkBitmap *bitmap_device;	
static GdkBitmap *bitmap_setting;		
static GdkBitmap *bitmap_connect;		
static GdkBitmap *bitmap_disconnect;	
static GdkBitmap *bitmap_quit;

GtkTreeIter current_device_combo_iter;

int iwconfig(int argc, char **	argv);	
int iwspy(int argc, char **argv);	
int iwspy(int argc, char **argv);	
	
int print_info(int skfd, char *	ifname,	char *args[], int count);
	
int print_scanning_info(GtkTreeStore *store, int skfd, char *ifname, char *args[],	int count);
int print_freq_info(int skfd, char *ifname, char *args[], int count);
int print_bitrate_info(int skfd, char *ifname, char *args[], int count);
int print_keys_info(int skfd, char *ifname, char *args[], int count);
int print_pm_info(int skfd, char *ifname, char *args[], int count);
int print_txpower_info(int skfd, char *ifname, char *args[], int count);
int	print_retry_info(int skfd, char *ifname, char *args[], int count);
int print_ap_info(int skfd, char *ifname, char *args[], int count);
int	print_event_capa_info(int skfd, char *ifname, char *args[], int count);
int print_auth_info(int skfd, char *ifname, char *args[], int count);
int print_wpakeys_info(int skfd, char *ifname, char *args[], int count);
int print_gen_ie_info(int skfd, char *ifname, char *args[], int count);
int print_modul_info(int skfd, char *ifname, char *args[], int count);
void ap_confirm();		
void ap_cancel();
void fill_ap_ui(GtkWidget* fixed, GtkTreeModel *model, GtkTreeIter *iter, int width, int height, int x, int y);
void fill_config_ui(GtkWidget* fixed, int width, int height, int x, int y);
int get_info(int skfd, char *ifname, struct wireless_info *info);
//void destroy_ap_page_widget(GtkWidget *widget, gpointer user_data);
	
static void destroy_widget(GtkWidget *widget, gpointer user_data)
{	
	if(GTK_IS_WIDGET(widget))
	{		
		showInfo("Get in %s, Destroy Widget: %s\n", 
			 	  __FUNCTION__, 
			  	  gtk_widget_get_name(widget));
		
		if(widget == treeview_scan)
			treeview_scan = NULL;
		else if(widget == combo_device)
			combo_device = NULL;
		else if(widget == label_device)
			label_device = NULL;
		else if(widget == label_device)
			label_device = NULL;
		else if(widget == eventbox_scan)
			eventbox_scan = NULL;
		else if(widget == eventbox_connect)
			eventbox_connect = NULL;
		else if(widget == eventbox_disconnect)
			eventbox_disconnect = NULL;
		else if(widget == eventbox_setting)
			eventbox_setting = NULL;
		else if(widget == eventbox_device)
			eventbox_device = NULL;
		else if(widget == eventbox_quit)
			eventbox_quit = NULL;
		
		gtk_widget_destroy(widget);
	}			
}

static void set_device_text (GtkTreeViewColumn *tree_column,
						       GtkCellRenderer   *cell,
						       GtkTreeModel      *model,
						       GtkTreeIter       *iter,
						       gpointer           data)
{	
	gchar *name;
	
	gtk_tree_model_get(model, iter,
	                   1, &name,
	                   -1);
	g_object_set(GTK_CELL_RENDERER(cell),
   	    		 "text", name,
	 			 NULL);	
	g_free(name);
}	

static void set_essid_text (GtkTreeViewColumn *tree_column,
						       GtkCellRenderer   *cell,
						       GtkTreeModel      *model,
						       GtkTreeIter       *iter,
						       gpointer           data)
{	
	gchar *name;	
			
	gtk_tree_model_get(model, iter,
	                   SCAN_STORE_COLUMN_ESSID, &name,
	                   -1);
	g_object_set(GTK_CELL_RENDERER(cell),
   	    		 "text", name,
	 			 NULL);	
	g_free(name);
}

static void set_status_text (GtkTreeViewColumn *tree_column,
						       GtkCellRenderer   *cell,
						       GtkTreeModel      *model,
						       GtkTreeIter       *iter,
						       gpointer           data)
{	
	
}	

static void set_status_icon (GtkTreeViewColumn *tree_column,
						       GtkCellRenderer   *cell,
						       GtkTreeModel      *model,
						       GtkTreeIter       *iter,
						       gpointer           data)
{	
	showInfo("on %s\n", __FUNCTION__);
}

static void set_encry_text (GtkTreeViewColumn *tree_column,
						       GtkCellRenderer   *cell,
						       GtkTreeModel      *model,
						       GtkTreeIter       *iter,
						       gpointer           data)
{		
	#if 1
	int swh;
		
	gtk_tree_model_get(model, iter,	
	                   SCAN_STORE_COLUMN_ENCRY, &swh,
	                   -1);
	if(swh > 0)
	{	
		g_object_set(GTK_CELL_RENDERER(cell),
	   	    		 "text", "on",
		 			 NULL);		
	}	
	else
	{	
		g_object_set(GTK_CELL_RENDERER(cell),
					 "text", "off",
					 NULL);	
	}	
	#endif
}	

static void set_address_text (GtkTreeViewColumn *tree_column,
						       GtkCellRenderer   *cell,
						       GtkTreeModel      *model,
						       GtkTreeIter       *iter,
						       gpointer           data)
{	
	#if 1
	gchar *addr;
	
	gtk_tree_model_get(model, iter,
	                   SCAN_STORE_COLUMN_ADDRESS, &addr,
	                   -1);
			
	g_object_set(GTK_CELL_RENDERER(cell),
				 "text", addr,
				 NULL);
	
	if(addr)
		g_free(addr);
	#endif
}	

static void add_scan_columns (GtkTreeView *treeview)
{	
	GtkTreeViewColumn *column_name;
	GtkTreeViewColumn *column_status;
	GtkTreeViewColumn *column_status_icon;
	GtkTreeViewColumn *column_encry;
	GtkTreeViewColumn *column_addr;
	GtkCellRenderer *renderer;
	
	column_name = gtk_tree_view_column_new();
	column_status = gtk_tree_view_column_new();
	column_status_icon = gtk_tree_view_column_new();
	column_encry = gtk_tree_view_column_new();
	column_addr = gtk_tree_view_column_new();
	
	gtk_tree_view_column_set_title(column_name, "Essid");				
	gtk_tree_view_column_set_title(column_status, "Status");				
	gtk_tree_view_column_set_title(column_status_icon,
								   _("status"));
	gtk_tree_view_column_set_title(column_encry, "Encry");
	gtk_tree_view_column_set_title(column_addr, "Addr");
	
	/* Name */
	renderer = gtk_cell_renderer_text_new ();
	g_object_set (renderer, "width", 100, NULL);
	
	gtk_tree_view_column_pack_start(column_name,
								    renderer,
									TRUE);				
	gtk_tree_view_column_set_cell_data_func(column_name, renderer,			
		                              	    set_essid_text, NULL, NULL);	
	
	/* Status */
	renderer = gtk_cell_renderer_text_new ();
	g_object_set (renderer, "width", 100, NULL);
	
	gtk_tree_view_column_pack_start(column_status,
								    renderer,
									TRUE);
	gtk_tree_view_column_set_cell_data_func(column_status, renderer,	
		                              	    set_status_text, NULL, NULL);	
	
	/* Status Icon*/
	//Pixbuf 
	renderer = gtk_cell_renderer_pixbuf_new();				
    gtk_tree_view_column_pack_start(column_status_icon,					
			       					renderer,			
			       					FALSE);							
    gtk_tree_view_column_set_attributes (column_status_icon,						
										 renderer,
										 "stock_id", SCAN_STORE_COLUMN_STATUS_ICON, 
										 NULL);	
	//gtk_tree_view_column_set_cell_data_func(column_status_icon, renderer,	
	//	                              	    			  set_status_icon, NULL, NULL);	
	
	/* Encry */
	renderer = gtk_cell_renderer_text_new ();	
	g_object_set (renderer, "width", 100, NULL);
	gtk_tree_view_column_pack_start(column_encry,
								    renderer,
									TRUE);	
	gtk_tree_view_column_set_cell_data_func(column_encry, renderer,	
		                              	    set_encry_text, NULL, NULL);

	/* Cell Address */
	renderer = gtk_cell_renderer_text_new ();	
	g_object_set (renderer, "width", 100, NULL);
	gtk_tree_view_column_pack_start(column_addr,
								    renderer,
									TRUE);
	gtk_tree_view_column_set_cell_data_func(column_addr, renderer,	
		                              	    set_address_text, NULL, NULL);
	
	/* bingding column to tree view */
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
					            column_name);	
	//gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
	//				            column_status);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
					            column_status_icon);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
					            column_encry);
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
					            column_addr);
}			

static void add_device_columns (GtkTreeView *treeview)
{		
	GtkTreeViewColumn *column_name;
	GtkCellRenderer *renderer;
	
	column_name = gtk_tree_view_column_new();
	gtk_tree_view_column_set_title(column_name, "Essid");
	
	//Name
	renderer = gtk_cell_renderer_text_new ();
	g_object_set (renderer, "width", 100, NULL);
	
	gtk_tree_view_column_pack_start(column_name,
								    renderer,
									TRUE);									
	gtk_tree_view_column_set_cell_data_func(column_name, renderer,			
		                              	    set_device_text, NULL, NULL);	
																			
	/* bingding column to tree view */				
	gtk_tree_view_append_column(GTK_TREE_VIEW(treeview),
					            column_name);
}			

static int fill_device_store(int		skfd,	
			   	    		  char*		ifname,	
			        		  char*		args[],	
			        		  int		count)
{	
	struct wireless_info info;		
	int					 rc;
	int i = -1;					
	GtkTreeIter iter;
	
	/* Avoid "Unused parameter" warning */
	args = args;
	count = count;		
	
	rc = get_info(skfd, ifname, &info);		
	switch(rc)		
	{	
		case 0:	/* Success */
			gtk_tree_store_append (store_device, &iter, NULL);
			gtk_tree_store_set (store_device, &iter,
								0, i,			
								1, ifname,		
								-1);
			break;
		
		case -ENOTSUP:
			fprintf(stderr, "%-8.16s  no wireless extensions.\n\n",
					ifname);		
			break;						
									
		default:
		  	fprintf(stderr, "%-8.16s  %s!!!\n\n", ifname, strerror(-rc));
	}		
		
	return 0;		
}
	
gboolean test_thread(gpointer data)
{			
	int static i = 0;	
	GtkTreeIter iter;
	
	gtk_tree_model_get_iter_first(GTK_TREE_MODEL(store_scan), &iter);
		
	if(i % 2)
	{	
		gtk_tree_store_set(store_scan, &iter,	
	                   	   3, "gtk-connect",		
	                       -1);		
	}	
	else
	{	
		gtk_tree_store_set(store_scan, &iter,	
	                   	   3, "gtk-stop",		
	                       -1);
	}	
	i++;
		
	return TRUE;
}	

void refresh_scan_result()
{		
	gchar *dev = NULL;
	if(peek_window() == WINDOW_PAGE_MAIN)
	{	
		gdk_threads_enter();
		if(GTK_IS_TREE_STORE(store_scan))
		{	
		    gtk_tree_store_clear(store_scan);
			if(!gtk_tree_store_iter_is_valid(store_device, &current_device_combo_iter))
			{				
				showError("****** current_device_combo_iter Invalid\n");	
				return;
			}	
			gtk_tree_model_get(GTK_TREE_MODEL(store_device), &current_device_combo_iter,
		                   	   1, &dev,
		                   	   -1);
			
			print_scanning_info(store_scan, skfd, dev, NULL, 0);
		}		
		else	
			showInfo("asser GTK_IS_TREE_STORE(store_scan) Fail\n");
		
		if(dev)
			g_free(dev);
		gdk_threads_leave();
	}
}	

gboolean scan_timer(gpointer data)
{		
	showInfo("-------------- on %s -----------------\n", __FUNCTION__);
	refresh_scan_result();
	
	return TRUE;
}	

void refresh_scan()
{	
	showInfo("on %s\n", __FUNCTION__);
	refresh_scan_result();
}

void show_device_info()
{	
	showInfo("on %s\n", __FUNCTION__);
}

void connect_cell()
{	
	showInfo("on %s\n", __FUNCTION__);
	GtkTreeModel *model;
	GtkTreeSelection *selection;
	GList *g_list = NULL;
	GtkTreeIter iter;
	GtkTreePath *tree_path;
	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_scan));
	g_list = gtk_tree_selection_get_selected_rows(selection, &model);
	if(g_list)
	{	
		if(1 != g_list_length(g_list))
		{	
			showWarning("********** Invalid Selection **********\n");
			return ;
		}	
		//Get Treepath and Iter
		tree_path = g_list_nth_data(g_list, 0);
		if(!gtk_tree_model_get_iter(model, &iter, tree_path))
		{		
			showWarning("**************** Get Iter Fail ****************\n");
			return;
		}	
	}			
	else	
	{	
		showError("****** Seletion NULL ********\n");
		show_message_window(MSG_NO_SELECTION);
		return;
	}		
	
	gtk_container_forall(GTK_CONTAINER(fixed), destroy_widget, NULL);
	fill_ap_ui(fixed,
			   model,
			   &iter,
			   get_screen_width() * 2 / 3, 
			   get_screen_height() * 2 / 3, 
			   0,
			   0);
}

void disconnect_from_ap()
{	
	showInfo("on %s\n", __FUNCTION__);
	struct iwreq		wrq;
	char				essid[IW_ESSID_MAX_SIZE + 1];
	int					we_kernel_version;
	gchar *dev = NULL;
	wrq.u.essid.flags = 0;
	essid[0] = 0;
	
	/* Get version from kernel, device may not have range... */
	we_kernel_version = iw_get_kernel_we_version();
	
	/* Finally set the ESSID value */
	wrq.u.essid.pointer = (caddr_t) essid;
	wrq.u.essid.length = strlen(essid);
	if(we_kernel_version < 21)
		wrq.u.essid.length++;
	
	//Get Dev
	if(!gtk_tree_store_iter_is_valid(store_device, &current_device_combo_iter))
	{		
		showError("****** current_device_combo_iter Invalid\n");	
		return;
	}
	gtk_tree_model_get(GTK_TREE_MODEL(store_device), &current_device_combo_iter,
                   	   1, &dev,
                   	   -1);
		
	iw_set_ext(skfd, dev, SIOCSIWESSID, &wrq);
	refresh_scan_result();
	if(dev)
		g_free(dev);
	show_message_window("Already Disconnect\n");
}	
	
void device_setting()
{
	showInfo("on %s\n", __FUNCTION__);
	gtk_container_forall(GTK_CONTAINER(fixed), destroy_widget, NULL);
	fill_config_ui(fixed,		
			   	   get_screen_width() * 2 / 3, 
			       get_screen_height() * 2 / 3,	 
			       0,
			       0);
}	

void quit()
{	
	showInfo("on %s\n", __FUNCTION__);
	hide_self();
}		

static gboolean button_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{		
	showInfo("on %s\n", __FUNCTION__);
	if(widget == eventbox_scan)
	{
		refresh_scan();
		return TRUE;
	}
	else if(widget == eventbox_device)		
	{
		show_device_info();
		return TRUE;
	}
	else if(widget == eventbox_connect)		
	{
		connect_cell();
		return TRUE;
	}
	else if(widget == eventbox_disconnect)		
	{
		disconnect_from_ap();
		return TRUE;
	}
	else if(widget == eventbox_setting)		
	{	
		device_setting();
		return TRUE;
	}	
	else if(widget == eventbox_quit)		
	{	
		quit();
		return TRUE;
	}
	
	return FALSE;
}	
	
static gboolean key_press_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{		
	switch(event->keyval) 
	{		
		case GDK_KP_Enter:
			showInfo("GDK_KP_Enter\n");	
			return button_press_event(widget, event, user_data);
					
		case GDK_Return:		
			g_print("GDK_Return\n");		
			return button_press_event(widget, event, user_data);
		
		case GDK_Escape:						
			showInfo("GDK_Escape\n");
			if(widget == window
			   && peek_window() == WINDOW_PAGE_MAIN)
			{	
				hide_self();
				return TRUE;
			}
			else if(widget == window
					&& peek_window() == WINDOW_PAGE_AP)	
			{	
				ap_cancel();	
				return TRUE;	
			}
			else if(widget == window
					&& peek_window() == WINDOW_PAGE_CONFIG)
			{	
				config_cancel();
				return TRUE;
			}
			else
				showWarning("***** Illegal Window Level: %d *****\n", peek_window());
			break;
					
		default:
			showInfo("Default\n");				
	}
	
	return FALSE;
}	

/* Focus In/Focus Out */		
static gboolean focus_in_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{		
	if(!gtk_widget_is_focus(widget))		
		gtk_widget_grab_focus(widget);
	
	char img_path[256];
	GdkPixbuf *pixbuf = NULL;
	
	if(0 == strcmp(user_data, "scan"))
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_ACTIVE);
		pixbuf = create_gtk_pixbuf(img_path,
								     get_screen_width() * 4 / 27, 			
								   	 get_screen_width() * 8 / 135,
									 _("Refresh scan"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_scan, pixbuf);
	}					
	else if(0 == strcmp(user_data, "device"))
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_ACTIVE);
		pixbuf = create_gtk_pixbuf(img_path,
									 get_screen_width() * 4 / 27,
								   	 get_screen_width() * 8 / 135,
									 _("Device"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_device, pixbuf);
	}
	else if(0 == strcmp(user_data, "connect"))		
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_ACTIVE);
		pixbuf = create_gtk_pixbuf(img_path,	
									 get_screen_width() * 4 / 27,			
								   	 get_screen_width() * 8 / 135,
									 _("Connect"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_connect, pixbuf);
	}
	else if(0 == strcmp(user_data, "disconnect"))		
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_ACTIVE);
		pixbuf = create_gtk_pixbuf(img_path,
									 get_screen_width() * 4 / 27, 			
								   	 get_screen_width() * 8 / 135,		
									 _("Disconnect"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_disconnect, pixbuf);
	}
	else if(0 == strcmp(user_data, "setting"))
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_ACTIVE);
		pixbuf = create_gtk_pixbuf(img_path,
									 get_screen_width() * 4 / 27, 			
								   	 get_screen_width() * 8 / 135,		
									 _("Setting"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_setting, pixbuf);
	}		
	else if(0 == strcmp(user_data, "quit"))
	{					
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_ACTIVE);
		pixbuf = create_gtk_pixbuf(img_path,
									 get_screen_width() * 4 / 27,			
								   	 get_screen_width() * 8 / 135,	 	
									 _("Quit"), 14);
		gtk_image_set_from_pixbuf((GtkImage *)image_quit, pixbuf);
	}	
	else
	{			
		showInfo("%s: Can not Disguish User Data\n", __FUNCTION__);
	}	
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	return TRUE;
}	

/* Focus In/Focus Out */
static gboolean focus_out_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{	
	char img_path[256];
	GdkPixbuf *pixbuf = NULL;
	
	if(0 == strcmp(user_data, "scan"))
	{		
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
		pixbuf = create_gtk_pixbuf(img_path,
									 //get_screen_width() / 9, 			
								     //get_screen_width() * 2 / 45,
								     get_screen_width() * 4 / 27,			
								   	 get_screen_width() * 8 / 135,
									 _("Refresh scan"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_scan, pixbuf);
	}
	else if(0 == strcmp(user_data, "device"))
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
		pixbuf = create_gtk_pixbuf(img_path,
									 get_screen_width() * 4 / 27, 			
								   	 get_screen_width() * 8 / 135,		
									 _("Device"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_device, pixbuf);
	}			
	else if(0 == strcmp(user_data, "setting"))
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);					
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
		pixbuf = create_gtk_pixbuf(img_path,
									 get_screen_width() * 4 / 27, 			
								   	 get_screen_width() * 8 / 135,		
									 _("Setting"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_setting, pixbuf);
	}
	else if(0 == strcmp(user_data, "connect"))		
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
		pixbuf = create_gtk_pixbuf(img_path, 
									 get_screen_width() * 4 / 27, 			
								   	 get_screen_width() * 8 / 135,		
									 _("Connect"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_connect, pixbuf);
	}
	else if(0 == strcmp(user_data, "disconnect"))		
	{		
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
		pixbuf = create_gtk_pixbuf(img_path,		
									 get_screen_width() * 4 / 27,			
								   	 get_screen_width() * 8 / 135,	
									 _("Disconnect"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_disconnect, pixbuf);
	}
	else if(0 == strcmp(user_data, "quit"))		
	{	
		showInfo("%s: %s\n", __FUNCTION__, (char *)user_data);
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
		pixbuf = create_gtk_pixbuf(img_path,
									 get_screen_width() * 4 / 27,			
								   	 get_screen_width() * 8 / 135,	
									 _("Quit"), 14);
		gtk_image_set_from_pixbuf((GtkImage*)image_quit, pixbuf);
	}
	else
	{		
		showInfo("%s: Can not Disguish User Data\n", __FUNCTION__);
	}	
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	return TRUE;
}	

void scan_treeview_activated_event(GtkWidget *widget, GdkEventKey *event, gpointer user_data)
{			
	showInfo("on %s\n", __FUNCTION__);
	
	int index;
	GtkTreeSelection *selection;
	GtkTreeModel *model;
	GtkTreePath *tree_path;
	GList *g_list;
	GtkTreeIter iter;
	
	//Selection Validate	
	selection = gtk_tree_view_get_selection(GTK_TREE_VIEW(treeview_scan));
	g_list = gtk_tree_selection_get_selected_rows(selection, &model);
	if(g_list)	
	{		
		if(1 != g_list_length(g_list))
		{	
			showWarning("********** Invalid Selection **********\n");
			return ;
		}	
		//Get Treepath and Iter	
		tree_path = g_list_nth_data(g_list, 0);
		if(!gtk_tree_model_get_iter(model, &iter, tree_path))
		{						
			showWarning("**************** Get Iter Fail ****************\n");
			return;
		}	
		gtk_tree_model_get(model, &iter,
					   	   0, &index,
	                       -1);
	}		
	else			
	{		
		showError("****** Seletion NULL ********\n");
		show_message_window(MSG_NO_SELECTION);
	}
}

static void fill_eventbox()
{	
	char img_path[128];
	GdkPixbuf *pixbuf = NULL;
		
	showInfo("----------------- Begin\n\n");
	/* ------------------------------- Create EventBox ----------------------------------*/
	/* Refresh Scan */
	if(!GTK_IS_WIDGET(eventbox_scan))
	{	
		showInfo("----------------- !GTK_IS_WIDGET(eventbox_scan)\n");
		//Eventbox
		eventbox_scan = gtk_event_box_new();
		gtk_widget_set_can_focus(eventbox_scan, TRUE);
		gtk_container_add(GTK_CONTAINER(fixed), eventbox_scan);
			
		g_signal_connect(G_OBJECT(eventbox_scan), "key_press_event",
						 G_CALLBACK(key_press_event), "scan");
		g_signal_connect(G_OBJECT(eventbox_scan), "button_press_event",
						 G_CALLBACK(button_press_event), "scan");
		g_signal_connect(G_OBJECT(eventbox_scan), "enter_notify_event",
						 G_CALLBACK(focus_in_event), "scan");
		g_signal_connect(G_OBJECT(eventbox_scan), "leave_notify_event",
						 G_CALLBACK(focus_out_event), "scan");
		g_signal_connect(G_OBJECT(eventbox_scan), "focus_in_event",
						 G_CALLBACK(focus_in_event), "scan");	
		g_signal_connect(G_OBJECT(eventbox_scan), "focus_out_event",
						 G_CALLBACK(focus_out_event), "scan");	
		gtk_widget_show (eventbox_scan);

		//Image
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
		pixbuf =  create_gtk_pixbuf(img_path,
									   get_screen_width() * 4 / 27, 			
									   get_screen_width() * 8 / 135,			
									   _("Refresh scan"), 14);
		image_scan = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
		if(G_IS_OBJECT(pixbuf))
			g_object_unref(pixbuf);
		
		gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_scan)), 
										  NULL,	
										  &bitmap_scan,
										  128);
		gtk_widget_shape_combine_mask(eventbox_scan, bitmap_scan, 0, 0);	
		gtk_container_add(GTK_CONTAINER(eventbox_scan), GTK_WIDGET(image_scan));		
		gtk_widget_show (GTK_WIDGET(image_scan));
	}
	else		
		showInfo("------------  evenboxscan is Widget\n");
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_scan,
									 get_screen_width() * 4 / 150 + get_screen_width() * 12 / 24,
									 get_screen_height() * 4 / 75);
	
	/* Connect */
	if(!GTK_IS_WIDGET(eventbox_connect))
	{	
		showInfo("----------------- !GTK_IS_WIDGET(eventbox_connect)\n");
		eventbox_connect = gtk_event_box_new();
		gtk_widget_set_can_focus(eventbox_connect, TRUE);
		gtk_container_add(GTK_CONTAINER(fixed), eventbox_connect);
		
		g_signal_connect(G_OBJECT(eventbox_connect), "key_press_event",
						 G_CALLBACK(key_press_event), "connect");
		g_signal_connect(G_OBJECT(eventbox_connect), "button_press_event",
						 G_CALLBACK(button_press_event), "connect");
		g_signal_connect(G_OBJECT(eventbox_connect), "enter_notify_event",
						 G_CALLBACK(focus_in_event), "connect");
		g_signal_connect(G_OBJECT(eventbox_connect), "leave_notify_event",
						 G_CALLBACK(focus_out_event), "connect");
		g_signal_connect(G_OBJECT(eventbox_connect), "focus_in_event",
						 G_CALLBACK(focus_in_event), "connect");
		g_signal_connect(G_OBJECT(eventbox_connect), "focus_out_event",
						 G_CALLBACK(focus_out_event), "connect");
		gtk_widget_show (eventbox_connect);

		//Image
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);	
		pixbuf =  create_gtk_pixbuf(img_path, 					
									   	  get_screen_width() * 4 / 27, 			
									   	  get_screen_width() * 8 / 135,			
									      _("Connect"), 14);
		image_connect = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
		if(G_IS_OBJECT(pixbuf))
			g_object_unref(pixbuf);
		
		gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_connect)), 
										  NULL,	
										  &bitmap_connect,
										  128);
		gtk_widget_shape_combine_mask(eventbox_connect, bitmap_connect, 0, 0);
		gtk_container_add(GTK_CONTAINER(eventbox_connect), GTK_WIDGET(image_connect));		
		gtk_widget_show (GTK_WIDGET(image_connect));	
	}
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_connect,
									 get_screen_width() * 4 / 150 + get_screen_width() * 12 / 24,
									 get_screen_height() * 4 / 75 + get_screen_height() * 4 / 48);
		
	/* Disconnect */
	if(!GTK_IS_WIDGET(eventbox_disconnect))
	{	
		showInfo("----------------- !GTK_IS_WIDGET(eventbox_disconnect)\n");
		eventbox_disconnect = gtk_event_box_new();
		gtk_widget_set_can_focus(eventbox_disconnect, TRUE);
		gtk_container_add(GTK_CONTAINER(fixed), eventbox_disconnect);
																
		g_signal_connect(G_OBJECT(eventbox_disconnect), "key_press_event",
						 G_CALLBACK(key_press_event), "disconnect");
		g_signal_connect(G_OBJECT(eventbox_disconnect), "button_press_event",
						 G_CALLBACK(button_press_event), "disconnect");
		g_signal_connect(G_OBJECT(eventbox_disconnect), "enter_notify_event",
						 G_CALLBACK(focus_in_event), "disconnect");
		g_signal_connect(G_OBJECT(eventbox_disconnect), "leave_notify_event",
						 G_CALLBACK(focus_out_event), "disconnect");
		g_signal_connect(G_OBJECT(eventbox_disconnect), "focus_in_event",
						 G_CALLBACK(focus_in_event), "disconnect");
		g_signal_connect(G_OBJECT(eventbox_disconnect), "focus_out_event",
						 G_CALLBACK(focus_out_event), "disconnect");
		gtk_widget_show (eventbox_disconnect);

		//Image
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);					
		pixbuf =  create_gtk_pixbuf(img_path, 
									         get_screen_width() * 4 / 27, 			
									   		 get_screen_width() * 8 / 135,					
									   		 _("Disconnect"), 14);
		image_disconnect = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
		if(G_IS_OBJECT(pixbuf))
			g_object_unref(pixbuf);
		
		gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_disconnect)), 
										  NULL,	
										  &bitmap_disconnect,
										  128);
		gtk_widget_shape_combine_mask(eventbox_disconnect, bitmap_disconnect, 0, 0);	
		gtk_container_add(GTK_CONTAINER(eventbox_disconnect), GTK_WIDGET(image_disconnect));		
		gtk_widget_show (GTK_WIDGET(image_disconnect));		
	}
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_disconnect,
									 get_screen_width() * 4 / 150 + get_screen_width() * 12 / 24,
							 		 get_screen_height() * 4 / 75 + get_screen_height() * 4 / 24);
												
	/* Device */				
	if(!GTK_IS_WIDGET(eventbox_device))
	{
		showInfo("----------------- !GTK_IS_WIDGET(eventbox_device)\n");
		eventbox_device = gtk_event_box_new();
		gtk_widget_set_can_focus(eventbox_device, TRUE);
		gtk_container_add(GTK_CONTAINER(fixed), eventbox_device);
															
		g_signal_connect(G_OBJECT(eventbox_device), "key_press_event",
						 G_CALLBACK(key_press_event), "device");
		g_signal_connect(G_OBJECT(eventbox_device), "button_press_event",
						 G_CALLBACK(button_press_event), "device");
		g_signal_connect(G_OBJECT(eventbox_device), "enter_notify_event",
						 G_CALLBACK(focus_in_event), "device");
		g_signal_connect(G_OBJECT(eventbox_device), "leave_notify_event",
						 G_CALLBACK(focus_out_event), "device");
		g_signal_connect(G_OBJECT(eventbox_device), "focus_in_event",
						 G_CALLBACK(focus_in_event), "device");
		g_signal_connect(G_OBJECT(eventbox_device), "focus_out_event",
						 G_CALLBACK(focus_out_event), "device");
		gtk_widget_show (eventbox_device);
		
		//Image
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);			
		pixbuf =  create_gtk_pixbuf(img_path,
									      get_screen_width() * 4 / 27, 			
									  	  get_screen_width() * 8 / 135,			
									      _("Device"), 14);
		image_device = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
		if(G_IS_OBJECT(pixbuf))
			g_object_unref(pixbuf);
		
		gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_device)), 
										  NULL,				
										  &bitmap_device,	
										  128);					
		gtk_widget_shape_combine_mask(eventbox_device, bitmap_device, 0, 0);
		gtk_container_add(GTK_CONTAINER(eventbox_device), GTK_WIDGET(image_device));
		gtk_widget_show (GTK_WIDGET(image_device));
	}
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_device, 
									 get_screen_width() * 4 / 150 + get_screen_width() * 12 / 24,
									 get_screen_height() * 4 / 75 + get_screen_height() * 12 / 48);
			
	/* Setting */
	if(!GTK_IS_WIDGET(eventbox_setting))
	{
		showInfo("----------------- !GTK_IS_WIDGET(eventbox_setting)\n");
		eventbox_setting = gtk_event_box_new();
		gtk_widget_set_can_focus(eventbox_setting, TRUE);
		gtk_container_add(GTK_CONTAINER(fixed), eventbox_setting);
		
		g_signal_connect(G_OBJECT(eventbox_setting), "key_press_event",
						 G_CALLBACK(key_press_event), "setting");
		g_signal_connect(G_OBJECT(eventbox_setting), "button_press_event",
						 G_CALLBACK(button_press_event), "setting");
		g_signal_connect(G_OBJECT(eventbox_setting), "enter_notify_event",
						 G_CALLBACK(focus_in_event), "setting");
		g_signal_connect(G_OBJECT(eventbox_setting), "leave_notify_event",
						 G_CALLBACK(focus_out_event), "setting");
		g_signal_connect(G_OBJECT(eventbox_setting), "focus_in_event",
						 G_CALLBACK(focus_in_event), "setting");
		g_signal_connect(G_OBJECT(eventbox_setting), "focus_out_event",
						 G_CALLBACK(focus_out_event), "setting");
		gtk_widget_show (eventbox_setting);

		//Image
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);			
		pixbuf =  create_gtk_pixbuf(img_path,
									      get_screen_width() * 4 / 27, 			
									   	  get_screen_width() * 8 / 135,				
									      _("Setting"), 14);
		image_setting = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
		if(G_IS_OBJECT(pixbuf))
			g_object_unref(pixbuf);
		
		gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_setting)), 
										  NULL,				
										  &bitmap_setting,	
										  128);					
		gtk_widget_shape_combine_mask(eventbox_setting, bitmap_setting, 0, 0);
		gtk_container_add(GTK_CONTAINER(eventbox_setting), GTK_WIDGET(image_setting));
		gtk_widget_show (GTK_WIDGET(image_setting));	
	}
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_setting,
									 get_screen_width() * 4 / 150 + get_screen_width() * 12 / 24,
									 get_screen_height() * 4 / 75 + get_screen_height() * 4 / 12);
					
	/* Quit */
	if(!GTK_IS_WIDGET(eventbox_quit))
	{	
		showInfo("----------------- !GTK_IS_WIDGET(eventbox_quit)\n");
		eventbox_quit = gtk_event_box_new();
		gtk_widget_set_can_focus(eventbox_quit, TRUE);
		gtk_container_add(GTK_CONTAINER(fixed), eventbox_quit);
					
		g_signal_connect(G_OBJECT(eventbox_quit), "key_press_event",
						 G_CALLBACK(key_press_event), "quit");	
		g_signal_connect(G_OBJECT(eventbox_quit), "button_press_event",	
					 	 G_CALLBACK(button_press_event), "quit");	
		g_signal_connect(G_OBJECT(eventbox_quit), "enter_notify_event",
						 G_CALLBACK(focus_in_event), "quit");	
		g_signal_connect(G_OBJECT(eventbox_quit), "leave_notify_event",
						 G_CALLBACK(focus_out_event), "quit");	
		g_signal_connect(G_OBJECT(eventbox_quit), "focus_in_event",
						 G_CALLBACK(focus_in_event), "quit");
		g_signal_connect(G_OBJECT(eventbox_quit), "focus_out_event",
						 G_CALLBACK(focus_out_event), "quit");
		gtk_widget_show (eventbox_quit);
		
		//Image
		sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
		pixbuf =  create_gtk_pixbuf(img_path,
									   get_screen_width() * 4 / 27, 			
									   get_screen_width() * 8 / 135,			
									   _("Quit"), 14);
		image_quit = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
		if(G_IS_OBJECT(pixbuf))
			g_object_unref(pixbuf);
		
		gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_quit)),
										  NULL,			
										  &bitmap_quit,			
										  128);
		gtk_widget_shape_combine_mask(eventbox_quit, bitmap_quit, 0, 0);
		gtk_container_add(GTK_CONTAINER(eventbox_quit), GTK_WIDGET(image_quit));
		gtk_widget_show (GTK_WIDGET(image_quit));
	}
	else		
		showInfo("------------  evenbox_quit is Widget\n");
	gtk_fixed_move(GTK_FIXED(fixed), eventbox_quit,
									 get_screen_width() * 4 / 150 + get_screen_width() * 12 / 24,
									 get_screen_height() * 4 / 75 + get_screen_height() * 20 / 48);

	showInfo("----------------- End\n\n");
	#if 0/* ------------------------------- Create Image ----------------------------------*/
	//Refresh Scan					
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
	pixbuf =  create_gtk_pixbuf(img_path,
								   get_screen_width() * 4 / 27, 			
								   get_screen_width() * 8 / 135,			
								   _("Refresh scan"), 14);
	image_scan = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_scan)), 
									  NULL,	
									  &bitmap_scan,
									  128);
	gtk_widget_shape_combine_mask(eventbox_scan, bitmap_scan, 0, 0);	
	gtk_container_add(GTK_CONTAINER(eventbox_scan), GTK_WIDGET(image_scan));		
	gtk_widget_show (GTK_WIDGET(image_scan));

	//Connect					
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);	
	pixbuf =  create_gtk_pixbuf(img_path, 					
								   	  get_screen_width() * 4 / 27, 			
								   	  get_screen_width() * 8 / 135,			
								      _("Connect"), 14);
	image_connect = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_connect)), 
									  NULL,	
									  &bitmap_connect,
									  128);
	gtk_widget_shape_combine_mask(eventbox_connect, bitmap_connect, 0, 0);
	gtk_container_add(GTK_CONTAINER(eventbox_connect), GTK_WIDGET(image_connect));		
	gtk_widget_show (GTK_WIDGET(image_connect));	
	
	//Disconnect					
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);					
	pixbuf =  create_gtk_pixbuf(img_path, 
								         get_screen_width() * 4 / 27, 			
								   		 get_screen_width() * 8 / 135,					
								   		 _("Disconnect"), 14);
	image_disconnect = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_disconnect)), 
									  NULL,	
									  &bitmap_disconnect,
									  128);
	gtk_widget_shape_combine_mask(eventbox_disconnect, bitmap_disconnect, 0, 0);	
	gtk_container_add(GTK_CONTAINER(eventbox_disconnect), GTK_WIDGET(image_disconnect));		
	gtk_widget_show (GTK_WIDGET(image_disconnect));						
	
	//Device		
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);			
	pixbuf =  create_gtk_pixbuf(img_path,
								      get_screen_width() * 4 / 27, 			
								  	  get_screen_width() * 8 / 135,			
								      _("Device"), 14);
	image_device = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_device)), 
									  NULL,				
									  &bitmap_device,	
									  128);					
	gtk_widget_shape_combine_mask(eventbox_device, bitmap_device, 0, 0);
	gtk_container_add(GTK_CONTAINER(eventbox_device), GTK_WIDGET(image_device));
	gtk_widget_show (GTK_WIDGET(image_device));
	
	//Setting	
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);			
	pixbuf =  create_gtk_pixbuf(img_path,
								      get_screen_width() * 4 / 27, 			
								   	  get_screen_width() * 8 / 135,				
								      _("Setting"), 14);
	image_setting = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_setting)), 
									  NULL,				
									  &bitmap_setting,	
									  128);					
	gtk_widget_shape_combine_mask(eventbox_setting, bitmap_setting, 0, 0);
	gtk_container_add(GTK_CONTAINER(eventbox_setting), GTK_WIDGET(image_setting));
	gtk_widget_show (GTK_WIDGET(image_setting));	
	
	//Quit				
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_BUTTON_NORMAL);
	pixbuf =  create_gtk_pixbuf(img_path,
								   get_screen_width() * 4 / 27, 			
								   get_screen_width() * 8 / 135,			
								   _("Quit"), 14);
	image_quit = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
	if(G_IS_OBJECT(pixbuf))
		g_object_unref(pixbuf);
	
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(image_quit)),
									  NULL,			
									  &bitmap_quit,			
									  128);
	gtk_widget_shape_combine_mask(eventbox_quit, bitmap_quit, 0, 0);
	gtk_container_add(GTK_CONTAINER(eventbox_quit), GTK_WIDGET(image_quit));
	gtk_widget_show (GTK_WIDGET(image_quit));
	#endif
}
	
void combo_device_change(GtkComboBox *widget,
                                gpointer user_data)
{		
	showInfo("-------------------------------------- on %s\n", __FUNCTION__);
	gchar *dev = NULL;
	
	if(gtk_combo_box_get_active_iter(GTK_COMBO_BOX(combo_device), &current_device_combo_iter))
	{		
		gtk_tree_model_get(GTK_TREE_MODEL(store_device), &current_device_combo_iter,
                   		   1, &dev,
                   		   -1);
		
		showInfo("------------ Activate Device in Combo: %s -----------\n", dev);
	}	
	else
	{	
		showWarning("**** Get Device Combo Active Iter Fail\n");
	}
}                                                        

void fill_main_ui()
{		
	gchar *dev = NULL;
	
	gtk_container_forall(GTK_CONTAINER(fixed), destroy_widget, NULL);
	//gtk_container_forall(GTK_CONTAINER(fixed), destroy_ap_page_widget, NULL);
	
	if(peek_window() == -1 || peek_window() != WINDOW_PAGE_MAIN)		
		push_window(WINDOW_PAGE_MAIN);
	
	/********************* Device Combo ***********************/
	//label
	if(!GTK_IS_WIDGET(label_device))
	{	
		label_device = gtk_label_new(_("Device"));
		gtk_container_add(GTK_CONTAINER(fixed), label_device);
		gtk_widget_show(label_device);
	}
	gtk_fixed_move(GTK_FIXED(fixed), label_device,	 
									     get_screen_width() * 4 / 150,
									     get_screen_height() * 4 / 93);	
		
	//Create Model
	if(!GTK_IS_TREE_STORE(store_device))
	{		
		store_device = gtk_tree_store_new (2, G_TYPE_INT, G_TYPE_STRING);
	}
	gtk_tree_store_clear (store_device);
	iw_enum_devices(skfd, &fill_device_store, NULL, 0);
	
	//Combo
	if(!GTK_IS_WIDGET(combo_device))
	{	
		combo_device = gtk_combo_box_new_with_model (GTK_TREE_MODEL(store_device));
		gtk_widget_set_size_request(GTK_WIDGET(combo_device),	
									get_screen_width() * 4 / 9,
									30);	
		gtk_container_add(GTK_CONTAINER(fixed), combo_device);
			
		GtkCellRenderer *renderer = gtk_cell_renderer_text_new ();
	    gtk_cell_layout_pack_start (GTK_CELL_LAYOUT (combo_device), renderer, TRUE);
	    gtk_cell_layout_set_attributes (GTK_CELL_LAYOUT (combo_device), renderer,
					    				"text", DEVICE_STORE_COLUMN_INTERFACE,
					    				NULL);	
		g_signal_connect(GTK_OBJECT(combo_device), "changed",	
						 G_CALLBACK(combo_device_change), NULL);
		gtk_widget_show(combo_device);
	}	
	gtk_fixed_move(GTK_FIXED(fixed), combo_device,	
									 get_screen_width() * 6 / 75,
									 get_screen_height() * 4 / 120);
	gtk_combo_box_set_active(GTK_COMBO_BOX (combo_device), 0);
	
	/************************* Scan Result Treeview **************************/						
	//Label
	if(!GTK_IS_WIDGET(label_scan))
	{	
		label_scan = gtk_label_new(_("Scan"));			
		gtk_container_add(GTK_CONTAINER(fixed), label_scan);
		gtk_widget_show(label_scan);
	}	
	gtk_fixed_move(GTK_FIXED(fixed), label_scan,
							  get_screen_width() *4 / 150,			
							  get_screen_height() * 12 / 120);		
	
	//create model
	if(!GTK_IS_TREE_STORE(store_scan))
	{	
		store_scan = gtk_tree_store_new (5, G_TYPE_INT, G_TYPE_STRING,	
										    G_TYPE_STRING, G_TYPE_INT, G_TYPE_STRING);									
	}		
	gtk_tree_store_clear (store_scan);
	
	//Get Dev
	if(gtk_tree_store_iter_is_valid(store_device, &current_device_combo_iter))
	{	
		gtk_tree_model_get(GTK_TREE_MODEL(store_device), &current_device_combo_iter,
									                   	   1, &dev,
									                   	   -1);	
		print_scanning_info(store_scan, skfd, dev, NULL, 0);
		if(dev)
			g_free(dev);	
	}
	
	//create tree view
	if(!GTK_IS_WIDGET(treeview_scan))
	{	
		treeview_scan = gtk_tree_view_new_with_model(GTK_TREE_MODEL(store_scan));
		gtk_widget_set_size_request(GTK_WIDGET(treeview_scan),
									get_screen_width() * 12 / 24,
									get_screen_height() * 32 / 66);
		gtk_tree_view_set_rules_hint (GTK_TREE_VIEW (treeview_scan), TRUE);
		gtk_tree_selection_set_mode (gtk_tree_view_get_selection (GTK_TREE_VIEW(treeview_scan)),
									 GTK_SELECTION_SINGLE); //GTK_SELECTION_MULTIPLE
		add_scan_columns(GTK_TREE_VIEW (treeview_scan));	
		gtk_container_add(GTK_CONTAINER(fixed), treeview_scan);
		
		//Event
		g_signal_connect(G_OBJECT(treeview_scan), "row-activated",	
						 G_CALLBACK(scan_treeview_activated_event), NULL);
		gtk_widget_show(treeview_scan);		
	}	
	gtk_fixed_move(GTK_FIXED(fixed), treeview_scan,	
									  get_screen_width() * 4 / 150,	
									  get_screen_height() * 4 / 120 + get_screen_height() * 5 / 39);
			
	char buf[128];
	if(get_ap_addr(skfd, "wlan0", buf))	
		showError("Get AP Address Fail\n");
	fill_eventbox();		
}		

static int show_main_window()
{				
	char img_path[128];
	GdkPixbuf *pixbuf = NULL;
	
	/* ---------------------------------- Create Main Window ------------------------------------*/
	window	= create_gtk_window(get_screen_width() * 2 / 3 , get_screen_height() * 2 / 3);	
	if(!window)	
	{	
		showError("**************** window is NULL ******************\n");
		return -1;
	}
	gtk_window_move(GTK_WINDOW(window), get_screen_width() / 6, get_screen_height() / 6);
	gtk_window_set_decorated(GTK_WINDOW(window), FALSE);
	gtk_widget_set_app_paintable(window, TRUE);
	g_signal_connect(G_OBJECT(window), "key_press_event",
					 G_CALLBACK(key_press_event), NULL);
		
	//Create Main Window Back Groud Image
	sprintf(img_path, "%s%s", IMAGE_FILE_PATH, IMG_WIRELESS_MANAGER_MAIN_BG);	
	pixbuf = create_gtk_pixbuf(img_path, get_screen_width() * 2 / 3,
										  get_screen_height() * 2 / 3, NULL, 14);
	bg_image = GTK_IMAGE(gtk_image_new_from_pixbuf(pixbuf));
	if(G_IS_OBJECT(pixbuf))		
		g_object_unref(pixbuf);
	
	gdk_pixbuf_render_pixmap_and_mask(gtk_image_get_pixbuf(GTK_IMAGE(bg_image)), &bg_pixmap, &bg_bitmap, 128);
	gtk_widget_shape_combine_mask(window, bg_bitmap, 0, 0);
	
	/* ------------------------------- Create Main Fixed ----------------------------------*/
	fixed = create_gtk_fixed(get_screen_width() * 2 / 3, get_screen_width() * 2 / 3);
	gtk_container_add(GTK_CONTAINER(window), fixed);
	gtk_widget_show(fixed);
	
	fill_main_ui();
	gtk_widget_realize(window);
	
	/*------------------ Set Irregular Window --------------------*/
	gdk_window_set_back_pixmap(window->window, bg_pixmap, FALSE);
	gtk_widget_show(window);
	
	gtk_timeout_add (SCAN_INTERVAL, scan_timer, NULL);
	return 0;
}

typedef struct iwlist_entry 
{		
	const char*			cmd;		// Command line shorthand
	iw_enum_handler		fn;			//Subroutine */
	int					max_count;		
	const char*			argsname;	// Args as human readable string
} iwlist_cmd;

static const struct iwlist_entry iwlist_cmds[] = 
{	
	{"scanning", print_scanning_info,	-1, "[essid NNN] [last]" },
	{"frequency", print_freq_info,	0, NULL },
	{"channel", print_freq_info,	0, NULL },
	{"bitrate", print_bitrate_info,	0, NULL },
	{"rate", print_bitrate_info,	0, NULL },
	{"encryption",	print_keys_info,	0, NULL },
	{"keys", print_keys_info,	0, NULL },
	{"power", print_pm_info,		0, NULL },
#ifndef WE_ESSENTIAL	
	{"txpower", print_txpower_info,	0, NULL },
	{"retry", print_retry_info,	0, NULL },
	{"ap",	print_ap_info,		0, NULL },
	{"accesspoints", print_ap_info,		0, NULL },
	{"peers", print_ap_info,		0, NULL },
	{"event", print_event_capa_info,	0, NULL },
	{"auth", print_auth_info,	0, NULL },
	{"wpakeys", print_wpakeys_info,	0, NULL },
	{"genie", print_gen_ie_info,	0, NULL },	
	{"modulation",	print_modul_info,	0, NULL},
#endif	/* WE_ESSENTIAL */
	{ NULL, NULL, 0, 0 },
};	

int main(int	argc,
    	  char **argv)	
{
	/* Single Instance Check */
	char lock_file[128] = {0};
	
	argv[0] += 2;
	snprintf(lock_file, sizeof(lock_file), "%s%s%s", LOCKFILE_PREFIX,
													  argv[0],
													  ".pid");
	if(0 != single_instance_check(lock_file))
		return -1;
	
	/* Set Locale */
	setlocale(LC_ALL, "");
	bindtextdomain (LOCALE_PACKAGE, LOCALEDIR);
	textdomain (LOCALE_PACKAGE);
	
	/* Gtk Thread Protection */	
	if(XInitThreads () == 0)
		printf(" XInitThreads Err\n");
	
	if(!g_thread_supported())
	{			
		g_thread_init(NULL);
		gdk_threads_init();
	}		
		
	gtk_init(&argc, &argv);
	GdkDisplay *gdk_display = gdk_display_get_default();
	GdkScreen *gdk_screen = gdk_display_get_default_screen(gdk_display);
	
	/* Create a channel to the NET kernel. */
	if((skfd = iw_sockets_open()) < 0)
	{	
		perror("socket");
		return -1;
	}	
	
	init_wireless_manager(gdk_screen);
	if(show_main_window())
	{
		showError("**************** Create Main Window Fail ******************\n");
		return -1;
	}
	
	/* Register to WM */
	if(GTK_IS_WIDGET(window))	
	{	
		if(init_client(window, PHONECONFIGER_ID, XK_F2))
		{		
			showError("**************** Register to WM Fail **************** \n");
			return -1;
		}		
		else
			showInfo("Register to WM Suc\n");
	}		
	else
	{	
		showError("************* Create Main Window Fail ************* \n");
		return -1;
	}	
		
	gtk_main();
	/* Close the socket. */
	iw_sockets_close(skfd);

	return 0;
}

