
ifconfig wlan0 up 192.168.0.89
