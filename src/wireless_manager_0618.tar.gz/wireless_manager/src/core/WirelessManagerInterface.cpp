#include <string.h>
#include <stdio.h>

#include "WirelessManager.h"

#ifdef __cplusplus
extern "C" 
{	
#endif

/**************************************************************************************************/
/**************************************** GtkManager ***************************************************/
/**************************************************************************************************/
int init_wireless_manager(GdkScreen *screen)
{		
	WirelessManager *manager = WirelessManager::get_instance();
  	return manager->init_wireless_manager(screen);
}		

GtkWidget* create_gtk_window(int width, int height)
{	
	WirelessManager *manager = WirelessManager::get_instance();
  	return manager->create_gtk_window(width, height);
}	
	
GtkWidget* create_gtk_fixed(int width, int height)
{
	WirelessManager *manager = WirelessManager::get_instance();
  	return manager->create_gtk_fixed(width, height);
}	

GdkPixbuf* create_gtk_pixbuf(char *img_path, int width, int height, char *markup, int size)
{	
	WirelessManager *manager = WirelessManager::get_instance();
  	return manager->create_gtk_pixbuf(img_path, width, height, markup, size);
}	

int get_screen_width()
{
	WirelessManager *manager = WirelessManager::get_instance();
  	return manager->get_screen_width();
}

int get_screen_height()
{
	WirelessManager *manager = WirelessManager::get_instance();
  	return manager->get_screen_height();
}

/* Page Stack */
int push_window(int window)	
{
	WirelessManager *manager = WirelessManager::get_instance();
  	return manager->push_window(window);
}	
	
int pop_window()
{	
	WirelessManager *manager = WirelessManager::get_instance();
	return manager->pop_window();
}	
	
int peek_window()
{	
	WirelessManager *manager = WirelessManager::get_instance();
	return manager->peek_window();
}

void show_stack()
{		
	WirelessManager *manager = WirelessManager::get_instance();
	return manager->show_stack();
}

#ifdef __cplusplus
}
#endif

