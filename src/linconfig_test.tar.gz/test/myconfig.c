#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#include "config.h"
#include "lpconfig.h"
#include "mcallconfig.h"

//GList *mcalls = NULL;

int main()
{
	int itemcounts, ret;
	struct _LpConfig *config = NULL;
	MediaFileInfo * item = NULL;
	char pathname[64];

	//////////////////////////////////////////////////////////////////
	printf("linconfig library test program, ver : %s, report : %s\r\n",
			PACKAGE_STRING,
			PACKAGE_BUGREPORT);
	//////////////////////////////////////////////////////////////////
	sprintf(pathname, "%s", "MCallConfig.cfg");

	config = lp_config_new(pathname);
	printf("start read : %s\r\n", pathname);

	mcall_config_read(config);
	delete_mcallink();
	mcall_config_read(config);
	itemcounts = get_mcallitem_counts();
	printf("get_mcallitem_counts : %d\r\n", itemcounts);
/*	
	item = get_mcallitem_by_index(7);
	if(item != NULL)
	{
		printf("FileID		: %d\r\n", item->nFileID);
		printf("PlayArea    : %d\r\n", item->mPlayArea);
		printf("MCallType   : %d\r\n", item->nMCallType);
		printf("JpegFile	: %s\r\n", item->szJpegFile);
		printf("VideoFile	: %s\r\n", item->szVideoFile);
		printf("AudioFile	: %s\r\n", item->szAudioFile);
		printf("\r\n");
	}
	else
	{
		printf("get mcall item by index error!\r\n");
	}

	ret = save_mcall_configs(config);
	if(ret != 0)
		printf("save mcall items error!\r\n");
*/
	delete_mcallink();
	if(config != NULL)
		lp_config_destroy(config);
	
	config = NULL;
	return 0;	
}








/*
[mcall_0]
index=0
playarea=AREA_C
playtype=PIC_ONLY
jpgfile=0.jpg
videofile=0.h264
audio=0.mp3

[mcall_1]
index=1
playarea=AREA_C
playtype=GIF_ONLY
jpgfile=1.gif
videofile=1.h264
audio=1.mp3

[mcall_2]
index=2
playarea=AREA_C
playtype=PIC_ONLY
jpgfile=2.jpg
videofile=2.h264
audio=2.mp3

[mcall_3]
index=3
playarea=AREA_C
playtype=GIF_ONLY
jpgfile=3.gif
videofile=3.h264
audio=3.mp3
*/

