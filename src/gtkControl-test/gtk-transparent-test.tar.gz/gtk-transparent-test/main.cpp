#include <gtk/gtk.h>
#include <X11/keysym.h>
#include <webkit/webkit.h>
#include <X11/Xlib.h>
#include <gdk/gdkx.h>


#ifdef VIDEO_PLAYER
#include "fnAdverVideo.h"
#endif

static GtkWidget* main_window;
static GtkWidget* uri_entry;
static GtkStatusbar* main_statusbar;
static WebKitWebView* web_view;
static gchar* main_title;
static gint load_progress;
static guint status_context_id; 
static GtkWidget* videoDraw;

static WebKitWebBackForwardList* bf_list_main;
GtkToolItem* button_back;
GtkToolItem* button_forward;
GtkToolItem* button_stop;
GtkToolItem* button_refresh;

static gboolean
show_web_view_cb (WebKitWebView* web_view_1)
{
    GtkWidget* window = gtk_widget_get_toplevel(GTK_WIDGET(web_view));
  
#if 1    
    printf("on [%s] new web_view_cb[%s]\r\n", __FUNCTION__, webkit_web_view_get_uri(web_view));
    gtk_widget_show(window);
    return TRUE;
#else		
    printf("on [%s] new web_view_cb[%s]\r\n", __FUNCTION__, webkit_web_view_get_uri(web_view));
    gtk_widget_destroy(window);
    return FALSE;
#endif

  return TRUE;
} 

static WebKitWebView*
create_web_view_cb (WebKitWebView* web_view, WebKitWebFrame* web_frame)
{
		printf("on [%s] \r\n", __FUNCTION__);
#if 0
    GtkWidget* new_window;
    GtkWidget* scrolled_window;
    GtkWidget* new_web_view = webkit_web_view_new(); 

    g_signal_connect (G_OBJECT (new_web_view), "web-view-ready", G_CALLBACK (show_web_view_cb), NULL); 

    new_window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    scrolled_window = gtk_scrolled_window_new(NULL, NULL);
    gtk_widget_show(scrolled_window);
    gtk_container_add(GTK_CONTAINER(new_window), scrolled_window);
    gtk_container_add(GTK_CONTAINER(scrolled_window), new_web_view); 
		
			if(web_view == NULL)
			printf("web_view == null\r\n");
		else
			printf("web_view != null [%s]\r\n", gtk_widget_get_name(web_view));
			
		if(web_frame == NULL)
			printf("web_frame == null\r\n");
		else
			printf("web_frame != null [%s]\r\n", gtk_widget_get_name(web_frame));
 printf("uri : %s\r\n", webkit_web_view_get_uri(new_web_view));	
    return WEBKIT_WEB_VIEW(new_web_view);
#else
	const gchar* uri = webkit_web_frame_get_uri(web_frame);
	
	printf("uri : [webview:%s] [webframe:%s]\r\n", webkit_web_view_get_uri(web_view), uri);
	return WEBKIT_WEB_VIEW(web_view);
#endif
//    return WEBKIT_WEB_VIEW(web_view);
} 

static void
activate_uri_entry_cb (GtkWidget* entry, gpointer data)
{
	printf("on [%s] \r\n", __FUNCTION__);
    const gchar* uri = gtk_entry_get_text (GTK_ENTRY (entry));
    g_assert (uri);
    webkit_web_view_open (web_view, uri);
} 

static void
update_title (GtkWindow* window)
{
    GString* string = g_string_new (main_title);
    g_string_append (string, " - WebKit Launcher");
    if (load_progress < 100)
        g_string_append_printf (string, " (%d%%)", load_progress);
    gchar* title = g_string_free (string, FALSE);
    gtk_window_set_title (window, title);
    gtk_widget_set_name (main_window, "fnBrowser");
    //gtk_statusbar_push (main_statusbar, status_context_id, title);
    g_free (title);
} 

static void
link_hover_cb (WebKitWebView* page, const gchar* title, const gchar* link, gpointer data)
{
		printf("on [%s] \r\n", __FUNCTION__);
    /* underflow is allowed */
    gtk_statusbar_pop (main_statusbar, status_context_id);
    if (link)
        gtk_statusbar_push (main_statusbar, status_context_id, link);
} 

static void
title_change_cb (WebKitWebView* web_view, WebKitWebFrame* web_frame, const gchar* title, gpointer data)
{
		printf("on [%s] \r\n", __FUNCTION__);
    if (main_title)
        g_free (main_title);
    main_title = g_strdup (title);
    update_title (GTK_WINDOW (main_window));
    gtk_widget_set_name (main_window, "fnBrowser");
} 

static void
progress_change_cb (WebKitWebView* page, gint progress, gpointer data)
{
		printf("on [%s] \r\n", __FUNCTION__);
    load_progress = progress;
    update_title (GTK_WINDOW (main_window));
    gtk_widget_set_name (main_window, "fnBrowser");
} 

static void
load_commit_cb (WebKitWebView* page, WebKitWebFrame* frame, gpointer data)
{
    const gchar* uri = webkit_web_frame_get_uri(frame);

    /* Disable Or Enable Back/Forward Button*/
    WebKitWebHistoryItem* history_item_back = webkit_web_back_forward_list_get_back_item(bf_list_main);
    WebKitWebHistoryItem* history_item_forward = webkit_web_back_forward_list_get_forward_item(bf_list_main); 
    if(!history_item_back)
    {
        printf("[%s] back item is NULL\n", __FUNCTION__);
		if(gtk_widget_is_sensitive(GTK_WIDGET(button_back)))
        	gtk_widget_set_sensitive (GTK_WIDGET(button_back), false);
    }
    else
    {
        printf("[%s] back item is not NULL\n", __FUNCTION__);
		if(!gtk_widget_is_sensitive(GTK_WIDGET(button_back)))
        	gtk_widget_set_sensitive (GTK_WIDGET(button_back), true);
    }
   
    if(!history_item_forward)
    {
        printf("[%s] forward item is NULL\n", __FUNCTION__);
		if(gtk_widget_is_sensitive(GTK_WIDGET(button_forward)))
        	gtk_widget_set_sensitive (GTK_WIDGET(button_forward), false);
    }
    else
    {
        printf("[%s] forward item is not NULL\n", __FUNCTION__);
		if(!gtk_widget_is_sensitive(GTK_WIDGET(button_forward)))
        	gtk_widget_set_sensitive (GTK_WIDGET(button_forward), true);
    }
	
	/* Enable Stop Button*/
    if(!gtk_widget_is_sensitive(GTK_WIDGET(button_stop)))
		gtk_widget_set_sensitive (GTK_WIDGET(button_stop), true);

    /* Disable Refresh Button*/
	if(gtk_widget_is_sensitive(GTK_WIDGET(button_refresh)))
		gtk_widget_set_sensitive (GTK_WIDGET(button_refresh), false);
	 	
	printf("on [%s] uri : [%s] -> [%s]\r\n", __FUNCTION__, 
		webkit_web_view_get_uri(web_view), uri);

#ifdef VIDEO_PLAYER       
    if (uri)
    {
       if(strstr(uri, "mms"))
       {
         webkit_web_view_go_back (web_view);
         gtk_widget_grab_focus (GTK_WIDGET (videoDraw));
         video_play((const char*)"infinity.avi");
       }
       gtk_entry_set_text (GTK_ENTRY (uri_entry), uri); 
   }
#endif

}

static void load_finished_cb(WebKitWebView* web_view)
{
    printf("on [%s]\n", __FUNCTION__);

	/*Disable Enable Stop Button*/
    if(gtk_widget_is_sensitive(GTK_WIDGET(button_stop)))
		gtk_widget_set_sensitive (GTK_WIDGET(button_stop), false);

	/* Enable Refresh Button*/
	if(!gtk_widget_is_sensitive(GTK_WIDGET(button_refresh)))
		gtk_widget_set_sensitive (GTK_WIDGET(button_refresh), true);
}

static void
destroy_cb (GtkWidget* widget, gpointer data)
{
    gtk_main_quit ();
} 

static void
go_home_cb (GtkWidget* widget, gpointer data)
{
    printf("on [%s] \r\n", __FUNCTION__);
    const char home_uri[] = "http://www.phonmedia.com/phonmedia";
    webkit_web_view_open (web_view, home_uri);
} 

static void
go_back_cb (GtkWidget* widget, gpointer data)
{
    printf("on [%s] \r\n", __FUNCTION__);
	WebKitWebHistoryItem* history_item = webkit_web_back_forward_list_get_back_item(bf_list_main);
    if(!history_item)    
    {
        printf("[%s] back item is NULL\n", __FUNCTION__);
        return;
    }
    else
        printf("[%s] back item not NULL\n", __FUNCTION__);        

    if(!webkit_web_view_can_go_back(web_view))
    {
        printf("[%s] can not go back\n", __FUNCTION__);
        return;
    }
	
    webkit_web_view_go_back (web_view);
} 

static void
go_forward_cb (GtkWidget* widget, gpointer data)
{
	printf("on [%s] \r\n", __FUNCTION__);

	WebKitWebHistoryItem* history_item = webkit_web_back_forward_list_get_forward_item(bf_list_main);
	if(!history_item)
    {
        printf("[%s] forward item is NULL\n", __FUNCTION__);
        return;
    }
    else
        printf("[%s] forward item not NULL\n", __FUNCTION__);

	if(!webkit_web_view_can_go_forward(web_view))    
    {
        printf("[%s] can not go forward\n", __FUNCTION__);
        return;
    }
	
    webkit_web_view_go_forward (web_view);
}

static void
go_stop_cb (GtkWidget* widget, gpointer data)
{
		printf("on [%s] \r\n", __FUNCTION__);
    webkit_web_view_stop_loading(web_view);
}

static void
go_reflash_cb (GtkWidget* widget, gpointer data)
{
		printf("on [%s] \r\n", __FUNCTION__);
    webkit_web_view_reload(web_view);
} 

static GtkWidget*
create_browser ()
{
    GtkWidget* scrolled_window = gtk_scrolled_window_new (NULL, NULL);
    gtk_scrolled_window_set_policy (GTK_SCROLLED_WINDOW (scrolled_window), GTK_POLICY_AUTOMATIC, GTK_POLICY_AUTOMATIC); 

    web_view = WEBKIT_WEB_VIEW (webkit_web_view_new ());
    gtk_container_add (GTK_CONTAINER (scrolled_window), GTK_WIDGET (web_view)); 

    g_signal_connect (G_OBJECT (web_view), "create-web-view", G_CALLBACK (create_web_view_cb), NULL);
    g_signal_connect (G_OBJECT (web_view), "title-changed", G_CALLBACK (title_change_cb), web_view);
    g_signal_connect (G_OBJECT (web_view), "load-progress-changed", G_CALLBACK (progress_change_cb), web_view);
    g_signal_connect (G_OBJECT (web_view), "load-committed", G_CALLBACK (load_commit_cb), web_view);
	g_signal_connect (G_OBJECT (web_view), "load-finished", G_CALLBACK (load_finished_cb), NULL);
    g_signal_connect (G_OBJECT (web_view), "hovering-over-link", G_CALLBACK (link_hover_cb), web_view); 
    g_signal_connect (G_OBJECT (web_view), "web-view-ready", G_CALLBACK (show_web_view_cb), web_view);
			
    return scrolled_window;
} 

static GtkWidget*
create_statusbar ()
{
    main_statusbar = GTK_STATUSBAR (gtk_statusbar_new ());
    status_context_id = gtk_statusbar_get_context_id (main_statusbar, "Link Hover"); 

    return (GtkWidget*)main_statusbar;
} 

static GtkWidget*
create_toolbar ()
{
    GtkWidget* toolbar = gtk_toolbar_new (); 

    gtk_toolbar_set_orientation (GTK_TOOLBAR (toolbar), GTK_ORIENTATION_HORIZONTAL);
    gtk_toolbar_set_style (GTK_TOOLBAR (toolbar), GTK_TOOLBAR_BOTH_HORIZ); 

    GtkToolItem* item;
	
    //GTK_STOCK_HOME 
    item = gtk_tool_button_new_from_stock (GTK_STOCK_HOME);
    g_signal_connect (G_OBJECT (item), "clicked", G_CALLBACK (go_home_cb), NULL);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), item, -1); 

    /* the back button */
    button_back = gtk_tool_button_new_from_stock (GTK_STOCK_GO_BACK);
    g_signal_connect (G_OBJECT (button_back), "clicked", G_CALLBACK (go_back_cb), NULL);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), button_back, -1); 

    /* The forward button */
    button_forward = gtk_tool_button_new_from_stock (GTK_STOCK_GO_FORWARD);
    g_signal_connect (G_OBJECT (button_forward), "clicked", G_CALLBACK (go_forward_cb), NULL);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), button_forward, -1);

    /* The stop button */
    button_stop = gtk_tool_button_new_from_stock (GTK_STOCK_STOP);
    g_signal_connect (G_OBJECT (button_stop), "clicked", G_CALLBACK (go_stop_cb), NULL);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), button_stop, -1);
	
    /* The redo button */
    button_refresh = gtk_tool_button_new_from_stock (GTK_STOCK_REFRESH);
    g_signal_connect (G_OBJECT (button_refresh), "clicked", G_CALLBACK (go_reflash_cb), NULL);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), button_refresh, -1); 
	
#if 0
    /* The URL entry */
    item = gtk_tool_item_new ();
    gtk_tool_item_set_expand (item, TRUE);
    uri_entry = gtk_entry_new ();
    gtk_container_add (GTK_CONTAINER (item), uri_entry);
    g_signal_connect (G_OBJECT (uri_entry), "activate", G_CALLBACK (activate_uri_entry_cb), NULL);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), item, -1); 

    /* The go button */
    item = gtk_tool_button_new_from_stock (GTK_STOCK_OK);
    g_signal_connect_swapped (G_OBJECT (item), "clicked", G_CALLBACK (activate_uri_entry_cb), (gpointer)uri_entry);
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), item, -1); 
#else
    item = gtk_tool_item_new ();
    gtk_tool_item_set_expand (item, TRUE);
    gtk_container_add (GTK_CONTAINER (item), create_statusbar());
    gtk_toolbar_insert (GTK_TOOLBAR (toolbar), item, -1); 
#endif
    return toolbar;
} 

static GtkWidget*
create_window ()
{
    GtkWidget* window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

#if 0
    GdkScreen*  scr = gtk_window_get_screen( GTK_WINDOW( window));
		
    gtk_window_set_default_size( GTK_WINDOW( window), 
    				gdk_screen_get_width( scr), 
				gdk_screen_get_height( scr));
#else
    gtk_window_set_default_size (GTK_WINDOW (window), 600, 450);
    gtk_window_move( GTK_WINDOW(window), 200, 0);
#endif

    gtk_widget_set_name (window, "fnBrowser");
    g_signal_connect (G_OBJECT (window), "destroy", G_CALLBACK (destroy_cb), NULL); 

    return window;
} 

static gboolean  keystroke_cb (GtkWidget* widget, GdkEventKey* event, gpointer user_data)
{
	printf("on key : %d\r\n", event->keyval);
	
	if(event->keyval == XK_Tab)
	{
	   printf("on tab key\r\n");
	   
	   GtkWidget *widget = gtk_window_get_focus(GTK_WINDOW(main_window));
	   printf("on focus widget : %s, %08X\r\n", gtk_widget_get_name(widget), widget);
           if(widget != NULL)
           {
		widget = gtk_container_get_focus_child(GTK_CONTAINER(widget));
		if(widget)
		 printf("on focus : %s\r\n", gtk_widget_get_name(widget));
           	
	   }
	   else
             printf("on focus null\r\n");
	}

        if(event->keyval == XK_Escape)
        {
        #ifdef VIDEO_PLAYER
           video_stop();
		   gtk_widget_grab_focus (GTK_WIDGET (web_view));
		#endif
           return TRUE;
        }
        printf("on key : %d\r\n", event->keyval);
        return FALSE;
}

static gboolean button_release_event_handle(GtkWidget *widget, GdkEventButton *event, gpointer data)
{
 printf("on key \r\n");
 return FALSE;
}

GtkWidget* window;
gint timeout( gpointer data )
{	
	#if 1 
	gdouble new_val;
	//gtk_progress_bar_pulse (GTK_PROGRESS_BAR (progress_bar));
	new_val = gtk_window_get_opacity (GTK_WINDOW(window));
	printf("--------------------- Get Opacity: %f ----------------------\n", new_val);
	
	new_val = new_val + 0.02;
	if (new_val > 1.0)
		new_val = 0.0;
		
	gtk_window_set_opacity(GTK_WINDOW(window), new_val);
	printf("--------------------- Get Opacity After Set Opacity: %f ----------------------\n", 
			gtk_window_get_opacity (GTK_WINDOW(window)));

	gtk_widget_show(GTK_WIDGET(window));
			
	//printf("--------------------- timeout ----------------------\n");
	#endif
	
	return TRUE;
}
	
cairo_surface_t *image = NULL; 
static gboolean on_window_expose_event(GtkWidget * widget,
											   GdkEventExpose * event, gpointer data)
{	
	cairo_t *cr; 
	
	cr = gdk_cairo_create(widget->window); 
	cairo_set_source_surface(cr, image, 0, 0);
	cairo_set_operator(cr, CAIRO_OPERATOR_SOURCE);          // ��Ҫ 
	cairo_paint(cr);   // ��ͼ 
	cairo_destroy(cr); 

	return FALSE; 
} 


static gboolean transparent_expose (GtkWidget *widget,
  										GdkEventExpose *event)
{	
	cairo_t *cr;
	
	cr = gdk_cairo_create (widget->window);
	cairo_set_operator (cr, CAIRO_OPERATOR_CLEAR);
	//cairo_set_operator (cr, CAIRO_OPERATOR_OVER);
	cairo_paint_with_alpha (cr, 0.5);
	printf("--------------------- transparent exporse ----------------\n");
	
	gdk_cairo_region (cr, event->region);
	cairo_fill (cr);
	cairo_destroy (cr);

	return FALSE;
}

static gboolean window_expose_event (GtkWidget *widget,
  						   					GdkEventExpose *event)
{
	GdkRegion *region;
	GtkWidget *child;
	cairo_t *cr;

	/* get our child (in this case, the event box) */  
	child = gtk_bin_get_child (GTK_BIN (widget));
	
	/* create a cairo context to draw to the window */
	cr = gdk_cairo_create (widget->window);
		
	/* the source data is the (composited) event box */
	gdk_cairo_set_source_pixmap (cr, child->window,
	child->allocation.x,
	child->allocation.y);
	
	/* draw no more than our expose event intersects our child */
	region = gdk_region_rectangle (&child->allocation);
	gdk_region_intersect (region, event->region);
	gdk_cairo_region (cr, region);
	cairo_clip (cr);
	
	/* composite, with a 50% opacity */
	cairo_set_operator (cr, CAIRO_OPERATOR_OVER);
	cairo_paint_with_alpha (cr, 0.5);
	printf("--------------------- window_expose_event ----------------\n");
	
	/* we're done */
	cairo_destroy (cr);
	
	return FALSE;
}

int main (int argc, char* argv[])
{	
	#if 0 /* -------------------------------------- Test --------------------------------------- */
	GtkWidget *window;
	GtkWidget *button;
	GdkGC *gc;
	GdkColormap *colormap;
	GdkBitmap *window_shape_bitmap;
	GdkColor black;
	GdkColor white;
	
	gtk_init(&argc, &argv);
	
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	gtk_window_set_title(GTK_WINDOW(window), "This is a test");
	//gtk_window_set_default_size(GTK_WINDOW(window), 400, 300);
	gtk_widget_set_size_request(GTK_WIDGET(window), 400, 300);
	
	//button = gtk_button_new_with_label("Hello,World Hello,World");
	//gtk_container_add(GTK_CONTAINER(window), button);
	//gtk_widget_show(button);
	
	
	/* Create GdkBitmap */
	//colormap = gdk_colormap_get_system();
	//window_shape_bitmap = (GdkBitmap *)gdk_pixmap_new (NULL, 400, 300, 1);
	//window_shape_bitmap = gdk_pixmap_create_from_xpm();
	//gdk_color_black (colormap, &black);
	//gdk_color_white (colormap, &white);
	
	/* Create GC */
	//gc = gdk_gc_new (window_shape_bitmap);
	
	#if 0 /* Draw Image */
	GtkImage *gtk_image = GTK_IMAGE(gtk_image_new_from_file("test.png"));
	if(!gtk_image)
	{
		printf("---------- Get GtkImage Fail ------------- \n");
		return -1;											
	}
	GdkPixbuf *gdk_pixbuf = gtk_image_get_pixbuf(gtk_image);
	if(!gdk_pixbuf)
	{		
		printf("---------- Get GdkPixbuf Fail ------------- \n");
		return -1;
	}	
		
	gdk_gc_set_foreground(gc, &black);
	//gdk_drawable_set_colormap(window_shape_bitmap, colormap);
	gdk_pixbuf_render_threshold_alpha(gdk_pixbuf,
									  window_shape_bitmap,				  
    								  0, 0,
									  0, 0,
									  40, 40,
									  0);
										
	/*gdk_draw_pixbuf(window_shape_bitmap, 
					gc,
					gdk_pixbuf, 
					0, 0,
					0, 0,
					40, 40,
					GDK_RGB_DITHER_NORMAL,
					0, 0);
	*/
	//gdk_draw_image
	#endif
	
	#if 0 /* Draw Retangle */
	gdk_gc_set_foreground(gc, &black);
	gdk_gc_set_background(gc, &white);
	gdk_draw_rectangle(window_shape_bitmap, 
					   gc, TRUE,
					   0, 0, 
					   400, 300);
	#endif
	
	#if 0 /* Draw Circle */
	gdk_gc_set_foreground (gc, &white);
	//gdk_gc_set_background (gc, &black);
	gdk_draw_arc(window_shape_bitmap, 
	             gc,
	             TRUE,
				 0, 0, 
				 400, 300, 
				 //0, 360*64);
				 0, 360 * 32);
	#endif
	
	//Set Mask
	//gtk_widget_shape_combine_mask (window, window_shape_bitmap, 0, 0);
	GdkPixbuf *pixbuf = NULL; 
	GdkBitmap *bitmap = NULL;
	GdkPixmap *pixmap = NULL;
	
	//gtk_window_set_decorated(GTK_WINDOW(window), FALSE);
	gtk_widget_set_app_paintable(window, TRUE); 
	gtk_widget_realize(window);
	
	pixbuf = gdk_pixbuf_new_from_file("test.png", NULL);
	gdk_pixbuf_render_pixmap_and_mask(pixbuf, &pixmap, &bitmap, 250);	// alphaС��128��Ϊ͸�� 
	gtk_widget_shape_combine_mask(window, bitmap, 0, 0);
	gdk_window_set_back_pixmap(window->window, pixmap, FALSE);
	
	//Show
	gtk_widget_show(window);
	
	gtk_main();
	#endif
	
	#if 1 /* */
	GtkWidget *window, *event, *button;
	GdkScreen *screen;
	GdkColormap *rgba;
	GdkColor red;
	
	gtk_init (&argc, &argv);
	
	/* Make the widgets */
	button = gtk_button_new_with_label ("A Button");
	event = gtk_event_box_new ();
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);

	/* Put a red background on the window */
	gdk_color_parse ("red", &red);
	gtk_widget_modify_bg (window, GTK_STATE_NORMAL, &red);

	/* Set the colourmap for the event box.
	* Must be done before the event box is realised.
	*/
	screen = gtk_widget_get_screen (event);
	rgba = gdk_screen_get_rgba_colormap (screen);
	gtk_widget_set_colormap (event, rgba);

	/* Set our event box to have a fully-transparent background
	* drawn on it. Currently there is no way to simply tell GTK+
	* that "transparency" is the background colour for a widget.
	*/
	gtk_widget_set_app_paintable (GTK_WIDGET (event), TRUE);
	g_signal_connect (event, "expose-event",
					  G_CALLBACK (transparent_expose), NULL);
	//gtk_timeout_add (200, transparent_expose, NULL);
	

	/* Put them inside one another */
	gtk_container_set_border_width (GTK_CONTAINER (window), 10);
	gtk_container_add (GTK_CONTAINER (window), event);
	gtk_container_add (GTK_CONTAINER (event), button);

	/* Realise and show everything */
	gtk_widget_show_all (window);
	
	/* Set the event box GdkWindow to be composited.
	* Obviously must be performed after event box is realised.
	*/
	gdk_window_set_composited (event->window, TRUE);
	printf("----------------- gtk_widget_is_composited After set Composited: %d\n", gtk_widget_is_composited(event));
	
	/* Set up the compositing handler.
	* Note that we do _after_ so that the normal (red) background is drawn
	* by gtk before our compositing occurs.
	*/
	
	g_signal_connect_after(window,
	   					   "expose-event",
						   G_CALLBACK (window_expose_event),
						   NULL);
			
	gtk_main();				
	#endif					
	
							
	#if 0 //Partical Transparent used cario
	GtkWidget *window; 
	GdkScreen *screen; 
	GdkColormap *colormap; 
	
	gtk_init(&argc, &argv); 
	image = cairo_image_surface_create_from_png("test.png");			 // cairo������ȡpng�ļ� 
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL); 
	
	gtk_window_set_decorated(GTK_WINDOW(window), FALSE); 	  // �����ޱ߿� 
	gtk_widget_set_app_paintable(window, TRUE); 
	gtk_window_resize(GTK_WINDOW(window), 250, 250); 
					
	g_signal_connect(G_OBJECT(window), "expose-event", 
		             G_CALLBACK(on_window_expose_event), NULL); 
	
	screen = gtk_widget_get_screen(window);		 // ��Ҫ 
	colormap = gdk_screen_get_rgba_colormap(screen); 
	gtk_widget_set_colormap(window, colormap); 
	
	gtk_widget_show_all(window); 
	gtk_main(); 
	#endif
	
	
	#if 0 //No Decorate
	GtkWidget *window = NULL; 
	GdkPixbuf *pixbuf = NULL; 
	GdkBitmap *bitmap = NULL; 
	GdkPixmap *pixmap = NULL; 
	
	gtk_init(&argc, &argv); 
	
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL); 
	gtk_window_set_decorated(GTK_WINDOW(window), FALSE);
	gtk_widget_set_app_paintable(window, TRUE); 
	gtk_widget_realize(window); 
	
	pixbuf = gdk_pixbuf_new_from_file("test.png", NULL);	  
	gdk_pixbuf_render_pixmap_and_mask(pixbuf, &pixmap, &bitmap, 128);	// alphaС��128��Ϊ͸�� 
	gtk_widget_shape_combine_mask(window, bitmap, 0, 0); 		 // ����͸���ɰ� 
	gdk_window_set_back_pixmap(window->window, pixmap, FALSE);		   // ���ô��ڱ��� 
	
	g_object_unref(pixbuf); 
	g_object_unref(bitmap); 
	g_object_unref(pixmap); 

	gtk_widget_show_all(window); 

	gtk_main();
	#endif

	
	#if 0 //My Test
	gtk_init (&argc, &argv); 
	
	Window xWindow;
	GdkWindow *gdk_window;
	GtkWidget* button;
	GtkWidget* fixed;
		
	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_widget_set_app_paintable (GTK_WIDGET (window), TRUE);
	gtk_widget_set_size_request(GTK_WIDGET(window), 600, 400);

	if(!window)
	{	
		printf("main window is NULL\n");
		return -1;
	}
	
	fixed = gtk_fixed_new();
		
	button = gtk_button_new();
	gtk_widget_set_size_request(GTK_WIDGET(button), 80, 30);

	gtk_container_add(GTK_CONTAINER (fixed), button);
	gtk_container_add(GTK_CONTAINER (window), fixed);

	//printf("----------------- gtk_widget_is_composited(window): %d\n", gtk_widget_is_composited(window));
	
	
	gtk_widget_show(GTK_WIDGET(button));		
	gtk_widget_show(GTK_WIDGET(fixed));
	gtk_widget_show(GTK_WIDGET(window));
	
	while (gtk_events_pending()) 
		gtk_main_iteration(); 
		
	g_return_val_if_fail (GDK_IS_WINDOW (window->window), 1); 
		
	gdk_window = window->window;
	if(!gdk_window)
	{			
		printf("gdk_window is NULL \n");
		return -1;
	}	
	
	gdk_window_set_composited(gdk_window, TRUE);
	printf("----------------- gtk_widget_is_composited After set Composited: %d\n", gtk_widget_is_composited(window));
	gtk_timeout_add (200, timeout, NULL);
		
	gtk_main (); 
	#endif
	
	#if 0 //Browser
    gtk_init (&argc, &argv); 
	
    GtkWidget* vbox = gtk_vbox_new (FALSE, 0);
	
    gtk_box_pack_start (GTK_BOX (vbox), create_browser(), TRUE, TRUE, 0);
    gtk_box_pack_start (GTK_BOX (vbox), create_toolbar (), FALSE, FALSE, 0);

    main_window = create_window();
#ifdef VIDEO_PLAYER 
    GtkWidget *fixed = gtk_fixed_new ();
    gtk_container_add(GTK_CONTAINER(main_window),fixed);
    gtk_widget_show(fixed);

    gtk_container_add (GTK_CONTAINER (main_window), fixed);
 
    gtk_widget_set_size_request(vbox, 600, 450);
    gtk_container_add (GTK_CONTAINER (fixed), vbox);    
    gtk_fixed_move (GTK_FIXED (fixed), vbox, 0, 0);


    videoDraw = creat_video_window(0, 0, 600, 450, fixed);
#else
//    gtk_widget_set_size_request(darea2, 600, 450);  

    gtk_container_add (GTK_CONTAINER (main_window), vbox); 
    
#endif
    gchar* uri = (gchar*) (argc > 1 ? argv[1] : "http://www.baidu.com");
    webkit_web_view_open (web_view, uri); 
	
	/* History List*/
    bf_list_main = webkit_web_back_forward_list_new_with_web_view(web_view);
	
    gtk_widget_grab_focus (GTK_WIDGET (web_view));
    gtk_widget_show_all (main_window);
#ifdef VIDEO_PLAYER
    gtk_widget_hide(videoDraw);
#endif

    gtk_widget_add_events(main_window, GDK_KEY_RELEASE_MASK);
    //gtk_widget_add_events(videoDraw, GDK_BUTTON_PRESS_MASK); 
    //gtk_widget_add_events(videoDraw, GDK_BUTTON_RELEASE_MASK);
    g_signal_connect (G_OBJECT (main_window), "key_release_event", G_CALLBACK (keystroke_cb), NULL);
    //g_signal_connect (videoDraw, "button_release_event", G_CALLBACK (button_release_event_handle), NULL);
    gtk_main (); 
	#endif
	
    return 0;
}

