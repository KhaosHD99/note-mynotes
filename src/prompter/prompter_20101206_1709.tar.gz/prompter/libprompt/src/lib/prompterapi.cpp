#include <string.h>
#include <stdio.h>
//#include <time.h>
#include "prompter.hpp"

#ifdef __cplusplus
extern "C" 
{
#endif

/**************************************************************************************************/
/**************************************** prompter ***************************************************/
/**************************************************************************************************/
GtkWidget* creat_prompter_gtkarea(unsigned int width, unsigned int height, const char *img_path)
{
	PrompterManager *manager = PrompterManager::get_instance();
    
  	return manager->creat_prompter_gtkarea(width, height, img_path);
}

int update_prompter_info(StatePrompterInfo *stateinfo)
{
	PrompterManager *manager = PrompterManager::get_instance();
    
    return manager->update_prompter_info(stateinfo->state, stateinfo->message);
}

ST_PP get_prompter_state()
{
	PrompterManager *manager = PrompterManager::get_instance();
	
  	return manager->get_prompter_state();
}

int get_prompter_stateinfo(StatePrompterInfo *stateinfo)
{
	PrompterManager *manager = PrompterManager::get_instance();
    
 	return manager->get_prompter_stateinfo(stateinfo);
}

#ifdef __cplusplus
}
#endif

