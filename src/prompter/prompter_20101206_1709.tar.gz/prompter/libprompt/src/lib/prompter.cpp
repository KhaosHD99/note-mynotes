#include <stdio.h>
#include <string.h>
#include <prompter.hpp>

#define RUN_FLAG 0
#define RUN_FLAG2 0
#define FORMAT "<span foreground='red'  font_desc='13'>%s</span>"

pthread_t thread_id;

PrompterManager::PrompterManager()
{
	init();
}

PrompterManager::~PrompterManager()
{
	uninit();
}

void PrompterManager::init()
{	
	cur_pp_state = PP_ON_HOOK;
	timer = 0;

	uncatch_msg_info = new UnCatchMsgInfo*[UNCATCH_TYPE_COUNT];
	
	for(int i = 0; i < UNCATCH_TYPE_COUNT; i++)
	{
		uncatch_msg_info[i] = new UnCatchMsgInfo;
		uncatch_msg_info[i]->uncatch_msg = new char*[PRO_MSG_MAX_COUNT];
		for(int j = 0; j < PRO_MSG_MAX_COUNT; j++)
		{
			uncatch_msg_info[i]->uncatch_msg[j] = NULL;
		}
	}
}

void PrompterManager::uninit()
{	
	for(int i = 0; i < UNCATCH_TYPE_COUNT; i++)
	{
	    if(uncatch_msg_info[i])
	    {
			for(int j = 0; j < PRO_MSG_MAX_COUNT; j++)
			{
			    if(uncatch_msg_info[i]->uncatch_msg[j])
			    {
					delete uncatch_msg_info[i]->uncatch_msg[j];
					uncatch_msg_info[i]->uncatch_msg[j] = NULL;
				}
			}
			delete uncatch_msg_info[i];
			uncatch_msg_info[i] = NULL;
		}
	}
}

/* ************************************************************************************************
				                           			       Single Instance
**************************************************************************************************/
PrompterManager* PrompterManager::instance = NULL;
PrompterManager* PrompterManager::get_instance()
{
	if(!instance)
		instance = new PrompterManager;
	
	return instance;
}

/* ************************************************************************************************
				                           			       get current date
**************************************************************************************************/
int get_date(char *dt)
{
	if(!dt)
		return -1;
	
	struct tm *local;
	time_t t;
	char year[8];
	char mon[8];
	char day[8];
	char date[128];
	 
	t = time(NULL);
	local = localtime(&t);

	sprintf(date, "%d年%d月%d日", local->tm_year + 1900,
						 			 local->tm_mon + 1,
						 		 	 local->tm_mday,
						 			 local->tm_hour,
						 			 local->tm_min,
						 			 local->tm_sec);
	strcpy(dt, date);
	
	return 0;
}

/* ************************************************************************************************
				                           			       get current time
**************************************************************************************************/
int get_time(char *tm)
{
    if(!tm)
		return -1;
	
	struct tm *local;
	time_t t;
	char hour[8];
	char min[8];
	char sec[8];
	
	t = time(NULL);
	local = localtime(&t);
	
	//char *time = new char[128];
	char time[128];
	static int flag = 0;

	if(flag++%2)
		sprintf(time, "%02d: %02d: %02d", local->tm_hour,
								local->tm_min,
								local->tm_sec);
	else
		sprintf(time, "%02d: %02d  %02d", local->tm_hour,
								local->tm_min,
								local->tm_sec);

	strcpy(tm, time);
	
	return 0;
}

/* ************************************************************************************************
				                           			       refresh widget
**************************************************************************************************/
gboolean refresh_loop(void *p_data)
{
	PrompterManager *manager = PrompterManager::get_instance();
	char *markup;
	char timer_str[128];
	int read_pos;
	int end_time;
	int timer_min;
	int timer_sec;
	
    switch(manager->cur_pp_state)
	{		
		case PP_ON_HOOK:
			char cur_time[128];
			char cur_date[128];
			get_time(cur_time);
			get_date(cur_date);
			
			markup = g_markup_printf_escaped (FORMAT, cur_date);
			gtk_label_set_markup(GTK_LABEL(manager->label), markup);
			
			markup = g_markup_printf_escaped (FORMAT, cur_time);
			gtk_label_set_markup(GTK_LABEL(manager->label2), markup);

       		if(markup)
				delete(markup);
			
			gtk_widget_show(manager->label);
			gtk_widget_show(manager->label2);
			
			break;
		case PP_OFF_HOOK:
			manager->timer++;
			timer_min = manager->timer / 60;
			timer_sec = manager->timer % 60;
			sprintf(timer_str, "%02d: %02d", timer_min, timer_sec);
			
			markup = g_markup_printf_escaped (FORMAT, timer_str);
			gtk_label_set_markup(GTK_LABEL(manager->label_timer), markup);
			gtk_widget_show(manager->label_timer);
			
			if(markup)
				delete(markup);
			
			break;
		case PP_RINGING:
			manager->timer++;
			timer_min = manager->timer / 60;
			timer_sec = manager->timer % 60;
			sprintf(timer_str, "%02d: %02d", timer_min, timer_sec);
			
			markup = g_markup_printf_escaped (FORMAT, timer_str);
			gtk_label_set_markup(GTK_LABEL(manager->label_timer), markup);
			gtk_widget_show(manager->label_timer);
			
			if(markup)
				delete(markup);
			
			break;
		case PP_CONNECT:
			manager->timer++;
			timer_min = manager->timer / 60;
			timer_sec = manager->timer % 60;
			sprintf(timer_str, "%02d: %02d", timer_min, timer_sec);
			
			markup = g_markup_printf_escaped (FORMAT, timer_str);
			gtk_label_set_markup(GTK_LABEL(manager->label_timer), markup);
			gtk_widget_show(manager->label_timer);
			/*manager->timer++;
			sprintf(timer_str, "%d", manager->timer);
			
			markup = g_markup_printf_escaped (FORMAT, timer_str);
			gtk_label_set_markup(GTK_LABEL(manager->label_timer), markup);
			gtk_widget_show(manager->label_timer);
			*/
			if(markup)
				delete(markup);
			break;
		case PP_UNCATCH_PHONE_MESSAGE:
			printf("get in %s\n", "PP_UNCATCH_PHONE_MESSAGE");
			printf("end time %d\n", manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->end_time);
			if((manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->end_time - 1) == 0)
			{
			    printf("get in change end time %d\n", manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->end_time);
				read_pos = manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->pos;
				
				markup = g_markup_printf_escaped (FORMAT, 
												  manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->
												  uncatch_msg[read_pos]);
				gtk_label_set_markup(GTK_LABEL(manager->label2), markup);

				if(manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->pos == PRO_MSG_MAX_COUNT)
					manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->pos = 0;
				else if(manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[read_pos + 1]) 
					manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->pos++;
				else
					manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->pos = 0;
				
				manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->end_time = PRO_MSG_END_TIME;
			}
			
			manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->end_time--;
			//printf("after -- end time %d\n", manager->uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->end_time);
			break;
		case PP_UNCATCH_SMS_MESSAGE:
			if((manager->uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->end_time - 1) == 0)
			{
				read_pos = manager->uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->pos;
				
				markup = g_markup_printf_escaped (FORMAT, 
												  manager->uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->
												  uncatch_msg[read_pos]);
				gtk_label_set_markup(GTK_LABEL(manager->label2), markup);

				if(manager->uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->pos == PRO_MSG_MAX_COUNT)
					manager->uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->pos = 0;
				else if(manager->uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[read_pos + 1]) 
					manager->uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->pos++;
				else
					manager->uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->pos = 0;
				
				manager->uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->end_time = PRO_MSG_END_TIME;
			}
			
			manager->uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->end_time--;
			printf("after -- end time %d\n", manager->uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->end_time);
			break;
		case PP_UNCATCH_EMAIL_MESSAGE:
			if((manager->uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->end_time - 1) == 0)
			{
				read_pos = manager->uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->pos;
				
				markup = g_markup_printf_escaped (FORMAT, 
												  manager->uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->
												  uncatch_msg[read_pos]);
				gtk_label_set_markup(GTK_LABEL(manager->label2), markup);

				if(manager->uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->pos == PRO_MSG_MAX_COUNT)
					manager->uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->pos = 0;
				else if(manager->uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[read_pos + 1]) 
					manager->uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->pos++;
				else
					manager->uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->pos = 0;
				
				manager->uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->end_time = PRO_MSG_END_TIME;
			}
			
			manager->uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->end_time--;
			printf("after -- end time %d\n", manager->uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->end_time);
			break;
		case PP_OTHER_MESSAGE:
			if((manager->uncatch_msg_info[PP_OTHER_MESSAGE - 4]->end_time - 1) == 0)
			{
				read_pos = manager->uncatch_msg_info[PP_OTHER_MESSAGE - 4]->pos;
				
				markup = g_markup_printf_escaped (FORMAT, 
												  manager->uncatch_msg_info[PP_OTHER_MESSAGE - 4]->
												  uncatch_msg[read_pos]);
				gtk_label_set_markup(GTK_LABEL(manager->label2), markup);

				if(manager->uncatch_msg_info[PP_OTHER_MESSAGE - 4]->pos == PRO_MSG_MAX_COUNT)
					manager->uncatch_msg_info[PP_OTHER_MESSAGE - 4]->pos = 0;
				else if(manager->uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[read_pos + 1]) 
					manager->uncatch_msg_info[PP_OTHER_MESSAGE - 4]->pos++;
				else
					manager->uncatch_msg_info[PP_OTHER_MESSAGE - 4]->pos = 0;
				
				manager->uncatch_msg_info[PP_OTHER_MESSAGE - 4]->end_time = PRO_MSG_END_TIME;
			}
			
			manager->uncatch_msg_info[PP_OTHER_MESSAGE - 4]->end_time--;
			printf("after -- end time %d\n", manager->uncatch_msg_info[PP_OTHER_MESSAGE - 4]->end_time);
			break;
		default:
				return -1;
	}
}

GtkWidget* PrompterManager::creat_prompter_gtkarea(unsigned int width, unsigned int height, const char *img_path)
{   
	printf("%s\n", __FUNCTION__);

    static gboolean bcreat = FALSE;
	if(bcreat && fixed)
		return fixed;
	
	GtkWidget *bg_image;
	
	fixed = gtk_fixed_new();
	gtk_widget_set_size_request(fixed, width, height);
	
	label = gtk_label_new("");
	label2 = gtk_label_new("");
	label_timer = gtk_label_new("");
	
	/* Load Back Groud Image */
	if(img_path)
	{
		bg_image = gtk_image_new_from_file(img_path);
		if(bg_image)
			gtk_container_add(GTK_CONTAINER(fixed), bg_image);
		else
			showWarning("Load BG Image fail\n");
	}
	
	/* Set Widget Size and Layout */
	gtk_widget_set_size_request(label, LABEL_SIZE_WIDTH, LABEL_SIZE_HEIGHT);
	gtk_widget_set_size_request(label2, LABEL2_SIZE_WIDTH, LABEL2_SIZE_HEIGHT);
	gtk_widget_set_size_request(label_timer, LABEL_TIMER_SIZE_WIDTH, LABEL_TIMER_SIZE_HEIGHT);
	gtk_label_set_line_wrap(GTK_LABEL(label2), TRUE);
	gtk_label_set_line_wrap_mode(GTK_LABEL(label2), PANGO_WRAP_CHAR);
	gtk_label_set_justify(GTK_LABEL(label2), GTK_JUSTIFY_LEFT);
	
	gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label));
	gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label2));
	gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label_timer));
	
  	gtk_fixed_move (GTK_FIXED(fixed), label, LABEL_POSITION_X, LABEL_POSITION_Y);
	gtk_fixed_move (GTK_FIXED(fixed), label2, LABEL2_POSITION_X, LABEL2_POSITION_Y);
	gtk_fixed_move (GTK_FIXED(fixed), label_timer, LABEL_TIMER_POSITION_X, LABEL_TIMER_POSITION_Y);
	
	gtk_widget_show_all(fixed);
	
	gtk_timeout_add (1000, refresh_loop, NULL);
	bcreat = TRUE;
	
	return fixed;
}



int PrompterManager::update_prompter_info(ST_PP state, const char *info)
{	
	printf("%s\n", __FUNCTION__);
	
	switch(state)
	{		
		case PP_ON_HOOK:
			if(cur_pp_state == PP_ON_HOOK)
			{
				showDebug("PrompterManager Invalid State : PP_ON_HOOK\n");
				return -1;
			}
			break;
		case PP_OFF_HOOK:
			if(cur_pp_state == PP_RINGING||
			   cur_pp_state == PP_CONNECT)
			{
				showDebug("PrompterManager Invalid State : PP_OFF_HOOK\n");
				return -1;
			}
			break;
		case PP_RINGING:
			if(cur_pp_state == PP_OFF_HOOK ||
				cur_pp_state == PP_CONNECT)
			{
				showDebug("PrompterManager Invalid State : PP_RINGING\n");
				return -1;
			}
			break;
		case PP_CONNECT:
			if( cur_pp_state == PP_ON_HOOK||
				cur_pp_state == PP_OFF_HOOK ||
				cur_pp_state == PP_CONNECT)
			{
				showDebug("PrompterManager Invalid State : PP_CONNECT\n");
				return -1;
			}
			break;
		case PP_UNCATCH_PHONE_MESSAGE:
			add_uncatch_phone_msg(info);
			break;
		case PP_UNCATCH_SMS_MESSAGE:
			add_uncatch_sms_msg(info);
			break;
		case PP_UNCATCH_EMAIL_MESSAGE:
			add_uncatch_email_msg(info);
			break;
		case PP_OTHER_MESSAGE:
			add_uncatch_other_msg(info);
			break;
		default:
			return -1;
	}
	
	cur_pp_state = state;
	change_widget_by_state(cur_pp_state, info);
}

int PrompterManager::change_widget_by_state(ST_PP state, const char *info)
{	
	int i = 0;
	char *markup;
	
	gdk_threads_enter();

	if(state == PP_ON_HOOK)
  	{
		printf("change_widget_by_state PP_ON_HOOK: %s\r\n", info);
		hide_all_widget();

		char cur_time[128];		
		char cur_date[128];
		get_time(cur_time);
		get_date(cur_date);
		
		markup = g_markup_printf_escaped (FORMAT, cur_date);
		gtk_label_set_markup(GTK_LABEL(label), 
		                   markup);
		
		markup = g_markup_printf_escaped (FORMAT, cur_time);
		gtk_label_set_markup(GTK_LABEL(label2), 
		                     markup);

		if(markup)
		delete(markup);

		gtk_widget_show(label);
		gtk_widget_show(label2);
	}	
	else if(state == PP_RINGING)
	{	
		printf("change_widget_by_state PP_RINGING: %s\r\n", info);
		markup = g_markup_printf_escaped (FORMAT, ST_PP_INFO[state]);
		gtk_label_set_markup(GTK_LABEL(label), markup);
		
		markup = g_markup_printf_escaped (FORMAT, info);
		gtk_label_set_markup(GTK_LABEL(label2), markup);
		gtk_label_set_line_wrap(GTK_LABEL(label2), TRUE);

		char timer_str[16];
		timer = 0;
		sprintf(timer_str, "%02d: %02d", timer, timer);
		markup = g_markup_printf_escaped (FORMAT, timer_str);
		gtk_label_set_markup(GTK_LABEL(label_timer), markup);
		
		if(markup)
		delete(markup);
		
		gtk_widget_show(label);
		gtk_widget_show(label2);
		gtk_widget_show(label_timer);
	}	
	else if(state == PP_OFF_HOOK)
	{	
		printf("change_widget_by_state PP_OFF_HOOK: %s\r\n", info);
		markup = g_markup_printf_escaped (FORMAT, ST_PP_INFO[state]);
		gtk_label_set_markup(GTK_LABEL(label), markup);
		
		markup = g_markup_printf_escaped (FORMAT, info);
		gtk_label_set_markup(GTK_LABEL(label2), markup);
		gtk_label_set_line_wrap(GTK_LABEL(label2), TRUE);
		
		char timer_str[16];
		timer = 0;
		sprintf(timer_str, "%02d: %02d", timer, timer);
		markup = g_markup_printf_escaped (FORMAT, timer_str);
		gtk_label_set_markup(GTK_LABEL(label_timer), markup);
		
		if(markup)
			delete(markup);
		
		gtk_widget_show(label);
		gtk_widget_show(label2);
		gtk_widget_show(label_timer);
		gtk_label_set_line_wrap(GTK_LABEL(label2), TRUE);
	}
	else if(state == PP_CONNECT)
	{	
		printf("change_widget_by_state PP_CONNECT: %s\r\n", info);
		//hide_all_widget();
		
		markup = g_markup_printf_escaped (FORMAT, ST_PP_INFO[state]);
		gtk_label_set_markup(GTK_LABEL(label), markup);

		markup = g_markup_printf_escaped (FORMAT, info);
		gtk_label_set_markup(GTK_LABEL(label2), markup);
		gtk_label_set_line_wrap(GTK_LABEL(label2), TRUE);
		
		char timer_str[16];
		timer = 0;
		sprintf(timer_str, "%d", timer);
		markup = g_markup_printf_escaped (FORMAT, timer_str);
		gtk_label_set_markup(GTK_LABEL(label_timer), markup);

		if(markup)
			delete(markup);
		
		gtk_widget_show(label);
		gtk_widget_show(label2);
		gtk_widget_show(label_timer);
	}
	else if(state == PP_UNCATCH_PHONE_MESSAGE)
	{
		printf("change_widget_by_state PP_UNCATCH_PHONE_MESSAGE: %s\r\n", info);
		hide_all_widget();
		
		markup = g_markup_printf_escaped (FORMAT, ST_PP_INFO[state]);
		gtk_label_set_markup(GTK_LABEL(label),  markup);

		markup = g_markup_printf_escaped (FORMAT, info);
		gtk_label_set_markup(GTK_LABEL(label2), markup);

		if(markup)
			delete(markup);

		gtk_widget_show(label);
		gtk_widget_show(label2);
	}
	else if(state == PP_UNCATCH_SMS_MESSAGE)
	{
		printf("change_widget_by_state PP_UNCATCH_SMS_MESSAGE: %s\r\n", info);
		hide_all_widget();
		
		markup = g_markup_printf_escaped (FORMAT, ST_PP_INFO[state]);
		gtk_label_set_markup(GTK_LABEL(label), markup);
	
		markup = g_markup_printf_escaped (FORMAT, info);
		gtk_label_set_markup(GTK_LABEL(label2), markup);

		if(markup)
			delete(markup);
		
		gtk_widget_show(label);
		gtk_widget_show(label2);
	}
	else if(state == PP_UNCATCH_EMAIL_MESSAGE)
	{
		printf("change_widget_by_state PP_UNCATCH_EMAIL_MESSAGE: %s\r\n", info);
		hide_all_widget();
		
		markup = g_markup_printf_escaped (FORMAT, ST_PP_INFO[state]);
		gtk_label_set_markup(GTK_LABEL(label), markup);

		markup = g_markup_printf_escaped (FORMAT, info);
		gtk_label_set_markup(GTK_LABEL(label2), markup);

		if(markup)
			delete(markup);
		
		gtk_widget_show(label);
		gtk_widget_show(label2);
	}
	else if(state == PP_OTHER_MESSAGE)
	{
		printf("change_widget_by_state PP_OTHER_MESSAGE: %s\r\n", info);
		hide_all_widget();
		
		markup = g_markup_printf_escaped (FORMAT, "Other MSG");
		gtk_label_set_markup(GTK_LABEL(label), markup);

		markup = g_markup_printf_escaped (FORMAT, info);
		gtk_label_set_markup(GTK_LABEL(label2), markup);

		if(markup)
			delete(markup);
		
		gtk_widget_show(label);
		gtk_widget_show(label2);
	}
	else
	{
		printf("type error \n");
	}
	gdk_threads_leave();
}

ST_PP PrompterManager::get_prompter_state()
{
	return cur_pp_state;
}

int PrompterManager::get_prompter_stateinfo(StatePrompterInfo *stateinfo)
{
	if(!stateinfo)
		return -1;
	
	stateinfo->state = cur_pp_state;
  return 0;
}

int PrompterManager::add_uncatch_phone_msg(const char *msg)
{
	for(int i = PRO_MSG_MAX_COUNT - 1; i > -1 ; i--)
	{
	    if(i == PRO_MSG_MAX_COUNT - 1 && uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[i])
	    {
			memset(uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[i], 0, PRO_MSG_MAX_LEN);
			continue;
		}
		
		if(uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[i])
		{	
			if(!uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[i + 1])
				uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[i + 1] = new char[PRO_MSG_MAX_LEN];

			strcpy(uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[i + 1], 
				   uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[i]);

			memset(uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[i], 0, PRO_MSG_MAX_LEN);
		}
	}
	
	if(uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[0])
		strcpy(uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[0], msg);	
	else
	{
		uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[0] = new char[PRO_MSG_MAX_LEN];
		strcpy(uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->uncatch_msg[0], msg);
	}

    /*  */
	uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->end_time = PRO_MSG_END_TIME;
	uncatch_msg_info[PP_UNCATCH_PHONE_MESSAGE - 4]->pos = 0;
}

int PrompterManager::add_uncatch_sms_msg(const char *msg)
{
	for(int i = PRO_MSG_MAX_COUNT - 1; i > -1 ; i--)
	{
	    if(i == PRO_MSG_MAX_COUNT - 1 && uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[i])
	    {
			memset(uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[i], 0, PRO_MSG_MAX_LEN);
			continue;
		}
		
		if(uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[i])
		{	
			if(!uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[i + 1])
				uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[i + 1] = new char[PRO_MSG_MAX_LEN];

			strcpy(uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[i + 1], 
				   uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[i]);

			memset(uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[i], 0, PRO_MSG_MAX_LEN);
		}
	}

	if(uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[0])
		strcpy(uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[0], msg);	
	else
	{
		uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[0] = new char[PRO_MSG_MAX_LEN];
		strcpy(uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->uncatch_msg[0], msg);
	}

	uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->end_time = PRO_MSG_END_TIME;
	uncatch_msg_info[PP_UNCATCH_SMS_MESSAGE - 4]->pos = 0;
}

int PrompterManager::add_uncatch_email_msg(const char *msg)
{
	for(int i = PRO_MSG_MAX_COUNT - 1; i > -1 ; i--)
	{
	    if(i == PRO_MSG_MAX_COUNT - 1 && uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[i])
	    {
			memset(uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[i], 0, PRO_MSG_MAX_LEN);
			continue;
		}
		
		if(uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[i])
		{	
			if(!uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[i + 1])
				uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[i + 1] = new char[PRO_MSG_MAX_LEN];

			strcpy(uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[i + 1], 
				   uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[i]);

			memset(uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[i], 0, PRO_MSG_MAX_LEN);
		}
	}

	if(uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[0])
		strcpy(uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[0], msg);	
	else
	{
		uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[0] = new char[PRO_MSG_MAX_LEN];
		strcpy(uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->uncatch_msg[0], msg);
	}

	uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->end_time = PRO_MSG_END_TIME;
	uncatch_msg_info[PP_UNCATCH_EMAIL_MESSAGE - 4]->pos = 0;
}


int PrompterManager::add_uncatch_other_msg(const char *msg)
{
	for(int i = PRO_MSG_MAX_COUNT - 1; i > -1 ; i--)
	{
	    if(i == PRO_MSG_MAX_COUNT - 1 && uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[i])
	    {
			memset(uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[i], 0, PRO_MSG_MAX_LEN);
			continue;
		}
		
		if(uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[i])
		{	
			if(!uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[i + 1])
				uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[i + 1] = new char[PRO_MSG_MAX_LEN];

			strcpy(uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[i + 1], 
				   uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[i]);

			memset(uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[i], 0, PRO_MSG_MAX_LEN);
		}
	}
	
	if(uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[0])
		strcpy(uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[0], msg);	
	else
	{
		uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[0] = new char[PRO_MSG_MAX_LEN];
		strcpy(uncatch_msg_info[PP_OTHER_MESSAGE - 4]->uncatch_msg[0], msg);
	}

	uncatch_msg_info[PP_OTHER_MESSAGE - 4]->end_time = PRO_MSG_END_TIME;
	uncatch_msg_info[PP_OTHER_MESSAGE - 4]->pos = 0;
}

int PrompterManager::string_split(char *dest ,const char *info)
{
	int count = 0;
	char *str;
	char *tmp = new char[strlen(info) + strlen(info)/MAX_LINE_TEXT_COUNT + 1];
	
    str = tmp;
	while(*info)
	{
		if(!(count % MAX_LINE_TEXT_COUNT) && count != 0)
		{
			*tmp = '\n';
			count = 0;
		}
		else		
		{
			*tmp = *info;
			info++;
			count++;
		}
		tmp++;
	}
	*tmp = '\0'; 
	strcpy(dest, str);

	delete(str);
}

int PrompterManager::hide_all_widget()
{
	gtk_widget_hide(label);
	gtk_widget_hide(label2);
	gtk_widget_hide(label_timer);
}


