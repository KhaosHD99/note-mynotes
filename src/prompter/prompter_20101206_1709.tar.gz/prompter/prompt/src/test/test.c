#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
//#include <prompterapi.h>
#include <pthread.h>
#include <PrompterGui.h>

pthread_t change_thread;

void* simulate_change_state(void *p_data)
{
    int i = 0;
    int state[8];
	//char msg[] = "info1"; 
	char msg[] = "中文"; 

	const char INFO[8][128] = 
	{
		"PP_ON_HOOKXXXXXXXXXXXX",
		"PP_OFF_HOOKXXXXXXXX",
		"PP_OFF_HOOKXXXXXXXXX",
		"PP_CONNECTXXXXXXXXXX",
		"PP_UNCATCH_PHONE_MESSAGEXXXXXXXXXX",
		"PP_UNCATCH_SMS_MESSAGEXXXXXXXXX",
		"PP_UNCATCH_EMAIL_MESSAGEXXXXXXXX",
		"PP_OTHER_MESSAGEXXXXXXXXXXXXXXXX"
	};
	
	//msg[0] = "info1";
	//msg[1] = "info2";
	//const char *msg2 = "info2";
	
	#if 1
	state[0] = PP_ON_HOOK;
	state[1] = PP_OFF_HOOK;
	state[2] = PP_ON_HOOK;
	state[3] = PP_RINGING;
	state[4] = PP_CONNECT;
    state[5] = PP_UNCATCH_PHONE_MESSAGE;
    state[6] = PP_UNCATCH_SMS_MESSAGE;
	state[7] = PP_UNCATCH_EMAIL_MESSAGE;
	state[8] = PP_OTHER_MESSAGE;
    #endif

	#if 0
	state[0] = PP_CONNECT;
	state[1] = PP_CONNECT;
	state[2] = PP_CONNECT;
	state[3] = PP_CONNECT;
    state[4] = PP_CONNECT;
    state[5] = PP_CONNECT;
	state[6] = PP_CONNECT;
	state[7] = PP_CONNECT;
	#endif
	
    while(1)
    {	
		usleep(2000 * 1000);
		//printf("%s\n", __FUNCTION__);
		if(i == 9)
			i = 0;
		
		//gdk_threads_enter();
		//pthread_mutex_lock(&mutex);
		StatePrompterInfo state_info;
		state_info.state = state[i];
		
		strcpy(state_info.message, INFO[i]);
		
		update_prompter_info(&state_info);
		
		//if(i == 1)
		//	usleep(1000000 * 1000);
		
		
        
		i++;
		//gdk_threads_leave();		
		//pthread_mutex_unlock(&mutex);
	}
}

int main(int argc, char *argv[])
{
	#if 0
	gtk_init(&argc, &argv);   

	GtkWidget *window;	  
	GtkWidget* fixed;
	GtkWidget* label_timer;
	GtkWidget* label;
	GtkWidget* label2;
	
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
	//gtk_window_set_default_size(GTK_WINDOW(window), 100, 100);
	fixed = gtk_fixed_new();
	gtk_widget_set_size_request(fixed, 200, 100);
	
	//label = gtk_label_new("");
	//label2 = gtk_label_new("this is a test, gtk test, confusing me long long time");
	label2 = gtk_label_new("this is a test gtk test confusing me long long time");
	gtk_widget_set_size_request(label2, 150, 100);
	//label_timer = gtk_label_new("");
	//frame = gtk_frame_new("frame");
	
	gtk_label_set_line_wrap(GTK_LABEL(label2), TRUE);
	gtk_label_set_line_wrap_mode(label2, PANGO_WRAP_WORD_CHAR);
	gtk_label_set_justify(GTK_LABEL(label2), GTK_JUSTIFY_LEFT);
	
	//gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label));
	gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label2));
	//gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label_timer));
	
  	//gtk_fixed_move (GTK_FIXED(fixed), label, 20, 50);
	gtk_fixed_move (GTK_FIXED(fixed), label2, 20, 20);
	//gtk_fixed_move (GTK_FIXED(fixed), label_timer, 80, 50);
	
	gtk_container_add(GTK_CONTAINER(window), fixed);   
	gtk_widget_show_all(fixed);
	gtk_widget_show(window);
	gtk_main();
	#endif
	
    #if 1
	//if(XInitThreads () == 0)
	//	printf(" XInitThreads err\n");
	
	//if(!g_thread_supported()) 
	//	g_thread_init(NULL);
	//gdk_threads_init();
	
	gtk_init(&argc, &argv);

	int ret = 0;
	char bg_img[128];
	GtkWidget* fixed;
	GtkWidget* window;

	window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_resizable(window, TRUE);
	gtk_window_move(window, 0 , 126 + 126 + 126);

	//strcpy(bg_img, "img/pb_main_bg.jpg");
	fixed = creat_prompter_gtkarea(200, 126, bg_img);
	
	gtk_container_add(GTK_CONTAINER(window), GTK_WIDGET(fixed));
	gtk_widget_show(window);
	
	ret = pthread_create(&change_thread,
						  NULL,
						  simulate_change_state,
						  NULL);
    if(ret != 0)
	{
		printf("Create  %d fail\n", ret);
		return -1;
	}
	else
		printf("suc\n");
	
	//gdk_threads_enter();
	gtk_main();
	//gdk_threads_leave();
    
    return 0;
	#endif
}

