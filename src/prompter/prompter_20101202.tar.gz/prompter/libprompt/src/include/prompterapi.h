#ifndef PHONEBOOKAPI_DEF
#define PHONEBOOKAPI_DEF

//#include "phonebookinfo.h"
#include <gtk/gtk.h>

#ifdef __cplusplus 
extern "C" 
{ 
#endif 

	//contact
	/*int get_contact_count();
	int get_contact_by_index(Contact *contact,	int index); 
	int get_contact_by_name(Contact *contact,	const char *szname);
	int get_contact_by_letter(Contact *contact, const char *szletter);		 
	int get_contact_by_phone(Contact *contact,	const char *szphone);		 
	 									
	int add_contact(Contact *contact);
	int add_contact_by_index(Contact *contact, int index);
	 	
	int update_contact_by_index(Contact *contact, int index);	
	 	
	int delete_contact_by_index(int index);
	int delete_contact_all();*/

	
	typedef enum ST_PP
	{
			ON_HOOK,	//����
			OFF_HOOK,	//����... + ����
			RINGING,	//����... + ����
			CONNECT,	//ͨ����... + ����
			UNCATCH_PHONE_MESSAGE,	//δ������
			UNCATCH_MSM_MESSAGE,		//Ϊ�鿴����
			UNCATCH_EMAIL_MESSAGE,	//δ�鿴�ʼ�
			OTHER_MESSAGE
	}ST_PP;
	
	//GUI Interface
	GtkWidget* creat_prompter_gtkarea(GtkWidget *fixed);
	
	int update_prompter_info(ST_PP states, const char*info);
	
	//ST_PP get_prompter_info();
	ST_PP get_prompter_state();

#ifdef _cplusplus 
} 
#endif

#endif

