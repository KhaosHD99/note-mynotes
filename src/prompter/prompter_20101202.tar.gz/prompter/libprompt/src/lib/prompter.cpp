#include <stdio.h>
#include <string.h>
#include <prompter.hpp>

//#ifdef __cplusplus
//extern "C" 
//{
//#endif

GtkBuilder *builder;
//window
GtkWidget *window_container;
GtkWidget *window_standby;
GtkWidget *window_miss_call;
GtkWidget *window_ring;
GtkWidget *window_offhook;
GtkWidget *window_dailing;
GtkWidget *window_connected;
GtkWidget *window_talking;
GtkWidget *window_hang_up;

GtkWidget *fix_standby;

GtkWidget *label_date;
GtkWidget *label_week;
GtkWidget *label_time;
//GtkWidget *label_date;
//GtkWidget *label_date;

PrompterManager::PrompterManager()
{
	init();
}

PrompterManager::~PrompterManager()
{
	
}

void PrompterManager::init()
{	
	fix = gtk_fixed_new();
	label = gtk_label_new("XXXX Y XX M XX D");
	label2 = gtk_label_new("Monday");
	label3 = gtk_label_new("XX:XX:XX");
}

void PrompterManager::uninit()
{	
	
}

/* ************************************************************************************************
				                           			       Single Instance
**************************************************************************************************/
PrompterManager* PrompterManager::instance = NULL;
PrompterManager* PrompterManager::get_instance()
{
	if(!instance)
		instance = new PrompterManager;
	
	return instance;
}

GtkWidget* PrompterManager::creat_prompter_gtkarea(GtkWidget *fixed)
{   
    printf("%s\n", __FUNCTION__);
	GtkAllocation allocation;
	memset(&allocation, 0, sizeof(GtkAllocation));
	
	//GtkWidget* fix = gtk_fixed_new();
	//GtkWidget* label = gtk_label_new("XXXX Y XX M XX D");
	//GtkWidget* label2 = gtk_label_new("Monday");
	//GtkWidget* label3 = gtk_label_new("XX:XX:XX");

	gtk_container_add(GTK_CONTAINER(fix), GTK_WIDGET(label));
	gtk_container_add(GTK_CONTAINER(fix), GTK_WIDGET(label2));
	gtk_container_add(GTK_CONTAINER(fix), GTK_WIDGET(label3));
	
	//gtk_widget_show_all(fix);
	
	allocation.x = 30;
	allocation.y = 15;
	allocation.width = 100;
	allocation.height = 30;
	//gtk_widget_set_allocation(label, &allocation);
	
	gtk_fixed_move (GTK_FIXED(fix), label, 30, 15);
	gtk_fixed_move (GTK_FIXED(fix), label2, 30, 50);
	gtk_fixed_move (GTK_FIXED(fix), label3, 100, 50);
	
	return fix;
}
	
int PrompterManager::update_prompter_info(ST_PP states, const char*info)
{
	printf("%s\n", __FUNCTION__);

    if(states == ON_HOOK)
    {
    	gtk_label_set_text((GtkLabel *)label, "ON_HOOK");
		gtk_label_set_text((GtkLabel *)label2, info);
		state = ON_HOOK;
	}
	else if(states == RINGING)
	{
		gtk_label_set_text((GtkLabel *)label, "RINGING");
		gtk_label_set_text((GtkLabel *)label2, info);
		state = ON_HOOK;
	}
	else if(states == OFF_HOOK)
	{
		gtk_label_set_text((GtkLabel *)label, "OFF_HOOK");
		gtk_label_set_text((GtkLabel *)label2, info);
		state = ON_HOOK;
	}
	else if(states == CONNECT)
	{
		gtk_label_set_text((GtkLabel *)label, "CONNECT");
		gtk_label_set_text((GtkLabel *)label2, info);
		state = ON_HOOK;
	}
	else if(states == UNCATCH_PHONE_MESSAGE)
	{
		gtk_label_set_text((GtkLabel *)label, "UNCATCH_PHONE_MESSAGE");
		gtk_label_set_text((GtkLabel *)label2, info);
		state = ON_HOOK;
	}
	else if(states == UNCATCH_MSM_MESSAGE)
	{
		gtk_label_set_text((GtkLabel *)label, "UNCATCH_MSM_MESSAGE");
		gtk_label_set_text((GtkLabel *)label2, info);
		state = ON_HOOK;
	}
	else if(states == UNCATCH_EMAIL_MESSAGE)
	{
		gtk_label_set_text((GtkLabel *)label, "UNCATCH_EMAIL_MESSAGE");
		gtk_label_set_text((GtkLabel *)label2, info);
		state = ON_HOOK;
	}
	else if(states == OTHER_MESSAGE)
	{
		gtk_label_set_text((GtkLabel *)label, "OTHER_MESSAGE");
		gtk_label_set_text((GtkLabel *)label2, info);
		state = ON_HOOK;
	}
	else
	{
		printf("type error \n");
	}
}

ST_PP PrompterManager::get_prompter_state()
{
	return state;
}

void on_button1_clicked(GtkWidget *window, gpointer user_data)
{
	printf("%s\n", __FUNCTION__);
	//gtk_widget_set_visible(button, FALSE);
}

#if 0
GtkWidget* get_standby_fix()
{
    GtkAllocation allocation;
	memset(&allocation, 0, sizeof(GtkAllocation));
	
	GtkWidget* fix = gtk_fixed_new();
	GtkWidget* label = gtk_label_new("XXXX Y XX M XX D");
	GtkWidget* label2 = gtk_label_new("Monday");
	GtkWidget* label3 = gtk_label_new("XX:XX:XX");

	gtk_container_add(GTK_CONTAINER(fix), GTK_WIDGET(label));
	gtk_container_add(GTK_CONTAINER(fix), GTK_WIDGET(label2));
	gtk_container_add(GTK_CONTAINER(fix), GTK_WIDGET(label3));
	
	//gtk_widget_show_all(fix);
	
	allocation.x = 30;
	allocation.y = 15;
	allocation.width = 100;
	allocation.height = 30;
	//gtk_widget_set_allocation(label, &allocation);
	
	gtk_fixed_move (GTK_FIXED(fix), label, 30, 15);
	gtk_fixed_move (GTK_FIXED(fix), label2, 30, 50);
	gtk_fixed_move (GTK_FIXED(fix), label3, 100, 50);
	
	return fix;
}
#endif

int main(int argc, char *argv[])
{
	gtk_init(&argc, &argv);
	
	//GtkWidget *window;
	//GtkWidget *button;
	GtkWidget* window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_default_size(GTK_WINDOW(window),
								200,
								126);
    
	//GtkWidget* fix = gtk_fixed_new();
	
    //GtkWidget* label = gtk_label_new("elon");
	//GtkWidget* label2 = gtk_label_new("XX:XX:XX:XX");
	//GtkWidget* button = gtk_button_new();
	//gtk_container_add(GTK_CONTAINER(window), GTK_WIDGET(get_standby_fix()));
	//gtk_container_add(GTK_CONTAINER(fix), GTK_WIDGET(label));
	//gtk_container_add(GTK_CONTAINER(fix), GTK_WIDGET(label2));
	
	//gtk_widget_show_all(label);
	//gtk_widget_show_all(label2);
	//gtk_widget_show_all(window);
	//gtk_widget_show_all(fix);
	
	/*allocation.x = 30;
	allocation.y = 15;
	allocation.width = 100;
	allocation.height = 30;
	gtk_widget_set_allocation(label, &allocation);
	
	allocation.x = 100;
	allocation.y = 80;
	allocation.width = 100;
	allocation.height = 30;*/
	
	//GTK_WIDGET(button)->allocation.width = 100; 
	//gtk_widget_set_allocation(label2, &allocation);
	//gtk_label_set_text(label, "elon");
	
	
	//gtk_container_add(GTK_CONTAINER(window), GTK_WIDGET(label2));
	//gtk_container_add(GTK_CONTAINER(fix), GTK_WIDGET(label));
	//gtk_container_add(GTK_CONTAINER(fix), GTK_WIDGET(label2));
	
	#if 0
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, "prompter.glade", NULL);
	window_container = GTK_WIDGET(gtk_builder_get_object(builder, "window_container"));
	
	//window_standby = GTK_WIDGET(gtk_builder_get_object(builder, "window_standby"));
	//fix_standby = GTK_WIDGET(gtk_builder_get_object(builder, "fixed_prompter"));

	GtkWidget *parent = gtk_widget_get_parent(fix_standby);
	
	gtk_container_remove(GTK_CONTAINER(parent), GTK_WIDGET(fix_standby));
	
	//label_date = GTK_WIDGET(gtk_builder_get_object(builder, "label_date"));
	//label_week = GTK_WIDGET(gtk_builder_get_object(builder, "label_week"));
	//label_time = GTK_WIDGET(gtk_builder_get_object(builder, "label_time"));
	
    gtk_container_add(GTK_CONTAINER(window_container), GTK_WIDGET(fix_standby));
	//gtk_container_add(GTK_CONTAINER(window_container), GTK_WIDGET(fix));
    //window = GTK_WIDGET(gtk_builder_get_object(builder, "window_missed_call"));
	
	//button = GTK_WIDGET(gtk_builder_get_object(builder, "label_date"));
	//gtk_window_move(GTK_WINDOW(window), 200, 0);
	//window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	
	//darea = gtk_drawing_area_new ();
	//gtk_container_add (GTK_CONTAINER (window), darea);
	
	//image = cairo_image_surface_create_from_png ("img/image_1_2.jpg");
	#endif
	
	//gtk_builder_connect_signals(builder, NULL);
	gtk_widget_show_all(window);
	//gtk_widget_set_allocation(label2, &allocation);
	//GTK_WIDGET(button)->allocation.width = 100; 
	//gtk_widget_set_allocation(button, &allocation);
	//gtk_widget_show(window_container);

    /*int w, h;
	g_object_get (window,
                  "default-height", &h,
                   NULL);

	g_object_get (window,
                  "default-width", &w,
                   NULL);

	//gtk_widget_size_allocate(window, &allocation);
	printf("w: %d, h: %d\n", w, h);*/
	
	
	gtk_main();
    
    return 0;
}

//#ifdef __cplusplus 
//}
//#endif


