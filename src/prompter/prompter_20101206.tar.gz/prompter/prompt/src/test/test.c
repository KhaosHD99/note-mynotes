#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
//#include <prompterapi.h>
#include <pthread.h>
#include <PrompterGui.h>

pthread_t change_thread;

void* simulate_change_state(void *p_data)
{
    int i = 0;
    int state[8];
	//char msg[] = "info1"; 
	char msg[] = "中文"; 

	const char INFO[8][128] = 
	{
		"PP_ON_HOOK",
		"PP_OFF_HOOK",
		"PP_OFF_HOOK",
		"PP_CONNECT",
		"PP_UNCATCH_PHONE_MESSAGE",
		"PP_UNCATCH_SMS_MESSAGE",
		"PP_UNCATCH_EMAIL_MESSAGE",
		"PP_OTHER_MESSAGE"
	};
	//msg[0] = "info1";
	//msg[1] = "info2";
	//const char *msg2 = "info2";
	#if 0
	state[0] = PP_ON_HOOK;
	state[1] = PP_OFF_HOOK;
	state[2] = PP_OFF_HOOK;
	state[3] = PP_CONNECT;
    state[4] = PP_UNCATCH_PHONE_MESSAGE;
    state[5] = PP_UNCATCH_SMS_MESSAGE;
	state[6] = PP_UNCATCH_EMAIL_MESSAGE;
	state[7] = PP_OTHER_MESSAGE;
    #endif

	#if 1
	state[0] = PP_OFF_HOOK;
	state[1] = PP_OFF_HOOK;
	state[2] = PP_OFF_HOOK;
	state[3] = PP_OFF_HOOK;
    state[4] = PP_OFF_HOOK;
    state[5] = PP_OFF_HOOK;
	state[6] = PP_OFF_HOOK;
	state[7] = PP_OFF_HOOK;
	#endif
	
    while(1)
    {
		usleep(2000 * 1000);
		//printf("%s\n", __FUNCTION__);
		if(i == 8)
			i = 0;
		
		//gdk_threads_enter();
		//pthread_mutex_lock(&mutex);
		StatePrompterInfo state_info;
		state_info.state = state[i];

		//if(
		strcpy(state_info.message, INFO[i]);
		
		update_prompter_info(&state_info);

		if(i == 2)
			usleep(1000000 * 1000);
		
		//printf("Get State: %d\n", get_prompter_state()); 
        //phoneState = state[i];
        
		i++;
		//gdk_threads_leave();		
		//pthread_mutex_unlock(&mutex);
		//sem_post(&timeSem);
	}
}

int main(int argc, char *argv[])
{
    #if 0
	GtkWidget *window;	  
	GtkWidget *vbox;	  
	GtkWidget *frame;    
	GtkWidget *label;	
	GtkWidget *fixed;	
	gtk_init(&argc, &argv);   
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);	
	gtk_window_set_default_size(GTK_WINDOW(window), 400, 400);    
	
	fixed = gtk_fixed_new();
	gtk_widget_set_size_request(fixed, 200, 200);
	
	label = gtk_label_new("You might think you know but actually you dontYou might think you know but actually you dontYou might think you know but actually you dont");	 
	gtk_label_set_line_wrap(GTK_LABEL(label), TRUE);
	
	gtk_container_add(GTK_CONTAINER(fixed), label);	  
	gtk_fixed_move (GTK_FIXED(fixed), label, 100, 100);
	gtk_container_add(GTK_CONTAINER(window), fixed);   
	
	gtk_widget_show_all(fixed);
	gtk_widget_show(window);
	gtk_main();
	
	return 0;
	#endif

	#if 0
	gtk_init(&argc, &argv);   

	GtkWidget *window;	  
	GtkWidget* fixed;
	GtkWidget* label_timer;
	GtkWidget* label;
	GtkWidget* label2;

	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);	
	gtk_window_set_default_size(GTK_WINDOW(window), 200, 200);    
	fixed = gtk_fixed_new();
	gtk_widget_set_size_request(fixed, 200, 200);
	
	//label = gtk_label_new("");
	label2 = gtk_label_new("You might think you know but actually you dontYou might think you know but actually you dontYou might think you know but actually you dont");
	//label_timer = gtk_label_new("");
	//frame = gtk_frame_new("frame");	

	gtk_label_set_line_wrap(GTK_LABEL(label2), TRUE);
	
	//gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label));
	gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label2));
	//gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label_timer));
	
  	//gtk_fixed_move (GTK_FIXED(fixed), label, 20, 50);
	gtk_fixed_move (GTK_FIXED(fixed), label2, 20, 120);
	//gtk_fixed_move (GTK_FIXED(fixed), label_timer, 80, 50);

	gtk_container_add(GTK_CONTAINER(window), fixed);   
	gtk_widget_show_all(fixed);
	gtk_widget_show(window);
	gtk_main();
	#endif
	
    #if 1
	//if(XInitThreads () == 0)
	//	printf(" XInitThreads err\n");
	
	//if(!g_thread_supported()) 
	//	g_thread_init(NULL);
	//gdk_threads_init();
	
	gtk_init(&argc, &argv);
	
	GtkWidget* window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	//gtk_window_set_default_size(GTK_WINDOW(window),
	//							100,
	//							126);

	gtk_window_set_resizable(window, TRUE);
	
	gtk_window_move(window, 0 , 126 + 126 + 126);
	//GtkWidget* fixed = gtk_fixed_new();
	//GtkWidget* fixed2 = gtk_fixed_new();
	GtkWidget* fixed;
	fixed = creat_prompter_gtkarea(200, 126);
	
	gtk_container_add(GTK_CONTAINER(window), GTK_WIDGET(fixed));
	
	int ret = 0;
	//gtk_builder_connect_signals(builder, NULL);
	//gtk_widget_show_all(window);
	gtk_widget_show(window);
	
	ret = pthread_create(&change_thread,
						  NULL,
						  simulate_change_state,
						  NULL);
    if(ret != 0)
	{
		printf("Create  %d fail\n", ret);
		return -1;
	}
	else
		printf("suc\n");
	
	//gdk_threads_enter();
	gtk_main();
	//gdk_threads_leave();
    
    return 0;
	#endif
}

