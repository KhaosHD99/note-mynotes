#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
//#include <prompterapi.h>
#include <pthread.h>
#include <PrompterGui.h>

pthread_t change_thread;

void* simulate_change_state(void *p_data)
{
    int i = 0;
    int state[8];
	//char msg[] = "info1"; 
	char msg[] = "中文"; 

	const char INFO[8][128] = 
	{
		"PP_ON_HOOK",
		"PP_OFF_HOOK",
		"PP_OFF_HOOK",
		"PP_CONNECT",
		"PP_UNCATCH_PHONE_MESSAGE",
		"PP_UNCATCH_SMS_MESSAGE",
		"PP_UNCATCH_EMAIL_MESSAGE",
		"PP_OTHER_MESSAGE"
	};
	//msg[0] = "info1";
	//msg[1] = "info2";
	//const char *msg2 = "info2";
	
	state[0] = PP_ON_HOOK;
	state[1] = PP_OFF_HOOK;
	state[2] = PP_OFF_HOOK;
	state[3] = PP_CONNECT;
    state[4] = PP_UNCATCH_PHONE_MESSAGE;
    state[5] = PP_UNCATCH_SMS_MESSAGE;
	state[6] = PP_UNCATCH_EMAIL_MESSAGE;
	state[7] = PP_OTHER_MESSAGE;
	
    while(1)
    {
		usleep(1000 * 1000);
		//printf("%s\n", __FUNCTION__);
		if(i == 8)
			i = 0;
		
		//gdk_threads_enter();
		//pthread_mutex_lock(&mutex);
		StatePrompterInfo state_info;
		state_info.state = state[i];

		//if(
		strcpy(state_info.message, INFO[i]);

		
		update_prompter_info(&state_info);
		//printf("Get State: %d\n", get_prompter_state()); 
        //phoneState = state[i];
        
		i++;
		//gdk_threads_leave();		
		//pthread_mutex_unlock(&mutex);
		//sem_post(&timeSem);
	}
}

int main(int argc, char *argv[])
{
	//if(XInitThreads () == 0)
	//	printf(" XInitThreads err\n");
	
	//if(!g_thread_supported()) 
	//	g_thread_init(NULL);
	//gdk_threads_init();
	
	gtk_init(&argc, &argv);
	
	GtkWidget* window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_default_size(GTK_WINDOW(window),
								200,
								126);
	gtk_window_set_resizable(window, TRUE);
	
	gtk_window_move(window, 0 , 126 + 126 + 126);
	GtkWidget* fixed = gtk_fixed_new();
	GtkWidget* fixed2 = gtk_fixed_new();
	fixed2 = creat_prompter_gtkarea(100, 100);
	
	gtk_container_add(GTK_CONTAINER(window), GTK_WIDGET(fixed2));
	
	#if 0
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, "prompter.glade", NULL);
	window_container = GTK_WIDGET(gtk_builder_get_object(builder, "window_container"));
	
	//window_standby = GTK_WIDGET(gtk_builder_get_object(builder, "window_standby"));
	//fix_standby = GTK_WIDGET(gtk_builder_get_object(builder, "fixed_prompter"));

	GtkWidget *parent = gtk_widget_get_parent(fix_standby);
	
	gtk_container_remove(GTK_CONTAINER(parent), GTK_WIDGET(fix_standby));
	
	//label_date = GTK_WIDGET(gtk_builder_get_object(builder, "label_date"));
	//label_week = GTK_WIDGET(gtk_builder_get_object(builder, "label_week"));
	//label_time = GTK_WIDGET(gtk_builder_get_object(builder, "label_time"));
	
    gtk_container_add(GTK_CONTAINER(window_container), GTK_WIDGET(fix_standby));
	//gtk_container_add(GTK_CONTAINER(window_container), GTK_WIDGET(fix));
    //window = GTK_WIDGET(gtk_builder_get_object(builder, "window_missed_call"));
	
	//button = GTK_WIDGET(gtk_builder_get_object(builder, "label_date"));
	//gtk_window_move(GTK_WINDOW(window), 200, 0);
	//window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	
	//darea = gtk_drawing_area_new ();
	//gtk_container_add (GTK_CONTAINER (window), darea);
	
	//image = cairo_image_surface_create_from_png ("img/image_1_2.jpg");
	#endif
	
	int ret = 0;
	//gtk_builder_connect_signals(builder, NULL);
	//gtk_widget_show_all(window);
	gtk_widget_show(window);
	
	ret = pthread_create(&change_thread,
						  NULL,
						  simulate_change_state,
						  NULL);
    if(ret != 0)
	{
		printf("Create  %d fail\n", ret);
		return -1;
	}
	else
		printf("suc\n");
	
	//gdk_threads_enter();
	gtk_main();
	//gdk_threads_leave();
    
    return 0;
}

