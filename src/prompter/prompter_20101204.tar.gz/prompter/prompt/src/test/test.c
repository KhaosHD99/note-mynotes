#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
//#include <prompterapi.h>
#include <pthread.h>
#include <PrompterGui.h>

pthread_t change_thread;

void* simulate_change_state(void *p_data)
{
    int i = 0;
    int state[8];
	//char msg[] = "info1"; 
	char msg[] = "中文"; 

	const char INFO[8][128] = 
	{
		"PP_ON_HOOKxxxxxxxxxxxxxxxxx",
		"PP_OFF_HOOKxxxxxxxxxxxxxx",
		"PP_OFF_HOOKxxxxxxxxxxxxxx",
		"PP_CONNECTxxxxxxxxxxxxxxxxxxx",
		"PP_UNCATCH_PHONE_MESSAGExxxxxxxxxxxxxxxxx",
		"PP_UNCATCH_SMS_MESSAGExxxxxxxxxxx",
		"PP_UNCATCH_EMAIL_MESSAGExxxxxxxxx",
		"PP_OTHER_MESSAGExxxxxxxxxxxxx"
	};
	//msg[0] = "info1";
	//msg[1] = "info2";
	//const char *msg2 = "info2";
	#if 0
	state[0] = PP_ON_HOOK;
	state[1] = PP_OFF_HOOK;
	state[2] = PP_OFF_HOOK;
	state[3] = PP_CONNECT;
    state[4] = PP_UNCATCH_PHONE_MESSAGE;
    state[5] = PP_UNCATCH_SMS_MESSAGE;
	state[6] = PP_UNCATCH_EMAIL_MESSAGE;
	state[7] = PP_OTHER_MESSAGE;
    #endif

	#if 1
	state[0] = PP_OFF_HOOK;
	state[1] = PP_OFF_HOOK;
	state[2] = PP_OFF_HOOK;
	state[3] = PP_OFF_HOOK;
    state[4] = PP_OFF_HOOK;
    state[5] = PP_OFF_HOOK;
	state[6] = PP_OFF_HOOK;
	state[7] = PP_OFF_HOOK;
	#endif
	
    while(1)
    {
		usleep(2000 * 1000);
		//printf("%s\n", __FUNCTION__);
		if(i == 8)
			i = 0;
		
		//gdk_threads_enter();
		//pthread_mutex_lock(&mutex);
		StatePrompterInfo state_info;
		state_info.state = state[i];

		//if(
		strcpy(state_info.message, INFO[i]);

		
		update_prompter_info(&state_info);

		if(i == 2)
			usleep(1000000 * 1000);
		
		//printf("Get State: %d\n", get_prompter_state()); 
        //phoneState = state[i];
        
		i++;
		//gdk_threads_leave();		
		//pthread_mutex_unlock(&mutex);
		//sem_post(&timeSem);
	}
}

int main(int argc, char *argv[])
{
    #if 1
	GtkWidget *window;	  
	GtkWidget *vbox;	  
	GtkWidget *frame;    
	GtkWidget *label;	
	GtkWidget *fixed;	
	gtk_init(&argc, &argv);   
	window = gtk_window_new(GTK_WINDOW_TOPLEVEL);	
	gtk_window_set_title(GTK_WINDOW(window), "GtkLabel");	 
	gtk_window_set_default_size(GTK_WINDOW(window), 400, 400);    
	vbox = gtk_vbox_new(FALSE, 5);	 frame = gtk_frame_new("���Θ�ӛ");    
	/*label = gtk_label_new(NULL);    
	gtk_label_set_markup(GTK_LABEL(label),		 
		"<span foreground='blue' size='x-large'>�����W���Pӛ</span>");	 
	gtk_container_add(GTK_CONTAINER(frame), label);	
	gtk_box_pack_start(GTK_BOX(vbox), frame, FALSE, FALSE, 0);	  
	frame = gtk_frame_new("����");	
	label = gtk_label_new("�����W���Pӛ\ncaterpillar.onlyfun.net\n" \ 		   
						  "Gossip@caterpillar");	 
	gtk_container_add(GTK_CONTAINER(frame), label);	
	gtk_box_pack_start(GTK_BOX(vbox), frame, FALSE, FALSE, 0);	  
	frame = gtk_frame_new("�ԄӓQ��");	
	label = gtk_label_new("You might think you know but actually you don't. " \ 
		"You might think you know but actually you don't. " \
		"You might think you know but actually you don't. " \
		"You might think you know but actually you don't.");
	gtk_label_set_line_wrap(GTK_LABEL(label), TRUE);    
	gtk_container_add(GTK_CONTAINER(frame), label);	  
	gtk_box_pack_start(GTK_BOX(vbox), frame, FALSE, FALSE, 0);	
	frame = gtk_frame_new("���Ҍ��R");	  
	label = gtk_label_new("�����W���Pӛ\ncaterpillar.onlyfun.net\n" \		
		"Gossip@caterpillar");	  
	gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_RIGHT);	
	gtk_container_add(GTK_CONTAINER(frame), label);	
	gtk_box_pack_start(GTK_BOX(vbox), frame, FALSE, FALSE, 0);	
	*/
	fixed = gtk_fixed_new();
	frame = gtk_frame_new("�ԄӓQ�С����Ҍ��R");	  
	label = gtk_label_new("You might think you know but actually you dontYou might think you know but actually you dontYou might think you know but actually you dont");	 
	gtk_label_set_line_wrap(GTK_LABEL(label), TRUE);	 
	//gtk_label_set_justify(GTK_LABEL(label), GTK_JUSTIFY_FILL);   
	gtk_container_add(GTK_CONTAINER(fixed), label);	  
	//gtk_box_pack_start(GTK_BOX(vbox), frame, FALSE, FALSE, 0);	
	//gtk_container_add(GTK_CONTAINER(window), frame);   
	gtk_container_add(GTK_CONTAINER(window), fixed);   
	g_signal_connect(GTK_OBJECT(window), "destroy",					   
		G_CALLBACK(gtk_main_quit), NULL);	 
	gtk_widget_show_all(window);
	gtk_main();	
	return 0;
	#endif

    #if 0
	//if(XInitThreads () == 0)
	//	printf(" XInitThreads err\n");
	
	//if(!g_thread_supported()) 
	//	g_thread_init(NULL);
	//gdk_threads_init();
	
	gtk_init(&argc, &argv);
	
	GtkWidget* window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	gtk_window_set_default_size(GTK_WINDOW(window),
								200,
								126);
	gtk_window_set_resizable(window, TRUE);
	
	gtk_window_move(window, 0 , 126 + 126 + 126);
	GtkWidget* fixed = gtk_fixed_new();
	GtkWidget* fixed2 = gtk_fixed_new();
	fixed2 = creat_prompter_gtkarea(100, 100);
	
	gtk_container_add(GTK_CONTAINER(window), GTK_WIDGET(fixed2));
	
	int ret = 0;
	//gtk_builder_connect_signals(builder, NULL);
	//gtk_widget_show_all(window);
	gtk_widget_show(window);
	
	ret = pthread_create(&change_thread,
						  NULL,
						  simulate_change_state,
						  NULL);
    if(ret != 0)
	{
		printf("Create  %d fail\n", ret);
		return -1;
	}
	else
		printf("suc\n");
	
	//gdk_threads_enter();
	gtk_main();
	//gdk_threads_leave();
    
    return 0;
	#endif
}

