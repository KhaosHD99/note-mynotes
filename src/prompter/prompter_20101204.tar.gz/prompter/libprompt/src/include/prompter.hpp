/*
* Copyright 广州泛网视讯有限公司
* All rights reserved.
* 
* 文件名称：Play_act.hpp
* 
* 摘    要：对时间表的读取与分析
* 
* 作    者：吴耀泉
*
* 修改者:   徐镇杰
* 
* 最后修改日期：2010年11月10日
*/
#ifndef _PROMPTER_HPP_
#define _PROMPTER_HPP_

#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include "LogMsg.hpp"
#include "PrompterGui.h"

#define STATE_COUNT 8

#define UNCATCH_TYPE_COUNT 4
#define PRO_MSG_MAX_COUNT 32
#define PRO_MSG_MAX_LEN 128
#define PRO_MSG_END_TIME 3

//position
#define LABEL_POSITION_X 20
#define LABEL_POSITION_Y 15
#define LABEL2_POSITION_X  20
#define LABEL2_POSITION_Y  50
#define LABEL_TIMER_POSITION_X  130
#define LABEL_TIMER_POSITION_Y  15

typedef struct UnCatchMsgInfo
{
	int pos;
	int end_time;
	char **uncatch_msg;
}UnCatchMsgInfo;

class PrompterManager
{
	public:
		ST_PP cur_pp_state;
	
	public:	
		int run_sign;
		pthread_mutex_t mutex;
    	static PrompterManager *instance;
		GtkWidget* fixed;
		GtkWidget* label_timer;
		GtkWidget* label;
		GtkWidget* label2;
		int timer;

		UnCatchMsgInfo **uncatch_msg_info;
	private:
		PrompterManager();
		~PrompterManager();
		void init();
		void uninit();

        int change_widget_by_state(ST_PP state, const char *info);
		
		int add_uncatch_phone_msg(const char *msg);
		int add_uncatch_sms_msg(const char *msg);
		int add_uncatch_email_msg(const char *msg);
		int add_uncatch_other_msg(const char *msg);
		
		int hide_all_widget();
		
	public:
		static PrompterManager *get_instance();
		
		GtkWidget* creat_prompter_gtkarea(unsigned int width, unsigned int hight);
		int update_prompter_info(ST_PP states, const char*info);
		ST_PP get_prompter_state();
		int get_prompter_stateinfo(StatePrompterInfo *stateinfo);
};

#endif

