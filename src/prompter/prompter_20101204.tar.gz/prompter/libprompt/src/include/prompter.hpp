/*
* Copyright 广州泛网视讯有限公司
* All rights reserved.
* 
* 文件名称：Play_act.hpp
* 
* 摘    要：对时间表的读取与分析
* 
* 作    者：吴耀泉
*
* 修改者:   徐镇杰
* 
* 最后修改日期：2010年11月10日
*/
#ifndef _PROMPTER_HPP_
#define _PROMPTER_HPP_

#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include "LogMsg.hpp"
#include "PrompterGui.h"

//#include <sys/time.h>
//#include <semaphore.h>

#define STATE_COUNT 8
#define MAX_WIDGET 3
#define MESSAGE_MAX_LEN	64
#define MAX_MSG_COUNT 3

class PrompterManager
{	
	public:
		ST_PP phone_state;

	public:	
		int run_sign;
		pthread_mutex_t mutex;
    	static PrompterManager *instance;
		GtkWidget* fixed;
		GtkWidget* label_timer;
		GtkWidget* label;
		GtkWidget* label2;
		int timer;

		char **uncatch_phone_msg;
		char **uncatch_msm_msg;
		char **uncatch_email_msg;
		char **uncatch_other_msg;
	private:
		PrompterManager();
		~PrompterManager();
		void init();
		void uninit();

        //static gboolean refresh_loop(void *p_data);

        int change_widget_by_state(ST_PP state, const char *info);

		int add_uncatch_phone_msg(const char *msg);
		int add_uncatch_msm_msg(const char *msg);
		int add_uncatch_email_msg(const char *msg);
		int add_uncatch_other_msg(const char *msg);
		
		int hide_all_widget();
		
	public:
		static PrompterManager *get_instance();
		
		GtkWidget* creat_prompter_gtkarea(unsigned int width, unsigned int hight);
		
		int update_prompter_info(ST_PP states, const char*info);
		
		ST_PP get_prompter_state();
		
		int get_prompter_stateinfo(StatePrompterInfo *stateinfo);
		
};

#endif

