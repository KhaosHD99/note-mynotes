#include <stdio.h>
#include <gtk/gtk.h>

GtkBuilder *builder;
GtkWidget *window;
GtkWidget *button;

void on_button1_clicked(GtkWidget *window, gpointer user_data)
{
	printf("%s\n", __FUNCTION__);
	gtk_widget_set_visible(button, FALSE);
}


int main(int argc, char *argv[])
{
	gtk_init(&argc, &argv);
	
	//GtkWidget *window;
	//GtkWidget *button;
	
	builder = gtk_builder_new();
	gtk_builder_add_from_file (builder, "prompter.glade", NULL);
	window = GTK_WIDGET(gtk_builder_get_object(builder, "window1"));
	button = GTK_WIDGET(gtk_builder_get_object(builder, "button1"));
	gtk_window_move(GTK_WINDOW(window), 200, 0);
	//window = gtk_window_new (GTK_WINDOW_TOPLEVEL);
	
	//darea = gtk_drawing_area_new ();
	//gtk_container_add (GTK_CONTAINER (window), darea);
	
	//image = cairo_image_surface_create_from_png ("img/image_1_2.jpg");
    
	gtk_builder_connect_signals(builder, NULL);
	gtk_widget_show(window);
    gtk_main();
    
    return 0;
}

