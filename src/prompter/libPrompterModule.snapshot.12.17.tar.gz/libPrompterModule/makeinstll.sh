cp src/lib/libpromptermodule.la src/lib/.libs/libpromptermodule.lai

echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
echo "交叉编译安装时，程序或库将会安装在/opt/nfs/home上, 在模板板上将48:/opt/nfs/home/usr/Fn 挂载至/usr/Fn"
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
make install DESTDIR=/opt/nfs/home
