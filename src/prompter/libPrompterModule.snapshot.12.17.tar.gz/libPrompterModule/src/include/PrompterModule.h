#ifndef PROMPTER_MODULE_DEF
#define PROMPTER_MODULE_DEF

#include <stdio.h>
#include "CodeConvert.hpp"
#include "LogMsg.hpp"
#include "CCST.hpp"
#include "Vial.hpp"
#include "VialType_Common.hpp"
#include "VialType_PhoneIntf.hpp"
#include "AbstractModule.hpp"
/********************************************************************
											�绰(����)��ʾ����
	��ģ����Ҫ��ʾ�绰(���������š����硢��ͨ)״̬����ʾ��Ϣ��
*********************************************************************/
class PrompterModule : public AbstractModule
{
#define __CLASS__ "PrompterModule"
#define VIAL_PHONECODE_LEN	32
	struct
	{
		int nPhoneMode;
		int nCallType;
		int nCodelen;
		char cPhoneCode[VIAL_PHONECODE_LEN];
	}PhoneCode;

	
	CCST::ST curstate, oldstate;
	

	private:
		VialSystem *vialSys;
		static PrompterModule *prompterModule_instance;
	public:
		void run();
	 	static PrompterModule *get_instance(VialSystem *vialSys);
		virtual bool localInit();
		virtual bool onExit();
		virtual bool OnReceive(Vial *vial);

		bool SendPhoneFreehand();
		
		bool SendPhoneDail(const char* phoneNum);
		
		bool is_right_state(CCST::ST st);
		bool is_standby();
		bool is_callin();
		bool is_callout();
	protected:
		bool onVialStateChang(StateChangeVial *vial);

		bool onVialDialNotify(DialNotifyVial *vial);
		bool onVialCallerPhoneCode(CallerPhoneCodeVial *vial);

	private:
		PrompterModule(VialSystem *vialSys);
		virtual ~PrompterModule(){};
		bool onOnHook(Vial *vial);
		bool onDialing(Vial *vial);
		bool onRinging(Vial *vial);
		bool onNoVideoConn(Vial *vial);
		bool onVideoConn(Vial *vial);
		
};
#endif
