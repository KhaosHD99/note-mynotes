#include "PrompterModule.h"
#include "PrompterGui.h"
#include "CCST.hpp"

/********************************************************************************
                                      get instance
********************************************************************************/
PrompterModule* PrompterModule::prompterModule_instance = NULL;
PrompterModule *PrompterModule::get_instance(VialSystem *vialSys)
{
	if(vialSys == NULL)
	{
		showWarning("vialSys null, creat prompter module failed!\r\n");
		return NULL;	
	}

	if(!prompterModule_instance)
			prompterModule_instance = new PrompterModule(vialSys);

	return prompterModule_instance;
}

/**************************************************************
**PrompterModule
**(�绰״̬)��ʾģ��
**
**************************************************************/
PrompterModule::PrompterModule(VialSystem *vialSys)
: AbstractModule(vialSys)
{
	this->vialSys = vialSys;
}

/**************************************************************
**run
**����runѭ��
**
**************************************************************/
void PrompterModule::run()
{
	vialSys->run();
}

/**************************************************************
**localInit
**ģ���ڲ���ʼ��
**�ú�����init()����
**************************************************************/
bool PrompterModule::localInit()
{
	showInfo("%s localInit\n", __CLASS__);
	return true;
}

/**************************************************************
**onExit
**����״̬�ı���Ϣ
**�ڲ����д���״̬
**************************************************************/
bool PrompterModule::onExit()
{
	showInfo("%s onExit\n", __CLASS__);
	return false;
}

/**************************************************************
1.	����  			[ON_HOOK, NON_PHONE] 				: StateChangeVial
2.	ժ��  			[OFF_HOOK, V_PHONE] 				: StateChangeVial
3.	��������		[OFF_HOOK, V_PHONE, ����] 	: StateDailVial
4.	����״̬		[RRINGING�� V_PHONE]				: StateChangeVial
5.	����״̬		[NOVIDEO_CONN�� V_PHONE]		: StateChangeVial

6. �������			[RINGING, V_PHONE, ����]		: CallerIDVial 
7. �һ�					[ON_HOOK, NON_PHONE]				: StateChangeVial
8. ��ͨ..  			[VIDEO_CONN, NON_PHONE]			: StateChangeVial
**************************************************************/
bool PrompterModule::OnReceive(Vial *vial)
{
	if (AbstractModule::OnReceive(vial))
	{
		showInfo("%s onReceive , return true\n", __CLASS__);
		return true;
	}
	switch (vial->vialType)
	{
		case GETVT(StateChangeVial):		
			return onVialStateChang((StateChangeVial *)vial);			//1/2/4/5/7/8
		case GETVT(DialNotifyVial):
			return onVialDialNotify((DialNotifyVial *)vial);				//3
		case GETVT(CallerPhoneCodeVial):
			return onVialCallerPhoneCode((CallerPhoneCodeVial *)vial);
	}
	return false;
}
/**************************************************************
**onVialStateChang
**����״̬�ı���Ϣ
**�ڲ����д���״̬
**************************************************************/
bool PrompterModule::onVialStateChang(StateChangeVial *vial)
{
	if(vial == NULL)
		return false;
	else
	{
		printf("Hello World %d!\n", vial->curState.st);//CCST.ST::OFF_HOOK);

		switch(vial->curState.st)
		{
			case CCST::ON_HOOK:				//������Ϣ���һ���Ӧ��״̬
				return onOnHook(vial);
			case CCST::OFF_HOOK:
				return onOffHook(vial);
			case CCST::RINGING:
				return onRinging(vial);
			case CCST::NOVIDEO_CONN:
				return onNoVideoConn(vial);
			case CCST::VIDEO_CONN:
				return onVideoConn(vial);
			default:
				showWarning("%s::%s, not on_hook state, stateVal : %d\n", __CLASS__, __FUNCTION__, vial->curState);
				return false;			
		}	
	}
}

/**************************************************************
**onOnHook
**������Ϣ���һ���Ӧ��״̬
**�ڲ����д���״̬
**************************************************************/
bool PrompterModule::onOnHook(Vial *vial)
{
	if(vial == NULL)
		return false;
	StateChangeVial *stateChangVial = (StateChangeVial*)vial;	
	
	if(stateChangVial->curState.st != CCST::ON_HOOK)
	{
		showWarning("%s::%s, not on_hook state, stateVal : %d\n", __CLASS__, __FUNCTION__, stateChangVial->curState);
		return false;
	}
	
	PhoneCode.nCallType = 0;
	PhoneCode.nCodelen = 0;
	memset(PhoneCode.cPhoneCode, 0, sizeof(PhoneCode.cPhoneCode));

	showWarning("%s::%s\n", __CLASS__, __FUNCTION__);

	StatePrompterInfo stateinfo;
	memset(&stateinfo, 0, sizeof(stateinfo));
	stateinfo.state = PP_ON_HOOK;
	showInfo("update_prompter_info : %d, %s\r\n", stateinfo.state, stateinfo.message);
	update_prompter_info(&stateinfo);

	switch(stateChangVial->oldState.st)
	{
		case CCST::OFF_HOOK:					//��������
			showWarning("%s::%s, end of dail\n", __CLASS__, __FUNCTION__);
			return true;
		case CCST::RINGING:						//������������
			showWarning("%s::%s, end of ringing\n", __CLASS__, __FUNCTION__);
			return true;
		case CCST::NOVIDEO_CONN:			//�����������
			showWarning("%s::%s, end of recv a call\n", __CLASS__, __FUNCTION__);
			return true;
		case CCST::VIDEO_CONN:				//������Ƶ��ͨ(����������)
			showWarning("%s::%s, end of a vphone\n", __CLASS__, __FUNCTION__);
			return true;
		default:
			showWarning("%s::%s, not on_hook state, unprocess oldstate : %d\n", __CLASS__, __FUNCTION__, stateChangVial->oldState);
			return false;
	}
}

/**************************************************************
**onOffHook
**ժ��(����)��Ϣ
**�ڲ����д���״̬
**************************************************************/
bool PrompterModule::onOffHook(Vial *vial)
{
	if(vial == NULL)
		return false;
	StateChangeVial *stateChangVial = (StateChangeVial*)vial;	
	
	if(stateChangVial->curState.st != CCST::OFF_HOOK)
	{
		showWarning("%s::%s, not off_hook state, stateVal : %d\n", __CLASS__, __FUNCTION__, stateChangVial->curState);
		return false;
	}
	
	PhoneCode.nCallType = 1;
	PhoneCode.nCodelen = 0;
	memset(PhoneCode.cPhoneCode, 0, sizeof(PhoneCode.cPhoneCode));

	StatePrompterInfo stateinfo;
	memset(&stateinfo, 0, sizeof(stateinfo));
	stateinfo.state = PP_OFF_HOOK;
	showInfo("update_prompter_info : %d, %s\r\n", stateinfo.state, stateinfo.message);
	update_prompter_info(&stateinfo);

	showWarning("%s::%s\n", __CLASS__, __FUNCTION__);
	switch(stateChangVial->oldState.st)
	{
		case CCST::ON_HOOK:					//������ժ��
			showWarning("%s::%s, start to call out\n", __CLASS__, __FUNCTION__);
			return true;
		default:
			showWarning("%s::%s, not off_hook state, unprocess oldstate : %d\n", __CLASS__, __FUNCTION__, stateChangVial->oldState);
			return false;
	}
}

/**************************************************************
**onRinging
**������Ϣ
**�ڲ����д���״̬
**************************************************************/
bool PrompterModule::onRinging(Vial *vial)
{
	if(vial == NULL)
		return false;
	StateChangeVial *stateChangVial = (StateChangeVial*)vial;	
	
	PhoneCode.nCallType = 0;
	PhoneCode.nCodelen = 0;
	memset(PhoneCode.cPhoneCode, 0, sizeof(PhoneCode.cPhoneCode));

	if(stateChangVial->curState.st != CCST::RINGING)
	{
		showWarning("%s::%s, not ringing state, stateVal : %d\n", __CLASS__, __FUNCTION__, stateChangVial->curState.st);
		return false;
	}
	
	showWarning("%s::%s\n", __CLASS__, __FUNCTION__);

	StatePrompterInfo stateinfo;
	memset(&stateinfo, 0, sizeof(stateinfo));
	
	stateinfo.state = PP_RINGING;
	update_prompter_info(&stateinfo);

	switch(stateChangVial->oldState.st)
	{
		case CCST::ON_HOOK:					//����������
			showWarning("%s::%s, start to call in ringing\n", __CLASS__, __FUNCTION__);
			return true;
		default:
			showWarning("%s::%s, not ringing state, unprocess oldstate : %d\n", __CLASS__, __FUNCTION__, stateChangVial->oldState.st);
			return false;
	}
}

/**************************************************************
**onNoVideoConn
**(����)������Ϣ
**�ڲ����д���״̬
**************************************************************/
bool PrompterModule::onNoVideoConn(Vial *vial)
{
	if(vial == NULL)
		return false;
	StateChangeVial *stateChangVial = (StateChangeVial*)vial;	
	
	if(stateChangVial->curState.st != CCST::NOVIDEO_CONN)
	{
		showWarning("%s::%s, not novideo_conn state, stateVal : %d\n", __CLASS__, __FUNCTION__, stateChangVial->curState.st);
		return false;
	}
	
	StatePrompterInfo stateinfo;
	memset(&stateinfo, 0, sizeof(stateinfo));

	stateinfo.state = PP_CONNECT;
	strncpy(stateinfo.message, PhoneCode.cPhoneCode, PhoneCode.nCodelen);
	stateinfo.message[PhoneCode.nCodelen]= '\0';
	showInfo("update_prompter_info : %d, %s\r\n", stateinfo.state, stateinfo.message);
	update_prompter_info(&stateinfo);

	showWarning("%s::%s\n", __CLASS__, __FUNCTION__);
	switch(stateChangVial->oldState.st)
	{
		case CCST::RINGING:					//�����嵽ժ������
			showWarning("%s::%s, start to catch a callin\n", __CLASS__, __FUNCTION__);
			return true;
		default:
			showWarning("%s::%s, not novideo_conn state, unprocess oldstate : %d\n", __CLASS__, __FUNCTION__, stateChangVial->oldState.st);
			return false;
	}
}

/**************************************************************
**onVideoConn
**������Ƶ��ͨ��Ϣ
**�ڲ����д���״̬
**************************************************************/
bool PrompterModule::onVideoConn(Vial *vial)
{
	if(vial == NULL)
		return false;
	StateChangeVial *stateChangVial = (StateChangeVial*)vial;	
	
	if(stateChangVial->curState.st != CCST::VIDEO_CONN)
	{
		showWarning("%s::%s, not video_conn state, stateVal : %d\n", __CLASS__, __FUNCTION__, stateChangVial->curState.st);
		return false;
	}
	
	showWarning("%s::%s\n", __CLASS__, __FUNCTION__);
/*
	//������ʾ
	StatePrompterInfo stateinfo;
	stateinfo.state = PP_CONNECT;
	memset(&stateinfo, 0, sizeof(stateinfo));
	strncpy(stateinfo.message, PhoneCode.cPhoneCode, PhoneCode.nCodelen);
	stateinfo.message[PhoneCode.nCodelen]= '\0';
	update_prompter_info(&stateinfo);
*/
	
	switch(stateChangVial->oldState.st)
	{
		case CCST::OFF_HOOK:							//���н�����Ƶ��ͨ
			showWarning("%s::%s, start from callout to vphone\n", __CLASS__, __FUNCTION__);
			return true;
		case CCST::NOVIDEO_CONN:					//���н���������Ƶ��ͨ
			showWarning("%s::%s, start from catch callin to vphone\n", __CLASS__, __FUNCTION__);
			return true;
		default:
			showWarning("%s::%s, not novideo_conn state, unprocess oldstate : %d\n", __CLASS__, __FUNCTION__, stateChangVial->oldState.st);
			return false;
	}
}

/**************************************************************
**onVialStateDail
**������Ϣ
**���ҽ�����һ״̬ΪOFF_HOOKʱ�����յ�������Ϣ
**************************************************************/
bool PrompterModule::onVialDialNotify(DialNotifyVial *vial)
{
	if(vial)
	{
		PhoneCode.cPhoneCode[PhoneCode.nCodelen] = vial->code;
		PhoneCode.nCodelen++;
		PhoneCode.cPhoneCode[PhoneCode.nCodelen]= '\0';	
		showWarning("%s::%s, phoneCode : %d -> %s\n", __CLASS__, __FUNCTION__, vial->code-'0', PhoneCode.cPhoneCode);

		StatePrompterInfo stateinfo;
		memset(&stateinfo, 0, sizeof(stateinfo));

		stateinfo.state = PP_OFF_HOOK;
		strncpy(stateinfo.message, PhoneCode.cPhoneCode, PhoneCode.nCodelen);
		stateinfo.message[PhoneCode.nCodelen]= '\0';
		showInfo("update_prompter_info : %d, %s\r\n", stateinfo.state, stateinfo.message);
		update_prompter_info(&stateinfo);
		
	}
	else
		showWarning("%s::%s, vial null\n", __CLASS__, __FUNCTION__);
	
	return true;	
}

/**************************************************************
**onVialCallerID
**���������Ϣ
**���ҽ�����һ״̬ΪRINGRINGʱ�����յ����������Ϣ
**************************************************************/
bool PrompterModule::onVialCallerPhoneCode(CallerPhoneCodeVial *vial)
{
	if(vial)
	{
		showWarning("%s::%s\n", __CLASS__, __FUNCTION__);
		PhoneCode.nCallType = 0;
		strncpy(PhoneCode.cPhoneCode, vial->cPhoneCode, vial->nLen);
		PhoneCode.nCodelen = vial->nLen;
		PhoneCode.cPhoneCode[PhoneCode.nCodelen]= '\0';	

		StatePrompterInfo stateinfo;
		memset(&stateinfo, 0, sizeof(stateinfo));

		stateinfo.state = PP_RINGING;
		strncpy(stateinfo.message, vial->cPhoneCode, vial->nLen);
		stateinfo.message[vial->nLen]= '\0';
		showInfo("update_prompter_info : %d, %s\r\n", stateinfo.state, stateinfo.message);
		update_prompter_info(&stateinfo);

		showWarning("%s::%s, phoneCode : %s\n", __CLASS__, __FUNCTION__, PhoneCode.cPhoneCode);

		
	}
	else
		showWarning("%s::%s, vial null\n", __CLASS__, __FUNCTION__);
	
	return true;
}
