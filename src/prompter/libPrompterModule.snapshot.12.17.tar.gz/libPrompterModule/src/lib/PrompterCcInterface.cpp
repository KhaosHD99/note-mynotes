#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include "PrompterModule.h"
#include "ModuleID.hpp"
#include "CCST.hpp"

static VialSystem *pVialSys = NULL;
/**************************************************************
**thread_promptermodule
**(�绰״̬)��ʾģ�������߳�
**
**************************************************************/
static void *thread_promptermodule(void *data)
{
	//��ʹ���Լ���module id

	pVialSys = new VialSystem(FN_PROMPTER_MODULE_ID);
	if(pVialSys)
	{
		PrompterModule *prompter = PrompterModule::get_instance(pVialSys);	
		if(prompter)
		{
			prompter->init();
			prompter->run();
		}
		else
			return NULL;
	}
	else
	{
		printf("creat prompter module null\r\n");
		return NULL;
	}
}

/**************************************************************
**creat_and_run_prompter_module
**����(�绰״̬)��ʾģ�������߳�
**
**************************************************************/
#ifdef __cplusplus
extern"C"
#endif
int creat_and_run_prompter_module()
{
//	���̣߳�
	pthread_t promptermodule_thread;

	if(pthread_create(&promptermodule_thread, NULL, thread_promptermodule, NULL) == 0)
	{
		printf("thread create Ok, promptermodule thread start \n");
		return 0;
	}
	else
	{
		printf("thread promptermodule create Err\n");
		return -1;
	}
}

/**************************************************************
**send_phone_freehand
**��绰ģ�鷢��������Ϣ
**
**************************************************************/
#ifdef __cplusplus
extern"C"
#endif
int send_phone_freehand()
{
	if(pVialSys)
	{
		PrompterModule *prompter = PrompterModule::get_instance(pVialSys);	
		
		if(prompter)
		{
			if(prompter->SendPhoneFreehand())
				return 0;
			else
				return -1;
		}
		else
		{
			printf("prompter module null, send phone freehand failed!\r\n");
			return -1;
		}
	}
	else
	{
		printf("prompter module vialsys null, send phone freehand failed!\r\n");
		return -1;
	}
}

/**************************************************************
**send_phone_dail
**��绰ģ�鷢�Ͳ�����Ϣ
**
**************************************************************/
#ifdef __cplusplus
extern"C"
#endif
int send_phone_dail(const char* phoneNum)
{
	if(pVialSys)
	{
		PrompterModule *prompter = PrompterModule::get_instance(pVialSys);	
		
		if(prompter)
		{
			if(prompter->SendPhoneDail(phoneNum))
				return 0;
			else
				return -1;
		}
		else
		{
			printf("prompter module null, send phone dail failed!\r\n");
			return -1;
		}
	}
	else
	{
		printf("prompter module vialsys null, send phone dail failed!\r\n");
		return -1;
	}
}

/**************************************************************
**is_standby
**��ѯ�Ƿ��ڴ�����
**1 true, 0 false
**************************************************************/
#ifdef __cplusplus
	extern"C"
#endif
int is_standby()
{
	if(pVialSys)
	{
		PrompterModule *prompter = PrompterModule::get_instance(pVialSys);	
		
		if(prompter)
		{
			if(prompter->is_standby())
				return 1;
			else
				return 0;
		}
		else
		{
			printf("prompter module null, check stand by failed!\r\n");
			return 0;
		}
	}
	else
	{
		printf("prompter module vialsys null, check stand by failed!\r\n");
		return 0;
	}

}
/**************************************************************
**is_callout
**��ѯ�Ƿ��ں�����
**1 true, 0 false
**************************************************************/
#ifdef __cplusplus
		extern"C"
#endif
int is_callout()
{
	if(pVialSys)
	{
		PrompterModule *prompter = PrompterModule::get_instance(pVialSys);	
		
		if(prompter)
		{
			if(prompter->is_callout())
				return 1;
			else
				return 0;
		}
		else
		{
			printf("prompter module null, check call out failed!\r\n");
			return 0;
		}
	}
	else
	{
		printf("prompter module vialsys null, check call out failed!\r\n");
		return 0;
	}
}

/**************************************************************
**is_callin
**��ѯ�Ƿ��ں�����
**1 true, 0 false
**************************************************************/
#ifdef __cplusplus
		extern"C"
#endif
int is_callin()
{
	if(pVialSys)
	{
		PrompterModule *prompter = PrompterModule::get_instance(pVialSys);	
		
		if(prompter)
		{
			if(prompter->is_callin())
				return 1;
			else
				return 0;
		}
		else
		{
			printf("prompter module null, check call in failed!\r\n");
			return 0;
		}
	}
	else
	{
		printf("prompter module vialsys null, check call in failed!\r\n");
		return 0;
	}

}

