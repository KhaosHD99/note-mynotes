#include <stdio.h>
#include <stdlib.h>
#include "PrompterCcInterface.h"

int update_prompter_info(StatePrompterInfo *stateinfo)
{
	printf("on update_prompter_info function\r\n");
	return 0;
}

int set_window_top()
{
	printf("on set_window_top function\r\n");
	return 0;
}

int send_phone_dail(const char* phoneNum);

int main(int argc, char* argv[])
{
	int ret = creat_and_run_prompter_module();
	if(ret != 0)
	{
	  printf("run prompter module error : %d....\r\n", ret);
	}
	else
		printf("run prompter module scuess....\r\n");
	send_phone_dail("13480236013");
	sleep(10);
	printf("send_phone_dail--------------------------\r\n");
	while(1)
	{
		sleep(1);
		if(is_callin())
			printf("------------------is callin\r\n");
		if(is_callout())
			printf("------------------is callout\r\n");
		if(is_standby())
			printf("------------------is standby\r\n");
		printf("wait for exit!\r\n");
	}
	return 0;	
}
