/*
* Copyright 广州泛网视讯有限公司
* All rights reserved.
* 
* 文件名称：Play_act.hpp
* 
* 摘    要：对时间表的读取与分析
* 
* 作    者：吴耀泉
*
* 修改者:   徐镇杰
* 
* 最后修改日期：2010年11月10日
*/
#ifndef _PROMPTER_HPP_
#define _PROMPTER_HPP_

#include <stdio.h>
#include <pthread.h>
#include <string.h>
#include <unistd.h>
#include <gtk/gtk.h>

//#include <sys/time.h>
//#include <semaphore.h>

#include "LogMsg.hpp"
#include "PrompterGui.h"

#define STATE_COUNT 8
#define MAX_WIDGET 3
#define MESSAGE_MAX_LEN	64

#if 0
typedef enum ST_PP
{
	PP_ON_HOOK,	//待机	 + (时间)
	PP_OFF_HOOK,	//拨号... + (计时) + 号码
	PP_RINGING,	//来电... + (计时) + 号码
	PP_CONNECT,	//通话中... + (计时) + 号码
	PP_UNCATCH_PHONE_MESSAGE,	//未接来电 + 号码
	PP_UNCATCH_SMS_MESSAGE,		//为查看短信  + 号码
	PP_UNCATCH_EMAIL_MESSAGE,	//未查看邮件  + 邮箱
	PP_OTHER_MESSAGE	// 邮箱
}ST_PP;

typedef struct StatePrompterInfo
{
	ST_PP state;
	char message[MESSAGE_MAX_LEN];
}StatePrompterInfo;
#endif
//gboolean refresh_loop(void *p_data);

class PrompterManager
{	
	public:
		ST_PP phone_state;

	public:	
		int run_sign;
		
    static PrompterManager *instance;
		
		GtkWidget* fixed;
		GtkWidget* label_timer;
		GtkWidget* label;
		GtkWidget* label2;

		int timer;
		
	private:
		PrompterManager();
		~PrompterManager();
		void init();
		void uninit();

        //static gboolean refresh_loop(void *p_data);

        int change_widget_by_state(ST_PP state, const char *info);
		
		int hide_all_widget();
		
	public:
		static PrompterManager *get_instance();
		
		GtkWidget* creat_prompter_gtkarea(unsigned int width, unsigned int hight);
		
		int update_prompter_info(ST_PP states, const char*info);
		
		ST_PP get_prompter_state();
		
		int get_prompter_stateinfo(StatePrompterInfo *stateinfo);
		
};

#endif

