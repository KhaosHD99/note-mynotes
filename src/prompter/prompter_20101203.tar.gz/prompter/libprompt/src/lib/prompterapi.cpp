#include <string.h>
#include <stdio.h>
//#include <time.h>
#include "prompter.hpp"

#ifdef __cplusplus
extern "C" 
{
#endif

/**************************************************************************************************/
/**************************************** prompter ***************************************************/
/**************************************************************************************************/

/*t get_contact_count()
{
	CContactManager *manager = CContactManager::get_instance();
   
    return manager->get_contact_count();
}

int get_contact_by_index(Contact *contact,	int index)
{
	CContactManager *manager = CContactManager::get_instance();
    
    return manager->get_contact_by_index(contact, index);
}*/

GtkWidget* creat_prompter_gtkarea()
{
	PrompterManager *manager = PrompterManager::get_instance();
    
    return manager->creat_prompter_gtkarea();
}

int update_prompter_info(ST_PP states, const char*info)
{
	PrompterManager *manager = PrompterManager::get_instance();
    
    return manager->update_prompter_info(states, info);
}

ST_PP get_prompter_state()
{
	
}

#ifdef __cplusplus
}
#endif

