#include <stdio.h>
#include <string.h>
#include <prompter.hpp>

#define RUN_FLAG 0
#define RUN_FLAG2 0
#define FORMAT "<span foreground='red'  font_desc='13'>%s</span>"
PrompterManager::PrompterManager()
{
	init();
}

PrompterManager::~PrompterManager()
{
	
}

void PrompterManager::init()
{	
	phone_state = (ST_PP)-1;
	timer = 0;
}

void PrompterManager::uninit()
{	
	
}

/* ************************************************************************************************
				                           			       Single Instance
**************************************************************************************************/
PrompterManager* PrompterManager::instance = NULL;
PrompterManager* PrompterManager::get_instance()
{
	if(!instance)
		instance = new PrompterManager;
	
	return instance;
}

char *get_date()
{
	struct tm *local;
	time_t t;
	char year[8];
	char mon[8];
	char day[8];
	char *date = new char[128];
	 
	t = time(NULL);
	local = localtime(&t);

	sprintf(date, "%d年%d月%d日", local->tm_year + 1900,
						 			 local->tm_mon + 1,
						 		 	 local->tm_mday,
						 			 local->tm_hour,
						 			 local->tm_min,
						 			 local->tm_sec);
	
	return date;
}

char *get_time()
{
	struct tm *local;
	time_t t;
	char hour[8];
	char min[8];
	char sec[8];
	
	t = time(NULL);
	local = localtime(&t);
	
	char *time = new char[128];
	sprintf(time, "%d: %d: %d", local->tm_hour,
								local->tm_min,
								local->tm_sec);
	
	return time;
}

static gboolean refresh_loop(void *p_data)
{
	printf("%s\n", __FUNCTION__);
	char *markup;

	PrompterManager *manager = PrompterManager::get_instance();
	if(manager->phone_state == PP_OFF_HOOK ||
		manager->phone_state == PP_CONNECT) 
	{
		printf("%s get in\n", __FUNCTION__);
		char timer_str[16];
		
		manager->timer++;
		sprintf(timer_str, "%d", manager->timer);
		
		markup = g_markup_printf_escaped (FORMAT, timer_str);
		gtk_label_set_markup(GTK_LABEL(manager->label_timer), markup);

		if(markup)
			delete(markup);
		//gtk_label_set_text((GtkLabel *)manager->label_timer, timer_str);
	}

	if(manager->phone_state == PP_ON_HOOK)
	{
		markup = g_markup_printf_escaped (FORMAT, get_date());
		gtk_label_set_markup(GTK_LABEL(manager->label), markup);

		markup = g_markup_printf_escaped (FORMAT, get_time());
		gtk_label_set_markup(GTK_LABEL(manager->label2), markup);

        if(markup)
			delete(markup);
	}
}

int PrompterManager::hide_all_widget()
{
	gtk_widget_hide(label);
	gtk_widget_hide(label2);
	gtk_widget_hide(label_timer);
}

int PrompterManager::change_widget_by_state(ST_PP state, const char *info)
{	
	printf("%s\n", __FUNCTION__);
	int i = 0;
	char *markup;
	
	if(state == PP_ON_HOOK)
  	{
      printf("change_widget_by_state ON_HOOK\n\n");
	  hide_all_widget();
			
	  markup = g_markup_printf_escaped (FORMAT, get_date());
      gtk_label_set_markup(GTK_LABEL(label), 
                           markup);
	  markup = g_markup_printf_escaped (FORMAT, get_time());
	  gtk_label_set_markup(GTK_LABEL(label2), 
                           markup);

	  if(markup)
		delete(markup);
	  
	  gtk_widget_show(label);
	  gtk_widget_show(label2);
	}
	else if(state == PP_RINGING)
	{
	 	printf("change_widget_by_state RINGING\n\n");

		hide_all_widget();
		markup = g_markup_printf_escaped (FORMAT, ST_PP_INFO[state]);
		gtk_label_set_markup(GTK_LABEL(label), markup);

		markup = g_markup_printf_escaped (FORMAT, info);
		gtk_label_set_markup(GTK_LABEL(label2), markup);

		if(markup)
		delete(markup);
		
		gtk_widget_show(label);
		gtk_widget_show(label2);
	}
	else if(state == PP_OFF_HOOK)
	{
		printf("change_widget_by_state OFF_HOOK\n\n");
		
		hide_all_widget();
		
		markup = g_markup_printf_escaped (FORMAT, ST_PP_INFO[state]);
		gtk_label_set_markup(GTK_LABEL(label), markup);
		
		char timer_str[16];
		timer = 0;
		sprintf(timer_str, "%d", timer);
		markup = g_markup_printf_escaped (FORMAT, timer_str);
		gtk_label_set_markup(GTK_LABEL(label2), markup);

		if(markup)
			delete(markup);
		
		gtk_widget_show(label);
		gtk_widget_show(label_timer);
	}
	else if(state == PP_CONNECT)
	{	
		printf("change_widget_by_state CONNECT\n\n");
		hide_all_widget();
		
		markup = g_markup_printf_escaped (FORMAT, ST_PP_INFO[state]);
		gtk_label_set_markup(GTK_LABEL(label), markup);
		//"<span foreground='red'  font_desc='13'>State</span>");
		
		char timer_str[16];
		timer = 0;
		
		sprintf(timer_str, "%d", timer);
		markup = g_markup_printf_escaped (FORMAT, timer_str);
		gtk_label_set_markup(GTK_LABEL(label_timer), markup);

		if(markup)
			delete(markup);
		
		gtk_widget_show(label);
		gtk_widget_show(label_timer);
	}
	else if(state == PP_UNCATCH_PHONE_MESSAGE)
	{
		printf("change_widget_by_state UNCATCH_PHONE_MESSAGE\n\n");
		hide_all_widget();
		
		markup = g_markup_printf_escaped (FORMAT, ST_PP_INFO[state]);
		gtk_label_set_markup(GTK_LABEL(label),  markup);

		markup = g_markup_printf_escaped (FORMAT, info);
		gtk_label_set_markup(GTK_LABEL(label2), markup);

		if(markup)
			delete(markup);

		gtk_widget_show(label);
		gtk_widget_show(label2);
	}
	else if(state == PP_UNCATCH_SMS_MESSAGE)
	{
		printf("change_widget_by_state UNCATCH_MSM_MESSAGE\n\n");
		hide_all_widget();
		
		markup = g_markup_printf_escaped (FORMAT, ST_PP_INFO[state]);
		gtk_label_set_markup(GTK_LABEL(label), markup);
	
		markup = g_markup_printf_escaped (FORMAT, info);
		gtk_label_set_markup(GTK_LABEL(label2), markup);

		if(markup)
			delete(markup);
		
		gtk_widget_show(label);
		gtk_widget_show(label2);
	}
	else if(state == PP_UNCATCH_EMAIL_MESSAGE)
	{
		printf("change_widget_by_state UNCATCH_EMAIL_MESSAGE\n\n");
		hide_all_widget();
		
		markup = g_markup_printf_escaped (FORMAT, ST_PP_INFO[state]);
		gtk_label_set_markup(GTK_LABEL(label), markup);

		markup = g_markup_printf_escaped (FORMAT, info);
		gtk_label_set_markup(GTK_LABEL(label2), markup);

		if(markup)
			delete(markup);
		
		gtk_widget_show(label);
		gtk_widget_show(label2);
	}
	else if(state == PP_OTHER_MESSAGE)
	{
		printf("change_widget_by_state OTHER_MESSAGE\n\n");
		hide_all_widget();
		
		markup = g_markup_printf_escaped (FORMAT, "Other MSG");
		gtk_label_set_markup(GTK_LABEL(label), markup);

		markup = g_markup_printf_escaped (FORMAT, info);
		gtk_label_set_markup(GTK_LABEL(label2), markup);

		if(markup)
			delete(markup);
		
		gtk_widget_show(label);
		gtk_widget_show(label2);
	}
	else
	{
		printf("type error \n");
	}
}

GtkWidget* PrompterManager::creat_prompter_gtkarea(unsigned int width, unsigned int hight)
{   
	printf("%s\n", __FUNCTION__);

	GtkRequisition require;
	require.width = width;
	require.height = hight;
	
	fixed = gtk_fixed_new();
	gtk_widget_size_request(fixed, &require);
	
	label = gtk_label_new("");
	label2 = gtk_label_new("");
	label_timer = gtk_label_new("");
	
	gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label));
	gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label2));
	gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label_timer));
	
  	gtk_fixed_move (GTK_FIXED(fixed), label, 20, 15);
	gtk_fixed_move (GTK_FIXED(fixed), label2, 20, 50);
	gtk_fixed_move (GTK_FIXED(fixed), label_timer, 120, 50);
	
	gtk_widget_show_all(fixed);
	
	update_prompter_info(PP_ON_HOOK, "init");
		
	gtk_timeout_add (1000, refresh_loop, NULL);
	
	//printf("go after timeout\n");
	/*
	ret = pthread_create(&change_thread,
											  NULL,
											  simulate_change_state,
						  					NULL);
  if(ret != 0)
	{
		printf("Create  %d fail\n", ret);
		return -1;
	}
	else
		printf("suc\n");*/
	
	return fixed;
}

int PrompterManager::update_prompter_info(ST_PP state, const char *info)
{	
	if(state == phone_state)
		return -1;
	
	printf("%s\n", __FUNCTION__);
	
	//phone_state_dirty = phone_state;
	phone_state = state;
	//gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label_date));
	//gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label_time));
	//gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label_week));
	
	//gtk_widget_show_all(fixed);
	//GtkWidget *label_date2;
	//label_date2 = (GtkWidget *)g_object_ref (label_date);
	//gtk_label_set_text((GtkLabel *)label_date, "elon2");
	//printf("l2: %s\n", gtk_label_get_text((GtkLabel *)label_date2));
	//g_object_ref (label_date);
	//if(gtk_widget_get_parent(label_date))
	//	printf("lb is not NULL\n");
	//else
	//	printf("lb is NULL\n");
	//gtk_container_remove(GTK_CONTAINER(fixed), label_date);

	
	//gtk_box_pack_start (GTK_BOX(fixed), label_date, FALSE, FALSE, 3);
	
	//gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label_date));
	//gtk_fixed_move (GTK_FIXED(fixed), label_date, 30, 15);
	//gtk_fixed_move (GTK_FIXED(fixed), label_time, 30, 50);
	//gtk_fixed_move (GTK_FIXED(fixed), label_week, 100, 50);*/
	
	//gtk_container_remove(GTK_CONTAINER(fixed), label_date);
	//gtk_container_add(GTK_CONTAINER(fixed), GTK_WIDGET(label_state));

    #if 0
	if(-1 != phone_state)
		remove_widget_by_state(phone_state);
	add_widget_by_state(state);
	
	phone_state = state;
	#endif
	
	change_widget_by_state(phone_state, info);
}

ST_PP PrompterManager::get_prompter_state()
{
	printf("%s state: %d\n", __FUNCTION__, phone_state);
	return phone_state;
}

int PrompterManager::get_prompter_stateinfo(StatePrompterInfo *stateinfo)
{
	if(!stateinfo)
		return -1;
	
	stateinfo->state = phone_state;
  return 0;
}

void on_button1_clicked(GtkWidget *window, gpointer user_data)
{
	printf("%s\n", __FUNCTION__);
	//gtk_widget_set_visible(button, FALSE);
}

#if 0
int PrompterManager::hide_widget_by_state(ST_PP state)
{
    printf("%s\n", __FUNCTION__);

	int i = 0;
	if(state == ON_HOOK)
    {
        printf("hide_widget_by_state ON_HOOK\n");
		#if RUN_FLAG
		while(state_widget[state]->widget[i])
		{
			gtk_widget_hide(state_widget[state]->widget[i]);
			i++;
		}
		#endif
		#if RUN_FLAG2
        gtk_widget_hide(label_date);
		gtk_widget_hide(label_week);
		gtk_widget_hide(label_time);
		#endif
	}
	else if(state == RINGING)
	{
	    printf("hide_widget_by_state RINGING\n");
		#if RUN_FLAG
		while(state_widget[state]->widget[i])
		{
			gtk_widget_hide(state_widget[state]->widget[i]);
			i++;
		}
		#endif
		#if RUN_FLAG2
		gtk_widget_hide(label_state);
		gtk_widget_hide(label_contact);
		#endif
	}
	else if(state == OFF_HOOK)
	{
	    printf("hide_widget_by_state OFF_HOOK\n");
		#if RUN_FLAG
		while(state_widget[state]->widget[i])
		{
			gtk_widget_hide(state_widget[state]->widget[i]);
			i++;
		}
		#endif
		#if RUN_FLAG2
		gtk_widget_hide(label_state);
		gtk_widget_hide(label_timer);
		#endif
	}
	else if(state == CONNECT)
	{	
		printf("hide_widget_by_state CONNECT\n");

		#if RUN_FLAG
		while(state_widget[state]->widget[i])
		{
			gtk_widget_hide(state_widget[state]->widget[i]);
			i++;
		}
		#endif

		#if RUN_FLAG2
		gtk_widget_hide(label_state);
		gtk_widget_hide(label_timer);
		#endif
	}
	else if(state == UNCATCH_PHONE_MESSAGE)
	{
		
	}
	else if(state == UNCATCH_MSM_MESSAGE)
	{
		
	}
	else if(state == UNCATCH_EMAIL_MESSAGE)
	{
		
	}
	else if(state == OTHER_MESSAGE)
	{
		
	}
	else
	{
		printf("type error \n");
	}
}


int PrompterManager::add_widget_by_state(ST_PP state)
{
    #if 1
	if(state == ON_HOOK)
    {
        printf("add ON_HOOK\n\n");
		if(label_date)
    		gtk_container_add(GTK_CONTAINER(fixed), label_date);
		else
			printf("label_date NULL");
		gtk_container_add(GTK_CONTAINER(fixed), label_week);
		gtk_container_add(GTK_CONTAINER(fixed), label_time);
		gtk_widget_show_all(fixed);

		gtk_fixed_move (GTK_FIXED(fixed), label_date, 30, 15);
		gtk_fixed_move (GTK_FIXED(fixed), label_week, 30, 50);
		gtk_fixed_move (GTK_FIXED(fixed), label_time, 100, 50);
	}
	else if(state == RINGING)
	{
	    printf("add RINGING\n\n");
		if(label_date)
		{
			printf("label_date not NULL\n");
			
			label_date = (GtkWidget *)g_object_ref (label_date);
			gtk_container_add(GTK_CONTAINER(fixed), label_date);
		}
		else
			printf("label_date NULL\n");
		gtk_container_add(GTK_CONTAINER(fixed), label_state);
		gtk_container_add(GTK_CONTAINER(fixed), label_contact);
		gtk_widget_show_all(fixed);

		gtk_fixed_move (GTK_FIXED(fixed), label_date, 30, 15);
		gtk_fixed_move (GTK_FIXED(fixed), label_state, 30, 15);
		gtk_fixed_move (GTK_FIXED(fixed), label_contact, 30, 50);
	}
	else if(state == OFF_HOOK)
	{
	    printf("add OFF_HOOK\n\n");
		gtk_container_add(GTK_CONTAINER(fixed), label_state);
		gtk_container_add(GTK_CONTAINER(fixed), label_timer);
		gtk_widget_show_all(fixed);

		gtk_fixed_move (GTK_FIXED(fixed), label_state, 30, 15);
		gtk_fixed_move (GTK_FIXED(fixed), label_timer, 30, 50);
	}
	else if(state == CONNECT)
	{
	    printf("add CONNECT\n\n");
		gtk_container_add(GTK_CONTAINER(fixed), label_state);
		gtk_container_add(GTK_CONTAINER(fixed), label_timer);
		gtk_widget_show_all(fixed);

		gtk_fixed_move (GTK_FIXED(fixed), label_state, 30, 15);
		gtk_fixed_move (GTK_FIXED(fixed), label_timer, 30, 50);
	}
	else if(state == UNCATCH_PHONE_MESSAGE)
	{
		
	}
	else if(state == UNCATCH_MSM_MESSAGE)
	{
		
	}
	else if(state == UNCATCH_EMAIL_MESSAGE)
	{
		
	}
	else if(state == OTHER_MESSAGE)
	{
	
	}
	else
	{
		printf("type error \n");
	}
	#endif
}

int PrompterManager::remove_widget_by_state(ST_PP state)
{
	if(state == ON_HOOK)
    {
        printf("remove ON_HOOK\n");
        if(gtk_widget_get_parent(label_date))
    		gtk_container_remove(GTK_CONTAINER(fixed), label_date);
		if(gtk_widget_get_parent(label_week))
			gtk_container_remove(GTK_CONTAINER(fixed), label_week);
		if(gtk_widget_get_parent(label_time))
			gtk_container_remove(GTK_CONTAINER(fixed), label_time);
	}
	else if(state == RINGING)
	{
	    printf("remove ON_HOOK\n");
		if(gtk_widget_get_parent(label_date))
			gtk_container_add(GTK_CONTAINER(fixed), label_date);
	    if(gtk_widget_get_parent(label_state))
			gtk_container_remove(GTK_CONTAINER(fixed), label_state);
		if(gtk_widget_get_parent(label_contact))
			gtk_container_remove(GTK_CONTAINER(fixed), label_contact);
	}
	else if(state == OFF_HOOK)
	{
	    printf("remove ON_HOOK\n");
		if(gtk_widget_get_parent(label_state))
			gtk_container_remove(GTK_CONTAINER(fixed), label_state);
		if(gtk_widget_get_parent(label_time))
			gtk_container_remove(GTK_CONTAINER(fixed), label_timer);
	}
	else if(state == CONNECT)
	{	
		printf("remove ON_HOOK\n");
		if(gtk_widget_get_parent(label_state))
			gtk_container_remove(GTK_CONTAINER(fixed), label_state);
		if(gtk_widget_get_parent(label_timer))
			gtk_container_remove(GTK_CONTAINER(fixed), label_timer);
	}
	else if(state == UNCATCH_PHONE_MESSAGE)
	{
		
	}
	else if(state == UNCATCH_MSM_MESSAGE)
	{
		
	}
	else if(state == UNCATCH_EMAIL_MESSAGE)
	{
		
	}
	else if(state == OTHER_MESSAGE)
	{
		
	}
	else
	{
		printf("type error \n");
	}
}
#endif

