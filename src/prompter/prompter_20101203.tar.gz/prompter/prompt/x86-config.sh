
export PRX="$HOME/opt/x86-usr"


export PKG_CONFIG_PATH=/usr/lib/pkgconfig/:/usr/share/pkgconfig:$PRX/lib/pkgconfig

./configure \
	--prefix=$PRX 



